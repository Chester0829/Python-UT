import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.select import Select
from enum import Enum
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions
import config.config as Config
from helper.log import MyLog
import pyautogui as pyg
from helper.common import Common


class BoxDriver(object):
    """
    private global param
    """
    _base_driver = None
    _by_char = None
    _log = None
    _headless = None

    @classmethod
    def get_current_driver(cls, browser_type=0, download_path=Config.DOWNLOAD_PATH, by_char=";"):
        """
        init the driver
        :param browser_type:
        :param by_char: seperator，default is","
        """
        if (cls._base_driver is not None):
            return cls._base_driver
        if browser_type == 0 or browser_type == Browser.Chrome:

            profile = webdriver.ChromeOptions()
            # profile.add_experimental_option("excludeSwitches", ["ignore-certificate-errors"])

            # download.default_directory：download path
            # profile.default_content_settings.popups：set 0 forbidden the popup
            prefs = {'profile.default_content_settings.popups': 0,
                     'download.default_directory': download_path}
            profile.add_experimental_option('prefs', prefs)
            if cls._headless == 'Y':
                profile.add_argument('--headless')
                profile.add_argument('--no-sandbox')

            driver = webdriver.Chrome(chrome_options=profile)
            # driver = webdriver.Chrome(executable_path='D:\\chromedriver.exe', chrome_options=options)


        elif browser_type == 1 or browser_type == Browser.Firefox:
            # if profile is not None:
            # profile = FirefoxProfile(profile)

            profile = webdriver.FirefoxProfile()
            # download path
            profile.set_preference('browser.download.dir', download_path)
            # 2: user defined download path; 0 desktop; 1 default downlaod path
            profile.set_preference('browser.download.folderList', 2)
            profile.set_preference('browser.download.manager.showWhenStarting', False)
            profile.set_preference('browser.helperApps.neverAsk.saveToDisk', 'application/zip')

            driver = webdriver.Firefox(firefox_profile=profile)

        elif browser_type == 2 or browser_type == Browser.Ie:
            driver = webdriver.Ie()
        else:
            driver = webdriver.PhantomJS()
        try:
            cls._base_driver = driver
            cls._by_char = by_char
            cls._log = MyLog.logger_with_file_and_console()  # init the log module
            cls._base_driver.maximize_window()
        except Exception as e:
            cls._log.error(e)
            raise NameError("Browser %s Not Found! " % browser_type)
        return cls._base_driver

    """
    private method
    """

    @classmethod
    def _convert_selector_to_locator(cls, selector):
        """
        convert  theselector to the selenium locator
        :param selector: string type ex:"i, xxx"
        :return: locator
        """
        if cls._by_char not in selector:
            cls._log.info('xpath: %s' % selector)
            return By.XPATH, selector

        selector_by = selector.split(cls._by_char)[0].strip()
        selector_value = selector.split(cls._by_char)[1].strip()
        if selector_by == "i" or selector_by == 'id':
            locator = (By.ID, selector_value)
            cls._log.info('id: %s' % selector_value)
        elif selector_by == "n" or selector_by == 'name':
            locator = (By.NAME, selector_value)
            cls._log.info('name: %s' % selector_value)
        elif selector_by == "c" or selector_by == 'class_name':
            locator = (By.CLASS_NAME, selector_value)
            cls._log.info('class_name: %s' % selector_value)
        elif selector_by == "l" or selector_by == 'link_text':
            locator = (By.LINK_TEXT, selector_value)
            cls._log.info('link_text: %s' % selector_value)
        elif selector_by == "p" or selector_by == 'partial_link_text':
            locator = (By.PARTIAL_LINK_TEXT, selector_value)
            cls._log.info('partial_link_text: %s' % selector_value)
        elif selector_by == "t" or selector_by == 'tag_name':
            locator = (By.TAG_NAME, selector_value)
            cls._log.info('tag_name: %s' % selector_value)
        elif selector_by == "x" or selector_by == 'xpath':
            locator = (By.XPATH, selector_value)
            cls._log.info('xpath: %s' % selector_value)
        elif selector_by == "s" or selector_by == 'css_selector':
            locator = (By.CSS_SELECTOR, selector_value)
            cls._log.info('css_selector: %s' % selector_value)
        else:
            cls._log.error('Please enter a valid selector of targeting elements.')
            raise NameError("Please enter a valid selector of targeting elements.")

        return locator

    @classmethod
    def _locate_element(cls, selector):
        """
        to locate element by selector
        :arg
        selector should be passed by an example with "i,xxx"
        "x,//*[@id='langs']/button"
        :returns
        DOM element
        """
        locator = cls._convert_selector_to_locator(selector)
        if locator is not None:
            element = cls._base_driver.find_element(*locator)
        else:
            cls._log.error("element not found.")
            raise NameError("Please enter a valid locator of targeting elements.")

        return element

    @classmethod
    def _locate_elements(cls, selector):
        """
        to locate element by selector
        :arg
        selector should be passed by an example with "i,xxx"
        "x,//*[@id='langs']/button"
        :returns
        DOM element
        """
        locator = cls._convert_selector_to_locator(selector)
        if locator is not None:
            elements = cls._base_driver.find_elements(*locator)
        else:
            cls._log.error("elements not found.")
            raise NameError("Please enter a valid locator of targeting elements.")

        return elements

    """
    browser itself
    """

    @classmethod
    def refresh(cls, url=None):
        """
        refresh page
        """
        if url is None:
            cls._base_driver.refresh()
        else:
            cls._base_driver.get(url)

    @classmethod
    def navigate(cls, url):
        """
        open URL
        """
        cls._base_driver.get(url)

    @classmethod
    def quit(cls):
        """
        quit driver
        """
        cls._base_driver.quit()
        cls._base_driver = None

    @classmethod
    def close_browser(cls):
        """
        close browser
        """
        cls._base_driver.close()

    """
    element operation
    """

    @classmethod
    def type(cls, selector, text):
        """
        Operation input box.
        """
        el = cls._locate_element(selector)
        el.clear()
        el.send_keys(text)

    @classmethod
    def click(cls, selector):
        """
        It can click any text / image can be clicked
        Connection, check box, radio buttons, and even drop-down box etc..
        """
        el = cls._locate_element(selector)
        el.click()

    @classmethod
    def click_eles_i(cls, selector, i):
        '''
        click the number i element
        :param selector:
        :param i: the index of element
        :return:
        '''
        eles = cls._locate_elements(selector)
        eles[i].click()

    @classmethod
    def click_by_enter(cls, selector):
        """
        It can type any text / image can be located  with ENTER key
        """
        el = cls._locate_element(selector)
        el.send_keys(Keys.ENTER)

    @classmethod
    def click_by_text(cls, text):
        """
        Click the element by the link text
        """
        cls._locate_element('p%s' % cls._by_char + text).click()

    @classmethod
    def move_to(cls, selector):
        """
        to move mouse pointer to selector
        :param selector:
        :return:
        """
        el = cls._locate_element(selector)
        ActionChains(cls._base_driver).move_to_element(el).perform()

    @classmethod
    def right_click(cls, selector):
        """
        right click
        :param selector:
        :return:
        """
        el = cls._locate_element(selector)
        ActionChains(cls._base_driver).context_click(el).perform()

    @classmethod
    def double_click(cls, selector):
        '''
        double click
        '''
        ele = cls._locate_element(selector)
        ActionChains(cls._base_driver).double_click(ele).perform()

    @classmethod
    def get_elements_count(cls, selector):
        """
        element counts
        """
        els = cls._locate_elements(selector)
        return len(els)

    @classmethod
    def drag_element(cls, source, target, ):
        """
        drag element
        :param source:
        :param target:
        :return:
        """
        cls._log.info('drag and drop element from %s to %s' % (source, target))
        el_source = cls._locate_element(source)
        el_target = cls._locate_element(target)
        if cls._base_driver.w3c:
            cls._log.info('w3c standard')
            ActionChains(cls._base_driver).drag_and_drop(el_source, el_target).perform()
        else:
            cls._log.info('not w3c standard')
            # ActionChains(cls._base_driver).click_and_hold(el_source).move_to_element(el_target).release(el_target).perform()
            ActionChains(cls._base_driver).click_and_hold(el_source).perform()
            ActionChains(cls._base_driver).move_to_element(el_target).perform()
            ActionChains(cls._base_driver).release(el_target).perform()

    @classmethod
    def drag_element_by_image(cls):
        target_img = 'master_full.png'
        cls._log.info('current resolution is ：' + str(pyg.size()))
        master = Common.get_file_path('./testdata', target_img, '/..')
        cls._log.info('target image path : %s' % master)
        target_position = pyg.locateOnScreen(master, confidence=0.6)
        step = 800  # the px count that drag from master to reference
        if target_position is None:  # can't find master_full.png
            cls._log.info('not find the image master_full.png')
            # try to find the master_part.png
            target_position = pyg.locateOnScreen(master.replace('_full', '_part'), grayscale=True)
            step = 700
        if target_position is not None:  # if can't find all target image
            x, y = pyg.center(target_position)
            cls._log.info('target image center position is: %d,%d' % (x, y))
            pyg.moveTo(x, y, 3)
            cls._log.info('choose the first row in master')
            pyg.moveRel(0, 55, 1)  # every row height is 26
            cls._log.info('drag to reference table')
            pyg.dragRel(step, 0, 2)
        else:  # use the absolute position to drag
            cls._log.info('not find the image master_part.png, maybe the resolution is different!!!')
            cls._log.info('try to drag with absolute position!!!')
            pyg.moveTo(500, 420, 3)
            pyg.dragRel(700, 0, 2)

    @classmethod
    def lost_focus(cls):

        ActionChains(cls._base_driver).key_down(Keys.TAB).key_up(Keys.TAB).perform()

    """
    <select> releted element
    """

    @classmethod
    def select_by_index(cls, selector, index=0):
        """
        It can click any text / image can be clicked
        Connection, check box, radio buttons, and even drop-down box etc..

        Usage:
        driver.select_by_index("i,el")
        """
        el = cls._locate_element(selector)
        Select(el).select_by_index(index)

    @classmethod
    def get_selected_text(cls, selector):
        """
        get text with selected item
        """
        el = cls._locate_element(selector)
        selected_opt = Select(el).first_selected_option
        return selected_opt.text

    @classmethod
    def get_all_option_values(cls, selector):
        """
        get text with selected item
        """
        el = cls._locate_element(selector)
        return [x.text for x in Select(el).options]

    @classmethod
    def select_by_visible_text(cls, selector, text):
        """
        It can click any text / image can be clicked
        Connection, check box, radio buttons, and even drop-down box etc..

        Usage:
        driver.select_by_index("i,el")
        """
        el = cls._locate_element(selector)
        Select(el).select_by_visible_text(text)

    @classmethod
    def select_by_value(cls, selector, value):
        """
        It can click any text / image can be clicked
        Connection, check box, radio buttons, and even drop-down box etc..

        Usage:
        driver.select_by_index("i,el")
        """
        el = cls._locate_element(selector)
        Select(el).select_by_value(value)

    """
    JavaScript related
    """

    @classmethod
    def execute_js(cls, script):
        """
        Execute JavaScript scripts.

        Usage:
        driver.js("window.scrollTo(200,1000);")
        """
        cls._base_driver.execute_script(script)

    """
    element attribute
    """

    @classmethod
    def get_value(cls, selector):
        """
        return element value
        """
        el = cls._locate_element(selector)
        return el.get_attribute("value")

    @classmethod
    def get_attribute(cls, selector, attribute):
        """
        Gets the value of an element attribute.

        Usage:
        driver.get_attribute("i,el","type")
        """
        el = cls._locate_element(selector)
        return el.get_attribute(attribute)

    @classmethod
    def get_attribute_list(cls, selector, attribute):
        """
        Gets the value of an element attribute.

        Usage:
        driver.get_attribute("i,el","type")
        """
        el = cls._locate_elements(selector)
        return [x.get_attribute(attribute) for x in el]

    @classmethod
    def get_text(cls, selector):
        """
        Get element text information.

        Usage:
        driver.get_text("i,el")
        """
        el = cls._locate_element(selector)
        return el.text

    @classmethod
    def get_text_list(cls, selector):
        """
        get the elements text
        :param selector:
        :return: list
        """

        el_list = cls._locate_elements(selector)

        results = []
        for el in el_list:
            results.append(el.text)

        return results

    @classmethod
    def get_displayed(cls, selector):
        """
        Gets the element to display,The return result is true or false.

        Usage:
        driver.get_display("i,el")
        """
        el = cls._locate_element(selector)
        return el.is_displayed()

    @classmethod
    def get_exist(cls, selector):
        '''
        judge element exist or not
        :param self:
        :param selector:
        :return: bool
        '''
        flag = True
        try:
            cls._locate_element(selector)
            return flag
        except:
            flag = False
            return flag

    @classmethod
    def get_enabled(cls, selector):

        if cls._locate_element(selector).is_enabled():
            return True
        else:
            return False

    @classmethod
    def get_title(cls):
        '''
        Get window title.

        Usage:
        driver.get_title()
        '''
        return cls._base_driver.title

    @classmethod
    def get_url(cls):
        """
        Get the URL address of the current page.

        Usage:
        driver.get_url()
        """
        return cls._base_driver.current_url

    @classmethod
    def get_selected(cls, selector):
        """
        to return the selected status of an WebElement
        :param selector: selector to locate
        :return: True False
        """
        el = cls._locate_element(selector)
        return el.is_selected()

    """
    browser alert
    """

    @classmethod
    def accept_alert(cls):
        '''
            Accept warning box.

            Usage:
            driver.accept_alert()
            '''
        cls._base_driver.switch_to.alert.accept()

    @classmethod
    def dismiss_alert(cls):
        '''
        Dismisses the alert available.

        Usage:
        driver.dismissAlert()
        '''
        cls._base_driver.switch_to.alert.dismiss()

    @classmethod
    def get_alert_text(cls):
        '''
        get alert text
        :return: String
        '''
        return cls._base_driver.switch_to.alert.text

    @classmethod
    def type_in_alert(cls, text):
        '''input in prompt popup'''
        cls._base_driver.switch_to.alert.send_keys(text)
        cls.forced_wait(1)

    '''
    frame operation
    '''

    @classmethod
    def switch_to_frame(cls, selector):
        """
        Switch to the specified frame.

        Usage:
        driver.switch_to_frame("i,el")
        """
        el = cls._locate_element(selector)
        cls._base_driver.switch_to.frame(el)

    @classmethod
    def switch_to_default(cls):
        """
        Returns the current form machine form at the next higher level.
        Corresponding relationship with switch_to_frame () method.

        Usage:
        driver.switch_to_frame_out()
        """
        cls._base_driver.switch_to.default_content()

    '''
    switch windows
    '''

    @classmethod
    def switch_to_window_by_title(cls, title):
        for handle in cls._base_driver.window_handles:
            cls._base_driver.switch_to.window(handle)
            if cls._base_driver.title == title:
                break

            cls._base_driver.switch_to.default_content()

    @classmethod
    def open_new_window(cls, selector):
        '''
        Open the new window and switch the handle to the newly opened window.

        Usage:
        driver.open_new_window()
        '''
        original_windows = cls._base_driver.current_window_handle
        el = cls._locate_element(selector)
        el.click()
        all_handles = cls._base_driver.window_handles
        for handle in all_handles:
            if handle != original_windows:
                cls._base_driver._switch_to.window(handle)

    @classmethod
    def save_window_snapshot(cls, file_name):
        """
        save screen snapshot
        :param file_name: the image file name and path
        :return:
        """
        driver = cls._base_driver
        driver.save_screenshot(file_name)

    @classmethod
    def save_window_snapshot_by_io(cls):
        """
        save as stream
        :return:
        """
        return cls._base_driver.get_screenshot_as_base64()

    @classmethod
    def save_element_snapshot_by_io(cls, selector):
        """
        control snapshot
        :param selector:
        :return:
        """
        el = cls._locate_element(selector)
        return el.screenshot_as_base64

    """
    wait method
    """

    @classmethod
    def forced_wait(cls, seconds=3):
        """
        sleep
        :param seconds:
        :return:
        """
        time.sleep(seconds)

    @classmethod
    def implicitly_wait(cls, seconds=Config.MAX_WAITING_TIME):
        """
        Implicitly wait. All elements on the page.
        :param seconds

        Usage:
        driver.implicitly_wait(10)
        """
        cls._base_driver.implicitly_wait(seconds)

    @classmethod
    def explicitly_wait_until(cls, selector, seconds=Config.MAX_WAITING_TIME):
        """
        explicitly_wait_until
        """
        locator = cls._convert_selector_to_locator(selector)

        WebDriverWait(cls._base_driver, seconds).until(expected_conditions.presence_of_element_located(locator))

    @classmethod
    def explicitly_wait_until_not(cls, selector, seconds=Config.MAX_WAITING_TIME):
        """
        explicitly_wait_until_not
        """
        locator = cls._convert_selector_to_locator(selector)

        WebDriverWait(cls._base_driver, seconds).until_not(expected_conditions.presence_of_element_located(locator))

    """
    table operation
    """

    @classmethod
    def get_row_count(cls, selector):
        el = cls._locate_elements(selector + '//tbody/tr')
        count = len(el)
        cls._log.info('table row count is %d' % count)
        return count

    @classmethod
    def get_column_count(cls, selector, header_index=1):
        el = cls._locate_elements(selector + '//thead/tr[' + header_index + ']/th')
        count = len(el)
        cls._log.info('table column count is %d' % count)
        return count

    @classmethod
    def table_convert_to_json(cls, selector):
        pass

    @classmethod
    def get_cell_value(cls, selector, row=1, column=4):
        el = cls._locate_element(selector + '//tbody/tr[' + str(row) + ']/td[' + str(column) + ']')
        value = el.text
        cls._log.info('row %s coulmn %s value is: %s' % (str(row), str(column), value))
        return value

    @classmethod
    def get_column_value_list(cls, selector, column=1):
        selector = selector + '//tbody/tr/td[' + str(column) + ']'
        value_list = cls.get_text_list(selector)
        return value_list


class Browser(Enum):
    Chrome = 0
    Firefox = 1
    Ie = 2


if __name__ == "__main__":
    driver = BoxDriver()
