'''
Created on May 20, 2019

@author: Chester
'''
import logging
import os
import time
from helper.common import Common


class MyLog():

    logger = None
    suffix = None

    @classmethod
    def logger_with_file_and_console(cls, filename=None, handler='both'):
        if cls.logger is not None:  # sigletone for logger
            return cls.logger
        cls.logger = logging.getLogger('mylogger')
        cls.logger.setLevel(logging.DEBUG)
        if filename is None:
            filename = 'log_' + Common.get_sufix_time_format() + '.log'
        logfilename = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../logs', filename)

        f_handler = logging.FileHandler(logfilename, encoding="utf-8")
        f_handler.setLevel(logging.DEBUG)
        f_handler.setFormatter(
            logging.Formatter("%(asctime)s - %(levelname)s - %(filename)s[:%(lineno)d] - %(message)s"))

        console_handle = logging.StreamHandler()
        console_handle.setLevel(logging.DEBUG)
        console_handle.setFormatter(
            logging.Formatter("%(asctime)s - %(levelname)s - %(filename)s[:%(lineno)d] - %(message)s"))
        if handler is 'file':
            cls.logger.addHandler(f_handler)
        elif handler is 'console':
            cls.logger.addHandler(console_handle)
        else:
            cls.logger.addHandler(f_handler)
            cls.logger.addHandler(console_handle)
        return cls.logger

    'sufix is build num'

    @classmethod
    def get_sufix_build_num(cls, suffix=None):
        if suffix is not None:  # for jenkins run ,build number
            cls.suffix = suffix
        if cls.suffix is None:
            cls.suffix = time.strftime('%Y%m%d_%H%M%S')
        return cls.suffix



if __name__ == '__main__':
    logger = MyLog.logger_with_file_and_console()
    logger.debug('this is a debug msg')
    logger.info('this is a info msg')
    logger.warning('this is a warning msg')
    logger.error('this is a error msg')
    ss = '126876uu3'
    try:
       is_int = int(ss)
    except:
        is_int=False
    if is_int:
        print('num is '+str(is_int))
    else:
        print(is_int)