import pymssql
import config.config as Config


class mssqlTool:
    def __init__(self, server=None, username=None, password=None, dbname=None):
        default_db_info = Config.DEFAULT_DB_INFO
        if server is None:
            server = default_db_info['server']
        if username is None:
            username = default_db_info['username']
        if password is None:
            password = default_db_info['password']
        if dbname is None:
            dbname = default_db_info['dbname']
        self.__server = server
        self.__username = username
        self.__password = password
        self.__dbname = dbname
        self.conn = None
        self.cursor = None

    def getCursor(self):
        if self.cursor != None:
            return self.cursor
            #self.cursor.close()
            #self.conn.close()
        conn = pymssql.connect(self.__server, self.__username, self.__password, self.__dbname);
        self.conn = conn
        self.cursor = conn.cursor()
        return self.cursor

    def closeCursor(self):
        if self.cursor != None:
            self.cursor.close()
            self.conn.close()
            self.cursor = None
            self.conn = None

    def commit(self):
        if self.cursor != None:
            self.conn.commit()

    def commitAndClose(self):
        if self.cursor != None:
            self.conn.commit()
            self.cursor.close()
            self.conn.close()
            self.cursor = None
            self.conn = None

    def fetchoneQuery(self, sql):
        cursor = self.getCursor()
        one_record = None
        if cursor:
            cursor.execute(sql)
            if cursor.rowcount != 0:
                one_record = cursor.fetchone()
            self.closeCursor()
        return one_record

    def execQuery(self, sql):
        cursor = self.getCursor()
        if cursor:
            cursor.execute(sql)
            result = cursor.fetchall()
            self.closeCursor()
            return result
        else:
            return None

    def batchExecQuery(self, sql):
        cursor = self.getCursor()
        if cursor:
            cursor.execute(sql)
            result = cursor.fetchall()
            return result
        else:
            return None

    def execNonQuery(self, sql):
        cursor = self.getCursor()
        if cursor:
            cursor.execute(sql)
            self.commitAndClose()


if __name__ == "__main__":
    db = mssqlTool('PTC-WBAFGDB311', 'ANALYTICS\chenc1', 'zhw#1FBVo1L', 'MA_PerfSingleSource')
    print(db.execQuery('select top 10 * from DimPool'))
    print('---------------')
    result = db.fetchoneQuery(" select top 10* from DimPool")
    print(result)
