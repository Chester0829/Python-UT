'''
Created on May 20, 2019

@author: Chester
'''
import logging
import os
import time
from selenium import webdriver
from selenium.webdriver.common.by import By


class Common():

    url = None
    @classmethod
    def get_sufix_time_format(cls, suffix=None):
        '''sufix is build num'''
        if suffix is None:
            suffix = time.strftime('%Y%m%d_%H%M%S')
        return suffix

    @classmethod
    def get_file_path(cls, folder, filename, basepath=None):
        if basepath is None:
            basepath = os.path.dirname(os.path.abspath(__file__))
        else:
            basepath = os.path.join(os.path.dirname(os.path.abspath(__file__)) + basepath)
        return os.path.join(basepath, folder, filename)



if __name__ == '__main__':
    browser = webdriver.Chrome()
    browser.get('http://www.baidu.com')
    browser.find_element_by_id("kw").send_keys("selenium")
    browser.maximize_window()
    print(browser.current_url)
    browser.find_element(By.XPATH, value="")
