#import win32com.client as win32
import smtplib
from email.mime.text import MIMEText

class Mail():

    '''
    FYI :https://www.jianshu.com/p/4f0ed762f521
    '''

    @classmethod
    def send_mail(cls):
        pass
        #outlook = win32.Dispatch('Outlook.Application')
        #mail_item = outlook.CreateItem(0)  # 0: olMailItem
        #mail_item.Recipients.Add('Chester.Chen@moodys.com')
        #mail_item.Subject = 'Mail Test'
        #mail_item.BodyFormat = 2  # 2: Html format
        #mail_item.HTMLBody = '''
        #    <H2>Hello, This is a test mail.</H2>
        #    Hello Guys.
        #    '''
        ##mail_item.Attachments.Add('<附件文件路径>')
        #mail_item.Send()

    @classmethod
    def smtp_send_email(cls):
        '''USERNAME = 'Chester.Chen@moodys.com'
        PASSWORD = 'zhw#1FBVo1L'
        mailserver = smtplib.SMTP('smtp.office365.com', 587)
        mailserver.ehlo()
        mailserver.starttls()
        mailserver.login(USERNAME, PASSWORD)
        mailserver.sendmail(USERNAME, USERNAME, 'python email')
        mailserver.quit()

        '''
        #mail_host = 'smtp.163.com'
        #mail_user = 'chenhaiyan_0829'
        #mail_pass = '43211234'
        #sender = 'chenhaiyan_0829@163.com'
        
        mail_host = 'smtp.office365.com'
        mail_user = 'Chester.Chen@moodys.com'
        mail_pass = 'zhw#1FBVo1L'
        sender = 'Chester.Chen@163.com'
        receivers = ['Chester.Chen@moodys.com']

        message = MIMEText('content', 'plain', 'utf-8')
        message['Subject'] = 'title'
        message['From'] = sender
        message['To'] = receivers[0]

        try:
            #smtpObj = smtplib.SMTP(mail_host)
            #smtpObj.set_debuglevel(1)

            #smtpObj = smtplib.SMTP_SSL(mail_host)
            #smtpObj.connect(mail_host, 587)
            smtpObj = smtplib.SMTP(mail_host, port=587)
            smtpObj.ehlo()
            smtpObj.starttls()
            smtpObj.set_debuglevel(1)
            smtpObj.login(mail_user, mail_pass)
            smtpObj.sendmail(sender, receivers[0], message.as_string())
            smtpObj.quit()
            print('success')
        except smtplib.SMTPException as e:
            print('error', e)



if __name__ == '__main__':
    #Mail.send_mail()
    Mail.smtp_send_email()