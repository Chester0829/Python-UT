import openpyxl
import os
from helper.log import MyLog
import config.config as Config
import time,json
from helper.common import Common
from helper.dbcommon import mssqlTool


class Excel(object):
    logger = MyLog.logger_with_file_and_console()  # init the log module
    with open(Config.SQL_QUERY_FILE) as f:
        sql_query_col = json.load(f)
    sql_helper = mssqlTool()

    @classmethod
    def get_work_book(cls, filePath):
        if os.path.exists(filePath):
            wb = openpyxl.load_workbook(filePath)
            return wb
        else:
            cls.logger.error('file not found: ' + format(filePath))
            raise FileNotFoundError("Browser %s Not Found! " % file_path)
            return None

    @classmethod
    def get_work_sheet(cls, filepath, sheet_name=None):
        wb = cls.get_work_book(filepath)
        if sheet_name is None:
            ws = wb.active
        else:
            ws = wb[sheet_name]
        return ws

    @classmethod
    def get_cell_value(cls, filepath, row_id, column_id, sheet_name=None):
        column_id = openpyxl.utils.get_column_letter(column_id)
        ws = cls.get_work_sheet(filepath, sheet_name)
        cell_value = ws[column_id + str(row_id)]
        return cell_value.value

    @classmethod
    def get_data_list(cls, file_path, sheet_name=None):
        total_list = []
        ws = cls.get_work_sheet(file_path, sheet_name)
        row_list = list(ws.rows)
        for row in row_list:
            row_list = []
            for cell in row:
                row_list.append(cell.value)
            total_list.append(row_list)
        return total_list

    '''
     # get all data except first row(header) and change to json
    '''
    @classmethod
    def get_data_to_json(cls, file_path, header_index=0, sheet_name=None):
        total_list = []
        ws = cls.get_work_sheet(file_path, sheet_name)
        row_list = list(ws.rows)
        for row in row_list:
            row_list = {}
            for cell in row:
                header_locate = cell.column + str(header_index + 1)
                key = ws[header_locate].value
                row_list[key] = cell.value
            total_list.append(row_list)
        return total_list[1:]

    '''
     # get the column value list, the first row default as header row
    '''

    @classmethod
    def get_column_value_list(cls, file_path, column_name, header_index=0, sheet_name=None):
        ws = cls.get_work_sheet(file_path, sheet_name)
        column_temp_list = list(ws.columns)
        for column in column_temp_list:
            if column[header_index].value == column_name:  # column header equal column_name
                return [c.value for c in column][1:]  # get the column value list except the column header
            else:
                cls.logger.error('column %s not exist in file %s' % (column_name, file_path))
                raise NameError('column %s not exist in file %s' % (column_name, file_path))

    '''
     # get row value list , default to get the first row
    '''

    @classmethod
    def get_row_value_list(cls, file_path, row_id=0, sheet_name=None):
        ws = cls.get_work_sheet(file_path, sheet_name)
        row_temp_list = list(ws.rows)
        return [r.value for r in row_temp_list[row_id]]

    '''
     # get value list of column Single Source id and Covered Types
    '''
    @classmethod
    def get_test_data_from_excel(cls, file_path, sheet_name=None):
        ws = cls.get_work_sheet(file_path, sheet_name)
        list_total = []
        for row_index in range(1,ws.max_row+1):
            single_source_id = str(ws['A'+str(row_index)].value).strip()
            covered_types_list = str(ws['B' + str(row_index)].value).split(',')
            for i in range(0,len(covered_types_list)):
                list_temp = [single_source_id,covered_types_list[i].strip()]
                list_total.append(list_temp)
        return list_total[1:]


    @classmethod
    def get_test_data_from_db(cls,):
        list_total = []
        sql = cls.sql_query_col["get_data_for_add_to_dim"]
        for key in sql:
            cls.logger.debug('get db data for key: '+key)
            pool_sql = cls.sql_query_col["get_data_for_add_to_dim"][key]
            for i in range(1,6):
                tmp_pool_sql = pool_sql.replace('__id__',str(i))
                result = cls.sql_helper.batchExecQuery(tmp_pool_sql)
                for x in range(0,len(result)):
                    temp_list = list(result[x])
                    temp_list.append(key+'+'+str(i))
                    list_total.append(temp_list)
        cls.sql_helper.closeCursor()  # close the DB connect
        cls.logger.debug(list_total)
        return list_total

    '''
    # the public method for get test data
    # default mode =1 get from DB, mode =2 ,get from Excel
    '''
    @classmethod
    def get_test_data(cls,mode=1,file_path=None, sheet_name=None):
        if mode == 1 :
            return cls.get_test_data_from_db()
        if mode == 2:
            if file_path == None:
                file_path=Config.TEST_DATA_FILE
            return cls.get_test_data_from_excel(file_path,sheet_name)
        else:
            cls.logger.error('only support get data from DB or Excel!!!')
            raise Exception('only support get data from DB or Excel!!!')

if __name__ == "__main__":
    from helper.common import Common
    import config.config as Config
    import sys

    str_split = 'Pools'
    item_id = None
    if '+' in str_split:
        temp_list = str_split.split('+')
        item_id = temp_list[1]
    print(item_id)
    Excel.get_test_data(1)
    Excel.get_test_data(2, Config.TEST_DATA_FILE, 'RefreshDimMapping')
    print(sys.argv)

    file_path = Common.get_file_path('./testdata', 'test_data.xlsx', '/..')
    # print(Excel.get_cell_value(file_path, 1, 1))
    # print(Excel.get_row_value_list(file_path))
    # print(Excel.get_column_value_list(file_path, 'Single Source Id'))
    # print('------------')
    # print(Excel.get_data_list(file_path))
    print(Excel.get_data_to_json(file_path))
    print(Excel.get_test_data_for_trust_edit(Config.TEST_DATA_FILE,'TrustEditAddToDim'))
    print(Excel.sql_query_col['get_data_for_add_to_dim'])