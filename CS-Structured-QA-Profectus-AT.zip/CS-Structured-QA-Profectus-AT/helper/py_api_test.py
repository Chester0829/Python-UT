import requests
import json,time


staging_server = 'https://api-g2-s.sfportal.com'
#staging_server = 'https://api.sfportal.com'
dev_server = 'http://10.32.160.45'
proxy = {
            "http": "http://wwwproxy.nslb.ad.moodys.net:80",
            "https": "https://wwwproxy.nslb.ad.moodys.net:80"}

loginJson = {"login":{"username":"SAVQA010","password":"SAVQA010"}}
r = requests.post(staging_server+ '/api/getLicense',json=loginJson,proxies=proxy)
# print r.text
token = json.loads(r.text)['token']
print (token)

header = {
	'x-auth-token' : token,
}

# tempJosn = {"widget":{"dataset":"CDO_PGIM","type":"filters","category":"general","module":"asset_manager","name":"U.S. Technicolor Report"},"index":"Collateral","type":"wso_fac,ald_assets","fxRates":{"asOfDate":"20200412","fxRates":"<FxRatesList><FxRatesContract><Currency>USD</Currency><FxRate>1</FxRate></FxRatesContract><FxRatesContract><Currency>SEK</Currency><FxRate>9.949803242640877</FxRate></FxRatesContract><FxRatesContract><Currency>NOK</Currency><FxRate>10.259699673967264</FxRate></FxRatesContract><FxRatesContract><Currency>JPY</Currency><FxRate>108.49000465313631</FxRate></FxRatesContract><FxRatesContract><Currency>HKD</Currency><FxRate>7.753398508401195</FxRate></FxRatesContract><FxRatesContract><Currency>GBP</Currency><FxRate>0.8026326350429408</FxRate></FxRatesContract><FxRatesContract><Currency>EUR</Currency><FxRate>0.9148293843198244</FxRate></FxRatesContract><FxRatesContract><Currency>DKK</Currency><FxRate>6.829402215594667</FxRate></FxRatesContract><FxRatesContract><Currency>CHF</Currency><FxRate>0.9663002778113299</FxRate></FxRatesContract><FxRatesContract><Currency>CAD</Currency><FxRate>1.3977000286947816</FxRate></FxRatesContract><FxRatesContract><Currency>AUD</Currency><FxRate>1.576789656259855</FxRate></FxRatesContract></FxRatesList>","fxRatesJSON":{"FxRatesList":{"FxRatesContract":[{"Currency":["USD"],"FxRate":["1"]},{"Currency":["SEK"],"FxRate":["9.949803242640877"]},{"Currency":["NOK"],"FxRate":["10.259699673967264"]},{"Currency":["JPY"],"FxRate":["108.49000465313631"]},{"Currency":["HKD"],"FxRate":["7.753398508401195"]},{"Currency":["GBP"],"FxRate":["0.8026326350429408"]},{"Currency":["EUR"],"FxRate":["0.9148293843198244"]},{"Currency":["DKK"],"FxRate":["6.829402215594667"]},{"Currency":["CHF"],"FxRate":["0.9663002778113299"]},{"Currency":["CAD"],"FxRate":["1.3977000286947816"]},{"Currency":["AUD"],"FxRate":["1.576789656259855"]}]}}}}
# r = requests.post(staging_server + '/api/getFieldMetaData', json = tempJosn, headers = header)
# print r.text

amDate = {
	'type': 'Liability',
	'fxRates': {
		"asOfDate": "20200412",
		"fxRates": "<FxRatesList><FxRatesContract><Currency>USD</Currency><FxRate>1</FxRate></FxRatesContract><FxRatesContract><Currency>SEK</Currency><FxRate>9.949803242640877</FxRate></FxRatesContract><FxRatesContract><Currency>NOK</Currency><FxRate>10.259699673967264</FxRate></FxRatesContract><FxRatesContract><Currency>JPY</Currency><FxRate>108.49000465313631</FxRate></FxRatesContract><FxRatesContract><Currency>HKD</Currency><FxRate>7.753398508401195</FxRate></FxRatesContract><FxRatesContract><Currency>GBP</Currency><FxRate>0.8026326350429408</FxRate></FxRatesContract><FxRatesContract><Currency>EUR</Currency><FxRate>0.9148293843198244</FxRate></FxRatesContract><FxRatesContract><Currency>DKK</Currency><FxRate>6.829402215594667</FxRate></FxRatesContract><FxRatesContract><Currency>CHF</Currency><FxRate>0.9663002778113299</FxRate></FxRatesContract><FxRatesContract><Currency>CAD</Currency><FxRate>1.3977000286947816</FxRate></FxRatesContract><FxRatesContract><Currency>AUD</Currency><FxRate>1.576789656259855</FxRate></FxRatesContract></FxRatesList>",
		"fxRatesJSON": {
			"FxRatesList": {
				"FxRatesContract": [
					{
						"Currency": [
							"USD"
						],
						"FxRate": [
							"1"
						]
					},
					{
						"Currency": [
							"SEK"
						],
						"FxRate": [
							"9.949803242640877"
						]
					},
					{
						"Currency": [
							"NOK"
						],
						"FxRate": [
							"10.259699673967264"
						]
					},
					{
						"Currency": [
							"JPY"
						],
						"FxRate": [
							"108.49000465313631"
						]
					},
					{
						"Currency": [
							"HKD"
						],
						"FxRate": [
							"7.753398508401195"
						]
					},
					{
						"Currency": [
							"GBP"
						],
						"FxRate": [
							"0.8026326350429408"
						]
					},
					{
						"Currency": [
							"EUR"
						],
						"FxRate": [
							"0.9148293843198244"
						]
					},
					{
						"Currency": [
							"DKK"
						],
						"FxRate": [
							"6.829402215594667"
						]
					},
					{
						"Currency": [
							"CHF"
						],
						"FxRate": [
							"0.9663002778113299"
						]
					},
					{
						"Currency": [
							"CAD"
						],
						"FxRate": [
							"1.3977000286947816"
						]
					},
					{
						"Currency": [
							"AUD"
						],
						"FxRate": [
							"1.576789656259855"
						]
					}
				]
			}
		}
	}
}

for i in range(10):
    time.sleep(120)
    r = requests.post(staging_server + '/api/getDefaultAMDateList', json = amDate, headers = header,proxies=proxy)
    print (i, '=========' ,json.loads(r.text))
