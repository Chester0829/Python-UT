from helper.common import Common
from pageobject.basepage import BasePage
from pageobject.login import Login
import time


class Trusts(BasePage):

    def __init__(self, ):
        """
        constructor
        """
        BasePage.__init__(self)
        # left ui control

        self.master_mapping_status_dropdown = 'name;ddlTrustMapOptions'
        self.left_source = '//div[contains(@class,"align-items-start")]//label[@class="form-check-label"]'
        self.left_paginator = '//p-table[@id="masterTable"]//p-paginator'
        self.master_table_column_input = '//p-table[@id="masterTable"]//table/tbody/tr/td[2]/input[@type="button"]'
        self.master_table_cell_i = '//p-table[@id="masterTable"]//table/tbody/tr[__row__]/td[__column__]//i'
        self.master_table_first_row_cell_3 = '//p-table[@id="masterTable"]//table/tbody/tr[1]/td[3]'
        self.right_click_menu_item='//p-contextmenusub/ul/li/a[contains(@class,"d-block")]//span[text()="__text__"]'
        self.popup_deal_docs_header='//div[@role="dialog"]/div[contains(@class,"ui-dialog-titlebar")]'
        self.popup_deal_docs_title=self.popup_deal_docs_header+'/span[@class="ui-dialog-title" and text()="Deal Docs - __text__"]'
        self.popup_deal_docs_close_btn = self.popup_deal_docs_header + '/a[contains(@class,"ui-dialog-titlebar-close")]'
        self.enable_button_in_validate_col='//input[@type="button" and @value = "__value__" and not(@disabled)]'
        self.disabled_button_in_validate_col = '//input[@type="button" and @value = "__value__" and @disabled]'
        self.delete_icon_enabled_in_dim_table = '//td/i[@class="fa fa-lg cursor fa-times"][1]'
        self.delete_icon_disabled_in_dim_table = '//td/i[@class="fa fa-lg cursor fa-times fa-disabled"][1]'

        # right ui control

        self.ref_mapping_status_dropdown = 'name;ddlSeriesMapOptions'
        self.right_source = '//div[contains(@class,"align-items-justify")]//label[@class="form-check-label"]'
        self.right_paginator = '//p-table[@id="referenceTable"]//p-paginator'

        # other ui control
        self.svg_path = '//*[contains(@id,"group__id__")]'
        self.svg_solid_line_path = '//*[contains(@id,"group__id__")]//*[not(@stroke-dasharray) and @stroke]'
        self.svg_dash_line_path = '//*[contains(@id,"group__id__")]//*[@stroke-dasharray and @stroke]'
        self.first_solid_line_parent = '(//*[contains(@id,"group")]//*[not(@stroke-dasharray) and @stroke])[1]/..'

        self.confirm_popup_msg = '//span[@class="ui-confirmdialog-message"]'
        self.confirm_popup_button = '//button/span[contains(text(),"__text__")]'

    def search(self, text, table='master', _column_name='SingleSourceTrustId'):
        if table == 'master':
            table_xpath = self.master_table
        else:
            table_xpath = self.ref_table
        input_xpath = table_xpath + '//input[@placeholder="' + _column_name + '"]'
        self.logger.info("input value %s to column %s in table %s" % (text, _column_name, table))
        self.driver.type(input_xpath, text)
        self.wait_loading()
        time.sleep(1)
        pass

    def verify_path_exist_with_SSTI(self, master_singlesourcetrustid, reference_serieskey):
        """
        verify the path exist in SingleSourceTrustId
        :return:
        """
        id = 'group' + master_singlesourcetrustid + '-' + reference_serieskey
        line_xpath = self.svg_path.replace('__id__', id)
        is_exist = self.driver.get_exist(line_xpath)
        return is_exist

    def click_cell_on_master_table(self,column,row):
        cell = self.master_table_cell_i.replace('__row__',str(row)).replace('__column__',str(column))
        try:
            time.sleep(1)
            self.driver.click(cell)
        except Exception as e:
            self.logger.error(e)
            raise NameError("element not found: "+cell)

    def click_cell_on_table(self, table=None, row=1, column=1, column_value=None):
        if table is None:
            table = self.ref_table
        if column_value is None:
            cell = table + '//tbody/tr[' + str(row) + ']/td[' + str(column) + ']//*[contains(@value,"Add To Dim")]'
        else:
            cell = table + '//tbody/tr[' + str(row) + ']/td[' + str(column) + ']'
        try:
            time.sleep(1)
            self.driver.click(cell)
            self.wait_loading()
        except Exception as e:
            self.logger.error(e)
            raise NameError("element not found: " + cell)


if __name__ == '__main__':
    login = Login()
    login.open()
    login.login()
    login.goto_trusts()
    trust = Trusts()
    expect_master_dropdown_values = ['All', 'Mapped', 'Unmapped']
    expect_source_list = ['DMSNG', 'SFG', 'SFW', 'CMBS', 'WMT', 'CDO', 'All']
    actual_master_dropdown_values = trust.driver.get_all_option_values(trust.master_mapping_status_dropdown)
    actual_resouce_list=trust.driver.get_text_list(trust.left_source)
    print(actual_resouce_list==expect_source_list)
    print(expect_master_dropdown_values == actual_master_dropdown_values)
    trust.driver.get_exist(trust.master_table)
    trust.driver.get_exist(trust.master_table)
    trust.click_cell_on_master_table(9,1)

    # trust.driver.get_row_count(trust.master_table)
    # trust.driver.get_column_count(trust.master_table)
    # trust.driver.get_cell_value(trust.master_table)
    # text_list = trust.driver.get_text_list(trust.master_table + '//tr')
    # print(text_list)

##trust.search('122700')
##trust.search('33226', 'reference', 'SeriesKey')
##print(trust.driver.get_enabled(trust.button.replace('__text__', 'Undo All')))
##trust.driver.drag_element_by_image()
##trust.verify_path_exist_with_SSTI('122700', '33226')
##print(trust.driver.get_enabled(trust.button.replace('__text__', 'Undo All')))
