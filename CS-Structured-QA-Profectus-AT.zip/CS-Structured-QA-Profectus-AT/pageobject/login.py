import config.config as Config
from pageobject.basepage import BasePage


class Login(BasePage):

    def __init__(self, ):
        """
        constructor
        """
        BasePage.__init__(self)
        'control info'
        self.login_btn = '//button[@type="submit"]'
        self.user = '//input[@formcontrolname="userName"]'
        self.pwd = '//input[@formcontrolname="password"]'

    def login(self, user_name=None, pwd=None):
        self.driver.explicitly_wait_until(self.login_btn)
        if user_name is None:
            user_name = 'kalan'
        if pwd is None:
            try:
                pwd = Config.USER_DICT[user_name]
            except:
                self.logger.error('user not add in USER_LIST in config file')
                return
        self.logger.info('log in with %s' % user_name)
        self.driver.type(self.user, user_name)
        self.driver.type(self.pwd, pwd)
        self.driver.click(self.login_btn)
        self.wait_loading()

    def get_popup_msg(self):
        is_exist = self.driver.get_exist(self.popup_msg_xpath)
        if(is_exist):
            msg = self.driver.get_text(self.popup_msg_xpath)
        else:
            self.logger.error('popup message not displayed!')
        return msg


if __name__ == '__main__':
    login = Login()
    login.open()
    login.login()
