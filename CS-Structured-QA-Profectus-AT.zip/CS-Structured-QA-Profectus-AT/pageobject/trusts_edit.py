from helper.common import Common
from pageobject.basepage import BasePage
from pageobject.login import Login
from pageobject.trusts import Trusts
import time


class TrustsEdit(Trusts):

    def __init__(self, ):
        """
        constructor
        """
        Trusts.__init__(self)
        # controls in page trust-edit
        self.tab = '//li[@role="presentation"]/a/span[text()="__text__"]'
        self.tab_list_without_trustinfo = '//a[@role="tab"]/span[text()!="Trust Info" and contains(@class, "ui-tabview-title")]'

        # controls in popup
        self.select_source_dropdownlist = '//div[@role="dialog"]//select'
        self.confirm_popup_msg = '//span[@class="ui-confirmdialog-message"]'
        self.confirm_popup_button = '//button/span[contains(text(),"__text__")]'

        # controls in tab
        self.source_types_tab = '//p-selectbutton[@name="btnSourceTypes"]//span[text()="__text__"]'
        self.source_types_tab_disable = '//p-selectbutton[@name="btnSourceTypes"]//span[text()="__text__"]/parent::div[contains(@class,"ui-state-disabled")]'
        self.trust_edit_ref_mapping_status_dropdown = 'name;ddlMapOptions'

    def exist_column_add_to_dim(self):

        column_xpath = self.ref_table + '//th[contains(text(),"Add To Dim")]'
        return self.driver.get_exist(column_xpath)





if __name__ == '__main__':
    login = Login()
    login.open()
    login.login()
    login.goto_trusts()
    trust = Trusts()
    trust.search('46030')
    trust.wait_loading()
    trust.click_cell_on_master_table(9, 1)  # click the icon in column Mapping
    trust.wait_loading()
    trust_edit = TrustsEdit()
    driver = trust_edit.driver
    trust_edit.get_exist_data_tab_list()
