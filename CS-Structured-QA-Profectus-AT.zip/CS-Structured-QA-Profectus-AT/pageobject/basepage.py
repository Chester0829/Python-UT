from helper.driver import BoxDriver
from helper.log import MyLog
import config.config as Config
import time,json
from helper.common import Common
from helper.dbcommon import mssqlTool


class BasePage(object):
    """
    base page for other page to inherit
    """
    driver = None

    def __init__(self, ):
        """
        constructor
        """
        BoxDriver.get_current_driver()
        self.driver = BoxDriver
        self.logger = MyLog.logger_with_file_and_console()
        self.home_xpath = '//a[@href="/home/active-tasks"]'
        self.trusts_xpath = '//a[@href="/home/trusts"]'
        self.loading_xpath = '//app-loader//div[@class="loader"]'
        self.button = '//button[contains(text(),"__text__")]'
        self.button_equal = '//button[text()="__text__"]'
        self.master_table = '//p-table[@id="masterTable"]//table'
        self.ref_table = '//p-table[@id="referenceTable"]//table'
        self.popup_msg_xpath = '//div[@class="ui-toast-detail"]'
        expect_json_file = Config.EXPECT_DATA_FILE
        with open(expect_json_file) as f:
            self.expect_json = json.load(f)
        with open(Config.SQL_QUERY_FILE) as f:
            self.sql_query_col = json.load(f)
        self.sql_helper = mssqlTool()


    def open(self, url=Common.url):
        """
        open url
        """
        if url == 'QA':
            url = Config.QA_URL
        elif url == 'Prod':
            url = Config.PROD_URL
        else:
            url = Config.QA_URL
        self.logger.info('open url:%s' % url)
        self.driver.navigate(url)
        self.driver.forced_wait(2)

    def goto_home(self):
        """
        go to home page
        :return:
        """
        self.driver.click(self.home_xpath)
        self.logger.info('redirect to Home page')

    def goto_trusts(self):
        """
        got ot Trusts page
        :return:
        """
        self.driver.click(self.trusts_xpath)
        self.logger.info('redirect to Trusts page')
        self.wait_loading()

    def wait_loading(self):
        self.driver.explicitly_wait_until_not(self.loading_xpath)
        time.sleep(1)
        self.logger.info('loading finish!')

    def click(self, selector):
        self.driver.click(selector)
        self.wait_loading()


if __name__ == '__main__':
    base = BasePage()
    print(Config.MAX_WAITING_TIME)
    print(Config.USER_DICT['kalan'])
    base.open('http://anv-lxconweb301/')
    base.driver.explicitly_wait('//button[@type="submit"]', )
    base.driver.type('//input[@formcontrolname="userName"]', 'kalan')
    base.driver.type('//input[@formcontrolname="password"]', 'kalan')
    base.driver.click('//button[@type="submit"]')
