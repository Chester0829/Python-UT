'''
Created on May 16, 2019

@author: Chester
'''

import unittest
import time
from helper.log import MyLog
from pageobject.login import Login


class LoginTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.logger = MyLog.logger_with_file_and_console()
        cls.logger.info("start to execute suite login")

    @classmethod
    def tearDownClass(cls):
        cls.logger.info("finish to execute suite login")

    def setUp(self):
        self.login = Login()
        self.login.open()

    def tearDown(self):
        self.login.driver.quit()

    def test_01_login_with_correct_user_pwd(self):
        self.logger.info('start to execute case :test_01_login_with_correct_user_pwd')
        self.login.login('kalan')
        is_home = self.login.driver.get_exist(self.login.home_xpath)
        self.assertTrue(is_home)
        self.logger.info('finish execute case :test_01_login_with_correct_user_pwd')

    def test_02_login_with_invalid_user(self):
        self.logger.info('start to execute case :test_02_login_with_invalid_user')
        self.login.login('kalan_invalid', 'kalan')
        pop_msg = self.login.get_popup_msg()
        self.assertIn(pop_msg, "Invalid username or password")
        self.logger.info('finish execute case :test_02_login_with_invalid_user')

    def test_03__login_with_invalid_pwd(self):
        self.logger.info('start to execute case :test_03__login_with_invalid_pwd')
        self.login.login('kalan', 'invalid_pwd')
        pop_msg = self.login.get_popup_msg()
        self.assertIn(pop_msg, "Invalid username or password")
        self.logger.info('finish execute case :test_03__login_with_invalid_pwd')


if __name__ == "__main__":
    pass
