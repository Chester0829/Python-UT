'''
Created on May 16, 2019

@author: Chester
'''

import unittest, time
from helper.log import MyLog
from helper.excel import Excel
import config.config as Config
from pageobject.login import Login
from pageobject.trusts import Trusts
from pageobject.trusts_edit import TrustsEdit
import ddt


@ddt.ddt
class TrustsEditTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.logger = MyLog.logger_with_file_and_console()
        cls.logger.info("start to execute suite trusts edit")

    @classmethod
    def tearDownClass(cls):
        cls.logger.info("finish to execute suite trusts edit")

    def setUp(self):
        login = Login()
        login.open()
        login.login()
        login.goto_trusts()
        self.trust = Trusts()
        self.trust_edit = TrustsEdit()
        self.driver = self.trust_edit.driver
        self.sql_helper = self.trust_edit.sql_helper
        self.source_list = self.trust_edit.expect_json['trust_edit_source_list']

    def tearDown(self):
        self.driver.quit()
        pass

    #@unittest.skip('...')
    @ddt.data(*Excel.get_test_data(2,Config.TEST_DATA_FILE,'RefreshDimMapping'))
    @ddt.unpack
    def test_01_button_refresh_dim_mapping(self, single_source_id, covered_types):
        self.logger.info('start to execute case: %s' % self._testMethodName)
        self.trust.search(str(single_source_id))
        self.trust.wait_loading()
        self.trust.click_cell_on_master_table(9, 1)  # click the icon in column Mapping
        self.trust.wait_loading()
        self.trust_edit.click(self.trust_edit.tab.replace('__text__', covered_types))
        self.logger.info('------------>click the source type ' + covered_types)
        '''
        click the source tab on the top right and try to find a source 
        which has data to verify the button Refresh Dim + Mappings
        
        '''
        for source_item in self.trust_edit.expect_json['trust_edit_source_list']:
            # if the source item is disabled to click
            disable_flag = self.driver.get_exist(
                self.trust_edit.source_types_tab_disable.replace('__text__', source_item))
            if disable_flag:
                self.logger.info('%s id disabled in source tab: %s' % (source_item, covered_types))
                continue
            self.trust_edit.click(self.trust_edit.source_types_tab.replace('__text__', source_item))
            self.logger.debug('click source tab: ' + source_item)
            mapping_button = self.trust_edit.button.replace('__text__', 'Refresh Dim + Mappings')
            enable_flag = self.driver.get_enabled(mapping_button)
            self.logger.debug('button Refresh Dim + Mappings enable is: ' + str(enable_flag))
            if enable_flag:
                # verify the button Refresh Dim + Mappings enabled
                self.assertTrue(self.driver.get_enabled(mapping_button))
                self.trust_edit.click(mapping_button)
                source_has_data_list = self.driver.get_all_option_values(self.trust_edit.select_source_dropdownlist)
                self.logger.debug(source_has_data_list)
                self.driver.select_by_index(self.trust_edit.select_source_dropdownlist, )
                selected_value = self.driver.get_selected_text(self.trust_edit.select_source_dropdownlist)
                self.logger.debug('the selected value: ' + selected_value)
                self.trust_edit.click(self.trust_edit.button.replace('__text__', 'Proceed'))
                # click the tab which mapped in above steps
                self.trust_edit.click(self.trust_edit.source_types_tab.replace('__text__', selected_value))
                column_value_list = self.driver.get_column_value_list(self.trust_edit.ref_table)
                self.logger.debug(column_value_list)
                for item in column_value_list:
                    trust_edit_single_source_id = str(item).strip()
                    # verify all the mapping path exist
                    self.assertTrue(self.driver.get_exist(
                        self.trust_edit.svg_solid_line_path.replace('__id__', trust_edit_single_source_id)))
                    # verify DB that mapping data exist
                    db_mapped_sql = str(
                        self.trust_edit.sql_query_col['trust_edit_validate_mapping'][covered_types]).replace(
                        '__id__', trust_edit_single_source_id)
                    db_mapped_count = self.sql_helper.execQuery(db_mapped_sql)
                    self.assertEqual(db_mapped_count[0][0], 1, msg="mapped path not in DB")
                    # verify DB that data added to dim table
                    db_added_to_dim_sql = str(
                        self.trust_edit.sql_query_col['trust_edit_dim_data_added_after_mapping'][
                            covered_types]).replace('__id__', trust_edit_single_source_id).replace(
                        '__trustid__', single_source_id)
                    db_added_to_dim_count = self.sql_helper.execQuery(db_added_to_dim_sql)
                    self.assertEqual(db_added_to_dim_count[0][0], 1, msg="data no added to dim table in DB")
                # verify row count are equal for Dim and ODS table
                master_row_count = self.driver.get_row_count(self.trust_edit.master_table)
                ref_row_count = self.driver.get_row_count(self.trust_edit.ref_table)
                self.assertEqual(master_row_count, ref_row_count)
                self.logger.debug('row count equal after Refresh Dim Mapping clicked')
                # get the value list of last column (column Source Id in master)
                actual_master_source_id = self.driver.get_column_value_list(self.trust_edit.master_table,
                                                                            column='last()')
                expect_source_id = self.trust_edit.expect_json['source_id_mapping'][selected_value]
                for x in actual_master_source_id:
                    ''' verify the Source Id of dim table must equal ods table after mapping'''
                    try:
                        is_int = int(x)
                    except:
                        is_int = False
                    if is_int:  # column displayed source id
                        self.assertEqual(expect_source_id, int(x))
                    else:  # column displayed source name
                        self.assertEqual(selected_value, x)
                    #  self.assertEqual(x, str(expect_source_id))
                break
            else:  # no data in ODS table
                # verify button Refresh Dim + Mappings should disabled when ODS table no data
                self.assertFalse(self.driver.get_enabled(mapping_button))
                table_no_data_value = self.driver.get_text(self.trust_edit.ref_table + '//h6')
                self.logger.debug(table_no_data_value)
                # verify no data in ODS table
                self.assertEqual(table_no_data_value, 'No Records Found')
                self.logger.debug(
                    'no data in ODS table under tab: %s in source type %s' % (source_item, covered_types))

        self.logger.info('finish execute case: %s' % self._testMethodName)

    @ddt.data(*Excel.get_test_data(1))
    @ddt.unpack
    def test_02_button_add_to_dim(self, single_source_id, covered_types):
        self.logger.info('start to execute case: %s' % self._testMethodName)
        single_source_id = str(single_source_id)
        self.trust.search(single_source_id)
        self.trust.wait_loading()
        self.trust.click_cell_on_master_table(9, 1)  # click the icon in column Mapping
        self.trust.wait_loading()
        tested_item = None
        if '+' in covered_types: # get data from DB
            temp_lst = covered_types.split('+')
            covered_types = temp_lst[0]
            tested_item = self.trust_edit.expect_json["source_name_mapping"][temp_lst[1]]
        self.trust_edit.click(self.trust_edit.tab.replace('__text__', covered_types))
        self.logger.info('------------>click the source type ' + covered_types)
        '''
                click the source tab on the top right and try to find a source 
                which has data to verify the button Add To Dim
        '''
        for source_item in self.trust_edit.expect_json['trust_edit_source_list']:
            if tested_item != source_item:
                continue
            # if the source item is disabled to click
            disable_flag = self.driver.get_exist(
                self.trust_edit.source_types_tab_disable.replace('__text__', source_item))
            if disable_flag:
                self.logger.info('%s id disabled in source tab: %s' % (source_item, covered_types))
                continue
            self.trust_edit.click(self.trust_edit.source_types_tab.replace('__text__', source_item))
            self.logger.debug('click source tab: ' + source_item)
            mapping_button = self.trust_edit.button.replace('__text__', 'Refresh Dim + Mappings')
            enable_flag = self.driver.get_enabled(mapping_button)
            self.logger.debug('button Refresh Dim + Mappings enable is: ' + str(enable_flag))
            if enable_flag:
                # judge if column Add To Dim exist
                column_add_to_dim_exist = self.trust_edit.exist_column_add_to_dim()
                if column_add_to_dim_exist:
                    original_row_count = self.driver.get_row_count(self.trust_edit.master_table)
                    ddl_mapping_status = self.trust_edit.trust_edit_ref_mapping_status_dropdown
                    self.driver.select_by_visible_text(ddl_mapping_status, 'Unmapped')
                    self.trust_edit.wait_loading()
                    self.logger.debug('select Unmapped in ODS table')
                    row_count = self.driver.get_row_count(self.trust_edit.ref_table)
                    if row_count >= 1:
                        #  click the button Add To Dim in row 1
                        self.trust_edit.click_cell_on_table(self.trust_edit.ref_table, row=1)
                        confirm_popup_exist = self.driver.get_exist(self.trust_edit.confirm_popup_msg)
                        if confirm_popup_exist:
                            # verify the content of popup msg
                            msg = self.driver.get_text(self.trust_edit.confirm_popup_msg)
                            self.logger.debug(msg)
                            self.assertIn('You are', msg)
                            'verify the mapping add successfully'
                            self.trust_edit.click(self.trust_edit.confirm_popup_button.replace('__text__', 'Yes'))
                            # verify mapping path added
                            self.driver.select_by_visible_text(ddl_mapping_status, 'All')
                            self.trust_edit.wait_loading()
                            # if only 1 row has Add To Dim button, after click the column Add To Dim will disappeared
                            if row_count == 1:
                                column_index = 1
                            else:
                                column_index = 2
                            trust_edit_single_source_id = self.driver.get_cell_value(self.trust_edit.ref_table,
                                                                                     row='last()', column=column_index)
                            self.logger.debug('mapped single source id is: ' + str(trust_edit_single_source_id))
                            self.assertTrue(self.driver.get_exist(
                                self.trust_edit.svg_solid_line_path.replace('__id__', trust_edit_single_source_id)))
                            # verify dim table add 1 row
                            mapped_row_count = self.driver.get_row_count(self.trust_edit.master_table)
                            self.assertEqual(mapped_row_count, original_row_count + 1)
                            #  verify dim Source Id column is same with ods table
                            expect_source_id = self.trust_edit.expect_json['source_id_mapping'][source_item]
                            actual_source_id = self.driver.get_cell_value(self.trust_edit.master_table, row='last()',
                                                                          column='last()')
                            try:
                                is_int = int(actual_source_id)
                            except:
                                is_int = False
                            if is_int:  # column displayed source id
                                self.assertEqual(expect_source_id, int(actual_source_id))
                            else:  # column displayed source name
                                self.assertEqual(source_item, actual_source_id)
                            # verify DB that mapping path exist
                            db_mapped_sql = str(
                                self.trust_edit.sql_query_col['trust_edit_validate_mapping'][covered_types]).replace(
                                '__id__', trust_edit_single_source_id)
                            db_mapped_count = self.sql_helper.execQuery(db_mapped_sql)
                            self.assertEqual(db_mapped_count[0][0], 1, msg="mapped path not in DB")
                            # verify DB that data added to dim table
                            db_added_to_dim_sql = str(
                                self.trust_edit.sql_query_col['trust_edit_dim_data_added_after_mapping'][
                                    covered_types]).replace('__id__', trust_edit_single_source_id).replace(
                                '__trustid__', single_source_id)
                            db_added_to_dim_count = self.sql_helper.execQuery(db_added_to_dim_sql)
                            self.assertEqual(db_added_to_dim_count[0][0], 1, msg="data no added to dim table in DB")
                            # delete data to make DB restore back to the original
                            db_delete_sql = str(self.trust_edit.sql_query_col['delete_one_mapped_query'][covered_types]).replace('__id__', trust_edit_single_source_id).replace(
                                '__trustid__', single_source_id)
                            result = self.sql_helper.execNonQuery(db_delete_sql);
                            if result is None:
                                self.logger.debug('delete data successfully!!!')
                            else:
                                self.logger.error('error occurred when delete data! error info: '+result)
                            break
                        else:  # entity already mapped into master table
                            # verify the error msg displayed
                            error_pop_msg = self.driver.get_text(self.trust_edit.popup_msg_xpath)
                            self.logger.warning(error_pop_msg)
                            self.assertIn('already exists in', error_pop_msg)
                            # waining popup displayed
                    else:  # no rows displayed after choose Unmapped
                        self.logger.warn('no data shows when choose Unmapped under tab %s in source tab %s' % (
                            source_item, covered_types))
                else:  # column Add To Dim not displayed
                    self.logger.warn(
                        'column Add To Dim not displayed under tab %s in source tab %s' % (source_item, covered_types))
            else:  # button Refresh Dim + Mappings is disabled ,verify no data in ODS table
                # verify button Refresh Dim + Mappings should disabled when ODS table no data
                self.assertFalse(self.driver.get_enabled(mapping_button))
                table_no_data_value = self.driver.get_text(self.trust_edit.ref_table + '//h6')
                self.logger.debug(table_no_data_value)
                # verify no data in ODS table
                self.assertEqual(table_no_data_value, 'No Records Found')
                self.logger.debug(
                    'no data in ODS table under tab: %s in source type %s' % (source_item, covered_types))
        self.logger.info('finish execute case: %s' % self._testMethodName)

    #@unittest.skip('...')
    def test_03_count_verify(self):
        source_id = self.sql_helper.execQuery(self.trust_edit.sql_query_col['top_1_dimTrust'])
        self.trust.search(str(source_id[0][0]))
        self.trust.wait_loading()
        tranche_count = self.driver.get_cell_value(self.trust.master_table, column=10)
        pool_count = self.driver.get_cell_value(self.trust.master_table, column=11)
        trigger_count = self.driver.get_cell_value(self.trust.master_table, column=12)
        support_count = self.driver.get_cell_value(self.trust.master_table, column=13)
        self.logger.debug('tranche_count: ' + tranche_count + ' pool_count: ' + pool_count)
        self.logger.debug('trigger_count: ' + trigger_count + ' support_count: ' + support_count)
        self.trust.click_cell_on_master_table(9, 1)  # click the icon in column Mapping
        self.trust.wait_loading()
        trust_edit_tab_list = self.driver.get_text_list(self.trust_edit.tab_list_without_trustinfo)
        self.logger.info('trust_edit_tab_list->' + str(trust_edit_tab_list))
        '''
        click the source tab on top left, which is Pools,Tranches,Triggers,Supports
        '''
        for source_tab in trust_edit_tab_list:
            self.trust_edit.click(self.trust_edit.tab.replace('__text__', source_tab))
            self.logger.info('------------>click the source tab ' + source_tab)
            mapped_count = 0
            total_ods_count = 0
            for source_item in self.trust_edit.expect_json['trust_edit_source_list']:
                # if the source item is disabled to click
                disable_flag = self.driver.get_exist(
                    self.trust_edit.source_types_tab_disable.replace('__text__', source_item))
                if disable_flag:
                    self.logger.info('%s id disabled in source tab: %s' % (source_item, source_tab))
                    continue
                self.trust_edit.click(self.trust_edit.source_types_tab.replace('__text__', source_item))
                self.logger.debug('click source types tab: ' + source_item)
                mapping_button = self.trust_edit.button.replace('__text__', 'Refresh Dim + Mappings')
                enable_flag = self.driver.get_enabled(mapping_button)
                self.logger.debug('button Refresh Dim + Mappings enable is: ' + str(enable_flag))
                if enable_flag:
                    temp_total_count = self.driver.get_row_count(self.trust_edit.ref_table)
                    total_ods_count += temp_total_count
                    current_mapped_count = self.driver.get_elements_count(
                        self.trust_edit.svg_solid_line_path.replace('__id__', ''))
                    mapped_count += current_mapped_count
            expect_count = str(mapped_count) + '/' + str(total_ods_count)

            if source_tab == "Pools":
                self.logger.debug('Pools-->expect_count: %s | actual_count: %s' % (expect_count, pool_count))
                self.assertEqual(pool_count, expect_count)
            if source_tab == "Tranches":
                self.logger.debug('Tranches-->expect_count: %s | actual_count: %s' % (expect_count, tranche_count))
                self.assertEqual(tranche_count, expect_count)
            if source_tab == "Triggers":
                self.logger.debug('Triggers-->expect_count: %s | actual_count: %s' % (expect_count, trigger_count))
                self.assertEqual(trigger_count, expect_count)
            if source_tab == "Supports":
                self.logger.debug('Supports-->expect_count: %s | actual_count: %s' % (expect_count, support_count))
                self.assertEqual(support_count, expect_count)

    #@unittest.skip('...')
    def test_04_validate_unvalidate_unmap_automap(self):
        source_id = self.sql_helper.execQuery(self.trust_edit.sql_query_col['top_1_dimTrust'])
        self.trust.search(str(source_id[0][0]))
        self.trust.wait_loading()
        self.trust.click_cell_on_master_table(9, 1)  # click the icon in column Mapping
        self.trust.wait_loading()
        trust_edit_tab_list = self.driver.get_text_list(self.trust_edit.tab_list_without_trustinfo)
        '''
        click the source tab on top left, which is Pools,Tranches,Triggers,Supports
        '''
        for source_tab in trust_edit_tab_list:
            is_validate =False
            self.trust_edit.click(self.trust_edit.tab.replace('__text__', source_tab))
            self.logger.info('------------>click the source tab ' + source_tab)
            for source_item in self.trust_edit.expect_json['trust_edit_source_list']:
                # if the source item is disabled to click
                disable_flag = self.driver.get_exist(
                    self.trust_edit.source_types_tab_disable.replace('__text__', source_item))
                if disable_flag:
                    self.logger.info('%s id disabled in source tab: %s' % (source_item, source_tab))
                    continue
                self.trust_edit.click(self.trust_edit.source_types_tab.replace('__text__', source_item))
                self.logger.debug('click source types tab: ' + source_item)
                mapping_button = self.trust_edit.button.replace('__text__', 'Refresh Dim + Mappings')
                enable_flag = self.driver.get_enabled(mapping_button)
                self.logger.debug('button Refresh Dim + Mappings enable is: ' + str(enable_flag))
                if enable_flag:
                    solid_line_count = self.driver.get_elements_count(
                        self.trust_edit.svg_solid_line_path.replace('__id__', ''))
                    if solid_line_count > 0:  # UI exist validate mapping
                        '''
                        validate mapping
                        '''
                        first_solid_line_id = self.driver.get_attribute(self.trust_edit.first_solid_line_parent, 'id')
                        id = first_solid_line_id.split('-')[0][5:]
                        # Pools-->PoolId,Tranches-->TrancheId
                        search_column_name = source_tab.split('s')[0]+'Id'
                        self.trust_edit.search(id, _column_name=search_column_name)
                        self.trust_edit.wait_loading()
                        # DB check is validate mapping
                        db_mapped_sql = str(self.trust_edit.sql_query_col['trust_edit_validate_mapping'][source_tab]).replace('__id__', id)
                        db_mapped_count = self.sql_helper.execQuery(db_mapped_sql)
                        self.assertGreaterEqual(db_mapped_count[0][0], 1, msg="mapped path not in DB")
                        # verify the button Unvalidate is enabled and count is 1
                        enable_count = self.driver.get_elements_count(
                            self.trust_edit.enable_button_in_validate_col.replace('__value__', 'Unvalidate'))
                        self.assertEqual(enable_count, 1, msg='enabled Unvalidate button count not match ')
                        # verify button Undo All and Save exist and disabled
                        self.assertFalse(self.trust.driver.get_enabled(self.trust_edit.button.replace('__text__', 'Undo All')))
                        self.assertFalse(self.trust.driver.get_enabled(self.trust_edit.button_equal.replace('__text__', 'Save')))
                        '''
                        Unvalidate mapping
                        '''
                        self.logger.debug('click Unvalidate button')
                        self.driver.click(self.trust_edit.enable_button_in_validate_col.replace('__value__', 'Unvalidate'))
                        # verify the button value change from Unvalidate to Validate
                        enable_count = self.driver.get_elements_count(
                            self.trust_edit.enable_button_in_validate_col.replace('__value__', 'Validate'))
                        self.assertEqual(enable_count, 1, msg='button value not change from Unvalidate to Validate')
                        # verify button Undo All and Save are enabled
                        self.assertTrue(self.trust.driver.get_enabled(self.trust_edit.button.replace('__text__', 'Undo All')))
                        self.assertTrue(self.trust.driver.get_enabled(self.trust_edit.button_equal.replace('__text__', 'Save')))
                        self.driver.click(self.trust_edit.button_equal.replace('__text__','Save'))
                        # verify the content of confirm popup msg
                        msg = self.driver.get_text(self.trust_edit.confirm_popup_msg)
                        self.logger.debug(msg)
                        self.assertIn('You have made the following changes:', msg)
                        self.logger.debug('click the Yes button in confirm popup for unvalidated')
                        self.trust_edit.click(self.trust.confirm_popup_button.replace('__text__', 'Yes'))
                        ddl_mapping_status = self.trust_edit.trust_edit_ref_mapping_status_dropdown
                        self.driver.select_by_visible_text(ddl_mapping_status, 'Unvalidated Mapping')
                        self.trust_edit.wait_loading()
                        # verify the mapping status change to Unvalidate and dash line
                        self.assertTrue(self.driver.get_exist(self.trust_edit.svg_dash_line_path.replace('__id__',id)))
                        # verify DB that mapping status change to Unvalidate
                        db_mapped_sql = str(
                            self.trust_edit.sql_query_col['trust_edit_unvalidate_mapping'][source_tab]).replace(
                            '__id__', id)
                        db_mapped_count = self.sql_helper.execQuery(db_mapped_sql)
                        self.assertEqual(db_mapped_count[0][0], 1, msg="mapping status not change to Unvalidate ")
                        '''
                        Unmapped mapping
                        '''
                        self.driver.select_by_visible_text(ddl_mapping_status, 'All')
                        self.trust_edit.wait_loading()
                        # verify button Undo All and Save exist and disabled
                        self.assertFalse(self.trust.driver.get_enabled(self.trust_edit.button.replace('__text__', 'Undo All')))
                        self.assertFalse(self.trust.driver.get_enabled(self.trust_edit.button_equal.replace('__text__', 'Save')))
                        # click the delete icon on dim table
                        self.driver.click(self.trust_edit.delete_icon_enabled_in_dim_table)
                        # verify button Undo All and Save are enabled
                        self.assertTrue(self.trust.driver.get_enabled(self.trust_edit.button.replace('__text__', 'Undo All')))
                        self.assertTrue(self.trust.driver.get_enabled(self.trust_edit.button_equal.replace('__text__', 'Save')))
                        self.driver.click(self.trust_edit.button_equal.replace('__text__', 'Save'))
                        # verify the content of confirm popup msg
                        msg = self.driver.get_text(self.trust_edit.confirm_popup_msg)
                        self.logger.debug(msg)
                        self.assertIn('You have made the following changes:', msg)
                        self.logger.debug('click the Yes button in confirm popup for unmapped')
                        self.trust_edit.click(self.trust.confirm_popup_button.replace('__text__', 'Yes'))
                        self.trust_edit.wait_loading()
                        # verify the mapping line is disappear
                        self.assertFalse(self.driver.get_exist(self.trust_edit.svg_path.replace('__id__', id)))
                        # verify the validate button change to disabled
                        self.assertTrue(self.driver.get_exist(self.trust_edit.disabled_button_in_validate_col.replace('__value__', 'Validate')))
                        # verify the delete icon change to disabled
                        self.assertTrue(self.driver.get_exist(self.trust_edit.delete_icon_disabled_in_dim_table))
                        # verify DB that mapping status change to Unmapped
                        db_mapped_sql = str(
                            self.trust_edit.sql_query_col['trust_edit_a_mapping_exist'][source_tab]).replace('__id__', id)
                        db_mapped_count = self.sql_helper.execQuery(db_mapped_sql)
                        self.assertEqual(db_mapped_count[0][0], 0, msg="mapping status not change to Unmapped ")
                        '''
                        Try To Auto Map function
                        '''
                        self.driver.click(self.trust_edit.button.replace('__text__','Try To Auto Map'))
                        # verify the content of confirm popup msg
                        msg = self.driver.get_text(self.trust_edit.confirm_popup_msg)
                        self.logger.debug(msg)
                        self.assertIn('This will try to automatically map all the', msg)
                        self.logger.debug('click the Proceed button in confirm popup for Try To Auto Map')
                        self.trust_edit.click(self.trust.confirm_popup_button.replace('__text__', 'Proceed'))
                        # verify the mapping status change to Unvalidate and dash line
                        self.assertTrue(self.driver.get_exist(self.trust_edit.svg_dash_line_path.replace('__id__', id)))
                        # verify DB that mapping status change to Unvalidate
                        db_mapped_sql = str(
                            self.trust_edit.sql_query_col['trust_edit_unvalidate_mapping'][source_tab]).replace(
                            '__id__', id)
                        db_mapped_count = self.sql_helper.execQuery(db_mapped_sql)
                        self.assertEqual(db_mapped_count[0][0], 1, msg="Try To Auto Map not work!!! ")
                        '''
                        restore back the validate mapping for the tested item
                        '''
                        self.driver.click(self.trust_edit.enable_button_in_validate_col.replace('__value__', 'Validate'))
                        self.driver.click(self.trust_edit.button_equal.replace('__text__', 'Save'))
                        # verify the content of confirm popup msg
                        msg = self.driver.get_text(self.trust_edit.confirm_popup_msg)
                        self.logger.debug(msg)
                        self.assertIn('You have made the following changes:', msg)
                        self.logger.debug('click the Yes button in confirm popup for unvalidated')
                        self.trust_edit.click(self.trust.confirm_popup_button.replace('__text__', 'Yes'))
                        self.trust_edit.wait_loading()
                        is_validate=True
                        break

                    else:
                        self.logger.info('no validate mapping under tab: %s in source type %s' % (source_item, source_tab))
            if is_validate:  # means all the check point already covered,no need check again
                break

if __name__ == "__main__":
    # from multiprocessing import Pool
    # pool=Pool(3)
    # pool.apply_async(unittest.main)
    unittest.main()

