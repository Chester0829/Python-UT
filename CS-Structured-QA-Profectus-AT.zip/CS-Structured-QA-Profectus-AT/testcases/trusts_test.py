'''
Created on May 16, 2019

@author: Chester
'''

import unittest, time
from helper.log import MyLog
from pageobject.login import Login
from pageobject.trusts import Trusts
from pageobject.trusts_edit import TrustsEdit


class TrustsTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.logger = MyLog.logger_with_file_and_console()
        cls.logger.info("start to execute suite trusts")

    @classmethod
    def tearDownClass(cls):
        cls.logger.info("finish to execute suite trusts")

    def setUp(self):
        login = Login()
        login.open()
        login.login()
        login.goto_trusts()
        self.trust = Trusts()
        self.driver = self.trust.driver
        self.sql_helper = self.trust.sql_helper

    def tearDown(self):
        self.trust.driver.quit()

    @unittest.skip('not in test plan')
    def test_01_drag_line_and_clear(self):
        self.logger.info('start to execute case :test_01_drag_line_and_clear')

        single_source_trust_id = '122700'
        series_key = '12166'
        self.trust.search(single_source_trust_id)
        self.trust.search(series_key, 'reference', 'SeriesKey')
        # verify button Undo All is disabled
        self.assertFalse(self.trust.driver.get_enabled(self.trust.button.replace('__text__', 'Undo All')))
        self.trust.driver.drag_element_by_image()
        time.sleep(3)
        # verify line exist
        self.assertTrue(self.trust.verify_path_exist_with_SSTI(single_source_trust_id, series_key))
        # verify button Undo All enabled
        self.assertTrue(self.trust.driver.get_enabled(self.trust.button.replace('__text__', 'Undo All')))
        self.trust.logger.info('click button Undo All')
        self.trust.driver.click(self.trust.button.replace('__text__', 'Undo All'))
        time.sleep(3)
        # verify line not exist after click button Undo All
        self.assertFalse(self.trust.verify_path_exist_with_SSTI(single_source_trust_id, series_key))
        self.logger.info('finish execute case :test_01_drag_line_and_clear')

    def test_02_verify_left_UI_items(self):
        self.logger.info('start to execute case :test_02_verify_left_UI_items')
        expect_master_dropdown_values = self.trust.expect_json['expect_master_dropdown_values']
        expect_source_list = self.trust.expect_json['expect_source_list']

        actual_master_dropdown_values = self.trust.driver.get_all_option_values(
            self.trust.master_mapping_status_dropdown)
        actual_resouce_list = self.trust.driver.get_text_list(self.trust.left_source)
        # verify left radio group
        self.assertEqual(actual_resouce_list, expect_source_list)
        # verify left ui dropdownlist values
        self.assertEqual(expect_master_dropdown_values, actual_master_dropdown_values)
        # verify Dim table exists
        self.trust.driver.get_exist(self.trust.master_table)
        # verify the validate column in Dim table has button Validate and Unvalidate
        expect_column_set = set(self.trust.expect_json['expect_column_set'])
        actual_column_set = set(self.trust.driver.get_attribute_list(self.trust.master_table_column_input, "value"))
        self.assertTrue(expect_column_set == actual_column_set)
        # verify Dim table top and bottom paginators exist
        left_paginator_count = self.trust.driver.get_elements_count(self.trust.left_paginator)
        self.assertTrue(left_paginator_count == 2, 'left paginator count not equal 2')
        self.logger.info('finish execute case :test_02_verify_left_UI_items')

    def test_03_verify_right_UI_items(self):
        self.logger.info('start to execute case :test_03_verify_right_UI_items')
        expect_ref_dropdown_values = self.trust.expect_json['expect_ref_dropdown_values']
        expect_source_list = self.trust.expect_json['expect_source_list']

        actual_ref_dropdown_values = self.trust.driver.get_all_option_values(self.trust.ref_mapping_status_dropdown)
        actual_right_resouce_list = self.trust.driver.get_text_list(self.trust.right_source)
        # verify right radio group
        self.assertEqual(actual_right_resouce_list, expect_source_list)
        # verify right ui dropdownlist values
        self.assertEqual(expect_ref_dropdown_values, actual_ref_dropdown_values)
        # verify ODS table exists
        self.trust.driver.get_exist(self.trust.ref_table)
        # verify ODS table top and bottom paginators exist
        right_paginator_count = self.trust.driver.get_elements_count(self.trust.right_paginator)
        self.assertTrue(right_paginator_count == 2, 'right paginator count not equal 2')
        self.logger.info('finish execute case :test_03_verify_right_UI_items')

    def test_04_verify_other_UI_items(self):
        self.logger.info('start to execute case :test_04_verify_other_UI_items')
        # verify button Undo All and Save exist and disabled
        self.assertFalse(self.trust.driver.get_enabled(self.trust.button.replace('__text__', 'Undo All')))
        self.assertFalse(self.trust.driver.get_enabled(self.trust.button.replace('__text__', 'Save')))
        # verify mapping path exists
        path_count = self.trust.driver.get_elements_count(self.trust.svg_path.replace('__id__', ''))
        self.assertTrue(path_count >= 1, 'no mapping path exists')
        self.logger.info('finish execute case :test_04_verify_other_UI_items')

    def test_05_trust_add_to_dim(self):
        ddl_ods_mapping_status = self.trust.ref_mapping_status_dropdown
        self.driver.select_by_visible_text(ddl_ods_mapping_status, 'Unmapped')
        self.trust.wait_loading()
        self.logger.debug('select Unmapped for ods table')
        row_count = self.driver.get_row_count(self.trust.ref_table)
        if row_count >= 1:
            # get the Series key for the first row
            series_key = self.driver.get_cell_value(self.trust.ref_table, column=3)
            #  click the button Add To Dim in row 1
            self.trust.click_cell_on_table(self.trust.ref_table, row=1)
            confirm_popup_exist = self.driver.get_exist(self.trust.confirm_popup_msg)
            if confirm_popup_exist:
                # verify the content of popup msg
                msg = self.driver.get_text(self.trust.confirm_popup_msg)
                self.logger.debug(msg)
                self.assertIn('You are about to insert', msg)
                'verify the mapping add successfully'
                self.trust.click(self.trust.confirm_popup_button.replace('__text__', 'Yes'))
                self.driver.select_by_visible_text(ddl_ods_mapping_status, 'All')
                self.trust.wait_loading()
                # search for the trust id which just mapped in above step
                self.trust.search(series_key, table=self.trust.ref_table, _column_name='SeriesKey')
                # get the single Source id based on the trust Id
                single_source_id = self.driver.get_cell_value(self.trust.ref_table, row=1, column=1)
                self.logger.debug('mapped single source id is: '+ str(single_source_id))
                # search for single source id in Dim table
                self.trust.search(single_source_id, table='master')
                self.trust.wait_loading()
                # verify data added to dim table
                row_count = self.driver.get_row_count(self.trust.master_table)
                self.assertEqual(row_count, 1, msg='data not add to dim table')
                # verify mapping path exist
                self.assertTrue(
                    self.driver.get_exist(self.trust.svg_solid_line_path.replace('__id__', single_source_id)))
                # verify DB that mapping data exist
                db_mapped_sql = str(self.trust.sql_query_col['trust_validate_mapping']).replace('__id__', single_source_id)
                db_mapped_count = self.sql_helper.execQuery(db_mapped_sql)
                self.assertEqual(db_mapped_count[0][0], 1,
                                 msg='DB has no mapping data for trustid %s' % single_source_id)
                # verify DB that data added to dim table
                db_added_to_dim_sql = str(self.trust.sql_query_col['trust_dim_data_added_after_mapping']).replace(
                    '__id__', single_source_id)
                db_added_to_dim_count = self.sql_helper.execQuery(db_added_to_dim_sql)
                self.assertEqual(db_added_to_dim_count[0][0], 1,
                                 msg='no data added to dim in DB for: %s' % single_source_id)

                '''
                below is to verify all entries are added to dim in trust edit page after do add to dim action in trust page
                '''
                tranche_count = self.driver.get_cell_value(self.trust.master_table, column=10)
                pool_count = self.driver.get_cell_value(self.trust.master_table, column=11)
                trigger_count = self.driver.get_cell_value(self.trust.master_table, column=12)
                support_count = self.driver.get_cell_value(self.trust.master_table, column=13)
                self.logger.debug('tranche_count: ' + tranche_count + ' pool_count: ' + pool_count)
                self.logger.debug('trigger_count: ' + trigger_count + ' support_count: ' + support_count)
                self.trust.click_cell_on_master_table(9, 1)  # click the icon in column Mapping
                self.trust.wait_loading()
                self.trust_edit = TrustsEdit()
                trust_edit_tab_list = self.driver.get_text_list(self.trust_edit.tab_list_without_trustinfo)
                self.logger.info('trust_edit_tab_list->' + str(trust_edit_tab_list))
                '''
                click the source tab on top left, which is Pools,Tranches,Triggers,Supports
                '''
                for source_tab in trust_edit_tab_list:
                    self.trust_edit.click(self.trust_edit.tab.replace('__text__', source_tab))
                    self.logger.info('------------>click the source tab ' + source_tab)
                    mapped_count = 0
                    total_ods_count = 0
                    for source_item in self.trust_edit.expect_json['trust_edit_source_list']:
                        # if the source item is disabled to click
                        disable_flag = self.driver.get_exist(
                            self.trust_edit.source_types_tab_disable.replace('__text__', source_item))
                        if disable_flag:
                            self.logger.info('%s disabled in source tab: %s' % (source_item, source_tab))
                            continue
                        self.trust_edit.click(self.trust_edit.source_types_tab.replace('__text__', source_item))
                        self.logger.debug('click source types tab: ' + source_item)
                        mapping_button = self.trust_edit.button.replace('__text__', 'Refresh Dim + Mappings')
                        enable_flag = self.driver.get_enabled(mapping_button)
                        self.logger.debug('button Refresh Dim + Mappings enable is: ' + str(enable_flag))
                        if enable_flag:
                            temp_total_count = self.driver.get_row_count(self.trust_edit.ref_table)
                            total_ods_count += temp_total_count
                            current_mapped_count = self.driver.get_elements_count(
                                self.trust_edit.svg_solid_line_path.replace('__id__', ''))
                            mapped_count += current_mapped_count
                    expect_count = str(mapped_count) + '/' + str(total_ods_count)
                    # verify all ods entries are mapped after do add to dim action in trust page
                    self.assertEqual(mapped_count,total_ods_count,msg='not all the entries are mapped')
                    if source_tab == "Pools":
                        self.logger.debug('Pools-->expect_count: %s | actual_count: %s' % (expect_count, pool_count))
                        self.assertEqual(pool_count, expect_count)
                    if source_tab == "Tranches":
                        self.logger.debug(
                            'Tranches-->expect_count: %s | actual_count: %s' % (expect_count, tranche_count))
                        self.assertEqual(tranche_count, expect_count)
                    if source_tab == "Triggers":
                        self.logger.debug(
                            'Triggers-->expect_count: %s | actual_count: %s' % (expect_count, trigger_count))
                        self.assertEqual(trigger_count, expect_count)
                    if source_tab == "Supports":
                        self.logger.debug(
                            'Supports-->expect_count: %s | actual_count: %s' % (expect_count, support_count))
                        self.assertEqual(support_count, expect_count)
                ''' restore the data back to original'''
                delete_all_query = str(self.trust.sql_query_col['delete_all_mapped_query_by_trust_id']).replace(
                    '__trustid__', single_source_id)
                result = self.sql_helper.execNonQuery(delete_all_query)
                if result is None:
                    self.logger.debug('delete data successfully!!!')
                else:
                    self.logger.error('error occurred when delete data! error info: ' + result)
            else:  # entity already mapped into master table
                # verify the error msg displayed
                error_pop_msg = self.driver.get_text(self.trust.popup_msg_xpath)
                self.assertIn('already exists in', error_pop_msg)
                # waining popup displayed
        else:  # no rows displayed after choose Unmapped
            self.logger.warn('no data shows when choose Unmapped under trust page')


    def test_06_master_trust_add_to_dim(self):
        source_trust_id = '8672'
        '''
        delete all the mapping related data for trust id 8672
        situation #1: already mapped and mapping path exist
        situation #2: already mapped but mapping path not exist, after click Add To Dim, error msg occurred
        '''
        get_trust_id_sql = self.trust.sql_helper.execQuery(str(self.trust.sql_query_col['get_trustid_by_sourcetrustid_for_trust_page']).replace('__trustid__', source_trust_id))
        if len(get_trust_id_sql) != 0:
            single_source_id=str(get_trust_id_sql[0][0])
            delete_all_query = str(self.trust.sql_query_col['delete_all_mapped_query_by_trust_id']).replace('__trustid__', single_source_id)
            result = self.sql_helper.execNonQuery(delete_all_query)
            if result is None:
                self.logger.debug('delete data successfully!!!')
            else:
                self.logger.error('error occurred when delete data! error info: ' + result)
            self.driver.refresh()
            time.sleep(5)
            self.trust.wait_loading()
        self.trust.search(source_trust_id, table=self.trust.ref_table, _column_name='TrustId')
        self.trust.wait_loading()
        #  click the button Add To Dim in row 1
        self.trust.click_cell_on_table(self.trust.ref_table, row=1)
        confirm_popup_exist = self.driver.get_exist(self.trust.confirm_popup_msg)
        if confirm_popup_exist:
            # verify the content of popup msg
            msg = self.driver.get_text(self.trust.confirm_popup_msg)
            self.logger.debug(msg)
            self.assertIn('You are about to insert', msg)
            'verify the mapping add successfully'
            self.trust.click(self.trust.confirm_popup_button.replace('__text__', 'Yes'))
            single_source_id = self.driver.get_cell_value(self.trust.ref_table, row=1, column=1)
            self.logger.debug('mapped single source id is: ' + str(single_source_id))
            # search for single source id in Dim table
            self.trust.search(single_source_id, table='master')
            self.trust.wait_loading()
            # verify UI that data added to dim table
            dim_row_count = self.driver.get_row_count(self.trust.master_table)
            self.assertEqual(dim_row_count, 1, msg='data not add to dim table')
            # verify UI that mapping path exist
            ods_row_count = self.driver.get_row_count(self.trust.ref_table)
            svg_path_count = self.driver.get_elements_count(self.trust.svg_solid_line_path.replace('__id__', single_source_id))
            self.assertEqual(svg_path_count,ods_row_count,msg='Master Trust mapping count not equal ods table count')
            # verify DB that mapping data exist
            db_mapped_sql = str(self.trust.sql_query_col['trust_validate_mapping']).replace('__id__', single_source_id)
            db_mapped_count = self.sql_helper.execQuery(db_mapped_sql)
            self.assertEqual(db_mapped_count[0][0], 1,
                             msg='DB has no mapping data for trustid %s' % single_source_id)
            # verify DB that data added to dim table
            db_added_to_dim_sql = str(self.trust.sql_query_col['trust_dim_data_added_after_mapping']).replace(
                '__id__', single_source_id)
            db_added_to_dim_count = self.sql_helper.execQuery(db_added_to_dim_sql)
            self.assertEqual(db_added_to_dim_count[0][0], 1,
                             msg='no data added to dim in DB for: %s' % single_source_id)

        else:  # entity already mapped into master table
            # verify the error msg displayed
            error_pop_msg = self.driver.get_text(self.trust.popup_msg_xpath)
            self.assertIn('already exists in', error_pop_msg)

    def test_07_item_right_click_filter_docs(self):
        # for debug
        # self.trust.search('46042')
        # self.trust.wait_loading()

        self.logger.info('start to execute case :test_07_item_right_click_filter_docs')
        self.logger.info('right click the cell Single Source Id in first row')
        self.driver.right_click(self.trust.master_table_first_row_cell_3)
        single_source_id = self.driver.get_text(self.trust.master_table_first_row_cell_3).strip()
        '''right click menu -- Deal Docs'''
        self.trust.click(self.trust.right_click_menu_item.replace('__text__','Deal Docs'))
        # verify the popup Deal Docs displayed
        is_exist = self.driver.get_exist(self.trust.popup_deal_docs_title.replace('__text__',single_source_id))
        self.assertTrue(is_exist)
        time.sleep(2)
        # click the close icon in popup
        self.trust.click(self.trust.popup_deal_docs_close_btn)
        '''right click menu -- Filter Series'''
        self.logger.info('right click the cell Single Source Id in first row')
        self.driver.right_click(self.trust.master_table_first_row_cell_3)
        self.trust.click(self.trust.right_click_menu_item.replace('__text__', 'Filter Series'))
        self.trust.wait_loading()
        ods_table_count = self.driver.get_row_count(self.trust.ref_table)
        is_no_data = self.driver.get_exist(self.trust.ref_table+'//h6')
        if ods_table_count == 1 and is_no_data:
            table_no_data_value = self.driver.get_text(self.trust.ref_table + '//h6')
            self.logger.debug(table_no_data_value)
            # verify no data in reference table
            self.assertEqual(table_no_data_value, 'No Series Found')
        else: # after filter, has some data in ods table
            single_source_id_list = self.driver.get_column_value_list(self.trust.ref_table)
            # verify only shows the filter data in ods table
            for x in single_source_id_list:
                self.assertEqual(x, str(single_source_id))
            # verify the mapping path equal the ods table count
            mapping_path_count = self.driver.get_elements_count(self.trust.svg_path.replace('__id__',single_source_id))
            self.assertEqual(ods_table_count,mapping_path_count)
        self.logger.info('finish to execute case :test_07_item_right_click_filter_docs')

    def test_08_item_right_click_delete_dim_trust(self):
        ddl_ods_mapping_status = self.trust.ref_mapping_status_dropdown
        self.driver.select_by_visible_text(ddl_ods_mapping_status, 'Unmapped')
        self.trust.wait_loading()
        self.logger.debug('select Unmapped for ods table')
        row_count = self.driver.get_row_count(self.trust.ref_table)
        if row_count >= 1:
            # get the series key for the first row
            series_key = self.driver.get_cell_value(self.trust.ref_table, column=3)
            #  click the button Add To Dim in row 1
            self.trust.click_cell_on_table(self.trust.ref_table, row=1)
            confirm_popup_exist = self.driver.get_exist(self.trust.confirm_popup_msg)
            if confirm_popup_exist:
                # verify the content of popup msg
                msg = self.driver.get_text(self.trust.confirm_popup_msg)
                self.logger.debug(msg)
                self.assertIn('You are about to insert', msg)
                'verify the mapping add successfully'
                self.trust.click(self.trust.confirm_popup_button.replace('__text__', 'Yes'))
                self.driver.select_by_visible_text(ddl_ods_mapping_status, 'All')
                self.trust.wait_loading()
                # search for the trust id which just mapped in above step
                self.trust.search(series_key, table=self.trust.ref_table, _column_name='SeriesKey')
                # get the single Source id based on the trust Id
                single_source_id = self.driver.get_cell_value(self.trust.ref_table, row=1, column=1)
                self.logger.debug('mapped single source id is: ' + str(single_source_id))
                # search for single source id in Dim table
                self.trust.search(single_source_id, table='master')
                self.trust.wait_loading()
                # verify data added to dim table in UI
                row_count = self.driver.get_row_count(self.trust.master_table)
                self.assertEqual(row_count, 1, msg='data not add to dim table')
                # verify mapping path exist in UI
                self.assertTrue(
                    self.driver.get_exist(self.trust.svg_solid_line_path.replace('__id__', single_source_id)))
                # verify DB that mapping data exist
                db_mapped_sql = str(self.trust.sql_query_col['trust_validate_mapping']).replace('__id__',
                                                                                                single_source_id)
                db_mapped_count = self.sql_helper.execQuery(db_mapped_sql)
                self.assertEqual(db_mapped_count[0][0], 1)
                # verify DB that data added to dim table
                db_added_to_dim_sql = str(self.trust.sql_query_col['trust_dim_data_added_after_mapping']).replace(
                    '__id__', single_source_id)
                db_added_to_dim_count = self.sql_helper.execQuery(db_added_to_dim_sql)
                self.assertEqual(db_added_to_dim_count[0][0], 1)
                '''below is right click for Delete Dim Trust'''
                self.logger.info('right click the cell Single Source Id in first row')
                self.driver.right_click(self.trust.master_table_first_row_cell_3)
                self.trust.click(self.trust.right_click_menu_item.replace('__text__', 'Delete Dim Trust'))
                self.trust.wait_loading()
                del_confirm_popup_exist = self.driver.get_exist(self.trust.confirm_popup_msg)
                if del_confirm_popup_exist:
                    # verify the content of popup msg
                    msg = self.driver.get_text(self.trust.confirm_popup_msg)
                    self.logger.debug(msg)
                    self.assertIn('Do you really want to delete trust '+single_source_id, msg)
                    self.trust.click(self.trust.confirm_popup_button.replace('__text__', 'Yes'))
                    self.trust.wait_loading()
                    # verify data delete from dim table in UI
                    is_no_data = self.driver.get_exist(self.trust.ref_table + '//h6')
                    self.assertTrue(is_no_data)
                    table_no_data_value = self.driver.get_text(self.trust.master_table + '//h6')
                    self.logger.debug(table_no_data_value)
                    self.assertEqual(table_no_data_value, 'No Trusts Found')
                    # verify mapping line delete in UI
                    self.assertFalse(
                        self.driver.get_exist(self.trust.svg_solid_line_path.replace('__id__', single_source_id)))
                    # verify DB that mapping data delete
                    db_mapped_sql = str(self.trust.sql_query_col['trust_validate_mapping']).replace('__id__',
                                                                                                    single_source_id)
                    db_mapped_count = self.sql_helper.execQuery(db_mapped_sql)
                    self.assertEqual(db_mapped_count[0][0], 0)
                    # verify DB that data delete from dim table
                    db_added_to_dim_sql = str(self.trust.sql_query_col['trust_dim_data_added_after_mapping']).replace(
                        '__id__', single_source_id)
                    db_added_to_dim_count = self.sql_helper.execQuery(db_added_to_dim_sql)
                    self.assertEqual(db_added_to_dim_count[0][0], 0)


if __name__ == "__main__":
    unittest.main()
