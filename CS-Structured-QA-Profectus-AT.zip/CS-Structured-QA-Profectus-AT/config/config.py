'''
Created on May 16, 2019

@author: Chester
'''

import os
from helper.common import Common

DOWNLOAD_PATH = r'C:\Download'
if not os.path.exists(r'C:\Download'):
    os.makedirs(r'C:\Download')

QA_URL = 'http://singlesourceqa/'
QA_URL_BK = 'http://singlesourceqa.analytics.moodys.net/'
PROD_URL = 'http://singlesource/'
PROD_URL_BK = 'http://singlesource.analytics.moodys.net/'

TRUST_EDIT_URL = 'http://anv-lxconweb301/home/trusts/trust-edit/'

USER_DICT = {
    "kalan": "kalan",
}

MAX_WAITING_TIME = 300
DEFAULT_WAITING_TIME = 180
MIN_WAITING_TIME = 30

TEST_DATA_FILE = Common.get_file_path('./testdata', 'test_data.xlsx', '/..')
EXPECT_DATA_FILE = Common.get_file_path('./testdata', 'expect_data.json', '/..')
SQL_QUERY_FILE = Common.get_file_path('./testdata', 'sql_query.json', '/..')
DEFAULT_DB_INFO = {
    "server": "PTC-WBAFGDB311",
    "username": "ANALYTICS\chenc1",
    "password": "zhw#1FBVo1L",
    "dbname": "MA_PerfSingleSource"
}
