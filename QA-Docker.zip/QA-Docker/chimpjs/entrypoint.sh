#!/bin/bash
x11vnc -forever -usepw -create &
/bin/bash