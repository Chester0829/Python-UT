#!/bin/bash

#mkdir /var/run/sshd

 #create an ubuntu user
PASS=`pwgen -c -n -1 10`
PASS=vagrant
echo "User: u900 Pass: $PASS"
useradd --create-home --shell /bin/bash --user-group --groups adm,sudo u900
echo "u900:$PASS" | chpasswd

/usr/bin/supervisord -c /supervisord.conf

/bin/bash
