#!/bin/bash
echo "when remote this docker container, the user will change to u900!!!"
/usr/bin/supervisord -c /supervisord.conf

/bin/bash
