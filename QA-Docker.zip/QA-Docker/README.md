    QA-Docker
        QA-Docker keeps code and instruction to setup Docker for QA-Automation.
        chimpjs - Ubuntu 16.4 docker image for SFPortal-JS Automation
        centos73 - Centos OS 7.3 docker image for API testing

    Docker files and prebuilt iimage:
        1. The chimpjs:vagrant docker image is used to run SFPortal-JS automation.
        The images has been prebuilt and uploaded to sf1-lgwsawik201.analytics.moodys.net:5000.
        It can be pull down to run automation directly.
            $ sudo docker pull sf1-lgwsawik201.analytics.moodys.net:5000/chimpjs:vagrant
        2. To rebuild the image from scratch, here are the steps:
            $ git pull git@SF1-LGSDWKtst.ANALYTICS.MOODYS.NET:SAVQA/QA-Docker.git
            $ cd ~/Projects/QA-Docker/chimpjs
            $ on target Linux system (tested on Ubuntu and CentOS)
            $ sudo docker build --tag chimpjs:vagrant .
        3. To publish:
            $ sudo docker tag chimpjs:vagrant cs-repository.analytics.moodys.net:5000/chimpjs:vagrant
            $ sudo docker push
        4. The repository have been changed, change from sf1-lgwsawik201.analytics.moodys.net:5000 to cs-repository.analytics.moodys.net:5000
           When you need to update the new repository , you can manual to change /etc/docker/daemon.json -> insecure-registries . 
           Then restart docker service
           And also need to change QA-Vagrant->sys_installDocker.sh file.

    Running SFPortal-JS Automation in Docker:
        Set up ssh access to AWS Docker host, i.e., OAC-LXESALOD301 (10.32.160.38):
        1.  SSH to the AWS Docker host as yourself
            $ ssh <yourself>@<aws-docker>
        2. Post the content of your local ssh public key to the AWS ~/.ssh/authorized_keys.
        This will allow you to ssh in as <yourself>@<aws-docker> without the need of typing password.
        3. Post the content of your local ssh public key to the AWS ~ec2-user/.ssh/authorized_keys.
        This will allow you to ssh in as ec2-user@<aws-docker> in the future.

    Create automation code archive:
    1. On your local PC
        $ export RUN_BRANCH=qa_candidate
        $ cd ~/Projects/SFPortal-JS; git checkout $RUN_BRANCH; git pull; git archive --format zip --output /tmp/SFPortal-JS_$RUN_BRANCH.zip $RUN_BRANCH
        $ cd ~/Projects/testlink-api-client; git checkout master; git pull; git archive --format zip --output /tmp/testlink-api-client_master.zip master
        $ rsync --perms --chmod=a+rwx /tmp/SFPortal-JS_$RUN_BRANCH.zip /tmp/testlink-api-client_master.zip <yourself>@<aws-docker>:/tmp
    2. Restore automation code base on AWS as user ec2-user 
        $ ssh ec2-user@<aws-docker>
        $ export RUN_BRANCH=qa_candidate
        $ rm -rf ~/Projects/SFPortal-JS ~/Projects/testlink-api-client
        $ mkdir -p ~/Projects/SFPortal-JS ~/Projects/testlink-api-client
        $ cd ~/Projects/SFPortal-JS; unzip /tmp/SFPortal-JS_$RUN_BRANCH.zip
        $ cd ~/Projects/testlink-api-client; unzip /tmp/testlink-api-client_master.zip

    Install NVM, Node and global NPM packages
        These steps only need to be installed/run once for the docker run user
        Install NVM
            $ curl --insecure -o- https://raw.githubusercontent.com/creationix/nvm/v0.33.2/install.sh | bash
            souce the new .bashrc or .profile to load the installed NVM path
        Install Node
            $ nvm install v6.11.1
        Install global NPM packages
            $ npm install -g node-gyp
            $ npm install -g java

    Install and rebuild Automation NPM packages
        These steps need to be re-run when the package.json is updated
        To determine:
            $ diff ~/package.json ~/Projects/SFPortal-JS/package.json
        To install and rebuild:
            $ cp ~/Projects/SFPortal-JS/package.json ~
            $ cp ~/Projects/SFPortal-JS/.npmrc ~
            $ cd ~; npm install
            (this could take a long time at first, but it should only be done once per system)
            $ npm rebuild

    Launch Automation
        1. Login to AWS docker host as user ec2-user
            $ ssh ec2-user@<aws-docker>
        2. Run Automation in docker
            This will share ec2-user's file system and env to the Docker container
            The test result will be wirtten back to ec2-user's file system under
                ~/Projects/SFPortal-JS/reports in a sub folder with the latest time stamp: 
            $ sudo docker run -d --rm=true --user=vagrant --privileged \
              -v $HOME/.npmrc:/home/vagrant/.npmrc \
              -v $HOME/.nvm:/home/vagrant/.nvm \
              -v $HOME/node_modules:/home/vagrant/node_modules \
              -v $HOME/Projects:/home/vagrant/Projects \
              -v $HOME/Downloads:/home/vagrant/Downloads  \
              --shm-size 4G \
            chimpjs:vagrant /bin/bash -c ". ~/.profile; cd ~/Projects/SFPortal-JS;
            NODE_ENV=Prod PARALLEL=12 RUNLEVEL=Feature XAUTHORITY=~/.Xauthority 
            SCREENSHOT=1 MOVIE=0 CUCUMBER_REPORT=1 FEATURE_REPORT=0 
            scripts/chimp_auto_v2.sh SanityTest RegModule ABSRMBS CFModule CLOModule CMBSModule"

    Check Automation
        1. Find out the running docker id
            $ sudo docker ps
            identify the docker container by the running command. add --no-trunck option to see the full running command
        2. To check the automation script running log
            $ sudo docker logs -f <docker container id>
        3. To monitor the automation feature runs
            $ cd to ~/Project/SFPortal-JS/reports/<latest directory>
            $ tail -f the any file of interest, i.e., screenshots, movvies, .run files.
            tail -f *.run can come handy. but remember to restart the command to see the new .run files
            present of cucumber-report.html file indicates the automation has completed.

    Retrive Results
        1. As AWS user ec2-user, $ find ~/Projects -type d -exec chmod a+rx {} \;
        2. Identify the result folder in ~/Projects/SFPortal-JS/reports/<target_folder>
        3. From your local PC, cd to ~/Projects/SFPortal-JS/reports
        4. $ rsync -r <yourself>@<aws-docker>:~ec2-user/Projects/SFPortal-JS/reports/<target_folder> .
        5. You can run this command multiple times. It will sync newly updated files

