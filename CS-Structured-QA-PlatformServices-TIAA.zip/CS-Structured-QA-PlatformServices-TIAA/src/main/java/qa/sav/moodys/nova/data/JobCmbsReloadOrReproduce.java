package qa.sav.moodys.nova.data;

import qa.sav.moodys.nova.JobCmbs;

public class JobCmbsReloadOrReproduce extends JobsMultiple{
	//WebDriver driver;
	public JobCmbs originalJob;
	public JobCmbs newJob;
	
	public JobCmbsReloadOrReproduce(JobCmbs originalJob) {		
		// TODO Auto-generated constructor stub
		this.setOriginalJob(originalJob);
		this.setNewjob(new JobCmbs(originalJob.getDriver()));

	}
	
	@Override
	public JobCmbs getOriginalJob() {
		return originalJob;
	}

	
	public void setOriginalJob(JobCmbs originalJob) {
		this.originalJob = originalJob;
	}

	@Override
	public JobCmbs getNewjob() {
		return newJob;
	}

	public void setNewjob(JobCmbs newjob) {
		this.newJob = newjob;
	}
		
}
