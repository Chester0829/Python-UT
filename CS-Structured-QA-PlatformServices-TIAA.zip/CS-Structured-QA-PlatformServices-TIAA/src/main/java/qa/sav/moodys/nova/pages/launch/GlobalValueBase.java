package qa.sav.moodys.nova.pages.launch;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import qa.sav.moodys.nova.pages.PageBase;

public class GlobalValueBase extends PageBase{
	
	@FindBy(id="input-tailPercentageLevel")
	public WebElement tailPercentageLevel;
	
	@FindBy(id="input-optimizationPercentageLevel")
	public WebElement optimizationPercentageLevel;
	
	@FindBy(id="gv-collateral-type")
	public WebElement collateralTypeSelect;
	
	final static String closeGlobalValuePopUpXpath = "//*[@id=\"modal-global-values\"]/div/div/div[1]/button";
	@FindBy(xpath = closeGlobalValuePopUpXpath)
	public WebElement closeGlobalValuePopUp;

	public GlobalValueBase(WebDriver driver) {
		super(driver);
	}

	public String readTailPercentageLevel(){
		String tailPercentage = null;
		tailPercentage = tailPercentageLevel.getAttribute("value");		
		return tailPercentage;
	}
	
	public void setTailPercetageLevel(String tailPercentageLevelValue){
		tailPercentageLevel.clear();
		tailPercentageLevel.sendKeys(tailPercentageLevelValue);
	}
	
	public String readOptimizationPercentageLevel(){
		String optPercentageLevel = null;
		optPercentageLevel= optimizationPercentageLevel.getAttribute("value");
		return optPercentageLevel;
	}
	
	public void setOptimizationPercentageLevel(String optPercentageValue){
		optimizationPercentageLevel.clear();
		optimizationPercentageLevel.sendKeys(optPercentageValue);
	}
	
	public String readCollateralType(){
		String collateralType = null;
		Select selectCollateralType = new Select(collateralTypeSelect);
		collateralType = selectCollateralType.getFirstSelectedOption().getAttribute("value");
		return collateralType;
	}
	
	public void setCollateralType(String collateralType){
		Select selectCollateralType = new Select(collateralTypeSelect);
		selectCollateralType.selectByVisibleText(collateralType);
	}
	
	public void closeGlobalValuePopUp() throws InterruptedException{
		closeGlobalValuePopUp.click();
		waitForAjaxLoaded();
		Thread.sleep(1000);
	}
	
	public void closeGlobalValuePopUp(boolean saveChange){		
		closeGlobalValuePopUp.click();
		if(saveChange){
			try {
				WebDriverWait wait = new WebDriverWait(driver, 2);
				wait.until(ExpectedConditions.alertIsPresent());
				Alert alert = driver.switchTo().alert();
				alert.accept();
			} catch (Exception e) {
				log.warn("no alert pop-up, continue ... ");
			}	
		} else {
			
			try {
				WebDriverWait wait = new WebDriverWait(driver, 2);
				wait.until(ExpectedConditions.alertIsPresent());
				Alert alert = driver.switchTo().alert();
				alert.dismiss();
			} catch (Exception e) {
				log.warn("no alert pop-up, continue ... ");
			}
		}
	}
	
	public void saveChangeIfAlerts(boolean saveChange){
		if(saveChange){
			try {
				WebDriverWait wait = new WebDriverWait(driver, 2);
				wait.until(ExpectedConditions.alertIsPresent());
				Alert alert = driver.switchTo().alert();
				alert.accept();
			} catch (Exception e) {
				log.warn("no alert pop-up, continue ... ");
			}	
		} else {
			
			try {
				WebDriverWait wait = new WebDriverWait(driver, 2);
				wait.until(ExpectedConditions.alertIsPresent());
				Alert alert = driver.switchTo().alert();
				alert.dismiss();
			} catch (Exception e) {
				log.warn("no alert pop-up, continue ... ");
			}
		}
	}


}



