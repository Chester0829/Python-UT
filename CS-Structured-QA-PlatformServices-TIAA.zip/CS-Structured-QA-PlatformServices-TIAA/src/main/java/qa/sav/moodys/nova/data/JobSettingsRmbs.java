package qa.sav.moodys.nova.data;

public class JobSettingsRmbs extends JobSettings {
	boolean useTargeLgd;
	boolean useSystemBookPrice;
	public String horizon;
	
	
	public boolean isUseTargeLgd() {
		return useTargeLgd;
	}
	public void setUseTargeLgd(boolean useTargeLgd) {
		this.useTargeLgd = useTargeLgd;
	}
	public boolean isUseSystemBookPrice() {
		return useSystemBookPrice;
	}
	public void setUseSystemBookPrice(boolean useSystemBookPrice) {
		this.useSystemBookPrice = useSystemBookPrice;
	}
	public String getHorizon() {
		return horizon;
	}
	public void setHorizon(String horizon) {
		this.horizon = horizon;
	}	
	
}
