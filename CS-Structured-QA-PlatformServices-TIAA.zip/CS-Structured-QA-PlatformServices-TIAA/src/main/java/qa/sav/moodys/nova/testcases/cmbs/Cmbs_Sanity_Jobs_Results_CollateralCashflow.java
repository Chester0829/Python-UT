package qa.sav.moodys.nova.testcases.cmbs;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.pages.jobResult.CollateralCashflowsCmbs;
import qa.sav.moodys.nova.pages.jobResult.JobResultCmbs;
import qa.sav.moodys.nova.pages.jobResult.OverviewCmbs;
import qa.sav.moodys.nova.testLogic.TestAsserts;

public class Cmbs_Sanity_Jobs_Results_CollateralCashflow extends Cmbs_Sanity_Jobs_Base{
	
	@Test(groups="job_submit_cmbs_results", dataProvider="cmbs_sanity_jobs_and_cusips",priority=6, description="job results sanity check - collateral cashflows")
	public void check_cmbs_sanity_job_results_collateral_cashflow(String jobName, String cusip) throws Exception{
		JobCmbs job = new JobCmbs(initialNewDriver(), this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		CollateralCashflowsCmbs collCashflow = cmbsResult.getCollateralCashflowInstance(job.driver);
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		
		try{
			collCashflow.selectToCusip(cusip);
			Assert.assertTrue(collCashflow.scenarioText.getText().equals("Scenario:"), "Verify the scenario list title is showing");
			Assert.assertTrue(collCashflow.cusipText.getText().equals("CUSIP:"),"Verify the cusip list title is displaying");
			//System.out.println(collCashflow.collateralCashflowTitleText.getText());
			Assert.assertTrue(collCashflow.collateralCashflowTitleText.getText().equals("COLLATERAL CASHFLOW")
					, "Verify the collateral cashflow title is \"COLLATERAL CASHFLOW\"");
			
			for(String scen:scenariosList){
				Reporter.log("Verify the collateral cashflow headers are displaying as predefined: " + Arrays.toString(collCashflow.cashflowFields));
				Assert.assertTrue(Arrays.toString(collCashflow.getcashflowHearderFieldsByScenarioAndCusip(scen, cusip)).equals(Arrays.toString(collCashflow.cashflowFields))
						, "Verify the collateral cashflow headers are displaying as predefined: " + collCashflow.getcashflowHearderFieldsByScenarioAndCusip(scen, cusip));
				Assert.assertTrue(Float.parseFloat(collCashflow.getTotalAmortizedAmountByScenarioAndCusip(scen, cusip).replaceAll(",", "")) > 0
						, "Verify the total amortize amout is greater then 0");
				Assert.assertTrue(Float.parseFloat(collCashflow.getTotalInterstPaymentByScenarioAndCusip(scen, cusip).replaceAll(",", "")) > 0
						, "Verify the total amortize amout is greater then 0");
				Assert.assertTrue(collCashflow.getCashflowSizeByScenarioAndCusip(scen, cusip)>1
						,"Verify Collateral cashflow size is greater then 2");
				
				String dealUpdatedDate[] = collCashflow.getDealUpdatedDateByScenarioAndCusip(scen, cusip).split("-");
				String asOfDate[] = job.getJobSettings().getAsOfDate().split("-");
				String firstPaymentDate[] = collCashflow.getFirstPayDateByScenarioAndCusip(scen, cusip).split("-");
				LocalDate date1 = LocalDate.of(Integer.parseInt(dealUpdatedDate[0]), Integer.parseInt(dealUpdatedDate[1]), 1);
		        LocalDate date2 = LocalDate.of(Integer.parseInt(asOfDate[0]), Integer.parseInt(asOfDate[1]), 1);
		        LocalDate date3 = LocalDate.of(Integer.parseInt(firstPaymentDate[0]), Integer.parseInt(firstPaymentDate[1]), 1);
				Assert.assertTrue((date2.plusMonths(1).isEqual(date3)), "Verify first payment date is 1 month later then as of date");	
		        Assert.assertTrue(date1.isEqual(date2)||date1.isBefore(date2), "Verify deal updated date is equal to or before as of date");			
			}		
				
		} catch(Exception ex) {
			throw ex;
		} finally{		
			quitDriver(job.driver);
			quitDriver(cmbsResult.jobCmbs.driver);
		}
	}

}
