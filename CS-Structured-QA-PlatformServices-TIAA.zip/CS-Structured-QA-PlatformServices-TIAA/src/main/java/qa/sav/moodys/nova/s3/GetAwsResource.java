package qa.sav.moodys.nova.s3;

import java.io.File;
import java.util.List;

import org.testng.annotations.Test;

import qa.sav.moodys.nova.utils.ZipUtilSav;

public class GetAwsResource {
	
	SimpleStoreHandlerImpl getAwsResource = new SimpleStoreHandlerImpl();
	
	public File downLoadJobResult(String jobId){
		
		String bucketName = (new Config()).getProperty("awsQaBucket");
		String jobResultPrefix = (new Config()).getProperty("awsJobResultsPrefix");
		//System.out.println("job result prefix: "+ jobResultPrefix);
		String fileName = "1-testJob.zip";
		String filePathLocal = (new Config()).getProperty("localJobResultPrefix")+jobId+"\\AWS\\";
		String key = filePathLocal+fileName;
		
		List<StoreObjectSummary> jobResultList = this.getAwsResource.listObjects(bucketName, jobResultPrefix);
		
		//System.out.println("output file name: "+ jobResultList.size());
		
		for(int i = 0; i < jobResultList.size(); i++){
			key = jobResultList.get(i).getKey();	
			if(key.split("/")[key.split("/").length-1].startsWith(jobId+"-")){
				fileName = key.split("/")[key.split("/").length-1]; 
				break;
			}
		}
				
		File file = new File(filePathLocal+"\\\\"+fileName);
		//System.out.println("fileName: "+file.getName());
		//System.out.println("key: "+key);
		this.getAwsResource.downloadObjectToFile(bucketName, key, file);
		ZipUtilSav.unzip(file, file.getParent());
		return file;		
	}
	
public File downLoadJobResult(String jobId, String jobName){
		
		String bucketName = (new Config()).getProperty("awsQaBucket");
		String jobResultPrefix = (new Config()).getProperty("awsJobResultsPrefix");
		System.out.println("job result prefix: "+ jobResultPrefix);
		String fileName = "1-testJob.zip";
		String filePathLocal = (new Config()).getProperty("localJobResultPrefix")+jobId+"\\AWS\\";
		String filePathAws = "sav-tiaa/exported-job-result/";
		String key = filePathLocal+fileName;
		
//		List<StoreObjectSummary> jobResultList = this.getAwsResource.listObjects(bucketName, jobResultPrefix);
		
//		for(int i = 0; i < jobResultList.size(); i++){
//			key = jobResultList.get(i).getKey();	
//			if(key.split("/")[key.split("/").length-1].startsWith(jobId+"-")){
//				fileName = key.split("/")[key.split("/").length-1]; 
//				break;
//			}
//		}
		
		fileName = jobId+"-"+jobName+".zip";
		key = filePathAws+fileName;
		System.out.println("output file name: "+ fileName);
		System.out.println("output key name: "+ key);
		
		File file = new File(filePathLocal+"\\\\"+fileName);
		this.getAwsResource.downloadObjectToFile(bucketName, key, file);
		ZipUtilSav.unzip(file, file.getParent());
		return file;		
	}
			
	@Test
	public void tttTest(){
//		System.out.println(this.downLoadJobResult("1001").getPath());
		System.out.println(this.downLoadJobResult("6432","reproduce").getPath());
	}
}
