package qa.sav.moodys.nova.testcases.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.ConfigurationSource;
import org.apache.logging.log4j.core.config.Configurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import qa.sav.moodys.nova.deprecated.ScreenShot;

public class TestBase {	
	   
    public static Properties env = null;
    public static Properties data = null;
    public static Properties config = null;
    public static FileInputStream inputFile = null;
    public static Logger log = null;
	
	private static boolean isInitialized = false;
	
	public static ScreenShot screenShot = null;
	
	public static WebDriver driver = null;	
	
	// log4j configuration file location 
	private static final String LOG4J_XML_NAME =  System.getProperty("user.dir")+ File.separator + "config" + File.separator+"log4j2.xml";
	
	
	protected TestBase(){
		
		if(!isInitialized){
			initialLogger();
			initialConfig();
			initialDriver();
			initialScreenShot();
		}			
	}
	
	
	private static void initialScreenShot(){
		if(screenShot == null){
			log.info("Initializing Screen Shot folder ... ");
			screenShot = new ScreenShot(driver, System.getProperty("user.dir")+ File.separator + "test-result" + File.separator+ "screen_shot");
		}
	}
	
	private static void initialConfig(){
		
		if(config == null){
			
			try{
				
				log.info("Initializing configuration ... ");
	
				//Initialise environment properties file
				env = new Properties();
				String fileName = "env"+".properties";
				inputFile = new FileInputStream(System.getProperty("user.dir")+ File.separator + "config" + File.separator+ fileName);		
				env.load(inputFile);
				log.info("Environment = "+ env.getProperty("Environment"));
	
				//Initialise configuration properties file
				config = new Properties();
				fileName = "config_" + env.getProperty("Environment")+ ".properties";
				String path = System.getProperty("user.dir") + File.separator+ "config" + File.separator + fileName;
				inputFile = new FileInputStream(path);
				config.load(inputFile);
				log.info("Config file initialized for environment = "+ env.getProperty("Environment"));
	
				//Initialise data properties file
				data = new Properties();
				fileName = "data_" + env.getProperty("Environment")+ ".properties";
				path = System.getProperty("user.dir") + File.separator+ "config" + File.separator + fileName;
				inputFile = new FileInputStream(path);
				data.load(inputFile);
				log.info("Data file initialized for environment = "+ env.getProperty("Environment"));							
			} 
			
			catch(FileNotFoundException e) {
				e.printStackTrace();
			}
			
			catch (IOException e) {
				e.printStackTrace();
			}
			
		}
	}
	
	protected static void initialDriver(){
		if(driver == null){
			log.info("Initializing WebDriver ...");
			String browser = config.getProperty("browser");
			if(browser == "FIREFOX"){
				
			}
			else if(browser == "IE"){
				
			} 
			else{
				log.info("Starting Chrome Driver ... ");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")
						+ File.separator+"driver"+File.separator+"chromedriver.exe");
				String downloadFilepath = System.getProperty("user.dir")+config.getProperty("downloadDir");
				HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
				chromePrefs.put("profile.default_content_settings.popups", 1);
				chromePrefs.put("download.default_directory", downloadFilepath);
				ChromeOptions options = new ChromeOptions();
				options.setExperimentalOption("prefs", chromePrefs);
//				DesiredCapabilities cap = DesiredCapabilities.chrome();
//				cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
//				cap.setCapability(ChromeOptions.CAPABILITY, options);
				//WebDriver driver = new ChromeDriver(cap);				
				driver = new ChromeDriver(options);
			}			
		}		
	}
	
	public static WebDriver initialNewDriver(){
		log.info("generating extral WebDriver ...");
		WebDriver newDriver = null;
		if(newDriver == null){
			log.info("Initializing extral WebDriver ...");
			String browser = config.getProperty("browser");
			if(browser == "FIREFOX"){
				
			}
			else if(browser == "IE"){
				
			} 
			else{
				log.info("Starting Chrome Driver ... ");
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")
						+ File.separator+"driver"+File.separator+"chromedriver.exe");
				String downloadFilepath = System.getProperty("user.dir")+config.getProperty("downloadDir");
				HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
				chromePrefs.put("profile.default_content_settings.popups", 1);
				chromePrefs.put("download.default_directory", downloadFilepath);
				ChromeOptions options = new ChromeOptions();
				options.setExperimentalOption("prefs", chromePrefs);
//				DesiredCapabilities cap = DesiredCapabilities.chrome();
//				cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
//				cap.setCapability(ChromeOptions.CAPABILITY, options);
				//WebDriver driver = new ChromeDriver(cap);				
				newDriver = new ChromeDriver(options);
			}			
		}	
		return newDriver;
	}
	
	
	public static void initialLogger(){
		
	    try{
	    	
	    	System.out.println("Initializing logger ... ");
	    	ConfigurationSource source = new ConfigurationSource(new FileInputStream(LOG4J_XML_NAME));
	    	File config=new File(LOG4J_XML_NAME);
			source = new ConfigurationSource(new FileInputStream(config),config);
			String path= LOG4J_XML_NAME;
			source = new ConfigurationSource(new FileInputStream(path),new File(path).toURL());
			Configurator.initialize(null, source);                
			log = LogManager.getLogger("");     // need to be confirm
		
	    } catch (Exception e) {
	    	
	    	System.out.println("Failed to initialize log4j file ... ");
			e.printStackTrace();
		
	    }    	    
	}
	
	public static void quitDriver() {
		driver.quit();
		driver = null;
		log.info("Closing Browser.");
	}
	
	public static void quitDriver(WebDriver extralDriver) {
		extralDriver.quit();
		extralDriver = null;
		log.info("Closing extral Browser.");
	}

}
