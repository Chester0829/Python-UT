package qa.sav.moodys.nova.s3;

import java.util.Date;

/**
 * Contains the summary of an object stored in an Amazon S3 bucket. This object
 * doesn't contain contain the
 * object's full metadata or any of its contents.
 * 
 * @see StoreObject
 */
public class StoreObjectSummary {

    /** The name of the bucket in which this object is stored */
    protected String bucketName;

    /** The key under which this object is stored */
    protected String key;

    /** Hex encoded MD5 hash of this object's contents, as computed by Amazon S3 */
    protected String eTag;

    /** The size of this object, in bytes */
    protected long size;

    /** The date, according to Amazon S3, when this object was last modified */
    protected Date lastModified;
    
    /**
     * The owner of this object - can be null if the requester doesn't have
     * permission to view object ownership information
     */
    protected String owner;


    /**
     * Gets the name of the Amazon S3 bucket in which this object is stored.
     * 
     * @return The name of the Amazon S3 bucket in which this object is stored.
     * 
     * @see StoreObjectSummary#setBucketName(String)
     */
    public String getBucketName() {
        return bucketName;
    }

    /**
     * Sets the name of the Amazon S3 bucket in which this object is stored.
     * 
     * @param bucketName
     *            The name of the Amazon S3 bucket in which this object is
     *            stored.
     *            
     * @see StoreObjectSummary#getBucketName()          
     */
    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    /**
     * Gets the key under which this object is stored in Amazon S3.
     * 
     * @return The key under which this object is stored in Amazon S3.
     * 
     * @see StoreObjectSummary#setKey(String)
     */
    public String getKey() {
        return key;
    }

    /**
     * Sets the key under which this object is stored in Amazon S3.
     * 
     * @param key
     *            The key under which this object is stored in Amazon S3.
     *            
     * @see StoreObjectSummary#getKey()          
     */
    public void setKey(String key) {
        this.key = key;
    }

    /**
     * Gets the hex encoded 128-bit MD5 hash of this object's contents as
     * computed by Amazon S3.
     * 
     * @return The hex encoded 128-bit MD5 hash of this object's contents as
     *         computed by Amazon S3.
     *         
     * @see StoreObjectSummary#setETag(String)       
     */
    public String getETag() {
        return eTag;
    }

    /**
     * Sets the hex encoded 128-bit MD5 hash of this object's contents as
     * computed by Amazon S3.
     * 
     * @param eTag
     *            The hex encoded 128-bit MD5 hash of this object's contents as
     *            computed by Amazon S3.
     *            
     * @see StoreObjectSummary#getETag()             
     */
    public void setETag(String eTag) {
        this.eTag = eTag;
    }

    /**
     * Gets the size of this object in bytes.
     * 
     * @return The size of this object in bytes.
     * 
     * @see 3ObjectSummary#setSize(long)
     */
    public long getSize() {
        return size;
    }

    /**
     * Sets the size of this object in bytes.
     * 
     * @param size
     *            The size of this object in bytes.
     *            
     * @see StoreObjectSummary#getSize()           
     */
    public void setSize(long size) {
        this.size = size;
    }

    /**
     * Gets the date when, according to Amazon S3, this object
     * was last modified.
     * 
     * @return The date when, according to Amazon S3, this object
     *         was last modified.
     *         
     * @see StoreObjectSummary#setLastModified(Date)
     */
    public Date getLastModified() {
        return lastModified;
    }

    /**
     * Sets the date, according to Amazon S3, this object
     * was last modified.
     * 
     * @param lastModified
     *            The date when, according to Amazon S3, this object
     *            was last modified.
     *            
     * @see StoreObjectSummary#getLastModified()          
     */
    public void setLastModified(Date lastModified) {
        this.lastModified = lastModified;
    }

    /**
     * Gets the owner of this object. Returns <code>null</code> 
     * if the requester doesn't have
     * {@link Permission#ReadAcp} permission for this object or owns the bucket
     * in which it resides.
     * 
     * @return The owner of this object. Returns <code>null</code> 
     *         if the requester doesn't have
     *         permission to see object ownership.
     *         
     * @see StoreObjectSummary#setOwner(Owner)        
     */
    public String getOwner() {
        return owner;
    }

    /**
     * Sets the owner of this object.
     * 
     * @param owner
     *            The owner of this object.
     *            
     * @see StoreObjectSummary#getOwner()                   
     */
    public void setOwner(String owner) {
        this.owner = owner;
    }

}
