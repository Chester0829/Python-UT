package qa.sav.moodys.nova.s3;

public class StringUtils {
	public static boolean isNotEmpty(String value) {
		if (value != null && !value.trim().isEmpty()) {
			return true;
		} else {
			return false;
		}
	}
}



