package qa.sav.moodys.nova.utils;

import java.io.*;
import java.util.Enumeration;
import java.util.zip.*;

import org.testng.annotations.Test;

public class ZipUtilSav {
	static final int BUFFER = 2048;
	public static void zip() {
//		try {
//			BufferedInputStream origin = null;
//			FileOutputStream dest = new 
//			FileOutputStream("c:\\zip\\myfigs.zip");
//			ZipOutputStream out = new ZipOutputStream(new 
//			BufferedOutputStream(dest));
//			//out.setMethod(ZipOutputStream.DEFLATED);
//			byte data[] = new byte[BUFFER];
//			// get a list of files from current directory
//			File f = new File(".");
//			String files[] = f.list();
//	
//			for (int i=0; i<files.length; i++) {
//				System.out.println("Adding: "+files[i]);
//	            FileInputStream fi = new 
//	            FileInputStream(files[i]);
//	            origin = new BufferedInputStream(fi, BUFFER);
//	            ZipEntry entry = new ZipEntry(files[i]);
//	            out.putNextEntry(entry);
//	            int count;
//	            while((count = origin.read(data, 0, 
//	              BUFFER)) != -1) {
//	            	out.write(data, 0, count);
//	            }
//	            origin.close();
//	        }
//	        out.close();
//	     } catch(Exception e) {
//	         e.printStackTrace();
//	     }
	 }

	public static void unzip(File inputFile, String outputDir){
		try {	         
	         BufferedInputStream ins = null;
	         ZipEntry entry;
	         ZipFile zipfile = new ZipFile(inputFile.getPath());	         
	         Enumeration e = zipfile.entries();
	         while(e.hasMoreElements()) {
	            entry = (ZipEntry) e.nextElement();
	            System.out.println("Extracting: " +entry);
	            ins = new BufferedInputStream(zipfile.getInputStream(entry));
	            int count;
	            byte data[] = new byte[BUFFER]; 
	            File newFile = new File(outputDir+"\\"+entry.getName());
	            FileOutputStream unzipOutput = new FileOutputStream(newFile);
	            while ((count = ins.read(data, 0, BUFFER)) 
	              != -1) {	            	
	            	unzipOutput.write(data, 0, count);
	            }	            
	            unzipOutput.flush();
	            unzipOutput.close();	           
	            ins.close();	            
	         }
	         zipfile.close();
	      } catch(Exception e) {
	         e.printStackTrace();
	      } 
	} 

	@Test
	public void tttTest(){
		ZipUtilSav.unzip(new File("C:\\TIAA\\AUTO\\727\\AWS\\727-auto_cmbs_20151228200202.zip"),"C:\\TIAA\\AUTO\\727\\");
	}
}
