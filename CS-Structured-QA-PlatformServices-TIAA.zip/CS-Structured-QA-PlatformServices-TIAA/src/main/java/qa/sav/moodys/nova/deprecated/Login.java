package qa.sav.moodys.nova.deprecated;

import junit.framework.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import qa.sav.moodys.nova.pages.PageBase;


public class Login extends PageBase{	
		
	public static String url = null;
	public static String user = null;
	public static String pwd = null;
	
	public Login(WebDriver driver){	
		super(driver);
	}

	protected void accessLoginPage(){
			
		Log.info("Login to "+ url); 
		driver.get(url);
		try {
			MyWebDriverProcessor.waitForAjaxLoad(driver);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Log.info("Maximal current browser windows");
		driver.manage().window().maximize();
	}

//	public void testLoginPage(WebDriver driver) throws Exception{
//		
//		this.accessLoginPage(driver);
//		System.out.println("test login page...");
//		
//		// checking the default status of the login page ...
//		Assert.assertEquals(true, driver.findElement(By.id("login")).isDisplayed());
//		Assert.assertEquals("Sign in",  driver.findElement(By.xpath("//*[@id='login']/h1")).getText());
//		Assert.assertEquals(true,  driver.findElement(By.id("username")).isEnabled());
//		Assert.assertEquals(true,  driver.findElement(By.id("password")).isEnabled());
//		Assert.assertEquals(false,  driver.findElement(By.id("localAuthon")).isSelected());
//		
//		driver.findElement(By.id("username")).clear();
//        driver.findElement(By.id("password")).clear();
//		this.driver.findElement((By.xpath("//*[@id='login']/div[5]/input[2]"))).click();
//		Assert.assertEquals("http://54.218.37.255:8080/sf-simulation/login", driver.getCurrentUrl());
//		
//		this.driver.findElement(By.id("username")).sendKeys("auto");
//		this.driver.findElement((By.xpath("//*[@id='login']/div[5]/input[2]"))).click();		
//		Assert.assertEquals("http://54.218.37.255:8080/sf-simulation/login", driver.getCurrentUrl());
//				
//		this.driver.findElement(By.id("password")).sendKeys("1234");
// 
//		this.driver.findElement((By.xpath("//*[@id='login']/div[5]/input[2]"))).click();
// 
//		Assert.assertEquals(true,driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*Login failed.*[\\s\\S]*"));
//		
//		this.driver.findElement(By.id("password")).sendKeys("1234");
//		this.driver.findElement(By.id("localAuthon")).click();
//		this.driver.findElement((By.xpath("//*[@id='login']/div[5]/input[2]"))).click();
//		Assert.assertEquals(true,driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*Login failed. The username or password is not correct!*[\\s\\S]*"));
//		
// 
//	}
	
	
	public void loginToDashboard(WebDriver driver) throws Exception {
		
		/*
		 * login to qa site
		 */
		
		this.accessLoginPage();
        
        driver.findElement(By.id("username")).clear();
        driver.findElement(By.id("username")).sendKeys(user);
        driver.findElement(By.id("password")).clear();
        driver.findElement(By.id("password")).sendKeys(pwd);
        driver.findElement(By.id("localAuthon")).click();
        driver.findElement(By.id("login")).submit();
        MyWebDriverProcessor.waitForAjaxLoad(driver);
        Log.info("Login to Dashborad...");
        Assert.assertEquals("http://54.218.37.255:8080/sf-simulation/dashboard", driver.getCurrentUrl().split(";")[0]);         
       
        Thread.sleep(1000);	
	}
	
	
//	public void testLogin() throws Exception{
//		this.driver = new BrowserProperty().getDriver();
//		this.testLoginPage(this.driver);	
//		this.loginToDashboard(this.driver);
//		ScreenShotUtil screenShot = new ScreenShotUtil();
//        screenShot.setDriver(driver);
//        screenShot.getScreenshot(driver);
//		this.driver.close();
//	}
	
}	

	
