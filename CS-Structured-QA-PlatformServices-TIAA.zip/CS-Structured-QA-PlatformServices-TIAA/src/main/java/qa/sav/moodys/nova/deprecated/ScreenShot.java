package qa.sav.moodys.nova.deprecated;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.apache.logging.log4j.Logger;

import qa.sav.moodys.nova.testcases.base.TestCaseBase;

/**
 * 
 * @version 1.0
 * @since 2017/11/12
 * @author QinS
 *
 */

public class ScreenShot {
	
	public WebDriver driver;
	public String screenShotPath;
	private static Logger log = TestCaseBase.log;
	
	public ScreenShot(WebDriver driver, String screenShotPath){
		setDriver(driver);
		setScreenShotPath(screenShotPath);
	}

	public String getScreenshotSavePath() {
		String packageName = this.getClass().getPackage().getName();
		File dir = new File(System.getProperty("user.dir")+File.separator+"screenshot"+File.separator + packageName + File.separator);
		dir.mkdirs();
		return dir.getAbsolutePath();
	}

	public String getScreenshotSavePath(String screenShotPath) {
		//String packageName = this.getClass().getPackage().getName();
		//File dir = new File(screenShotPath+File.separator+"screenshot"+File.separator + packageName + File.separator);
		File dir = new File(screenShotPath+File.separator);
		dir.mkdirs();
		return dir.getAbsolutePath();
	}

	/**
	 * Take Screenshot on failure.
	 */
	public void getScreenshot(WebDriver driver, String url) {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		String date = sdf.format(new Date());
		//String url = driver.getCurrentUrl().replaceAll("[\\/:*\\?\"<>\\|]", "_").replaceAll("___", "_");
		//String url =  getClass().getSimpleName();
		String ext = ".png";
		String path = getScreenshotSavePath(screenShotPath) + File.separator + date + "_" + url + ext;

		
		if (driver instanceof TakesScreenshot) {
			File tmpFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				org.openqa.selenium.io.FileHandler.copy(tmpFile, new File(path));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			log.error("Captured Screenshot for Failure: "+path);
			
		}
		
	}

	
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public String getScreenShotPath() {
		return screenShotPath;
	}

	public void setScreenShotPath(String screenShotPath) {
		this.screenShotPath = screenShotPath;
	}
}
