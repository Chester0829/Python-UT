package qa.sav.moodys.nova.pages.launch;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GlobalValueRmbs extends GlobalValueBase{	
	

	@FindBy(id="modal-global-values")
	WebElement globalValuePopUp;
	
	@FindBy(id="input-pdMultiplier")
	public WebElement pdMultiplier;
	
	@FindBy(id="input-prepayMultiplier")
	public WebElement prepayMultiplier;
	
	@FindBy(id="input-lgdMultiplier")
	public WebElement lgdMultiplier;
	
	@FindBy(id="input-pdCap")
	public WebElement pdCap;
	
	@FindBy(id="input-prepayCap")
	public WebElement prepayCap;
	
	@FindBy(id="input-lgdCap")
	public WebElement ldgCap;
	
	@FindBy(id="input-pdFloor")
	public WebElement pdFloor;
	
	@FindBy(id="input-prepayFloor")
	public WebElement prepayFloor;
	
	@FindBy(id="input-lgdFloor")
	public WebElement ldgFloor;
	
	@FindBy(id="input-ltvOffset")
	public WebElement ltvOffset;
	
	@FindBy(id="input-ficoOffset")
	public WebElement ficoOffset;
	
	@FindBy(id="input-delinqPd30")
	public WebElement thirtyDayDelinq;
	
	@FindBy(id="input-delinqPd60")
	public WebElement sixtyDayDelinq;
	
	@FindBy(id="input-bookPrice")
	public WebElement bookPrice;
	
	@FindBy(id="input-insuranceCoveragePct")
	public WebElement insuranceCoverage;
		
		
	final static String disableServerityCapXpath = "//*[@id=\"chk-disable-caps\"]";
	@FindBy(xpath = disableServerityCapXpath)
	public WebElement disableServerityCap;

	final static String importXpath = "//*[@id=\"modal-global-values\"]/div/div/div[3]/label";
	@FindBy(xpath = importXpath)
	public WebElement importGlobalValues;
	
	final static String exportXpath = "//*[@id=\"export-global-values\"]";
	@FindBy(xpath = exportXpath)
	public WebElement exportGlobalValues;
	
	final static String saveChangeXpath = "//*[@id=\"btn-save-global-values\"]";
	@FindBy(xpath = saveChangeXpath)
	public WebElement saveChange;
	
	final static String applyChangeXpath = "//*[@id=\"modal-global-values\"]/div/div/div[3]/button[3]";
	@FindBy(xpath = applyChangeXpath)
	public WebElement applyChange;
	
	public GlobalValueRmbs(WebDriver driver) throws Exception{
		super(driver);	
		try{
			if(globalValuePopUp.isDisplayed()){
				//do nothing
			} else {
				new LaunchRmbs(driver).openGlobalValueDashboard();
			}
		}catch(Exception e){
			new LaunchRmbs(driver).openGlobalValueDashboard();
		}
	}
			
	public void importGlobalValue(String importFilePath) throws Exception{
		importGlobalValues.click();
		autoItUploadFile(importFilePath);
	}
	
	public String exportGlobalValue(String exportFilePath) throws Exception{
		File file = null;
		try {
			file = downloadFile(driver.findElement(By.xpath(exportXpath)), new File(exportFilePath));
		} catch (Exception e) {
			log.error("Failed to download RMBS sample portfolio file");
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		return file.getName();
	}
	
	public void saveChange(){
		saveChange.click();
	}
	
	public void applyChange() throws Exception{
		applyChange.click();
		waitForAjaxLoaded();
		Thread.sleep(1000);
	}		
	
	public void setDisableServerityCap(boolean disableServerity){
		if(disableServerity){
			if(disableServerityCap.isSelected()){
				//do nothing
			} else{
				disableServerityCap.click();
			}
		} else {
			if(disableServerityCap.isSelected()){
				disableServerityCap.click();
			} else{
				// do nothing
			}				
		}
	}
	
	public boolean readIsDisableServerityCap(){
		return disableServerityCap.isSelected();
	}		
	
}
