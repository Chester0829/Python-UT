package qa.sav.moodys.nova.utils;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.supercsv.io.CsvListReader;
import org.supercsv.io.CsvListWriter;
import org.supercsv.prefs.CsvPreference;
import org.testng.annotations.Test;

/**
 * 
 * @author QinS
 * @since 2017/11/23
 * 
 */

public class CsvUtils_Map {
	
	public HashMap<String, String> mapJobResultToKeyValue(String inputCsvFile) throws IOException{
		
		HashMap<String, String> jobResultMap = new HashMap<String, String>();
		
		String outputFile = inputCsvFile.replace(".csv", "_") + "Out.csv";
		
		CsvListReader reader = new CsvListReader(new FileReader(inputCsvFile), CsvPreference.STANDARD_PREFERENCE);
		CsvListWriter writer = new CsvListWriter(new FileWriter(outputFile), CsvPreference.STANDARD_PREFERENCE);
		
		List<String> columns = null;
					
		String key = null;
		String value = null;
		int size = 0;
		int i = 0;
		
		while((columns = reader.read())!=null){
			
			size = columns.size();
			key = columns.get(0);
			
			for(i = 1; i < 3; i++){
				key = key+ "," + columns.get(i) ;
			}
			
			value = columns.get(3);
			
			for(i = 4; i < size; i++){
				value = value + "," + columns.get(i);
			}
			
			jobResultMap.put(key, value);
			
		}		
		
		reader.close();
		writer.close();
		
		return jobResultMap;
		
	}
		
	
	@Test
	public void main() throws IOException{
		HashMap<String, String> map = this.mapJobResultToKeyValue("C:\\TIAA\\AUTO\\5425\\AWS\\TrancheCashFlows.csv");
		for(String key : map.keySet()){
			System.out.println(key);
			System.out.println(map.get(key));
		}
		
	}
}
