package qa.sav.moodys.nova.testcases.cmbs;

import java.util.ArrayList;
import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.pages.jobResult.JobResultCmbs;
import qa.sav.moodys.nova.pages.jobResult.OverviewCmbs;

public class Cmbs_Sanity_Jobs_Results_CompareBench_Overview extends Cmbs_Sanity_Jobs_Base{

	@Test(groups="job_submit_cmbs_compare2bench", dataProvider="cmbs_sanity_jobs_and_cusips",priority=6, description="compare job resutls to benchmark - overview")
	public void compare_cmbs_sanity_job_results_to_benchmark_Overview(String jobName, String cusip) throws Exception{
		
		JobCmbs job = new JobCmbs(initialNewDriver(), this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		OverviewCmbs overview = cmbsResult.getOverviewInstance(job.driver);
		
		String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
		JobCmbs jobBench = this.getBenchJob(initialNewDriver(), benchJobNameType);

		JobResultCmbs cmbsResultBench = jobBench.getResult();
		OverviewCmbs overviewBench = cmbsResultBench.getOverviewInstance(jobBench.driver);
				
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		
		try{
			overview.selectToCusip(cusip);
			for(String scen:scenariosList){
				overview.selectToScenario(scen);
				overviewBench.selectToCusip(cusip);
				overviewBench.selectToScenario(scen);
				
				String profileTabContent = overview.profileTable.getText()
						.replaceAll("[\\d]{4}[-]+[\\d]{2}[-]+[\\d]{2}[a-zA-Z]+[\\d]{2}:[\\d]{2}:[\\d]{2}","");
				String profileTabContentBench = overviewBench.profileTable.getText()
						.replaceAll("[\\d]{4}[-]+[\\d]{2}[-]+[\\d]{2}[a-zA-Z]+[\\d]{2}:[\\d]{2}:[\\d]{2}","");
				Assert.assertEquals(profileTabContent, profileTabContentBench, "Verify overveiw >> profile table content is the same between test and bench job");
				
				String summaryTabContent = overview.summaryTable.getText();
				String summaryTabContentBench = overview.summaryTable.getText();
				Assert.assertEquals(summaryTabContent, summaryTabContentBench, "Verify overview >> summary table content is the same between test and bench job");			
			}
			
		} catch (Exception ex){
			throw ex;
		} finally {
			quitDriver(job.driver);
			quitDriver(jobBench.driver);
			quitDriver(cmbsResult.jobCmbs.driver);
			quitDriver(cmbsResultBench.jobCmbs.driver);
		}
	}
	
}
