package qa.sav.moodys.nova.deprecated;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.testcases.base.TestCaseBase;

public class MyWindowsInteractor extends TestCaseBase {

	public static void autoItUploadFile(String filePath) throws Exception{
	
		String scriptCmdDir = System.getProperty("user.dir") + config.getProperty("autoItScriptDir")+"uploadFile.exe";
		String filePathFull = filePath;
		
		Process process = Runtime.getRuntime().exec(scriptCmdDir +" "+ filePathFull);
		process.waitFor();
		process.destroy();
		System.out.println("File "+filePathFull+ " uploaded succesfully!");
	}
	
	public static File autoItExportFile(String filePath) throws Exception{
		String scriptCmdDir = System.getProperty("user.dir") + (config).getProperty("autoItScriptDir")+"exportCsv.exe";
		String filePathFull = filePath;		
		File file = new File(filePathFull);
		
		if(file.exists()){			
			file.delete();
		}
		Process process = Runtime.getRuntime().exec(scriptCmdDir +" "+ filePathFull);
		process.waitFor();
		process.destroy();
		System.out.println("File "+filePathFull+ " downloaded succesfully!");
		return new File(filePathFull);
	}

	public static File downloadFile(WebDriver driver, String xpath, File desLocationDir) throws Exception{
		String tmpFolder = System.getProperty("user.dir")+(config).getProperty("downloadDir");
		File folder = new File(tmpFolder);
		
		if(!folder.exists()) folder.mkdirs();

		for(File file: folder.listFiles()){
			if (!file.isDirectory()){				
				file.delete();
				System.out.println("Deleted file \""+file.getName() +"\"");
			}
		}
		
		driver.findElement(By.xpath(xpath)).click();
		
		Thread.sleep(2000);
		int i = 0;		
		while(folder.listFiles().length < 1){
			Thread.sleep(1000 * ++i);
			if( i > 60 * 5) break;
		}		
		for(File file: folder.listFiles()){
			String fileName = file.getName();	
			File desFile = new File(desLocationDir.getPath()+"\\"+fileName);
			if(desFile.exists()){
				desFile.delete();
			}		
			
			Files.move(Paths.get(file.getPath()), Paths.get(desFile.getPath()));
				System.out.println("Moved file \""+file.getName() +"\" to " + desLocationDir.getPath());	
			return desFile;	
		}
		
		System.out.println("No file was downloaded, return.");
		return null;
	}
	
	@Test
	public void tttest() throws Exception{
		String filePath = "C:\\SAV\\p4v\\MWSA_test\\Nova\\SFSimulationTests\\src\\main\\resources\\data\\cmbs\\scenario\\cmbs_economic_scenario_ir_sample.csv";
		MyWindowsInteractor.autoItUploadFile(filePath);
	}

}