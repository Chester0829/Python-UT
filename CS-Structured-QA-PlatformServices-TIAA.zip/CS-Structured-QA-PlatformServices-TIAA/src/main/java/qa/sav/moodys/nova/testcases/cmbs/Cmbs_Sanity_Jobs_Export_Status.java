package qa.sav.moodys.nova.testcases.cmbs;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.JobCmbs;

public class Cmbs_Sanity_Jobs_Export_Status extends Cmbs_Sanity_Jobs_Base{
	
	@Test(groups="job_submit_cmbs_status", dataProvider="cmbs_sanity_jobs_submitted",threadPoolSize = 3,priority=4,timeOut=5*60*1000,description="wait for job to be exported, time out after 5 minutes")
	public void wait_for_job_to_be_exported(String jobName) throws Exception{
		WebDriver newDriver = initialNewDriver();
		JobCmbs job = new JobCmbs(newDriver, this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));
		job.reFreshStatus();
		while(job.getJobStatus().getExportStatus().equals("exporting")){
			Thread.sleep(10*1000);
			job.reFreshStatus();
		}
		try{
			Assert.assertEquals(job.getJobStatus().getExportStatus(), "exported");
		} catch(Exception ex){
			throw ex;
		} finally {
			quitDriver(job.driver);
		}
	}
}
