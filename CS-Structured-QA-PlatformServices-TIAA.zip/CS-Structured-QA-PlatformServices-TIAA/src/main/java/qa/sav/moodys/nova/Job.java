package qa.sav.moodys.nova;

import org.openqa.selenium.WebDriver;

import qa.sav.moodys.nova.data.JobSettings;
import qa.sav.moodys.nova.data.JobStatus;
import qa.sav.moodys.nova.pages.Dashboard;

public abstract class Job implements JobInterface{
	public enum SubmitType {
	    newLaunch,
	    reload,
	    reprouce,
	    secondRun
	}
	public SubmitType submitType = SubmitType.newLaunch;
	public boolean sequencial = false;
	
	public WebDriver driver;
	public JobSettings jobSettings = new JobSettings();
	public JobStatus jobStatus = new JobStatus();
	
	public Job(){
		
	}
	
	public Job(WebDriver driver){
		this.driver = driver;
		
	}	

	public JobStatus reFreshStatus() throws Exception{

		// TODO Auto-generated method stub
		
		Dashboard dashboard = new Dashboard(driver);
		if(jobStatus.getJobID()== null){
			jobStatus = dashboard.getFirstJobStatusByName(jobSettings.getJobName());
		} else {
			jobStatus = dashboard.getJobStatus(jobStatus.getJobID(), jobSettings.getJobName());
		}
		return jobStatus;	
	}
	
	public void goToJobResultsPage(String jobName) throws Exception{
		Dashboard dashboard = new Dashboard(driver);
		dashboard.getFirstJobStatusByName(jobName);
		dashboard.goToJobResultsPage(jobName);
	}
	
	public void goToJobResultsPage(String jobName, int jobId) throws Exception{
		Dashboard dashboard = new Dashboard(driver);
		dashboard.goToJobResultsPage(jobName, jobId);
	}
	
	@Override
	public boolean waitForJobCompleted() throws Exception{
		
		jobStatus = reFreshStatus();
		Dashboard dashboard = new Dashboard(driver);
		int i = 0;
		while(i < 2*60){
			if(dashboard.getJobRunStatus(jobStatus.getJobID(), jobSettings.getJobName()).equals("finish")
					||dashboard.getJobRunStatus(jobStatus.getJobID(), jobSettings.getJobName()).equals("stopped")){
				jobStatus = dashboard.getJobStatus(jobStatus.getJobID(), jobSettings.getJobName());
				return true;
			} else {
				System.out.println("Waiting for job name = "+jobSettings.getJobName()+" & job id = "+jobStatus.getJobID() + " to be completed");
				Thread.sleep(1000*60);
				i++;
			};
		}
				
		return false;		
	
	}
	
//	public JobsMultiple reproduce(boolean waitForJobCompleted, boolean useNewName) throws Exception {
//		// TODO Auto-generated method stub
//		if(getJobStatus().getName()==null || getJobStatus().getJobID()==null){
//			System.out.println("Cannot reload a job without job name and job id, please check!");
//			return null;
//		} else {
//			
//			Dashboard dashboard = new Dashboard(driver);
//			dashboard.reproduceJob(this, waitForJobCompleted, useNewName);		
//			return null;
//		}		
//	}
		
	public JobStatus getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(JobStatus jobStatus) {
		this.jobStatus = jobStatus;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public JobSettings getJobSettings() {
		return jobSettings;
	}

	public void setJobSettings(JobSettings jobSettings) {
		this.jobSettings = jobSettings;
	}

	public SubmitType getSubmitType() {
		return submitType;
	}

	public void setSubmitType(SubmitType submitType) {
		this.submitType = submitType;
	}
}
