package qa.sav.moodys.nova.pages.launch;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import qa.sav.moodys.nova.pages.PageBase;

public class DscrLtvOverrideCmbs extends PageBase{
	
	final static String dscrlvtOverridePopUpXpath = "//*[@id=\"modal-default-values\"]";
	@FindBy(xpath =  dscrlvtOverridePopUpXpath)
	WebElement dscrLtvOverridePage;
	
	final static String useAverageValueEntryXpath = "//*[@id=\"modal-default-values\"]/div/div/div[2]/form/div[1]";
	@FindBy(xpath = useAverageValueEntryXpath)
	WebElement useAverageValueEntry;
	
	final static String useAverageCheckBoxId = "chk-use-average";
	@FindBy(id = useAverageCheckBoxId)
	WebElement useAverageCheckBox;
	
	final static String nameEntryXpath = "//*[@id=\"modal-default-values\"]/div/div/div[2]/form/div[2]";
	@FindBy(xpath = nameEntryXpath)
	WebElement nameEntry;
	
	final static String nameSelectId = "select-dv-name";
	@FindBy(id = nameSelectId)
	WebElement nameSelect;
	
	final static String addPropertyId = "btn-add-dv-property";
	@FindBy(id = addPropertyId)
	WebElement addProperty;
	
	final static String deletePropertyId = "btn-delete-dv-property";
	@FindBy(id = deletePropertyId)
	WebElement deleteProperty;
	
	final static String dscrLtvTableHeaderXpath = "//*[@id=\"tb-defaultvalues_wrapper\"]/div[2]/div[1]/div/table/thead"; 
	@FindBy(xpath = dscrLtvTableHeaderXpath)
	WebElement dscrLtvTable;
	
	final static String dscrLtvTableBodyXpath = "//*[@id=\"tb-defaultvalues\"]/tbody";
	@FindBy(xpath = dscrLtvTableBodyXpath)
	WebElement dscrLtvTableBody;
	
	final static String saveAsButtonId = "btn-create-default-values";
	@FindBy(id = saveAsButtonId)
	WebElement saveAsButton;
	
	final static String saveChangesButtonId = "btn-save-default-values";
	@FindBy(id = saveChangesButtonId)
	WebElement saveChangesButton;
	
	final static String deleteButtonId = "btn-delete-default-values";
	@FindBy(id = deleteButtonId)
	WebElement deleteButton;
	
	final static String applySettingButtonXpath = "//*[@id=\"modal-default-values\"]/div/div/div[3]/button[4]";
	@FindBy(xpath = applySettingButtonXpath)
	WebElement applySetting;
	
	
	
	public DscrLtvOverrideCmbs(WebDriver driver) throws Exception {
		
		super(driver);
		
		try {
		
			if(dscrLtvOverridePage.isDisplayed()){
				//already in DSCR/LTV Overrides page, do nothing
			} else {
				new LaunchCmbs(driver).openDscrLtvOverrideDashborad();
			}
			
		} catch(Exception e) {
			
				new LaunchCmbs(driver).openDscrLtvOverrideDashborad();
				
		}
	}
	
	public void setUseAverageValueSetting(boolean enable) throws Exception{
		if(enable == getUseAverageValueSetting()){
			// already set as expected, do nothing
		} else {
			useAverageCheckBox.click();
			this.waitForAjaxLoaded();
		}
	}
	
	public boolean getUseAverageValueSetting(){
		return useAverageCheckBox.isSelected();
	}

	public String getCurrentDscrLtvTypeName(){
		return new Select(nameSelect).getFirstSelectedOption().getText();
	}
	
	public void setDscrLtvType(String dscrLtvTypeName) throws Exception{
		if(dscrLtvTypeName.equalsIgnoreCase("Use Average")){
			setUseAverageValueSetting(true);
		} else {
			if(getUseAverageValueSetting()){
				setUseAverageValueSetting(false);
			}
			new Select(nameSelect).selectByVisibleText(dscrLtvTypeName);
			waitForAjaxLoaded();
		}
	}

	public void applySettings() throws Exception {
		applySetting.click();
		waitForAjaxLoaded();
		Thread.sleep(1000);
	}
	
	public void saveChanges() throws Exception{
		saveChangesButton.click();
		waitForAjaxLoaded();
	}
	
	public void saveAsNewType() throws Exception {
		saveAsButton.click();
		waitForAjaxLoaded();
	}
	
	public void delectSelectedTypes(List<String> types){
		//coming soon
	}
	
	protected void addProperty(){
		// coming soon
	}
	
	protected void deleteProperty(){
		//coming soon
	}
}
