package qa.sav.moodys.nova.testcases.cmbs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.pages.jobResult.JobResultCmbs;
import qa.sav.moodys.nova.pages.jobResult.LoanLevelStratificationCmbs;

public class Cmbs_Sanity_Jobs_Results_LoanLevelStratifications extends Cmbs_Sanity_Jobs_Base{
	
	@Test(groups="job_submit_cmbs_results", dataProvider="cmbs_sanity_jobs_and_cusips",priority=6, description="job results sanity check - loan level stratifications")
	public void check_cmbs_sanity_job_results_LoanLevelStratifications(String jobName, String cusip) throws Exception{
		JobCmbs job = new JobCmbs(initialNewDriver(), this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		LoanLevelStratificationCmbs loanLevelStra = cmbsResult.getLoanLevelStratificationInstance(job.driver);
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		loanLevelStra.selectToCusip(cusip);
		try{	
			for(String scen:scenariosList){
				loanLevelStra.selectToScenario(scen);
				Assert.assertTrue(loanLevelStra.scenarioText.getText().equals("Scenario:"), "Verify the scenario list title is showing");
				Assert.assertTrue(loanLevelStra.cusipText.getText().equals("CUSIP:"),"Verify the cusip list title is displaying");
				Assert.assertEquals(loanLevelStra.top10PropertyTypeTitle.getText(), "PROPERTY TYPE (TOP 10)");
				Assert.assertEquals(loanLevelStra.dscrStratificationTitle.getText(), "DSCR");
				Assert.assertEquals(loanLevelStra.ltvStratificationTitle.getText(), "LTV");
				Assert.assertEquals(loanLevelStra.top10StateTitle.getText(), "STATE (TOP 10)");
				Assert.assertEquals(loanLevelStra.loanSizeTitle.getText(), "LOAN SIZE");
				Assert.assertEquals(loanLevelStra.delinquencyTitle.getText(), "DELINQUENCY");				
				
				String propertyTypeHeaders = Arrays.toString(loanLevelStra.propertyStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("thead/tr")).getText().equals(propertyTypeHeaders));				
				int propertyTypeEntrySize = loanLevelStra.top10PropertyTypeTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(propertyTypeEntrySize >= 2);
				//System.out.println(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("tbody")).getText().replace("\n", " "));
				Assert.assertEquals(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("tbody")).getText().replaceAll("\n", " ").split(" ").length
						, propertyTypeEntrySize*loanLevelStra.propertyStratificationFields.length);
				
				String dscrHeaders = Arrays.toString(loanLevelStra.dscrStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(loanLevelStra.dscrStratificationTable.findElement(By.xpath("thead/tr")).getText().equals(dscrHeaders));				
				int dscrEntrySize = loanLevelStra.dscrStratificationTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(dscrEntrySize >= 2);
				//System.out.println(loanLevelStra.dscrStratificationTable.findElement(By.xpath("tbody")).getText());
				Assert.assertEquals(loanLevelStra.dscrStratificationTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, dscrEntrySize*loanLevelStra.dscrStratificationFields.length);	
				
				String ltvHeaders = Arrays.toString(loanLevelStra.ltvStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(loanLevelStra.ltvStratificationTable.findElement(By.xpath("thead/tr")).getText().equals(ltvHeaders));				
				int ltvEntrySize = loanLevelStra.ltvStratificationTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(ltvEntrySize >= 2);
				//System.out.println(loanLevelStra.dscrStratificationTable.findElement(By.xpath("tbody")).getText());
				Assert.assertEquals(loanLevelStra.ltvStratificationTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, ltvEntrySize*loanLevelStra.ltvStratificationFields.length);	
				
				String stateHeaders = Arrays.toString(loanLevelStra.stateStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(loanLevelStra.top10StateTable.findElement(By.xpath("thead/tr")).getText().equals(stateHeaders));				
				int stateEntrySize = loanLevelStra.top10StateTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(stateEntrySize >= 2);
				//System.out.println(loanLevelStra.dscrStratificationTable.findElement(By.xpath("tbody")).getText());
				Assert.assertEquals(loanLevelStra.top10StateTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, stateEntrySize*loanLevelStra.stateStratificationFields.length);
				
				String loanSizeHeaders = Arrays.toString(loanLevelStra.loanSizeStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(loanLevelStra.loanSizeTable.findElement(By.xpath("thead/tr")).getText().equals(loanSizeHeaders));				
				int loanSizeEntrySize = loanLevelStra.loanSizeTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(loanSizeEntrySize >= 2);
				//System.out.println(loanLevelStra.dscrStratificationTable.findElement(By.xpath("tbody")).getText());
				Assert.assertEquals(loanLevelStra.loanSizeTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, loanSizeEntrySize*loanLevelStra.loanSizeStratificationFields.length);
				
				String delinquencyHeaders = Arrays.toString(loanLevelStra.delinquencyStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(loanLevelStra.delinquencyTable.findElement(By.xpath("thead/tr")).getText().equals(delinquencyHeaders));				
				int delinquencyEntrySize = loanLevelStra.delinquencyTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(delinquencyEntrySize >= 2);
				//System.out.println(loanLevelStra.dscrStratificationTable.findElement(By.xpath("tbody")).getText());
				Assert.assertEquals(loanLevelStra.delinquencyTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, delinquencyEntrySize*loanLevelStra.delinquencyStratificationFields.length);								
			}
		
		} catch(Exception ex) {
			throw ex;
		} finally{		
			quitDriver(job.driver);
			quitDriver(cmbsResult.jobCmbs.driver);
		}
		
	
	}
}
