package qa.sav.moodys.nova.testcases.cmbs;

import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.pages.jobResult.JobResultCmbs;
import qa.sav.moodys.nova.pages.jobResult.LoanLevelDetailsCmbs;

public class Cmbs_Sanity_Jobs_Results_LoanLevelDetails extends Cmbs_Sanity_Jobs_Base{
	
	@Test(groups="job_submit_cmbs_results", dataProvider="cmbs_sanity_jobs_and_cusips",priority=6, description="job results sanity check - loan level details")
	public void check_cmbs_sanity_job_results_LoanLevelDetails(String jobName, String cusip) throws Exception{
		JobCmbs job = new JobCmbs(initialNewDriver(), this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		LoanLevelDetailsCmbs loanLevelDetails = cmbsResult.getLoanLevelDetailsInstance(job.driver);
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		loanLevelDetails.selectToCusip(cusip);
		try{	
			for(String scen:scenariosList){
				loanLevelDetails.selectToScenario(scen);
				Assert.assertTrue(loanLevelDetails.scenarioText.getText().equals("Scenario:"), "Verify the scenario list title is showing");
				Assert.assertTrue(loanLevelDetails.cusipText.getText().equals("CUSIP:"),"Verify the cusip list title is displaying");
				String loanLevelFields = loanLevelDetails.loanLevelDetailTable.findElement(By.xpath("thead/tr")).getText() + " ";
				String expectedLoanLevelFields = "";
				for(int k = 0; k < loanLevelDetails.loanLevelDetailsFields.length; k++){
					expectedLoanLevelFields = expectedLoanLevelFields + loanLevelDetails.loanLevelDetailsFields[k] + " ";
				}
				System.out.println(expectedLoanLevelFields); 
				Assert.assertEquals(loanLevelFields,expectedLoanLevelFields);
				int expectedloanLevelFeildsSize = loanLevelDetails.loanLevelDetailsFields.length;
				int loanSizes = loanLevelDetails.loanLevelDetailTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(loanSizes > 0);
				for(int i = 0; i < loanSizes; i++){
					//System.out.println("i = "+i);
					int loanLevelFeildsSize = loanLevelDetails.loanLevelDetailTable.findElements(By.xpath("tbody/tr["+(i+1)+"]/td")).size();
					Assert.assertEquals(loanLevelFeildsSize, expectedloanLevelFeildsSize+1);
				}
			}
		} catch(Exception ex) {
			throw ex;
		} finally{		
			quitDriver(job.driver);
			quitDriver(cmbsResult.jobCmbs.driver);
		}
			
	}
}
