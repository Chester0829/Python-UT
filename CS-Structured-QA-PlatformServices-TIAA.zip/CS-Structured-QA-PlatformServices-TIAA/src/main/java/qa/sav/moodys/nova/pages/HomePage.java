package qa.sav.moodys.nova.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage extends PageBase{
	protected String dashboardPageUrl;
	
	public HomePage(WebDriver driver) {
		super(driver);
		pageUrl = config.getProperty("website")+"/sf-simulation/dashboard";
		dashboardPageUrl = pageUrl;
		// TODO Auto-generated constructor stub
		if(driver.getCurrentUrl().contains("dashboard")){
		} else {
			Login login = new Login(driver);
			try {
				login.loginToDashboard();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.error("Not able to login to dashboard, please check");
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * @usage: get launch button WebElement
	 * @return
	 */
	@SuppressWarnings("finally")
	protected WebElement launch(){		
		
		String xpath = "//*[@id=\"link-launch\"]";
		WebElement webElement = null;		
		log.info("Preparing to luanch a model page...");
		try{
			webElement = driver.findElement(By.xpath(xpath));
		} catch(NoSuchElementException e){
			log.error("Cannot find element by xpath: " + xpath);
			webElement = null;
			throw e;			
		} finally {
			return webElement;
		}
	}

	/**
	 * @usage: go to launch page by model type
	 * @param modelType: support type: "rmbs", "cmbs", "abs"
	 * @throws InterruptedException
	 */
	public void launchToModel(String modelType) throws InterruptedException{
		mouseOverToElement(launch());
		String modelTypeXpath = null;
		switch (modelType) {
			case RMBS: 
				log.info("launch RMBS model");
				modelTypeXpath = "//a[@href='/sf-simulation/launch?businessType=RMBS']";
				break;
			case CMBS:
				log.info("launch CMBS model");
				modelTypeXpath = "//a[@href='/sf-simulation/launch?businessType=CMBS']";
				break;
			case ABS:
				log.info("launch ABS model");
				modelTypeXpath = "//a[@href='/sf-simulation/launch?businessType=ABS']";
				break;
			default: 
				log.warn("Input wrong model type, please check");
				break;
		}
		
		waitForAjaxLoaded();		
		driver.findElement(By.xpath(modelTypeXpath)).click();
		waitForAjaxLoaded();	
	}

	public void goToAdminPage() throws Exception{
		waitForAjaxLoaded();
		driver.findElement(By.xpath("//*[@id=\"menuContent\"]/ul/li[3]/a"));
		waitForAjaxLoaded();
	}
	
	public void goToDashboardPage() throws Exception {
		if(driver.getCurrentUrl().contains(dashboardPageUrl)){
			log.info("Your are already in dashboard page");
		} else {
			driver.get(dashboardPageUrl);
		}
		waitForAjaxLoaded();
		
	}
	
	public String getPageUrl() {
		return pageUrl;
	}

}
