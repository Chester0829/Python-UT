package qa.sav.moodys.nova.pages.launch;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import qa.sav.moodys.nova.pages.PageBase;

public class EconomicScenarioBase extends PageBase {
	
	HashMap<String, String>[] economicRowXpathMapping = null; 
	
	/** 
	 * Elements in Economic scenario dashboard 
	 */
	
	@FindBy(xpath = "//*[@id=\"tb-economicscenarios_length\"]/label/select")
	public WebElement elementSelectPageShowEntries;
	
	@FindBy(xpath = "//*[@id=\"tb-economicscenarios_filter\"]/label/input")
	public WebElement elementSearchBox;
	
	final static String economicScenariosTableXpath = "//*[@id=\"tb-economicscenarios\"]";
	@FindBy(xpath = economicScenariosTableXpath)
	public WebElement elementEconScenTable;
	
	@FindBy(xpath = "//*[@id=\"msg-economic-scenario-response\"]")
	public WebElement elementAlertMsgBlock;
		
	
	@FindBy(xpath = "//*[@id=\"tb-economicscenarios_previous\"]")
	public WebElement elementPreviousPageButton;
	
	@FindBy(xpath = "//*[@id=\"tb-economicscenarios_next\"]")
	public WebElement elementNextPageButton;
	
	@FindBy(xpath = "//*[@id=\"btn-scenario-create\"]")
	public WebElement elementCreateScenButton;
	
	@FindBy(xpath = "//*[@id=\"btn-scenario-delete\"]")
	public WebElement elementDeleteScenButton;
	
	@FindBy(xpath = "//*[@id=\"body-confirm-delete\"]")
	public WebElement elementConfirmDeleteBlock;
	
	@FindBy(xpath = "//*[@id=\"modal-economic-scenario\"]/div/div/div[3]/button[3]")
	public WebElement elementApplyChangeButton;
	
	@FindBy(xpath = "//*[@id=\"modal-economic-scenario\"]/div/div/div[1]/button")
	public WebElement elementCloseDashboard;
	
	/*
	 * Elements in Create new economic scenario 
	 * @param driver
	 */	
	
	@FindBy(xpath = "//*[@id=\"input-scenario-name\"]")
	public WebElement element_NameBox_NewEcon;
	
	@FindBy(xpath = "//*[@id=\"msg-scenario-detail-prompt\"]")
	public WebElement elementAlertMsgBox_NewEcon; 
	
	@FindBy(xpath = "//*[@id=\"btn-import-economic-scenario\"]")
	public WebElement elementImportScenariosButton;
	
	@FindBy(xpath = "//*[@id=\"modal-content-scenario-detail\"]/div[3]/button[4]")
	public WebElement elementCloseButton_NewEco; 
	
	@FindBy(xpath = "//*[@id=\"btn-save-economic-scenario\"]")
	public WebElement elementSaveButtonInNewEcon;
	
	@FindBy(xpath = "//*[@id=\"btn-update-economic-scenario\"]")
	public WebElement elementUpdateButtonInNewEcon;
	
	public EconomicScenarioBase(WebDriver driver){
		super(driver);
	}
	
	//@SuppressWarnings("unchecked")
	public HashMap<String, String>[] readEconScenRowXpathMapping() throws Exception{
		
		int pageCount = driver.findElements(By.xpath("//*[@id=\"tb-economicscenarios_paginate\"]/span/a")).size();
		log.info("Page Count: "+pageCount);
		String scenarionNameXpath = null;
		String scenarionRowXpath= null;
		String scenarionName = null;
		
		economicRowXpathMapping = new HashMap[pageCount];
		
		for(int i = 0; i < pageCount;){
			i++;
			economicRowXpathMapping[i-1] = new HashMap<String, String>();
			log.info("Page Row: "+ elementEconScenTable.findElements(By.xpath("tbody/tr")).size()); 
			for(int j = 0; j < elementEconScenTable.findElements(By.xpath("tbody/tr")).size();){
				j++;
				scenarionNameXpath = "tbody/tr["+j+"]/td[2]";
				scenarionRowXpath = "/tbody/tr["+j+"]";
				scenarionName = elementEconScenTable.findElement(By.xpath(scenarionNameXpath)).getText();
				economicRowXpathMapping[i-1].put(scenarionName, economicScenariosTableXpath+scenarionRowXpath);
			}
			
			if(i < pageCount){
				this.elementNextPageButton.click();
				this.waitForAjaxLoaded();
			}
		}
		
		this.goToFirstPage();
		this.waitForAjaxLoaded();
		
		return economicRowXpathMapping;
	}
	
	public void setPageShowEntries(String number) throws Exception{
		Select pageShowEntriesSelector = new Select(this.elementSelectPageShowEntries);
		if(pageShowEntriesSelector.getFirstSelectedOption().getText().equalsIgnoreCase(number)){
			// do nothing;
		} else {
			pageShowEntriesSelector.selectByVisibleText(number);
		}
		this.waitForAjaxLoaded();
	}
	
	public WebElement searchByScenarioName(String scenarionName) throws Exception{
		this.elementSearchBox.clear();
		this.elementSearchBox.sendKeys(scenarionName);
		this.waitForAjaxLoaded();
		return driver.findElement(By.xpath(economicScenariosTableXpath));
	}
	
	public void setScenarios(Map<String, String> scenariosBlendedMap, boolean blended) throws Exception{
		
		HashMap<String, String>[] scenXpathTableMap = this.readEconScenRowXpathMapping();
		
		HashMap<String, String>[] selectedScenXpathMap = new HashMap[scenXpathTableMap.length];
		
		for(int i = 0; i < selectedScenXpathMap.length; i++){
			selectedScenXpathMap[i] = new HashMap<String, String>();selectedScenXpathMap[i] = new HashMap<String, String>();
		}
		
		// to do
		for(Entry<String, String> scenarioName : scenariosBlendedMap.entrySet()){
			log.info("Find scenario xpath: " +scenarioName.getKey() );
			for(int i = 0; i < scenXpathTableMap.length; i++){
				
				log.info("Find Scenario in page " + i);
				for (Entry<String, String> entry : scenXpathTableMap[i].entrySet()){
					if(entry.getKey().equalsIgnoreCase(scenarioName.getKey())){
						selectedScenXpathMap[i].put(entry.getKey(), entry.getValue());
						log.info("Found Scenarios: "+entry.getKey());
						break;
					} 
				}
			}
		}
		
		//blended = true
		if(blended){
			log.info("set Blended: true ");
			log.info("ScenariosNumbers: " + selectedScenXpathMap.length);
			driver.findElement(By.xpath("//*[@id=\"chk-blend\"]")).click();
			this.waitForAjaxLoaded();
			log.info("ScenariosNumber: " + selectedScenXpathMap.length);
			for(int i = 0; i < selectedScenXpathMap.length;){
				i++;
				log.info("To check scenarios on page " + i);
				for(Entry<String, String> scenarioName : selectedScenXpathMap[i-1].entrySet()){
					driver.findElement(By.xpath(scenarioName.getValue()+"/td[1]/input")).click();
					this.waitForAjaxLoaded();
					log.info("Checked Scenario: " + scenarioName.getKey() );
					driver.findElement(By.xpath(scenarioName.getValue()+"/td[4]/input")).clear();
					driver.findElement(By.xpath(scenarioName.getValue()+"/td[4]/input")).sendKeys(scenariosBlendedMap.get(scenarioName.getKey()));
					this.waitForAjaxLoaded();
				}	
				
				if(i < selectedScenXpathMap.length){
					this.elementNextPageButton.click();
					this.waitForAjaxLoaded();				
				}
			}
		} else {
			log.info("set Blended: false ");
			log.info("ScenariosNumber: " + selectedScenXpathMap.length);
			for(int i = 0; i < selectedScenXpathMap.length;i++){
				
				log.info("To check scenarios on page " + i);
				for(Entry<String, String> scenarioName : selectedScenXpathMap[i].entrySet()){
					driver.findElement(By.xpath(scenarioName.getValue()+"/td[1]/input")).click();
					this.waitForAjaxLoaded();
					log.info("Checked Scenario: " + scenarioName.getKey() );
				}	
				
				if(i < selectedScenXpathMap.length -1){
					this.elementNextPageButton.click();
					this.waitForAjaxLoaded();				
				}
			}
			
		}
	}
	
	public String readAlertMessage(){
		String message = null;
		message = this.elementAlertMsgBlock.getText().replace("×", "").replace("\n", "");
		return message;
	}
	
	public void goToCreateNewEconWindow() throws Exception{
		this.waitForElementPresent("//*[@id=\"btn-scenario-create\"]");
		this.elementCreateScenButton.click();
		this.waitForAjaxLoaded();
	}
	
	public void importNewEconSetting(String fullFileName) throws Exception{
		this.elementImportScenariosButton.click();
		this.waitForAjaxLoaded();
		this.autoItUploadFile(fullFileName);
	}
	
	public String deleteSelectedScen(boolean confirm) throws Exception{
		
		String message = null;
		this.elementDeleteScenButton.click();
		this.waitForAjaxLoaded();
		message = this.readConfirmDeleteMsg();
		if(confirm){
			driver.findElement(By.id("btn-confirm-delete")).click();
		} else{
			driver.findElement(By.xpath("//*[@id=\"modal-confirm-delete\"]/div/div/div[3]/button"));
		}
		this.waitForAjaxLoaded();
		
		return message;
	}
	
	public String applyCurrentChanges() throws Exception{
		this.elementApplyChangeButton.click();
		this.waitForAjaxLoaded();
		Thread.sleep(1000);
		return this.readAlertMessage();
	}
	
	public void fillScenName(String scenarioName){
		this.element_NameBox_NewEcon.clear();
		this.element_NameBox_NewEcon.sendKeys(scenarioName);
	}
	
	public void saveNewEconomic() throws Exception{
		this.elementSaveButtonInNewEcon.click();
		this.waitForAjaxLoaded();
	}
	
	public void saveUpdateEconomic() throws Exception{
		this.elementUpdateButtonInNewEcon.click();
		this.waitForAjaxLoaded();
	}
	
	public void closeEconContentPage() throws Exception{
		this.elementCloseButton_NewEco.click();
		this.waitForAjaxLoaded();
	}

	public void clearUpAllselectedScenarios() throws Exception{
		
		this.goToFirstPage();
		this.waitForAjaxLoaded();
		HashMap<String, String>[] scenList = this.readEconScenRowXpathMapping();
		
		for(int i = 0; i < scenList.length;i++){
			
			for(Entry<String, String> scenarioName : scenList[i].entrySet()){
				String checkBoxXpath = scenarioName.getValue()+"/td[1]/input";				
				if(driver.findElement(By.xpath(checkBoxXpath)).isSelected()){
					driver.findElement(By.xpath(checkBoxXpath)).click();
				}				
			}	
			
			if(i < scenList.length -1){
				this.elementNextPageButton.click();
				this.waitForAjaxLoaded();				
			}
		}
		
	
		
		this.goToFirstPage();
		this.waitForAjaxLoaded();
		
	}
	
	protected String readConfirmDeleteMsg(){
		String msg = null;
		this.elementConfirmDeleteBlock.getText();
		return msg;
	}
	
	protected void goToFirstPage(){
		driver.findElement(By.xpath("//*[@id=\"tb-economicscenarios_paginate\"]/span/a[1]")).click();
	}
	
	public HashMap<String, String>[] getEconomicRowXpathMapping() {
		return economicRowXpathMapping;
	}
}
