package qa.sav.moodys.nova.pages.launch;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import qa.sav.moodys.nova.data.JobSettings;
import qa.sav.moodys.nova.pages.PageBase;

public abstract class Launch extends PageBase {
	
	//JobSettings job;
	
	final static String runModeXpath = "//*[@id=\"pageContent\"]/div[10]/div[2]/div[1]/div[1]";
	@FindBy(xpath = runModeXpath)
	public WebElement runMode;
	
	final static String simulationRunXpath="//*[@id=\"radio-simulation\"]";
	@FindBy(xpath=simulationRunXpath)
	public WebElement simulationRun;
	
	
	final static String staticRunXpath = "//*[@id=\"radio-static-scenario\"]";
	@FindBy(xpath=staticRunXpath)
	public WebElement staticRun;
	
	final static String clickToSelectPortfolioXpath = "//*[@id=\"fakeBrowse\"]";
	@FindBy(xpath=clickToSelectPortfolioXpath)
	public WebElement clickToSelectPortfolio;
	
	final static String datePickerXpath = "//*[@id=\"as-of-date\"]";
	@FindBy(xpath = datePickerXpath)
	public WebElement datePicker;
	
	final static String datePickerDoneXpath = "//*[@id=\"ui-datepicker-div\"]/div[2]/button[2]";
	@FindBy(xpath =  datePickerDoneXpath)
	public WebElement datePickerDone;
	
	final static String dateSelecterYearXpath = "//*[@id=\"ui-datepicker-div\"]/div[1]/div/select[2]";
	@FindBy(xpath = dateSelecterYearXpath)
	public WebElement dateSelecterYear;
	
	final static String dateSelecterMonthXpath = "//*[@id=\"ui-datepicker-div\"]/div[1]/div/select[1]";
	@FindBy(xpath = dateSelecterMonthXpath)
	public WebElement dateSelecterMonth;
	
	final static String confidenceLevelXpath = "//*[@id=\"confidenceLevel\"]";
	@FindBy(xpath = confidenceLevelXpath)
	public WebElement confidenceLevel;
	
	final static String tailPercentXpath = "//*[@id=\"tailPercentageLevel\"]";
	@FindBy(xpath = tailPercentXpath)
	public WebElement tailPercent;
	
	final static String optimizationXpath = "//*[@id=\"optimizationPercentageLevel\"]";	
	@FindBy(xpath = optimizationXpath)
	public WebElement optimizationLevel;
	
	final static String downloadSampleCsvXpath = "//*[@id=\"pageContent\"]/div[10]/div[2]/div[1]/div[2]/a";	
	@FindBy(xpath = downloadSampleCsvXpath)
	public WebElement downloadSampleCsv;
	
	@FindBy(xpath = "//*[@id=\"btn-run-simulation\"]")
	public WebElement submitJobButton;
	
	@FindBy(xpath = "//*[@id=\"alert-placeholder\"]")
	public WebElement submitJobAlertBox;
	
	@FindBy(xpath = "//*[@id=\"btn-confirm-delete\"]")
	public WebElement forceSyncDealButton;
	
	@FindBy(xpath = "//*[@id=\"modal-confirm-delete\"]/div/div/div[3]/button")
	public WebElement removeUnSyncedDealButton;
	
	@FindBy(xpath = "//*[@id=\"modal-confirm-delete\"]/div/div/div[1]/button")
	public WebElement closeAutoSyncPopUp;
	
	
	public Launch(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}	
	
		
	public void loadPortfolio(String portfolioFile) throws Exception{
		
		//clickToSelectPortfolio.click();
		try {
//			clickToSelectPortfolio.click();
			System.out.println("Loading "+portfolioFile+" file ... \n");
			//String portfolioFile = _portfolioFile;
			
			//this.accessCmbsModule(driver);
			JavascriptExecutor js= (JavascriptExecutor)driver;
		    js.executeScript("document.getElementById('file-input-cusip').style.display='block'; ");
		    driver.findElement(By.id("file-input-cusip")).clear();
		    driver.findElement(By.id("file-input-cusip")).sendKeys(portfolioFile.replace("/", "\\\\"));
			this.waitForAjaxLoaded();
//			autoItUploadFile(portfolioFile);
			
			
		 boolean loadTag = true; int i = 1;
		    while(loadTag){
		    	//log.info("Wait for file loaded");
		    	Thread.sleep(100);
	    		loadTag = driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*Parsing input file...*[\\s\\S]*");
	    		if(i++ > 10*60*5) {
	    			log.error("Time out after waiting for 5 minute"); break;
	    		}		    	
		    }
		    
		    //auto sync	    
		    if((driver.findElement(By.id("modal-confirm-delete")).isDisplayed())){
		    	log.info("wait for auto sync pop up");
		    	i = 1;
		    	while(!driver.findElement(By.id("title-confirm-delete")).isDisplayed()){
		    		if(i++ > 30) {
		    			log.error("Time out after waiting for 2 minutes"); break;
		    		}	    		
		    		Thread.sleep(100);
		    	}
		    }
			      
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error("Failed to upload portfolio file: "+portfolioFile);
			e.printStackTrace();
			throw e;
		}
	}

	public void downloadSamplePortfolioCsv(String desLocationDir) throws Exception{
		
		try {
			downloadFile(driver.findElement(By.xpath(downloadSampleCsvXpath)), new File(desLocationDir));
		} catch (Exception e) {
			log.error("Failed to download RMBS sample portfolio file");
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
	}
	
	public void setAsOfDate(String asOfDate) throws InterruptedException{
		driver.findElement(By.xpath(datePickerXpath)).click();
		waitForElementPresent(dateSelecterYearXpath);
		new Select(driver.findElement(By.xpath(dateSelecterYearXpath))).selectByValue(asOfDate.split("-")[0]);

		waitForElementPresent(dateSelecterMonthXpath);
		new Select(driver.findElement(By.xpath(dateSelecterMonthXpath)))
		.selectByValue(Integer.toString(Integer.valueOf(asOfDate.split("-")[1])-1));
		
		driver.findElement(By.xpath(datePickerDoneXpath)).click();
	}
	
	public void getAsOfDateValue(){
		
	}
	
	public void setConfidenceLevel(String confidenceLevelPercent){
		driver.findElement(By.xpath(confidenceLevelXpath)).clear();
		driver.findElement(By.xpath(confidenceLevelXpath)).sendKeys(confidenceLevelPercent);
	}
	
	public String getConfidenceLevelValue(){
		return driver.findElement(By.xpath(confidenceLevelXpath)).getAttribute("value");	
	}
	
	public void setTailPercent(String tailPercent){
		driver.findElement(By.xpath(tailPercentXpath)).clear();
		driver.findElement(By.xpath(tailPercentXpath)).sendKeys(tailPercent);
	}
	
	public String getTailPercentValue(){
		return driver.findElement(By.xpath(tailPercentXpath)).getAttribute("value");	
	}
	
	public void setOptimization(String optimization){
		driver.findElement(By.xpath(optimizationXpath)).clear();
		driver.findElement(By.xpath(optimizationXpath)).sendKeys(optimization);
	}
	
	public String getOptimizationValue(){
		return driver.findElement(By.xpath(optimizationXpath)).getAttribute("value");
	}
	
	public void setRunMode(String runType) throws Exception{
		
		switch(runType){
			case STATIC:
				setRunModeByXpath(staticRunXpath);
				break;
			case SIMULATION:				
				setRunModeByXpath(simulationRunXpath);
				break;
			default:
				log.error("Cannot find properly run mode \""+runType+"\", please check your input" );
					throw (new Exception());
		}
				
	}
	
	public void submitJob(String jobName) throws Exception{
		//System.out.println("submitting job: "+jobName);
		
		this.waitForAjaxLoaded();
		this.submitJobButton.click();
		this.waitForAjaxLoaded();
		WebDriverWait wait = new WebDriverWait(driver,Long.parseLong(config.getProperty("page_timeout")));
		wait.until(new ExpectedCondition<WebElement>(){  
            //@Override  
            public WebElement apply(WebDriver d) {  
                return d.findElement(By.id("inputNote"));
            }}).sendKeys(jobName);
        
    	//submitting job: 
    	driver.findElement(By.id("btn-run")).click();
	    this.waitForAjaxLoaded();
	}
	
	public String readSubmitJobAlert(){
		return this.submitJobAlertBox.getText();
	}
	
	public void autoSyncDeal(boolean forceSync) throws Exception{
		    	
		if(forceSync){	
		    	boolean syncTag = true;
		    	int i = 1;
		    	while(syncTag == true){	    		
		    		Thread.sleep(100);
		    		syncTag = driver.findElement(By.cssSelector("BODY")).getText().matches("^[\\s\\S]*Sychronizing CUSIP*[\\s\\S]*");
		    		if(i++ > 10*60*5) {
		    			System.out.println("Time out after 2 minute"); break;
		    		}	   
		    	}	    	
		    	    
		    this.forceSyncDealButton.click();
		} else{
			this.removeUnSyncedDealButton.click();
		}
		
	}
	
	public void cancelAutoSyncDeal() throws Exception{
		this.closeAutoSyncPopUp.click();
		this.waitForAjaxLoaded();
	}
		
	private void setRunModeByXpath(String xpath){
		if(driver.findElement(By.xpath(xpath)).isSelected()){
			// do nothing
		} else {
			driver.findElement(By.xpath(xpath)).click();
		}		
	}
	
}
