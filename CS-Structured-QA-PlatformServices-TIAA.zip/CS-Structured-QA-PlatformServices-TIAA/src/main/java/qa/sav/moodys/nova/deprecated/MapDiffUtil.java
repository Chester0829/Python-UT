package qa.sav.moodys.nova.deprecated;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import com.google.common.collect.MapDifference;
import com.google.common.collect.MapDifference.ValueDifference;
import com.google.common.collect.Maps;

import qa.sav.moodys.nova.testcases.base.TestCaseBase;

public class MapDiffUtil {
	
	private static Logger log;
	
	public MapDiffUtil(){
		TestCaseBase.initialLogger();
		log = TestCaseBase.log;
	}
		
	 
	    public static boolean validateEqual(
	               Map<String, String> map1, Map<String, String> map2,
	               String map1Name, String map2Name) {
	 
	        final MapDifference<String, String> diff = Maps.difference(map1, map2);
	 
	        if (diff.areEqual()) {
	        	log.info("Maps '"+map1Name+"' and '"+map2Name+"' contain exactly the same "+ "name/value pairs");
	            return true;
	 
	        } else {
	            logKeys(diff.entriesOnlyOnLeft(), map1Name, map2Name);
	            logKeys(diff.entriesOnlyOnRight(), map2Name, map1Name);
	            logEntries(diff.entriesDiffering(), map1Name, map2Name);
	            return false;
	        }
	    }
	 
	    private static void logKeys(Map<String, String> mapSubset, String n1, String n2) {
	        if (not(mapSubset.isEmpty())) {
	        	log.error("Keys found in {} but not in {}: {}", n1, n2, mapSubset.keySet());
	        }
	    }
	 
	    private static <K, V> void logEntries(Map<K, ValueDifference<V>> differing,  String n1, String n2) {
	        if (!(differing.isEmpty())) {
	        	//log.error(differing);
	            log.error("Differing values found {key={}-value,{}-value}: {}",
	                        n1, n2, differing);
	        }
	    }
	 
	    private static boolean not(boolean b) {
	        return !b;
	    }
	    
	    
	    
	   // @Test
	    public void testLog(){
	    	final Map<String, String> map1 = new HashMap<String, String>();
	        map1.put("A", "1");
	    	log.info("test {}", map1.get("A"));
	    }

	 //   @Test
	    public void testEqual() {
	        final Map<String, String> map1 = new HashMap<String, String>();
	        map1.put("A", "1");
	        map1.put("B", "2");
	 
	        final Map<String, String> map2 = new HashMap<String, String>();
	        map2.put("B", "2");
	        map2.put("A", "1");
	 
	        MapDiffUtil.validateEqual(map1, map2, "map1", "map2");
	    }
	 
	    @Test
	    public void testSubset() {
	        final Map<String, String> map1 = new HashMap<String, String>();
	        map1.put("A", "1");
	        map1.put("C", "2");
	        map1.put("B", "1");
	        map1.put("E", "1");
	 
	        final Map<String, String> map2 = new HashMap<String, String>();
	        map2.put("B", "2");
	        map2.put("A", "0");
	        map2.put("D", "0");
	 
	        MapDiffUtil.validateEqual(
	            map1, map2, "map1", "map2");
	 
	    }
	 
	 //  @Test
	    public void testSeparate() {
	        final Map<String, String> map1 = new HashMap<String, String>();
	        map1.put("A", "1");
	 
	        final Map<String, String> map2 = new HashMap<String, String>();
	        map2.put("B", "2");
	 
	        MapDiffUtil.validateEqual(
	            map1, map2, "map1", "map2");
	    }
	 
	  // 	@Test
	    public void testMismatches() {
	        final Map<String, String> map1 = new HashMap<String, String>();
	        map1.put("A", "1");
	        map1.put("B", "2");
	 
	        final Map<String, String> map2 = new HashMap<String, String>();
	        map2.put("B", "20");
	        map2.put("C", "3");
	 
	        MapDiffUtil.validateEqual(
	            map1, map2, "map1", "map2");
	 
	    }
	    
}
