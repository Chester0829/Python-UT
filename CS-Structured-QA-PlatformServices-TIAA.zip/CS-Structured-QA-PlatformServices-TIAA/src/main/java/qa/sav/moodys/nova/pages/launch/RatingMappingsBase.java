package qa.sav.moodys.nova.pages.launch;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import qa.sav.moodys.nova.pages.PageBase;

public class RatingMappingsBase extends PageBase{

	public RatingMappingsBase(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	final static String DEFAULT = "Default";
	final static String CORPORATE = "Corporate Default";

	@FindBy(xpath = "//*[@id=\"sel-mapping-type\"]")
	protected WebElement rattingMapTypeSelect;
	
	@FindBy(xpath = "//*[@id=\"defaultMapLink\"]")
	protected WebElement defaultMappingSubTab;
	
	@FindBy(xpath = "//*[@id=\"expectMapLink\"]")
	protected WebElement expectLossSubTab;
	
	@FindBy(xpath = "//*[@id=\"modal-rating-mappings\"]/div/div/div[3]/a")
	protected WebElement downloadSampleCsvButton;
	
	@FindBy(xpath = "//*[@id=\"btn-import-rating-mapping\"]")
	protected WebElement importButton;
	
	@FindBy(xpath = "//*[@id=\"btn-update\"]")
	protected WebElement updateButton;

	@FindBy(xpath = "//*[@id=\"closeBtn\"]")
	protected WebElement applyButton;
	
	@FindBy(xpath = "//*[@id=\"modal-rating-mappings\"]/div/div/div[1]/button")
	protected WebElement closeDashboardButton;
	
	
	public void selectRatingMapType(String ratingMapType) throws Exception{
		Select typeSelector = new Select(this.rattingMapTypeSelect);
		if(typeSelector.getFirstSelectedOption().getText().equalsIgnoreCase(ratingMapType)){
			// do nothing
		} else {
			typeSelector.selectByVisibleText(ratingMapType);
		}
		this.waitForAjaxLoaded();
	}
	
	public void switchToDefaultMappingTab() throws Exception{
		this.defaultMappingSubTab.click();
		this.waitForAjaxLoaded();
	}
	
	public void switchToExpectLossTab() throws Exception{
		this.expectLossSubTab.click();
		this.waitForAjaxLoaded();
	}
	
	public void downloadSampleCsv(String sampleFileName) throws Exception{
		this.downloadSampleCsvButton.click();
		this.autoItExportFile(sampleFileName);	
		this.waitForAjaxLoaded();
	}
	
	public void importFromCsv(String fullFileName) throws Exception{
		this.importButton.click();
		this.waitForAjaxLoaded();
		this.autoItUploadFile(fullFileName);
	}
	
	public void saveChanges() throws Exception{
		this.updateButton.click();
		this.waitForAjaxLoaded();
	}
	
	public void applyToClose() throws Exception{
		this.applyButton.click();
		this.waitForAjaxLoaded();
	}
	
	
}
