package qa.sav.moodys.nova.deprecated;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MyWebDriverProcessor {

	public static void waitForAjaxLoad(WebDriver driver) throws InterruptedException{
		
		// selenium api,get page status
		
	    JavascriptExecutor executor = (JavascriptExecutor)driver;
	    if((Boolean) executor.executeScript("return window.jQuery != undefined")){
	        while(!(Boolean) executor.executeScript("return jQuery.active == 0")){
	            Thread.sleep(10);
	        }
	    }
	    return;
	}
	
	/**
	 * wait for show
	 * @param driver
	 * @param xpath
	 * @throws Exception
	 */
	public static void waitForButtonActive(WebDriver driver, String xpath) throws Exception{
		
		WebDriverWait wait = new WebDriverWait(driver,60);
		final String xPath = xpath;
		wait.until(new ExpectedCondition<WebElement>(){  
	        // @Override  
	    	public WebElement apply(WebDriver d) {  
	              return d.findElement(By.xpath(xPath));
	          }});
		Thread.sleep(1000);
	}
	
	/**
	 * wait for clickable
	 * @param driver
	 * @param xpath
	 * @return
	 */
	public static boolean waitForButtonActiveClick(WebDriver driver, String xpath){
		
		try {
			
			MyWebDriverProcessor.waitForButtonActive(driver, xpath);
			driver.findElement(By.xpath(xpath)).click();
			MyWebDriverProcessor.waitForAjaxLoad(driver);
			return true;
		} catch (Exception e) {
			
			// TODO Auto-generated catch block				
			e.printStackTrace();
			return false;
		}
	}
	
	public static void waitForElementPresence(WebDriver driver, String xpath){
		
		WebDriverWait wait = new WebDriverWait(driver,60);
		final String xPath = xpath;
		wait.until(new ExpectedCondition<WebElement>(){  
	        // @Override  
	    	public WebElement apply(WebDriver d) {  
	              return d.findElement(By.xpath(xPath));
	          }});
	}

	
	public static boolean waitForElementPresenceClick(WebDriver driver, String xpath){
		try {
			MyWebDriverProcessor.waitForElementPresence(driver, xpath);
			driver.findElement(By.xpath(xpath)).click();		
			MyWebDriverProcessor.waitForAjaxLoad(driver);
			return true;
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}	
	}

}