package qa.sav.moodys.nova.pages.launch;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.pages.HomePage;

public class LaunchCmbs extends Launch {
	
	String launchCmbsPageUrl = "sf-simulation/launch?businessType=CMBS";
	
	final static String cmmForecastXpath = "//*[@id=\"select-forecast\"]";
	@FindBy(xpath = cmmForecastXpath)
	public WebElement cmmForecast;
	
	final static String cmmModelVersionXpath = "//*[@id=\"select-CmmVersion\"]";
	@FindBy(xpath = cmmModelVersionXpath)
	public WebElement cmmModelVersion;
	
	final static String pathsOfSimulationXpath = "//*[@id=\"PathOfSimulation\"]";
	@FindBy(xpath = pathsOfSimulationXpath)
	public WebElement pathsOfSimulation;
			
	final static String globalValueDashboradXpath = "//a[@href='/sf-simulation/dialog?modalType=globalValues&businessType=CMBS\']";
	@FindBy(xpath = globalValueDashboradXpath)
	public WebElement globalValue;	
	
	final static String defaultValuesXpath = "//a[@href=\"/sf-simulation/dialog?modalType=defaultValuesCMBS&businessType=CMBS\"]";
	@FindBy(xpath = defaultValuesXpath)
	public WebElement defaultValuesLink;	 
	
	final static String econScenXpath = "//a[@href='/sf-simulation/dialog?modalType=economicScenarios&businessType=CMBS']";
	@FindBy(xpath = econScenXpath)
	public WebElement econScenLink;
	
	final static String rattingMapXpath = "//a[@href='/sf-simulation/dialog?modalType=rateMappings&businessType=CMBS']";
	@FindBy(xpath = rattingMapXpath)
	public WebElement rattingMapLink;
	
	final static String forceSync = "//*[@id=\"forceSync\"]";
		//	"//a[@href='/sf-simulation/dialog?modalType=rateMappings&businessType=CMBS']";
	@FindBy(xpath = forceSync)
	public WebElement forceSyncLink;

	
	public LaunchCmbs(WebDriver driver) throws Exception {
		super(driver);
		
		if(driver.getCurrentUrl().contains(launchCmbsPageUrl)){
			//do nothing
		} else {
			try {
				new HomePage(driver).launchToModel(CMBS);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.error("Not able to go to Cmbs Launch page");
				e.printStackTrace();
				throw e;
			}
		}
		// TODO Auto-generated constructor stub
	}	
	
	public void setCmmForecastValue(String cmmForecastName){
		 new Select(this.cmmForecast).selectByVisibleText(cmmForecastName);
	}
	
	public String getCmmForecastValue(){
		String cmmForecastValue = new Select(cmmForecast).getFirstSelectedOption().getText();
		return cmmForecastValue;
	}
	
	public void setCmmVersion(String cmmVesion){
		new Select(cmmModelVersion).selectByVisibleText(cmmVesion);
	}
	
	public String getCmmVersion(){
		String cmmVersion = new Select(this.cmmModelVersion).getFirstSelectedOption().getText();
		return cmmVersion;
	}
	
	public void setSimulationPaths(String simulationPathsNum){
		pathsOfSimulation.clear();
		pathsOfSimulation.sendKeys(simulationPathsNum);
	}
	
	public String getSimulationPathsValue(){
		String pathsNum = pathsOfSimulation.getAttribute("value");
		return pathsNum;
	}
	
	
	
	
	//@Override
		public void setForceSync(boolean isForceSync) {
			if(isForceSync){
				if(driver.findElement(By.xpath(forceSync)).isSelected()){
					// use target lgd already set to true, do nothing
				} else {
					
					driver.findElement(By.xpath(forceSync)).click();
				}
			} else{
				if(driver.findElement(By.xpath(forceSync)).isSelected()){
					
					driver.findElement(By.xpath(forceSync)).click();
				} else {
					// use target Lgd has already set to false, do nothing
				}
			}	
			
		}
	public void openGlobalValueDashboard() throws InterruptedException{
		driver.findElement(By.xpath(globalValueDashboradXpath)).click();
		waitForAjaxLoaded();
	}
	
	public void openDscrLtvOverrideDashborad() throws Exception{
		defaultValuesLink.click();
		waitForAjaxLoaded();
	}
	
	public void openEconScenDashboard() throws Exception{
		this.econScenLink.click();
		waitForAjaxLoaded();
	}
	
	public void openRatingMapDashboard() throws Exception{
		this.rattingMapLink.click();
		this.waitForAjaxLoaded();
	}
	
}
