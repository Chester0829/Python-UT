package qa.sav.moodys.nova.data;

import org.openqa.selenium.WebElement;

public class JobStatus {
	
	private String dataSource = null;
	
	private Integer jobID = null;
	private String name = null;
	private String businessType = null;
	private String submitTime = null;
	private String startTime = null;
	private String endTime = null;
	private String submittedBy = null;
	private Integer totalTasks = -1;
	private Integer progress = -1;
	private Integer failNum = -1;
	private String runType = null;
	private WebElement globalValuePopUp = null;
	private String runStatus = null;
	private String jobResultStatus = null;
	private WebElement jobResultStatusPopUp = null;
	private String exportStatus = null;
	private WebElement reloadButton = null;
	private WebElement reproduceButton = null;
	private WebElement stopButton = null;
	private WebElement destroyButton = null;
	private WebElement exportButton = null;
		
	public String getDataSource() {
		return dataSource;
	}
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	public Integer getJobID() {
		return jobID;
	}
	public void setJobID(int jobID) {
		this.jobID = jobID;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSubmitTime() {
		return submitTime;
	}
	public void setSubmitTime(String submitTime) {
		this.submitTime = submitTime;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getSubmittedBy() {
		return submittedBy;
	}
	public void setSubmittedBy(String submittedBy) {
		this.submittedBy = submittedBy;
	}
	public Integer getTotalTasks() {
		return totalTasks;
	}
	public void setTotalTasks(int totalTasks) {
		this.totalTasks = totalTasks;
	}
	public Integer getProgress() {
		return progress;
	}
	public void setProgress(int progress) {
		this.progress = progress;
	}
	public Integer getFailNum() {
		return failNum;
	}
	public void setFailNum(int failNum) {
		this.failNum = failNum;
	}
	public String getRunType() {
		return runType;
	}
	public void setRunType(String runType) {
		this.runType = runType;
	}
	public String getRunStatus() {
		return runStatus;
	}
	public void setRunStatus(String runStatus) {
		this.runStatus = runStatus;
	}
	public String getJobResultStatus() {
		return jobResultStatus;
	}
	public void setJobResultStatus(String jobResultStatus) {
		this.jobResultStatus = jobResultStatus;
	}
	public String getExportStatus() {
		return exportStatus;
	}
	public void setExportStatus(String exportStatus) {
		this.exportStatus = exportStatus;
	}
	public WebElement getGlobalValuePopUp() {
		return globalValuePopUp;
	}
	public void setGlobalValuePopUp(WebElement globalValuePopUp) {
		this.globalValuePopUp = globalValuePopUp;
	}
	public WebElement getJobResultStatusPopUp() {
		return jobResultStatusPopUp;
	}
	public void setJobResultStatusPopUp(WebElement jobResultStatusPopUp) {
		this.jobResultStatusPopUp = jobResultStatusPopUp;
	}
	public WebElement getReloadButton() {
		return reloadButton;
	}
	public void setReloadButton(WebElement reloadButton) {
		this.reloadButton = reloadButton;
	}
	public WebElement getReproduceButton() {
		return reproduceButton;
	}
	public void setReproduceButton(WebElement reproduceButton) {
		this.reproduceButton = reproduceButton;
	}
	public WebElement getStopButton() {
		return stopButton;
	}
	public void setStopButton(WebElement stopButton) {
		this.stopButton = stopButton;
	}
	public WebElement getDestroyButton() {
		return destroyButton;
	}
	public void setDestroyButton(WebElement destroyButton) {
		this.destroyButton = destroyButton;
	}
	public WebElement getExportButton() {
		return exportButton;
	}
	public void setExportButton(WebElement exportButton) {
		this.exportButton = exportButton;
	}
	
}
