package qa.sav.moodys.nova.pages;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import qa.sav.moodys.nova.testcases.base.TestCaseBase;

public class PageBase {
	
	protected static boolean downloadFolderInUsed = false; 
	protected static final String STATIC = "static";
	protected static final String SIMULATION = "simulation";
	
	protected WebDriver driver = null;
	protected static Properties config = TestCaseBase.config;
	protected static Logger log = TestCaseBase.log;
	
	protected static final String RMBS = "rmbs";
	protected static final String CMBS = "cmbs";
	protected static final String ABS = "abs";
	
	protected String pageUrl = null;	
	
	public PageBase(WebDriver driver){
		
		this.driver = driver;
		PageFactory.initElements(driver, this);	
	}
		
	/**
	 * @usage: wait for web element present 
	 * @param xpath
	 * @return boolean
	 */
	public boolean waitForElementPresent(String xpath){
		
		// set time out
		long waitTimeout = Math.round(60*Float.parseFloat(config.getProperty("page_timeout")));
		WebDriverWait wait = new WebDriverWait(driver,waitTimeout);
		
		final String xPath = xpath;
		
		wait.until
		(
				new ExpectedCondition<WebElement>(){		
					// @Override
					public WebElement apply(WebDriver d)
					{
						return d.findElement(By.xpath(xPath));
					}
				}
		);
		
		return driver.findElement(By.xpath(xpath)).isDisplayed();
	}
	
	/**
	 * @usage: wait for button activity
	 * @param xpath
	 * @return
	 */
	public boolean waitForButtonActive(String xpath){
		
		// set time out
		long waitTimeout = Math.round(60*Float.parseFloat(config.getProperty("page_timeout")));
		WebDriverWait wait = new WebDriverWait(driver,waitTimeout);
		
		final String xPath = xpath;
		
		wait.until
		(
				new ExpectedCondition<WebElement>(){		
					// @Override
					public WebElement apply(WebDriver d)
					{
						return d.findElement(By.xpath(xPath));
					}
				}
		);
		
		return driver.findElement(By.xpath(xpath)).isEnabled();
	}
	
	
	/**
	 * @usage: wait jQuery loaded 
	 * @throws InterruptedException
	 */
	public void waitForAjaxLoaded() throws InterruptedException{
		
		int i = 0;
		
		int waitUnit = 10;  // wait 10 millisecond for each loop
		
		// find totalLoop times from global page_time out setting
		int totalLoop = Math.round(Float.parseFloat(config.getProperty("page_timeout"))*60*1000/waitUnit);
		
		// Selenium API,get page state
	    JavascriptExecutor executor = (JavascriptExecutor)driver;
	    if((Boolean) executor.executeScript("return window.jQuery != undefined")){
	        while(!(Boolean) executor.executeScript("return jQuery.active == 0")){
	            i++;
	        	Thread.sleep(waitUnit);
	            if(i > totalLoop) break;
	        }
	    }
	    
	    Thread.sleep(1000);
	    return;
	}

	/**
	 * @usage: put mouse over an element
	 * @param WebElement
	 */
	public void mouseOverToElement(WebElement webElement){
		Actions action = new Actions(driver);
		action.moveToElement(webElement).build().perform();
	}
	
	public void acceptAlert(boolean acceptAlertCondition){
		if(acceptAlertCondition){
			try {
				WebDriverWait wait = new WebDriverWait(driver, 2);
				wait.until(ExpectedConditions.alertIsPresent());
				Alert alert = driver.switchTo().alert();
				alert.accept();
			} catch (Exception e) {
				log.warn("no alert pop-up, continue ... ");
			}	
		} else {
			
			try {
				WebDriverWait wait = new WebDriverWait(driver, 2);
				wait.until(ExpectedConditions.alertIsPresent());
				Alert alert = driver.switchTo().alert();
				alert.dismiss();
			} catch (Exception e) {
				log.warn("no alert pop-up, continue ... ");
			}
		}
	}
	
	public void get(String pageUrl){
		driver.get(pageUrl);
	}

	public void autoItUploadFile(String filePath) throws Exception{
		
		String scriptCmdDir = System.getProperty("user.dir") + config.getProperty("autoItScriptDir")+"uploadFile.exe";
		String filePathFull = filePath;
		
		Process process = Runtime.getRuntime().exec(scriptCmdDir +" "+ filePathFull);
		process.waitFor();
		process.destroy();
		System.out.println("File "+filePathFull+ " uploaded succesfully!");
	}
	
	public File autoItExportFile(String filePath) throws Exception{
		String scriptCmdDir = System.getProperty("user.dir") + config.getProperty("autoItScriptDir")+"exportCsv.exe";
		String filePathFull = filePath;		
		File file = new File(filePathFull);
		
		if(file.exists()){			
			file.delete();
		}
		Process process = Runtime.getRuntime().exec(scriptCmdDir +" "+ filePathFull);
		process.waitFor();
		process.destroy();
		log.info("File "+filePathFull+ " downloaded succesfully!");
		return new File(filePathFull);
	}

	public File downloadFile(WebElement downloadLinkClickButton, File desLocationDir) throws Exception{
		String tmpFolder = System.getProperty("user.dir")+config.getProperty("downloadDir");
		File folder = new File(tmpFolder);
		int i = 0;
		while(downloadFolderInUsed){
			log.warn("downloading folder is used by another thread, pelase hold on");
			Thread.sleep(100);
			i++;
			if(i> 5*60*10){
				log.error("downloading folder is in used and seems will never be completed, exit");
				return null;
			}
		}
		
		downloadFolderInUsed = true;
		if(!folder.exists()) folder.mkdirs();

		for(File file: folder.listFiles()){
			if (!file.isDirectory()){				
				file.delete();
				log.info("Deleted file \""+file.getName() +"\"");
			}
		}
		
		downloadLinkClickButton.click();
		this.waitForAjaxLoaded();
		
		i = 0;
		boolean downloadFinished = true;
		while(i<10*60*5){
			downloadFinished = true;
			for(File file: folder.listFiles()){
				if(file.getName().contains(".tmp")||file.getName().contains(".crdownload")){
					downloadFinished = false;
					System.out.println("Sleeping for 0.1 sec, waiting for file downloaded");
					break;
				}
			}
			if(downloadFinished){
				break;
			} else{
				Thread.sleep(100);
				i++;
			}
		}
		
		i = 0;		
		while(folder.listFiles().length < 1){
			Thread.sleep(100 * ++i);
			if( i > 60 * 5 * 10) break;
		}		
		
		for(File file: folder.listFiles()){
			String fileName = file.getName();
			
			File desFile = new File(desLocationDir.getPath()+"\\"+fileName);
			if(desFile.exists()){
				desFile.delete();
			}		
			
			Files.move(Paths.get(file.getPath()), Paths.get(desFile.getPath()));
				log.info("Moved file \""+file.getName() +"\" to " + desLocationDir.getPath());	
				PageBase.downloadFolderInUsed = false;
				return desFile;	
		}
		
		log.warn("No file was downloaded, return.");
		PageBase.downloadFolderInUsed = false;
		return null;
	}

}
