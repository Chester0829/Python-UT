package qa.sav.moodys.nova.pages.jobResult;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import qa.sav.moodys.nova.JobCmbs;

public class JobResultTabCmbs extends JobResultTabBase{
	
	
	final static String loanLevelDetailsTabBlockXpath = "//*[@id=\"resultTabs\"]/li[5]";
	
	@FindBy(xpath = "//*[@id=\"resultTabs\"]/li[5]/a")
	WebElement loanLevelDetailsTab;
	
	final static String loanLevelStratificationTabBlockXpath = "//*[@id=\"resultTabs\"]/li[6]";
	
	@FindBy(xpath = "//*[@id=\"resultTabs\"]/li[6]/a")
	WebElement loanLevelStratificationTab;
	
	final static String performanceStratificationTabBlockXpath = "//*[@id=\"resultTabs\"]/li[7]";
	
	@FindBy(xpath = "//*[@id=\"resultTabs\"]/li[7]/a")
	WebElement performanceStratificationTab;
	
	public JobResultTabCmbs(WebDriver driver, JobCmbs job) throws Exception{
		super(driver, job);
		// TODO Auto-generated constructor stub		
	}
	
	public String[] getScenariosList(WebElement scenarioSelector){
		Select scenarios = new Select(scenarioSelector);
		List<WebElement> options = scenarios.getOptions();
		int scenariosCount = options.size();
		System.out.println(scenariosCount);
		String scenarioOptions[] = new String[scenariosCount];
		for(int i = 0; i < scenariosCount; i++){
			scenarioOptions[i] = options.get(i).getAttribute("textContent");
			//System.out.println(options.get(i).getAttribute("value"));
		}
		return scenarioOptions;
	}
	
	public String[] getCusipsList(WebElement cusipSelector){
		Select cusips = new Select(cusipSelector);
		List<WebElement> options = cusips.getOptions();
		int cusipsCount = options.size();
		System.out.println(cusipsCount);
		String cusipOptions[] = new String[cusipsCount];
		for(int i = 0; i < cusipsCount; i++){
			cusipOptions[i] = options.get(i).getAttribute("textContent");			
		}
		return cusipOptions;
	}
	
	public void goToLoanLevelDetailsTab() throws Exception{
		this.waitForAjaxLoaded();
		this.waitForElementPresent(loanLevelDetailsTabBlockXpath);
		if(driver.findElement(By.xpath(loanLevelDetailsTabBlockXpath)).getAttribute("class").equals("active")){
			// already in loan level detail tab, do nothing
		}else{
			this.loanLevelDetailsTab.click();
			this.waitForAjaxLoaded();
		}
	}
	
	public void goToLoanLevelStratificationTab() throws Exception{
		this.waitForAjaxLoaded();
		this.waitForElementPresent(loanLevelStratificationTabBlockXpath);
		if(driver.findElement(By.xpath(loanLevelStratificationTabBlockXpath)).getAttribute("class").equals("active")){
			// already in loan lever stratification page, do nothing
		} else {
			this.loanLevelStratificationTab.click();
			this.waitForAjaxLoaded();
		}
	}
	
	public void goToPerformanceStratificationTab() throws Exception{
		this.waitForAjaxLoaded();
		this.waitForElementPresent(performanceStratificationTabBlockXpath);
		if(driver.findElement(By.xpath(performanceStratificationTabBlockXpath)).getAttribute("class").equals("active")){
			// already in performance stratification tab, do nothing
		} else {
			this.performanceStratificationTab.click();
			this.waitForAjaxLoaded();
		}
	}
	
}
