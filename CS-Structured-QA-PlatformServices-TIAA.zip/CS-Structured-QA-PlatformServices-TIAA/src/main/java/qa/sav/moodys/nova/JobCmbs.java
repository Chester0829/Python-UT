package qa.sav.moodys.nova;

import org.openqa.selenium.WebDriver;

import qa.sav.moodys.nova.data.JobSettings;
import qa.sav.moodys.nova.data.JobStatus;
import qa.sav.moodys.nova.data.JobCmbsReloadOrReproduce;
import qa.sav.moodys.nova.pages.Dashboard;
import qa.sav.moodys.nova.pages.jobResult.JobResultCmbs;
import qa.sav.moodys.nova.pages.launch.DscrLtvOverrideCmbs;
import qa.sav.moodys.nova.pages.launch.EconomicScenarioCmbs;
import qa.sav.moodys.nova.pages.launch.LaunchCmbs;

public class JobCmbs extends Job{	
	
	JobResultCmbs result;
	
	public JobCmbs(WebDriver driver){		
		super(driver);
	}
	
	public JobCmbs(WebDriver driver, JobSettings jobSettingsCmbs){
		super(driver);
		this.setJobSettings(jobSettingsCmbs);
		this.setJobStatus(new JobStatus());
	}
	
	public JobCmbs(WebDriver driver, JobSettings jobSettingsCmbs, JobStatus jobStatus) throws Exception{
		super(driver);
		this.setJobSettings(jobSettingsCmbs);
		this.setJobStatus(jobStatus);
		this.result = new JobResultCmbs(this.driver, this);
	}
	
	public JobCmbs() {
		// TODO Auto-generated constructor stub
	}

	public JobResultCmbs getResult() throws Exception{
		if(result==null){
			result = new JobResultCmbs(this.driver, this);
		}		
		return result;		
	}
	
	
	@Override
	public JobCmbs run(boolean waitForJobCompleted) throws Exception{

		LaunchCmbs launch = new LaunchCmbs(driver);
		if(jobSettings.getRunType()== null){
			//do nothing
		} else {
			launch.setRunMode(jobSettings.getRunType());
		}
		if(jobSettings.getPortfolioFilePath()==null){
			//do nothing
		} else {
			launch.loadPortfolio(jobSettings.getPortfolioFilePath());
		}
		if(jobSettings.getCmmForecast() == null){
			// using default setting, do nothing
		} else {
			launch.setCmmForecastValue(jobSettings.getCmmForecast());
		}
		if(jobSettings.getAsOfDate()==null){
			//do nothing
		} else {
			launch.setAsOfDate(jobSettings.getAsOfDate());
		} 
		if(jobSettings.getCmmVersion()==null){
			//do nothing
		} else {
			launch.setCmmVersion(jobSettings.getCmmVersion());
		}
		if(jobSettings.getRunType()==null){
			//do nothing
		} else {
			if(jobSettings.getRunType().equals("simulation")){
				if(jobSettings.getConfidenceLevelPercentage()==null){
					// do nothing
				} else {
					launch.setConfidenceLevel(jobSettings.getConfidenceLevelPercentage());
				}
				if(jobSettings.getTailPercentageLevl() == null){
					//do nothing
				} else {
					launch.setTailPercent(jobSettings.getTailPercentageLevl());		
				}
				if(jobSettings.getOptimizationPercentageLevel()==null){
					// do nothing
				} else {
					launch.setOptimization(jobSettings.getOptimizationPercentageLevel());
				}
				if(jobSettings.getSimPaths() == null){
					//do nothing
				} else {
					launch.setSimulationPaths(jobSettings.getSimPaths());
				}
			}	
		}
		if(jobSettings.getForceSync()==null){
			// do nothing
		} else {
			launch.setForceSync(jobSettings.getForceSync());
		}
		
		if(jobSettings.getDscrLtv()==null){
			//do nothing
		} else {
			DscrLtvOverrideCmbs dscrLtv = new DscrLtvOverrideCmbs(driver);
			dscrLtv.setDscrLtvType(jobSettings.getDscrLtv());
			dscrLtv.applySettings();
		}
		if(jobSettings.getScenarios()==null){
			//do nothing
		} else {
			EconomicScenarioCmbs economySettings = new EconomicScenarioCmbs(driver);
			economySettings.setScenarios(jobSettings.getScenarios(), jobSettings.isScenarioBlended());
			economySettings.applyCurrentChanges();
		}
		
		launch.submitJob(jobSettings.getJobName());
		
		// wait for job completed and get job status
		if(waitForJobCompleted){
			waitForJobCompleted();
		} else {
			// do nothing, return job settings inmeditely
		}
		
		jobStatus = reFreshStatus();
		
		return this;	
	}
	
	@Override
	public JobCmbsReloadOrReproduce reload(boolean waitForJobCompleted)
			throws Exception {
		// TODO Auto-generated method stub
		JobCmbsReloadOrReproduce jobCmbsReload = new JobCmbsReloadOrReproduce(this);
		Dashboard dashboard = new Dashboard(driver);
		jobCmbsReload.originalJob = (JobCmbs) dashboard.clickToReloadJob(jobCmbsReload.getOriginalJob());
		
		String newJobName = this.jobSettings.getJobName()
				+"_reload_"+jobCmbsReload.originalJob.jobStatus.getJobID();
		
		jobCmbsReload.newJob.jobSettings.setJobName(newJobName);		
	
		jobCmbsReload.newJob.jobStatus = jobCmbsReload.newJob.run(waitForJobCompleted).jobStatus;
		jobCmbsReload.newJob.jobSettings = jobCmbsReload.originalJob.jobSettings;
		jobCmbsReload.newJob.jobSettings.setJobName(newJobName);
		jobCmbsReload.newJob.setSubmitType(SubmitType.reload);

		return jobCmbsReload;
	}
	
	public JobCmbsReloadOrReproduce reload(boolean waitForJobCompleted, String newJobName)
			throws Exception {
		// TODO Auto-generated method stub
		JobCmbsReloadOrReproduce jobCmbsReload = new JobCmbsReloadOrReproduce(this);
		Dashboard dashboard = new Dashboard(driver);
		jobCmbsReload.originalJob = (JobCmbs) dashboard.clickToReloadJob(jobCmbsReload.getOriginalJob());
		
		jobCmbsReload.newJob.jobSettings.setJobName(newJobName);		
	
		jobCmbsReload.newJob.jobStatus = jobCmbsReload.newJob.run(waitForJobCompleted).jobStatus;
		jobCmbsReload.newJob.jobSettings = jobCmbsReload.originalJob.jobSettings;
		jobCmbsReload.newJob.jobSettings.setJobName(newJobName);
		jobCmbsReload.newJob.setSubmitType(SubmitType.reload);

		return jobCmbsReload;
	}
	

	public JobCmbsReloadOrReproduce reload(boolean waitForJobCompleted,
			JobSettings resetJobSettings) throws Exception {
		// TODO Auto-generated method stub
		JobCmbsReloadOrReproduce jobCmbsReload = new JobCmbsReloadOrReproduce(this);
		Dashboard dashboard = new Dashboard(driver);
		jobCmbsReload.originalJob = (JobCmbs) dashboard.clickToReloadJob(jobCmbsReload.getOriginalJob());
		
		jobCmbsReload.newJob.jobSettings = resetJobSettings;		
	
		jobCmbsReload.newJob.jobStatus = jobCmbsReload.newJob.run(waitForJobCompleted).jobStatus;

		jobCmbsReload.newJob.setSubmitType(SubmitType.reload);

		return jobCmbsReload;
	}
	

	@Override
	public JobCmbsReloadOrReproduce reproduce(boolean waitForJobCompleted) throws Exception{
		// TODO Auto-generated method stub
		if(getJobStatus().getName()==null || getJobStatus().getJobID()==null){
			System.out.println("Cannot reload a job without job name and job id, please check!");
			return null;
		} else {
			JobCmbsReloadOrReproduce job = new JobCmbsReloadOrReproduce((JobCmbs) this);

			String newJobName = job.originalJob.jobSettings.getJobName()
					+"_reproduce_"+job.originalJob.jobStatus.getJobID();
			
			job.newJob.setJobSettings(job.originalJob.jobSettings);		
			job.newJob.jobSettings.setJobName(newJobName);	
			job.newJob.setSubmitType(SubmitType.reprouce);
			Dashboard dashboard = new Dashboard(driver);
			dashboard.reproduceJob(this, false, newJobName);	
			job.newJob.setJobStatus(job.newJob.reFreshStatus());
			if(waitForJobCompleted){
				job.newJob.waitForJobCompleted();
			}
			return job;
		}
	}
	
	@Override
	public JobCmbsReloadOrReproduce reproduce(boolean waitForJobCompleted, String newName) throws Exception{
		// TODO Auto-generated method stub
		if(getJobStatus().getName()==null || getJobStatus().getJobID()==null){
			System.out.println("Cannot reload a job without job name and job id, please check!");
			return null;
		} else {
			JobCmbsReloadOrReproduce job = new JobCmbsReloadOrReproduce(this);
			
			job.newJob.setJobSettings(job.originalJob.jobSettings);	
			job.newJob.jobSettings.setJobName(newName);	
			job.newJob.setSubmitType(SubmitType.reprouce);
			Dashboard dashboard = new Dashboard(driver);
			dashboard.reproduceJob(this, false, newName);	
			job.newJob.setJobStatus(job.newJob.reFreshStatus());
			if(waitForJobCompleted){
				job.newJob.waitForJobCompleted();
			}
			return job;
		}
	}

	
}
