package qa.sav.moodys.nova.utils;

import java.util.HashMap;
import java.util.Map;

import com.google.common.collect.MapDifference;
import com.google.common.collect.MapDifference.ValueDifference;
import com.google.common.collect.Maps;

public class MapDiffUtil {
	
	private boolean differentFlag = false;
	
	private Map<String, String> benchMarkMap = new HashMap<String, String>();
	private Map<String, String> targetMap = new HashMap<String, String>();

	private Map<String, String> onlyOnLeft = new HashMap<String, String>();
	private Map<String, String> onlyOnRight = new HashMap<String, String>();
	private Map<String, ValueDifference<String>> differing = new HashMap<String, ValueDifference<String>>();
	
	public MapDiffUtil(HashMap<String, String> bench, HashMap<String, String> target){
		setBenchMarkMap(bench);
		setTargetMap(target);
	}
		
	 
	public boolean validateEqual() {
	 
	        final MapDifference<String, String> diff = Maps.difference(benchMarkMap, targetMap);
	 
	        if (diff.areEqual()) {
	        	
	        	setDifferentFlag(true);
	        	return isDifferentFlag();
	        	
	        } else {
	        	
	        	setOnlyOnLeft(diff.entriesOnlyOnLeft());
	        	setOnlyOnRight(diff.entriesOnlyOnRight());
	        	setDiffering(diff.entriesDiffering());
	            
	        	setDifferentFlag(false);
	        	return isDifferentFlag();
	        
	        }
	    }


	public boolean isDifferentFlag() {
		return differentFlag;
	}


	public void setDifferentFlag(boolean differentFlag) {
		this.differentFlag = differentFlag;
	}


	public Map<String, String> getBenchMarkMap() {
		return benchMarkMap;
	}


	public void setBenchMarkMap(Map<String, String> benchMarkMap) {
		this.benchMarkMap = benchMarkMap;
	}


	public Map<String, String> getTargetMap() {
		return targetMap;
	}


	public void setTargetMap(Map<String, String> targetMap) {
		this.targetMap = targetMap;
	}


	public Map<String, String> getOnlyOnLeft() {
		return onlyOnLeft;
	}


	public void setOnlyOnLeft(Map<String, String> onlyOnLeft) {
		this.onlyOnLeft = onlyOnLeft;
	}


	public Map<String, String> getOnlyOnRight() {
		return onlyOnRight;
	}


	public void setOnlyOnRight(Map<String, String> onlyOnRightMap) {
		this.onlyOnRight = onlyOnRightMap;
	}


	public Map<String, ValueDifference<String>> getDiffering() {
		return differing;
	}


	public void setDiffering(Map<String, ValueDifference<String>> differing) {
		this.differing = differing;
	}
	
	
	
	     
}
