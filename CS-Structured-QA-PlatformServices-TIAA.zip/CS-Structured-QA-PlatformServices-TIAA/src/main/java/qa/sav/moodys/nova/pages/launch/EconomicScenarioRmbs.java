package qa.sav.moodys.nova.pages.launch;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class EconomicScenarioRmbs extends EconomicScenarioBase{
	
	@FindBy(id="modal-economic-scenario")
	WebElement econScenPopUp;

	public EconomicScenarioRmbs(WebDriver driver) throws Exception {
		super(driver);
		// TODO Auto-generated constructor stub
		try{
			if(econScenPopUp.isDisplayed()){
				//do nothing
			} else {
				new LaunchRmbs(driver).openEconScenDashboard();
			}
		}catch(Exception e){
			new LaunchRmbs(driver).openEconScenDashboard();
		}
	}

}
