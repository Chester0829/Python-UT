package qa.sav.moodys.nova.pages.jobResult;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import qa.sav.moodys.nova.JobCmbs;

public class AnnualPDsELsMappingsCmbs extends JobResultTabCmbs{
	
	public AnnualPDsELsMappingsCmbs(WebDriver driver, JobCmbs job)
		throws Exception {
		
		super(driver, job);
		// TODO Auto-generated constructor stub
		this.goToAnnualPDsELsMappingsTab();
	}

	public String averageSummaryFields[] = {
			"DealName",
			"Full Deal Name",
			"Bloomberg Name",
			"Tranche Id",
			"Attachment",
			"Detachment",
			"Collateral Type",
			"Balance",
			"Coupon",
			"Credit Rating Moody",
			"Credit Rating SP",
			"Credit Rating Fitch",
			"Delinquent30DPD",
			"Delinquent60DPD",
			"Delinquent90DPD",
			"Defaulted",
			"LTV",
			"Current Loss",
			"Cumulative Interest Shortfall"
	};
	
	public HashMap<String, Integer> summaryIndexMapping = new HashMap<String, Integer>(){
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
	
		{
			for(int i = 0; i < averageSummaryFields.length; i++){
				put(averageSummaryFields[i],i+1);
			}
		}		
	};
	
	public String averageOverallRattingFields[] = {
			"WAL",
			"Tranche PD",
			"Tranche LGD",
			"Tranche EL",
			"WAL Rating",
			"CE Rating",
			"Collateral PD",
			"Collateral LGD",
			"Collateral Ppy",
			"Collateral EL"
	};
	
	
	public HashMap<String, Integer> averageOverallRattingIndexMapping = new HashMap<String, Integer>(){
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
	
		{
			for(int i = 0; i < averageOverallRattingFields.length; i++){
				put(averageOverallRattingFields[i],i+1);
			}
		}		
	};
	
	public String confidenceOverallRattingFields[] = {
			"WAL",
			"Tranche EL",
			"WAL Rating",
			"Collateral PD",
			"Collateral LGD",
			"Collateral Ppy",
			"Collateral EL"
	};
	public HashMap<String, Integer> confidenceOverallRattingIndexMapping = new HashMap<String, Integer>(){
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
	
		{
			for(int i = 0; i < confidenceOverallRattingFields.length; i++){
				put(confidenceOverallRattingFields[i],i+1);
			}
		}		
	};	
	

	public String projectedRattingFields[] = {
			"Year",
			"EL",
			"EL Rating",
			"PD",
			"PD Rating",
			"CE Rating",
			"Collateral PD",
			"Collateral LGD",
			"Collateral Ppy",
			"Collateral EL",
			"Attachment",
			"Detachment"	
	};
	
	public HashMap<String, Integer> projectedRattingIndexMapping = new HashMap<String, Integer>(){
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
	
		{
			for(int i = 0; i < projectedRattingFields.length; i++){
				put(projectedRattingFields[i],i+1);
			}
		}		
	};
			
	@FindBy(xpath = "//*[@id=\"pd_el_scenario\"]") //*[@id="pd_el_scenario"]
	public WebElement choseScenaio;

	@FindBy(xpath = "//*[@id=\"pd_el_cusip\"]") //*[@id="pd_el_cusip"]
	public WebElement choseCusip;
	
	@FindBy(xpath = "//*[@id=\"pd_el_mapping\"]/div/div/form/span[1]") //*[@id="pd_el_mapping"]/div/div/form/span[1]
	public WebElement scenarioText; 
	
	@FindBy(id = "select2-chosen-12")
	public WebElement clickChoseScenario;
	
	@FindBy(xpath = "//*[@id=\"pd_el_mapping\"]/div/div/form/span[2]") //*[@id="pd_el_mapping"]/div/div/form/span[2]
	public WebElement cusipText;
	
	@FindBy(id = "select2-chosen-11")
	public WebElement clickChoseCusip;
	
	final static String exportButtonXpath = "//*[@id=\"pd_el_mapping\"]/div/div/form/button";  //*[@id="bondCashflow"]/div/div/form
	@FindBy(xpath = exportButtonXpath) //*[@id="btn-export-overview"]  //*[@id="btn-export-overview"] //*[@id="bondCashflow"]/div/div/form/button
	public WebElement exportButton;
	
	@FindBy(xpath = "//*[@id=\"average\"]/div[1]/div[1]") //*[@id="average"]/div[1]/div[1]
	public WebElement averageSummaryTitleText;
	
	@FindBy(xpath = "//*[@id=\"pd_el_mapping_summary\"]") //*[@id="pd_el_mapping_summary"]
	public WebElement averageSummaryTable;
	
	@FindBy(xpath = "//*[@id=\"average\"]/div[2]/div[1]")  //*[@id="percentile"]/div[2]/div[1]
	public WebElement averageOverallRattingTitleText;	
	@FindBy(xpath = "//*[@id=\"average\"]/div[2]/div[2]/table") //*[@id="average"]/div[2]/div[2]/table
	public WebElement averageOverallRattingTable;
	
	
	@FindBy(xpath = "//*[@id=\"percentile\"]/div[1]/div[1]") //*[@id="percentile"]/div[1]/div[1]
	public WebElement confidenceOverallRattingTitleText;
	@FindBy(xpath = "//*[@id=\"percentile\"]/div[1]/div[2]/table")
	public WebElement confidenceOverallRattingTable;
	
	@FindBy(xpath = "//*[@id=\"percentile\"]/div[2]/div[1]")
	public WebElement confidenceProjectedRattingMapTitleText;
	@FindBy(xpath = "//*[@id=\"percentile\"]/div[2]/div[2]/table")
	public WebElement confidenceProjectedRattingMapTable;
	
	
	@FindBy(xpath = "//*[@id=\"average\"]/div[3]/div[1]")
	public WebElement averageProjectedRattingMapTitleText;	
	@FindBy(xpath = "//*[@id=\"average\"]/div[3]/div[2]/table")
	public WebElement averageProjectedRattingMapTable;
	
	public void exportRattingMapReportsByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectToScenario(scenario);
		this.selectToCusip(cusip);
		//Thread.sleep(1000*30);
		this.waitForButtonActive(exportButtonXpath);
		this.downloadFile(this.exportButton, new File("C:\\temp\\"));
		this.waitForAjaxLoaded();
	}

	public String[] getAverageRattingMappingSummaryHeadersByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.goToAverageSubtab();
		this.selectScenarioAndCusip(scenario, cusip);
		
		String headers[] = new String[this.averageSummaryTable.findElements(By.xpath("thead/tr/th")).size()];
		
		for(int i = 0; i < headers.length; i++){
			headers[i] = this.averageSummaryTable.findElement(By.xpath("thead/tr/th["+(i+1)+"]")).getText();
		}		
		return headers;
	}
	
	public HashMap<String, String> getAverageRattingMapSummaryByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.goToAverageSubtab();
		this.selectScenarioAndCusip(scenario, cusip);
		HashMap<String, String> rattingMapSummary = new HashMap<String, String>();
		int collumns = this.averageSummaryTable.findElements(By.xpath("thead/tr[1]/th")).size();
		String feild = null;
		String value = null;
		for(int i = 0; i < collumns; i++){
			feild = this.averageSummaryTable.findElement(By.xpath("thead/tr[1]/th["+(i+1)+"]")).getText();
			value = this.averageSummaryTable.findElement(By.xpath("tbody/tr[1]/td["+(i+1)+"]")).getText();
			rattingMapSummary.put(feild, value);
		}		
		return rattingMapSummary;
	}
	
	public String[] getAverageOverallRattingHeadersByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.goToAverageSubtab();
		this.selectScenarioAndCusip(scenario, cusip);		
		String headers[] = new String[this.averageOverallRattingTable.findElements(By.xpath("thead/tr/th")).size()];
		
		for(int i = 0; i < headers.length; i++){
			headers[i] = this.averageOverallRattingTable.findElement(By.xpath("thead/tr/th["+(i+1)+"]")).getText();
		}			
		return headers;
	}
	
	public HashMap<String, String> getAverageOverallRattingByScenarioAndCusip(String scenario, String cusip) throws Exception{		
		this.selectScenarioAndCusip(scenario, cusip);
		this.goToAverageSubtab();
		HashMap<String, String> overallRattings = new HashMap<String, String>();
		int collumns = this.averageOverallRattingTable.findElements(By.xpath("thead/tr[1]/th")).size();
		String feild = null;
		String value = null;
		for(int i = 0; i < collumns; i++){
			feild = this.averageOverallRattingTable.findElement(By.xpath("thead/tr[1]/th["+(i+1)+"]")).getText();
			value = this.averageOverallRattingTable.findElement(By.xpath("tbody/tr[1]/td["+(i+1)+"]")).getText();
			overallRattings.put(feild, value);
		}		
		return overallRattings;
	}
	
	public String[] getAveragePorjectedRattingHeadersByScenarioAndCusip() throws Exception{
		this.goToAverageSubtab();		
		String headers[] = new String[this.averageProjectedRattingMapTable.findElements(By.xpath("thead/tr/th")).size()];
		
		for(int i = 0; i < headers.length; i++){
			headers[i] = this.averageProjectedRattingMapTable.findElement(By.xpath("thead/tr/th["+(i+1)+"]")).getText();
		}	
		
		return headers;
	}
	
	public String[] getAveragePorjectedRattingHeadersByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.goToAverageSubtab();
		this.selectScenarioAndCusip(scenario, cusip);
		
		String headers[] = new String[this.averageProjectedRattingMapTable.findElements(By.xpath("thead/tr/th")).size()];
		
		for(int i = 0; i < headers.length; i++){
			headers[i] = this.averageProjectedRattingMapTable.findElement(By.xpath("thead/tr/th["+(i+1)+"]")).getText();
		}	
		
		return headers;
	}
	
	public HashMap<String, String>[] getAverageProjectedRattingMapByScenarioAndCusip() throws Exception{
		this.goToAverageSubtab();
		HashMap<String, String> projectedRattings[] = new HashMap[10];
		HashMap<String, String> annualRatting;
		String header[] = this.projectedRattingFields;
		int collumns = header.length;
		String feild = null; 
		String value = null;
		for(int n = 0; n < 10; n++){
			annualRatting = new HashMap<String, String>();
			for(int i = 0; i < collumns; i++){ 
				feild = header[i];
				
				value = this.averageProjectedRattingMapTable.findElement(By.xpath("tbody/tr["+(n+1)+"]/td["+(i+1)+"]")).getText();
			//	System.out.println(feild+": "+value);
				annualRatting.put(feild, value);
			}		
			projectedRattings[n] = annualRatting;
		}
		return projectedRattings;
	}
	
	public HashMap<String, String>[] getAverageProjectedRattingMapByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.goToAverageSubtab();
		this.selectScenarioAndCusip(scenario, cusip);
		HashMap<String, String> projectedRattings[] = new HashMap[10];
		HashMap<String, String> annualRatting;
		String header[] = this.getAveragePorjectedRattingHeadersByScenarioAndCusip(scenario, cusip);
		int collumns = header.length;
		String feild = null; 
		String value = null;
		for(int n = 0; n < 10; n++){
			annualRatting = new HashMap<String, String>();
			for(int i = 0; i < collumns; i++){ 
				feild = header[i];
				
				value = this.averageProjectedRattingMapTable.findElement(By.xpath("tbody/tr["+(n+1)+"]/td["+(i+1)+"]")).getText();
			//	System.out.println(feild+": "+value);
				annualRatting.put(feild, value);
			}		
			projectedRattings[n] = annualRatting;
		}
		return projectedRattings;
	}
	
	public String[] getConfidenceOverallRattingHeadersByScenarioAndCusip() throws Exception{
		
		this.goToConfidenceSubtab();
		int collumns = this.confidenceOverallRattingTable.findElements(By.xpath("thead/tr[1]/th")).size();
		String headers[] = new String[collumns];
		
		for(int i = 0; i < collumns; i++){
			headers[i] = confidenceOverallRattingTable.findElement(By.xpath("thead/tr/th["+(i+1)+"]")).getText();
		}		
		return headers;
	}
	
public String[] getConfidenceOverallRattingHeadersByScenarioAndCusip(String scenario, String cusip) throws Exception{
		
		this.selectScenarioAndCusip(scenario, cusip);
		this.goToConfidenceSubtab();
		int collumns = this.confidenceOverallRattingTable.findElements(By.xpath("thead/tr[1]/th")).size();
		String headers[] = new String[collumns];
		for(int i = 0; i < collumns; i++){
			headers[i] = confidenceOverallRattingTable.findElement(By.xpath("thead/tr/th["+(i+1)+"]")).getText();
		}		
		return headers;
	}
	
	public HashMap<String, String> getConfidenceOverallRattingByScenarioAndCusip(String scenario, String cusip) throws Exception{
		
		this.selectScenarioAndCusip(scenario, cusip);
		this.goToConfidenceSubtab();
		HashMap<String, String> overallRattings = new HashMap<String, String>();
		String[] header = getConfidenceOverallRattingHeadersByScenarioAndCusip(scenario, cusip);
		int collumns = header.length;
		String feild = null;
		String value = null;
		for(int i = 0; i < collumns; i++){
			feild = header[i];
			value = this.confidenceOverallRattingTable.findElement(By.xpath("tbody/tr[1]/td["+(i+1)+"]")).getText();
			overallRattings.put(feild, value);
		}		
		return overallRattings;
	}
	
	
	public String[] getConfidenceProjectedRattingMapHeadersByScenarioAndCusip(String scenario, String cusip) throws Exception{
			
		this.selectScenarioAndCusip(scenario, cusip);
		this.goToConfidenceSubtab();
		String headers[] = new String[this.confidenceProjectedRattingMapTable.findElements(By.xpath("thead/tr/th")).size()];
		
		for(int i = 0; i < headers.length; i++){
			headers[i] = this.confidenceProjectedRattingMapTable.findElement(By.xpath("thead/tr/th["+(i+1)+"]")).getText();
		}	
		
		return headers;
	}
	
	public HashMap<String, String>[] getConfidenceProjectedRattingMapByScenarioAndCusip(String scenario, String cusip) throws Exception{
		
		this.selectScenarioAndCusip(scenario, cusip);
		this.goToConfidenceSubtab();
		HashMap<String, String> projectedRattings[] = new HashMap[10];
		HashMap<String, String> annualRatting;
		String header[] = this.getConfidenceProjectedRattingMapHeadersByScenarioAndCusip(scenario, cusip);
		int collumns = header.length;
		String feild = null;
		String value = null;
		for(int n = 0; n < 10; n++){
			annualRatting = new HashMap<String, String>();
			for(int i = 0; i < collumns; i++){
				feild = header[i];
				value = this.confidenceProjectedRattingMapTable.findElement(By.xpath("tbody/tr["+(n+1)+"]/td["+(i+1)+"]")).getText();
				annualRatting.put(feild, value);
			}		
			projectedRattings[n] = annualRatting;
		}
		return projectedRattings;
	}
	
	public void goToAverageSubtab() throws Exception{
		String xpath = "//*[@id=\"pdElmappingContent\"]/ul/li[1]";
		if(driver.findElement(By.xpath(xpath)).getAttribute("class").equals("active")){
			// already in average subtab, do nothing
		} else {
			driver.findElement(By.xpath(xpath+"/a")).click();
			this.waitForAjaxLoaded();
		}
	}
	
	public void goToConfidenceSubtab() throws Exception{
		String xpath = "//*[@id=\"pdElmappingContent\"]/ul/li[2]";
		if(driver.findElement(By.xpath(xpath)).getAttribute("class").equals("active")){
			// already in average subtab, do nothing
		} else {
			driver.findElement(By.xpath(xpath+"/a")).click();
			this.waitForAjaxLoaded();
		}
	}
	
	protected void selectScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectToScenario(scenario);
		this.selectToCusip(cusip);
	}

	public void selectToScenario(String scenario) throws Exception{
		
		if(clickChoseScenario.getText().equals(scenario)){
			//scenario alread selected, do nothing
		} else {
			clickChoseScenario.click();
			this.waitForAjaxLoaded();
			Select choseScenarioSelector = new Select(choseScenaio);
			choseScenarioSelector.selectByVisibleText(scenario);
			this.waitForAjaxLoaded();
		}
	}
	
	public void selectToCusip(String cusip) throws Exception{
		
		if(clickChoseCusip.getText().equals(cusip)){
			// cusip alread selected, do nothing
		} else {
			clickChoseCusip.click();
			this.waitForAjaxLoaded();
			Select choseCusipSelector = new Select(choseCusip);
			choseCusipSelector.selectByVisibleText(cusip);
			this.waitForAjaxLoaded();
		}
	}

}
