package qa.sav.moodys.nova.pages.jobResult;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import qa.sav.moodys.nova.JobCmbs;

public class OverviewCmbs extends JobResultTabCmbs{
	
	@FindBy(xpath = "//*[@id=\"overView\"]/div/div/form/span[1]")
	public WebElement scenarioText;
	
	@FindBy(xpath = "//*[@id=\"overview_scenario\"]") //*[@id="overview_scenario"]
	public WebElement choseScenario;

	@FindBy(xpath = "//*[@id=\"overview_cusip\"]") //*[@id="overview_cusip"]
	public WebElement choseCusip;
	
	@FindBy(xpath = "//*[@id=\"select2-chosen-1\"]")
	public WebElement clickChoseScenario;
	
	@FindBy(xpath = "//*[@id=\"overView\"]/div/div/form/span[2]")
	public WebElement cusipText;
	
	@FindBy(xpath = "//*[@id=\"select2-chosen-2\"]")
	public WebElement clickChoseCusip;
	
	static final String profileTitleXpath = "//*[@id=\"overViewContent\"]/div[1]/div[1]";
	@FindBy(xpath = profileTitleXpath)
	public WebElement profileTitle;
	
	static final String profileTableXpath = "//*[@id=\"overview_profile\"]/tbody";
	@FindBy(xpath = profileTableXpath)
	public WebElement profileTable;
	
	static final String summaryTitleXpath = "//*[@id=\"overViewContent\"]/div[2]/div[1]";
	@FindBy(xpath = summaryTitleXpath)
	public WebElement summaryTitle;
	
	static final String summaryTableXpath = "//*[@id=\"overview_summary\"]/tbody";
	@FindBy(xpath = summaryTableXpath)
	public WebElement summaryTable;
	
	public String profileKeys[] = {"Current CUSIP",
			"Verification",
			"Previous Month's Update Used",
			"Use Default CMM file",
			"Full Deal Name",
			"Bloomberg Name",
			"Total Securitized Balance",
			"Total Current Balance",
			"Total Active Loan Count",
			"Average Securitized Balance",
			"Average Current Balance",
			"Deal Closing Date",
			"Remittance Date",
			"Analysis Type",
			"Run Date",
			"As Of Date",
			"Tranche Id",
			"Coupon",
			"Balance",
			"Attachment",
			"Detachment",
			"Credit Rating Moody",
			"Credit Rating SP",
			"Credit Rating Fitch",
			"Credit Rating DBRS",
			"Credit Rating Kroll",
			"Credit Rating Morningstar",
			"Delinquent30DPD",
			"Delinquent60DPD",
			"Delinquent90DPD",
			"Defaulted"};

	public String summaryKeys[] = {
		"Wtd.Avg.Gross Margin(ARM)",
		"Wtd.Avg.Rate",
		"Wtd.Avg.Original Term",
		"Wtd.Avg.IO Term/IO%",
		"insured"	
	};
			
	public OverviewCmbs(WebDriver driver, JobCmbs job) throws Exception {
		super(driver, job);
		// TODO Auto-generated constructor stub		
		this.goToOverviewTab();						
	}
	
	public void selectToScenario(String scenario) throws Exception{
		Select choseScenarioSelector = new Select(choseScenario);
		
		if(clickChoseScenario.getText().equals(scenario)){
			//scenario alread selected, do nothing
		} else {
			clickChoseScenario.click();
			this.waitForAjaxLoaded();
			choseScenarioSelector.selectByVisibleText(scenario);
			this.waitForAjaxLoaded();
		}
	}
	
	public void selectToCusip(String cusip) throws Exception{
		
		Select choseCusipSelector = new Select(choseCusip);
		if(clickChoseCusip.getText().equals(cusip)){
			// cusip alread selected, do nothing
		} else {
			clickChoseCusip.click();
			this.waitForAjaxLoaded();
			
			choseCusipSelector.selectByVisibleText(cusip);
			this.waitForAjaxLoaded();
		}
	}

	public String[] getScenariosList(){	
		return this.getScenariosList(choseScenario);
	}
	
	public String[] getCusipsList() throws Exception{
		return this.getCusipsList(choseCusip);
	}
	
	public HashMap<String,String> readProfileByScenAndCusip(String scenario, String cusip) throws Exception{
		selectToScenario(scenario);
		selectToCusip(cusip);
		HashMap<String, String> profile = new HashMap<String, String>();
		String profileValue = new String();
		for(int i = 0; i < this.profileKeys.length; i++){
			profileValue = profileTable.findElement(By.xpath("tr["+(i+1)+"]/td[2]")).getText();
			profile.put(profileKeys[i],profileValue);
		}
		return profile;
	}
	
	public HashMap<String,String> readProfileByScenAndCusip(){
		HashMap<String, String> profile = new HashMap<String, String>();
		String profileValue = new String();
		for(int i = 0; i < this.profileKeys.length; i++){
			profileValue = profileTable.findElement(By.xpath("tr["+(i+1)+"]/td[2]")).getText();
			profile.put(profileKeys[i],profileValue);
		}
		return profile;
	}
	
	public HashMap<String,String> readSummaryByScenAndCusip(String scenario, String cusip) throws Exception{
		selectToScenario(scenario);
		selectToCusip(cusip);
		HashMap<String, String> summary = new HashMap<String, String>();
		String summaryValue = new String();
		for(int i = 0; i < this.summaryKeys.length; i++){
			summaryValue = summaryTable.findElement(By.xpath("tr["+(i+1)+"]/td[2]")).getText();
			summary.put(summaryKeys[i],summaryValue);
		}
		return summary;
	}
	
	public HashMap<String,String> readSummaryByScenAndCusip(){
		HashMap<String, String> summary = new HashMap<String, String>();
		String summaryValue = new String();
		for(int i = 0; i < this.summaryKeys.length; i++){
			summaryValue = summaryTable.findElement(By.xpath("tr["+(i+1)+"]/td[2]")).getText();
			summary.put(summaryKeys[i],summaryValue);
		}
		return summary;
	}
}
 