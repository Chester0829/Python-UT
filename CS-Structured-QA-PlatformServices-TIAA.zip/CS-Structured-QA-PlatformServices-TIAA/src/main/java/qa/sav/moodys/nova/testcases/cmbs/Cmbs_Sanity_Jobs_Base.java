package qa.sav.moodys.nova.testcases.cmbs;

import java.io.File;
import java.io.FileReader;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.data.JobSettings;
import qa.sav.moodys.nova.data.JobStatus;
import qa.sav.moodys.nova.testcases.base.TestCaseBase;

public class Cmbs_Sanity_Jobs_Base extends TestCaseBase{
	String job_records_path_tmp = System.getProperty("user.dir")+File.separator+"data/cmbs_job_records_tmp.json";
	String job_records_path = System.getProperty("user.dir")+File.separator+"data/cmbs_sanity_test_job_records.json";
	String job_records_path_benchmark = System.getProperty("user.dir")+File.separator+"data/cmbs_sanity_benchmark_job_records.json";
	
	String job_benchmark_mapping_path = System.getProperty("user.dir")+File.separator+"data/cmbs_sanity_benchmark_job_mapping.json";
	
	String job_config_filePath = System.getProperty("user.dir")+ File.separator +"config/testcase/job_configue_cmbs_sanity.csv";
	String portfolioPath = System.getProperty("user.dir")+ File.separator +"config/testcase/launchCmbsSanity.csv";
	
//	@BeforeSuite @Override
//	public void clearOutput(){		
//		//initialDriver();	
//		log.info("initial log file ... ");
//		// clear log file
//		log.info("initializing screen shot folder");
//		// clear screen shot folders
//	}	
	
	@DataProvider(name = "cmbs_sanity_jobs")
	public Object[][] get_cmbs_sanity_jobs_to_submit() throws Exception{
		JobCmbs jobs[];
		Object data[][];
		try {
			jobs = DataProviderJobConfigCmbs.readTestCasesConfig(job_config_filePath,portfolioPath);
			data= new Object[jobs.length][2];
			System.out.println("data provider length: "+jobs.length);
			for(int n = 0; n < jobs.length; n++){
				data[n][1] = jobs[n].getJobSettings().getJobName();
				data[n][0] = jobs[n];
			}
		} catch (Exception e) {
			
			e.printStackTrace();
			throw e;
		}
		return data;
	}
	
	@DataProvider(name = "cmbs_sanity_jobs_submitted",parallel=true)
	public Object[][] get_submitted_cmbs_sanity_jobs() throws Exception{
		log.info("get data for submitted jobs.");
		Object data[][];
		JsonParser parser = new JsonParser();
		
		try {
			Object obj = parser.parse(new FileReader(this.job_records_path_tmp));

	        JsonObject submitJobsJsonObject =  (JsonObject) obj;
			//jobs = DataProviderJobConfigCmbs.readTestCasesConfig(job_config_filePath,portfolioPath);
			data= new Object[submitJobsJsonObject.keySet().size()][1];
			int n = 0;			
			for(String submitJobName:submitJobsJsonObject.keySet()){
				data[n++][0] = submitJobName;
			}
						
		} catch (Exception e) {
			
			e.printStackTrace();
			throw e;
		}
		return data;
	}
	
	@DataProvider(name = "cmbs_sanity_jobs_and_cusips") //,parallel=true
	public Object[][] get_submitted_cmbs_sanity_jobs_and_cusips() throws Exception{
		log.info("get data for submitted jobs.");
		Object data[][];
		JsonParser parser = new JsonParser();
		int paramLength = 0;
		
		try {
			Object obj = parser.parse(new FileReader(this.job_records_path_tmp));
	        JsonObject submitJobsJsonObject =  (JsonObject) obj;
	        for(String submitJobName:submitJobsJsonObject.keySet()){
	        	paramLength += new Gson().fromJson(submitJobsJsonObject.get(submitJobName), JobSettings.class).getCusipsList().size();
	        }
	        
			data= new Object[paramLength][2];
			int n = 0;			
			for(String submitJobName:submitJobsJsonObject.keySet()){
				
				for(String cusip:new Gson().fromJson(submitJobsJsonObject.get(submitJobName), JobSettings.class).getCusipsList()){
					data[n][0] = submitJobName;
					data[n++][1] = cusip;
				}				
			}
						
		} catch (Exception e) {
			
			e.printStackTrace();
			throw e;
		}
		return data;
	}
	
	JobSettings readJobSettingsFromJsonFile(String jsonFilePath, String jobName) throws Exception {
		
		JsonParser parser = new JsonParser();
		try {
			Object obj = parser.parse(new FileReader(this.job_records_path_tmp));

	        JsonObject submitJobsJsonObject =  (JsonObject) obj;
			
			JobSettings jobSettings = new Gson().fromJson(submitJobsJsonObject.get(jobName), JobSettings.class);		
			return jobSettings;
		} catch(Exception ex){
			throw ex;
		}
		
	}

	JobCmbs getBenchJob(WebDriver driver, String jobNameType) throws Exception{
		JsonParser parser = new JsonParser();
		try {
			Object obj = parser.parse(new FileReader(this.job_benchmark_mapping_path));

	        JsonObject submitJobsJsonObject =  (JsonObject) obj;
			
	        JsonObject jobSettingJsonObject = (JsonObject) submitJobsJsonObject.get(jobNameType);
	        String jobName = jobSettingJsonObject.get("jobName").toString().replace("\"", "");
	        int jobId = Integer.parseInt(jobSettingJsonObject.get("jobId").toString());
	        
	        
			JobSettings jobSettings = new JobSettings();	
			JobStatus jobStatus = new JobStatus();
			jobSettings.setJobName(jobName);
			jobStatus.setName(jobName);
			jobStatus.setJobID(jobId);
		
			JobCmbs jobBench = new JobCmbs(driver);
			jobBench.setJobSettings(jobSettings);
			jobBench.setJobStatus(jobStatus);
		
			return jobBench;
		} catch(Exception ex){
			throw ex;
		}
		}
		
}
