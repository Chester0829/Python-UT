package qa.sav.moodys.nova.s3;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.event.ProgressEvent;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.RegionUtils;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.transfer.Download;
import com.amazonaws.services.s3.transfer.PersistableTransfer;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.internal.S3ProgressListener;


public class SimpleStoreHandlerImpl implements SimpleStoreHandler{
	private AmazonS3 s3Client;
	private TransferManager transferManager;
	private final static Logger LOGGER = LoggerFactory.getLogger(SimpleStoreHandlerImpl.class);
	
	public SimpleStoreHandlerImpl(){
//		AWSCredentials credentials = new BasicAWSCredentials(AWSConfig.getIdentity(),AWSConfig.getCredential());
		AWSCredentials credentials = new BasicAWSCredentials("AKIAJKBQX2XEBYFX22EA","Y+ceK3LE8ZP9L6sNYkst1mVrGNhT4zgtCqIRyCQE");
		ClientConfiguration clientCfg = new ClientConfiguration();
		
//		String proxyServer=AWSConfig.getS3ProxyServer();
//		String proxyPort=AWSConfig.getS3ProxyPort();
		String proxyServer="proxy-sfo";
		String proxyPort="80";
		
		if(StringUtils.isNotEmpty(proxyServer)&&StringUtils.isNotEmpty(proxyPort)){
			clientCfg.setProtocol(Protocol.HTTP);
			clientCfg.setProxyHost(proxyServer);
			clientCfg.setProxyPort(Integer.parseInt(proxyPort));
		}
		s3Client = new AmazonS3Client(credentials,clientCfg);
		
//		Region region = RegionUtils.getRegion(AWSConfig.getAwsRegion());
		Region region = RegionUtils.getRegion("us-west-2");
		if(region!=null){
			s3Client.setRegion(region);
		}else{
			s3Client.setRegion(Region.getRegion(Regions.DEFAULT_REGION));
		}
		transferManager=new TransferManager(s3Client);
	}

	public StoreObject retrieveObject(String bucketname, String key) throws RuntimeException {
		if (bucketname == null || bucketname.isEmpty()) {
			throw new InvalidParameterException(
					"bucket name shoud not be empty");
		}

		if (key == null || key.isEmpty()) {
			throw new InvalidParameterException("key shoud not be empty");
		}

		GetObjectRequest request = new GetObjectRequest(bucketname, key);
		com.amazonaws.services.s3.model.S3Object s3object = s3Client.getObject(request);
		StoreObject storeObject = Wrapper.wrapStoreObject(s3object);
        
        return storeObject;
	}
	public ObjectMetadata retrieveObjectToFile(String bucketname, String key, File destFile) throws RuntimeException {
		if (bucketname == null || bucketname.isEmpty()) {
			throw new InvalidParameterException(
					"bucket name shoud not be empty");
		}

		if (key == null || key.isEmpty()) {
			throw new InvalidParameterException("key shoud not be empty");
		}

		GetObjectRequest request = new GetObjectRequest(bucketname, key);
		return Wrapper.wrapObjectMetadata(s3Client.getObject(request,destFile));
	}
	public StoreObject retrieveObject(String bucketname, String key, String versionId) throws RuntimeException {
		if (bucketname == null || bucketname.isEmpty()) {
			throw new InvalidParameterException(
					"bucket name shoud not be empty");
		}

		if (key == null || key.isEmpty()) {
			throw new InvalidParameterException("key shoud not be empty");
		}

		if (versionId == null || versionId.isEmpty()) {
			throw new InvalidParameterException("version id shoud not be empty");
		}

		GetObjectRequest request = new GetObjectRequest(bucketname, key,
				versionId);
		return Wrapper.wrapStoreObject(s3Client.getObject(request));
	}
	
	public List<StoreObjectSummary> listObjects(String bucketname) throws RuntimeException {
		if (bucketname == null || bucketname.isEmpty()) {
			throw new InvalidParameterException(
					"bucket name shoud not be empty");
		}
		List<StoreObjectSummary> results = new ArrayList<StoreObjectSummary>();
		ObjectListing listing = s3Client.listObjects(new ListObjectsRequest().withBucketName(bucketname));
		while(true) {
			List<com.amazonaws.services.s3.model.S3ObjectSummary> summaries = listing.getObjectSummaries();
			for (com.amazonaws.services.s3.model.S3ObjectSummary summary : summaries) {
				results.add(Wrapper.wrapStoreObjectSummary(summary));
			}
			listing = s3Client.listNextBatchOfObjects(listing);
			if(!listing.isTruncated()) {
				List<com.amazonaws.services.s3.model.S3ObjectSummary> leftSummaries = listing.getObjectSummaries();
				for (com.amazonaws.services.s3.model.S3ObjectSummary summary : leftSummaries) {
					results.add(Wrapper.wrapStoreObjectSummary(summary));
				}
				break;
			}
		}
		return results;
	}
	public List<StoreObjectSummary> listObjects(String bucketname, String prefix) throws RuntimeException {
		if (bucketname == null || bucketname.isEmpty()) {
			throw new InvalidParameterException(
					"bucket name shoud not be empty");
		}
		List<StoreObjectSummary> results = new ArrayList<StoreObjectSummary>();
		ObjectListing listing = s3Client.listObjects(new ListObjectsRequest().withBucketName(bucketname).withPrefix(prefix));
		do{
			List<com.amazonaws.services.s3.model.S3ObjectSummary> summaries = listing.getObjectSummaries();
			for (com.amazonaws.services.s3.model.S3ObjectSummary summary : summaries) {
				results.add(Wrapper.wrapStoreObjectSummary(summary));
			}
			listing = s3Client.listNextBatchOfObjects(listing);
		}while(listing.isTruncated());
		
		
		return results;
	}
	public List<StoreObjectSummary> listObjects(String bucketname, String prefix, boolean fuzzy, String... delimiters) throws RuntimeException {
		if (bucketname == null || bucketname.isEmpty()) {
			throw new InvalidParameterException(
					"bucket name shoud not be empty");
		}
		List<StoreObjectSummary> results = new ArrayList<StoreObjectSummary>();
		ObjectListing listing = null;
		if(delimiters != null && delimiters.length > 0) {
			listing = s3Client.listObjects(new ListObjectsRequest().withBucketName(bucketname).withPrefix(prefix).withDelimiter(delimiters[0]));
		} else {
			listing = s3Client.listObjects(new ListObjectsRequest().withBucketName(bucketname).withPrefix(prefix));
		}
		while(true) {
			List<com.amazonaws.services.s3.model.S3ObjectSummary> summaries = listing.getObjectSummaries();
			for (com.amazonaws.services.s3.model.S3ObjectSummary summary : summaries) {
				String dealName = summary.getKey().split("/")[0].trim();
				if(!fuzzy && !dealName.equals(prefix)) {
					continue;
				}
				results.add(Wrapper.wrapStoreObjectSummary(summary));
			}
			listing = s3Client.listNextBatchOfObjects(listing);
			if(!listing.isTruncated()) {
				List<com.amazonaws.services.s3.model.S3ObjectSummary> leftSummaries = listing.getObjectSummaries();
				for (com.amazonaws.services.s3.model.S3ObjectSummary summary : leftSummaries) {
					String dealName = summary.getKey().split("/")[0].trim();
					if(!fuzzy && !dealName.equals(prefix)) {
						continue;
					}
					results.add(Wrapper.wrapStoreObjectSummary(summary));
				}
				break;
			}
		}
		return results;
	}
	
	public List<Bucket> listBuckets() throws RuntimeException {
		List<com.amazonaws.services.s3.model.Bucket> buckets = s3Client.listBuckets();
		List<Bucket> results = new ArrayList<Bucket>();
		for (com.amazonaws.services.s3.model.Bucket bucket : buckets) {
			results.add(Wrapper.wrapBucket(bucket));
		}
		return results;
	}
	
	public String retrieveObjectStringContent(String bucketname, String key)throws Exception{
		if (bucketname == null || bucketname.isEmpty()) {
			throw new InvalidParameterException(
					"bucket name shoud not be empty");
		}

		if (key == null || key.isEmpty()) {
			throw new InvalidParameterException("key shoud not be empty");
		}
		InputStream input=null;
		int retry=30;
		for(int i=1;i<=retry;i++){
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            com.amazonaws.services.s3.model.S3Object s3object = null;
			try{
				GetObjectRequest request = new GetObjectRequest(bucketname, key);
                s3object = s3Client.getObject(request);
				input=s3object.getObjectContent();
				byte[] buffer = new byte[1024 * 10];
				int bytesRead;
				while ((bytesRead = input.read(buffer)) > -1) {
					out.write(buffer, 0, bytesRead);
				}
				
				return out.toString();
			}catch(Exception e){
				Thread.sleep(3000);
				if(i==retry){
					throw e;
				}
			}finally{
				try{
					if(input!=null){
						input.close();
					}	
	                out.close();

	                if (s3object != null) {
	                    s3object.close();
	                }
				}catch(IOException e){
					
				}
				
			}
		}
		return null;
		
		
	}
	public void downloadObjectToFile(String bucket, String key,File file)throws RuntimeException{

		if (bucket == null || bucket.isEmpty()) {
			throw new InvalidParameterException(
					"bucket name shoud not be empty");
		}
	
		if (key == null || key.isEmpty()) {
			throw new InvalidParameterException("key shoud not be empty");
		}
	
		int tryTime=30;
		for(int i=1;i<=tryTime;i++){
			try{
				GetObjectRequest get=new GetObjectRequest(bucket, key);
				Download download=transferManager.download(get, file,new S3ProgressListener()  {
					
					public void progressChanged(ProgressEvent progressEvent) {
						
					}
					
					public void onPersistableTransfer(PersistableTransfer persistableTransfer) {
					
						
					}
				});
				download.waitForCompletion();
				break;
			}catch(Exception e){
				if(i==tryTime){
					throw new RuntimeException("download file from s3  exception :"+e.getMessage());
				}
				LOGGER.error("download file from  s3  exception : try again");
			}
		}
		LOGGER.info("download complete.");
	}
		
	@Test
	public void tttTest() throws Exception{
		SimpleStoreHandlerImpl test = new SimpleStoreHandlerImpl();
		List<Bucket> buckets = test.listBuckets();
		for(int i = 0; i < buckets.size(); i++){
		System.out.println(buckets.get(i).getName());
		}
				
		List<StoreObjectSummary> test2 = test.listObjects("moodys-sf-simulation-abs","sav-tiaa/deal-sync-tiaa/cmbs_boa01003/2016/08/3463558/3463558.zip"); //CMBS_BOA01003_3463558_CUSTOM_sherry_Sherry_Summer_2016_batch_output.csv");
//		for(int i = 0; i < test2.size(); i++){
		String key = test2.get(0).getKey();

		System.out.println(key);
		System.out.println(this.retrieveObject("moodys-sf-simulation-abs", key).getBucketName());
		System.out.println(this.retrieveObject("moodys-sf-simulation-abs", key).getKey());
		
		//}
		File file = new File("C:\\\\SAV\\\\nova\\\\QA_255\\\\test.zip");//+key.split("/")[key.split("/").length-1]); 
		test.downloadObjectToFile("moodys-sf-simulation-qa", key, file);
		
	}
}
