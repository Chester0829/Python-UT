package qa.sav.moodys.nova.pages.jobResult;

import java.io.File;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import qa.sav.moodys.nova.JobCmbs;

public class LoanLevelDetailsCmbs extends JobResultTabCmbs{
	
	public LoanLevelDetailsCmbs(WebDriver driver, JobCmbs job)
			throws Exception {
		
		super(driver, job);
		// TODO Auto-generated constructor stub
		this.goToLoanLevelDetailsTab();
	}

	int dscrIndex = 59;
	int ltvIndex = 69;
	int pdIndex = 79;
	int lgdIndex = 89;
	
	public String loanLevelDetailsFields[] = {
			"LoanID",
			"Loan Name",
			"Expected Loss",
			"Prepayment",
			"Default",
			"Severity",
			"Securitized Balance",
			"Current Balance",
			"Rate Type",
			"Orig Term",
			"Amor Term",
			"IO Term",
			"Rate",
			"Maturity Date",
			"Overwrite",
			"LTV",
			"LTV Reference Date",
			"DSCR",
			"DSCR Reference Date",
			"State",
			"MSA",
			"Modified",
			"Loan Status",
			"Tail Risk Contribution Default",
			"Tail Risk Contribution Percentage*",
			"Tail Risk Contribution Amount",
			"Tail Risk Contribution Severity",
			"Tail Risk Contribution Loss %",
			"Portfolio Name",
			"Group ID",
			"Analysis Date",
			"Loan Account",
			"Loan Type",
			"Origination Date",
			"Maturity Date",
			"Current Outstanding Loan Balance",
			"CMM Rate Type",
			"Payment Type",
			"Current CouponRate",
			"IO End Date",
			"Cash Reserves",
			"Seniority Within Loan Group",
			"CMM Loan Status",
			"Use Refinance Grid",
			"Property Name",
			"Property Description",
			"Property Type",
			"Sub-Property-type",
			"Property Status",
			"Zipcode",
			"Submarket",
			"Property Value",
			"Property NOI",
			"Value Reference Date",
			"NOI Reference Date",
			"Property Size",
			"Orig Amort Term",
			"Input LTV",
			"Dscr Year1",
			"Dscr Year2",
			"Dscr Year3",
			"Dscr Year4",
			"Dscr Year5",
			"Dscr Year6",
			"Dscr Year7",
			"Dscr Year8",
			"Dscr Year9",
			"Dscr Year10",
			"Ltv Year1",
			"Ltv Year2",
			"Ltv Year3",
			"Ltv Year4",
			"Ltv Year5",
			"Ltv Year6",
			"Ltv Year7",
			"Ltv Year8",
			"Ltv Year9",
			"Ltv Year10",
			"PD Year1",
			"PD Year2",
			"PD Year3",
			"PD Year4",
			"PD Year5",
			"PD Year6",
			"PD Year7",
			"PD Year8",
			"PD Year9",
			"PD Year10",
			"LGD Year1",
			"LGD Year2",
			"LGD Year3",
			"LGD Year4",
			"LGD Year5",
			"LGD Year6",
			"LGD Year7",
			"LGD Year8",
			"LGD Year9",
			"LGD Year10",
			"PD/LGD Overwrite",
			"Comments"
	};
	public HashMap<String, Integer> LoanLevelDetailsIndexMapping = new HashMap<String, Integer>(){
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
	
		{
			for(int i = 0; i < loanLevelDetailsFields.length; i++){
				put(loanLevelDetailsFields[i],i+1);
			}
		}		
	};
	
	public String projectedDscrFields[] = {
			"Dscr Year1",
			"Dscr Year2",
			"Dscr Year3",
			"Dscr Year4",
			"Dscr Year5",
			"Dscr Year6",
			"Dscr Year7",
			"Dscr Year8",
			"Dscr Year9",
			"Dscr Year10"
	};
	public HashMap<String, Integer> projectedDscrIndexMapping = new HashMap<String, Integer>(){
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
	
		{
			for(int i = 0; i < projectedDscrFields.length; i++){
				put(projectedDscrFields[i],i+dscrIndex);
			}
		}		
	};
	
	public String projectedLtvFields[] = {
			"Ltv Year1",
			"Ltv Year2",
			"Ltv Year3",
			"Ltv Year4",
			"Ltv Year5",
			"Ltv Year6",
			"Ltv Year7",
			"Ltv Year8",
			"Ltv Year9",
			"Ltv Year10"
	};
	public HashMap<String, Integer> projectedLtvIndexMapping = new HashMap<String, Integer>(){
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
	
		{
			for(int i = 0; i < projectedLtvFields.length; i++){
				put(projectedLtvFields[i],i+ltvIndex);
			}
		}		
	};	
	
	public String projectedPdFields[] = {
			"PD Year1",
			"PD Year2",
			"PD Year3",
			"PD Year4",
			"PD Year5",
			"PD Year6",
			"PD Year7",
			"PD Year8",
			"PD Year9",
			"PD Year10"	
	};
	public HashMap<String, Integer> projectedRattingIndexMapping = new HashMap<String, Integer>(){
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
	
		{
			for(int i = 0; i < projectedPdFields.length; i++){
				put(projectedPdFields[i],i+pdIndex);
			}
		}		
	};
		
	public String projectedLgdFields[] = {
			"PD Year1",
			"PD Year2",
			"PD Year3",
			"PD Year4",
			"PD Year5",
			"PD Year6",
			"PD Year7",
			"PD Year8",
			"PD Year9",
			"PD Year10"	
	};
	public HashMap<String, Integer> projectedLgdIndexMapping = new HashMap<String, Integer>(){
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
	
		{
			for(int i = 0; i < projectedLgdFields.length; i++){
				put(projectedLgdFields[i],i+lgdIndex);
			}
		}		
	};
			
	
	@FindBy(xpath = "//*[@id=\"loanLevelDetail_scenario\"]") //*[@id="pd_el_scenario"]
	public WebElement choseScenario;

	@FindBy(xpath = "//*[@id=\"loanLevelDetail_cusip\"]") //*[@id="pd_el_cusip"]
	public WebElement choseCusip;
	
	@FindBy(xpath = "//*[@id=\"loanLevelDetail\"]/div/div/form/span[1]") //*[@id="loanLevelDetail"]/div/div/form/span[1]
	public WebElement scenarioText; 
	
	@FindBy(id = "select2-chosen-9")
	public WebElement clickChoseScenario;
	
	@FindBy(xpath = "//*[@id=\"loanLevelDetail\"]/div/div/form/span[2]") //*[@id="pd_el_mapping"]/div/div/form/span[2]
	public WebElement cusipText;
	
	@FindBy(id = "select2-chosen-10")
	public WebElement clickChoseCusip;
	
	final static String exportButtonXpath = ".//button[contains(@onclick, 'exportLoanLevelDetailsCashflow()')]";  //*[@id="loanLevelDetail"]/div/div/form/button[1]
	@FindBy(xpath = exportButtonXpath) //*[@id="btn-export-overview"]  //*[@id="btn-export-overview"] //*[@id="bondCashflow"]/div/div/form/button
	public WebElement exportButton;
	
	final static String exportCmmFileXpath = ".//button[contains(@onclick, 'exportCmmFile()')]";
			//"//*[@id=\"loanLevelDetai\"]/div/div/form/button[2]";exportCmmFile()
	@FindBy(xpath = exportCmmFileXpath)
	public WebElement exportCmmFileButton;
	
	final static String loanLevelDetailTableXpath = "//*[@id=\"loanLevelDetail_tb\"]"; 
	@FindBy(xpath = loanLevelDetailTableXpath)
	public WebElement loanLevelDetailTable;
	
	
	public String[] getScenariosList(){	
		return this.getScenariosList(choseScenario);
	}
	
	public String[] getCusipsList(){
		return this.getCusipsList(choseCusip);
	}
	
	public File exportLoanLevelDetailsByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectToScenario(scenario);
		this.selectToCusip(cusip);
		//Thread.sleep(1000*30);
		//Thread.sleep(1000*30);
		//this.waitForButtonActive(exportButtonXpath);
		File exportedfile = this.downloadFile(this.exportButton, new File("C:\\temp\\"));
		this.waitForAjaxLoaded();
		return exportedfile;
	}

	public File exportCmmFileByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectScenarioAndCusip(scenario, cusip);
		this.waitForButtonActive(exportCmmFileXpath);
		File exportedCmmFile = this.downloadFile(exportCmmFileButton, new File("C:\\temp\\"));
		this.waitForAjaxLoaded();
		return exportedCmmFile;
		
	}
	
	public String[] getLoanLevelDetailsHeaderFieldsByScenarioAndCusip(String scenario, String cusip) throws Exception{
		String loanLevelDetailsHeader[] = new String[this.loanLevelDetailsFields.length];
		this.selectScenarioAndCusip(scenario, cusip);
		WebElement loanLevelDetailHeaderRow = this.loanLevelDetailTable.findElement(By.xpath("thead/tr"));
		for(int i = 0; i < loanLevelDetailsHeader.length; i++){
			loanLevelDetailsHeader[i] = 
					loanLevelDetailHeaderRow.findElement(By.xpath("th["+(i+1)+"]")).getText();
		}
		return loanLevelDetailsHeader;
	}
	
	public String[] getProjectedDscrByLoanIdScenarioAndCusip(String loanId, String scenario, String cusip){
		String projectedDscr[] = new String[10];
		String value = null;
		int row = 0;
		int length = this.loanLevelDetailTable.findElements(By.xpath("tbody/tr")).size();
		for(int n = 1; n < length+1; n++){
			if(this.loanLevelDetailTable.findElement(By.xpath("tbody/tr["+n+"]/td[1]")).getText().equalsIgnoreCase(loanId)){
				row = n;
				break;
			}
		}
		
		if(row == 0){
			log.error("Cannot find loan id + \""+loanId+"\"");
			return null;
		} else {
			for(int i = 0; i < 10; i++){
			
				value = this.loanLevelDetailTable.findElement(By.xpath("tbody/tr["+row+"]/td["+(this.dscrIndex+i)+"]")).getText();				
			
				projectedDscr[i] = value;
			}
			return projectedDscr;
		}
	}
	
	public String[] getProjectedLtvByLoanIdScenarioAndCusip(String loanId, String scenario, String cusip){
		String projectedLtv[] = new String[10];
		String value = null;
		int row = 0;
		int length = this.loanLevelDetailTable.findElements(By.xpath("tbody/tr")).size();
		for(int n = 1; n < length+1; n++){
			if(this.loanLevelDetailTable.findElement(By.xpath("tbody/tr["+n+"]/td[1]")).getText().equalsIgnoreCase(loanId)){
				row = n;
				break;
			}
		}
		
		if(row == 0){
			log.error("Cannot find loan id + \""+loanId+"\"");
			return null;
		} else {
			for(int i = 0; i < 10; i++){
			
				value = this.loanLevelDetailTable.findElement(By.xpath("tbody/tr["+row+"]/td["+(this.ltvIndex+i)+"]")).getText();				
			
				projectedLtv[i] = value;
			}
			return projectedLtv;
		}
	}
	
	public String[] getProjectedPdByLoanIdScenarioAndCusip(String loanId, String scenario, String cusip){
		String projectedPd[] = new String[10];
		String value = null;
		int row = 0;
		int length = this.loanLevelDetailTable.findElements(By.xpath("tbody/tr")).size();
		for(int n = 1; n < length+1; n++){
			if(this.loanLevelDetailTable.findElement(By.xpath("tbody/tr["+n+"]/td[1]")).getText().equalsIgnoreCase(loanId)){
				row = n;
				break;
			}
		}
		
		if(row == 0){
			log.error("Cannot find loan id + \""+loanId+"\"");
			return null;
		} else {
			for(int i = 0; i < 10; i++){
			
				//value = this.loanLevelDetailTable.findElement(By.xpath("tbody/tr["+row+"]/td["+(this.ltvIndex+i+1)+"]")).getText();	
				value = this.loanLevelDetailTable.findElement(By.xpath("tbody/tr["+row+"]/td["+(this.pdIndex+i)+"]/input")).getAttribute("value");	
			
				projectedPd[i] = value;
			}
			return projectedPd;
		}
	}
	
	
	public String[] getProjectedLgdByLoanIdScenarioAndCusip(String loanId, String scenario, String cusip){
		String projectedLgd[] = new String[10];
		String value = null;
		int row = 0;
		int length = this.loanLevelDetailTable.findElements(By.xpath("tbody/tr")).size();
		for(int n = 1; n < length+1; n++){
			if(this.loanLevelDetailTable.findElement(By.xpath("tbody/tr["+n+"]/td[1]")).getText().equalsIgnoreCase(loanId)){
				row = n;
				break;
			}
		}
		
		if(row == 0){
			log.error("Cannot find loan id + \""+loanId+"\"");
			return null;
		} else {
			for(int i = 0; i < 10; i++){
			
				//value = this.loanLevelDetailTable.findElement(By.xpath("tbody/tr["+row+"]/td["+(this.ltvIndex+i+1)+"]")).getText();	
				value = this.loanLevelDetailTable.findElement(By.xpath("tbody/tr["+row+"]/td["+(this.lgdIndex+i)+"]/input")).getAttribute("value");	
			
				projectedLgd[i] = value;
			}
			return projectedLgd;
		}
	}
	
	public String[] getSingleLoanLevelDetailsByRowScenarioAndCusip(int row, String scenario, String cusip) throws Exception{
		String loanLevelDetails[] = new String[this.loanLevelDetailsFields.length];
		String value = null;
		for(int i = 0; i < this.loanLevelDetailsFields.length-1; i++){
			if((i+1)>=this.pdIndex && (i+1)<=this.lgdIndex+9){
				if(this.loanLevelDetailTable.findElement(By.xpath("tbody/tr[1]/td[1]")).getText().equals("")){
					value = this.loanLevelDetailTable.findElement(By.xpath("tbody/tr["+row+"]/td["+(i+1)+"]/input")).getAttribute("value");	
				} else {
					value = "";
				}
			} else {
				value = this.loanLevelDetailTable.findElement(By.xpath("tbody/tr["+row+"]/td["+(i+1)+"]")).getText();				
			}
			loanLevelDetails[i] = value;
		}
		loanLevelDetails[this.loanLevelDetailsFields.length-1] = 
				this.loanLevelDetailTable.findElement(By.xpath("//*[@id=\"loanLevelDetail_tb\"]/tbody/tr[1]/td[100]/input")).getAttribute("value"); //*[@id="loanLevelDetail_tb"]/tbody/tr[1]/td[100]/input
		return loanLevelDetails;
	}
	
	
	public void selectScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectToScenario(scenario);
		this.selectToCusip(cusip);
	}

	public void selectToScenario(String scenario) throws Exception{
		
		if(clickChoseScenario.getText().equals(scenario)){
			//scenario alread selected, do nothing
		} else {
			clickChoseScenario.click();
			this.waitForAjaxLoaded();
			Select choseScenarioSelector = new Select(choseScenario);
			choseScenarioSelector.selectByVisibleText(scenario);
			this.waitForAjaxLoaded();
		}
	}
	
	public void selectToCusip(String cusip) throws Exception{
		
		if(clickChoseCusip.getText().equals(cusip)){
			// cusip alread selected, do nothing
		} else {
			clickChoseCusip.click();
			this.waitForAjaxLoaded();
			Select choseCusipSelector = new Select(choseCusip);
			choseCusipSelector.selectByVisibleText(cusip);
			this.waitForAjaxLoaded();
		}
	}

	
	
}
