package qa.sav.moodys.nova.testcases.cmbs;

import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.pages.jobResult.JobResultCmbs;
import qa.sav.moodys.nova.testLogic.TestAsserts;

public class Cmbs_Sanity_Jobs_Results_Somke_Overall extends Cmbs_Sanity_Jobs_Base{
	
	@Test(groups="job_submit_cmbs_results", dataProvider="cmbs_sanity_jobs_submitted",threadPoolSize = 3,priority=5, description="job results smoke checking")
	public void cmbs_sanity_job_results_smoke_check_overall(String jobName) throws Exception{
		WebDriver newDriver = initialNewDriver();
		JobCmbs job = new JobCmbs(newDriver, this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();		
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
				
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		
		try{
			Assert.assertEquals(TestAsserts.compareLists(job.getJobSettings().getCusipsList(), cmbsResult.getOverviewInstance(job.driver).getCusipsList()),true, 
				"overview page cusips list is equaled to cusips list in job setting");
			Assert.assertEquals(true, TestAsserts.compareLists(scenariosList, 
				cmbsResult.getOverviewInstance(job.driver).getScenariosList()));
			Assert.assertTrue(cmbsResult.getOverviewInstance(job.driver).readProfileByScenAndCusip().get("Current CUSIP")
				!=null, "verify cusip value in profile table is showing");
		} catch(Exception ex){
			throw ex;
		}finally{
			quitDriver(job.driver);
			quitDriver(cmbsResult.jobCmbs.driver);
		}
	}
}
