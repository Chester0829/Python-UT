package qa.sav.moodys.nova.pages.jobResult;

import java.io.File;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import qa.sav.moodys.nova.JobCmbs;

public class BondCashflowsCmbs extends JobResultTabCmbs{
	
	public BondCashflowsCmbs(WebDriver driver, JobCmbs job)
			throws Exception {
		
		super(driver, job);
		// TODO Auto-generated constructor stub
		this.goToBondCashflowsTab();
	}

	public String cashflowFields[] = {
		"Date","Tranche Balance","Tranche Interest","Tranche Principal","Tranche Losses",
		"Tranche Reimbursed Losses","Tranche Implied Losses","Tranche Coupon","Attachment","Detachment"
	};
	
	public HashMap<String, Integer> cashflowIndexMapping = new HashMap<String, Integer>(){
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
	
		{
			put("Date",1);
			put("Tranche Balance",2);
			put("Tranche Interest",3);
			put("Tranche Principal",4);
			put("Tranche Losses",5);
			put("Tranche Reimbursed Losses",6);
			put("Tranche Implied Losses",7);
			put("Tranche Coupon",8);
			put("Attachment",9);
			put("Detachment",10);
		}		
	};
	
	@FindBy(xpath = "//*[@id=\"bond_scenario\"]")
	public WebElement choseScenaio;

	@FindBy(xpath = "//*[@id=\"bond_cusip\"]") //*[@id="select2-results-6"] //*[@id="select2-drop"]
	public WebElement choseCusip;
	
	@FindBy(xpath = "//*[@id=\"bondCashflow\"]/div/div/form/span[1]") //*[@id="bondCashflow"]/div/div/form/span[1]
	public WebElement scenarioText; 
	
	@FindBy(id = "select2-chosen-6")
	public WebElement clickChoseScenario;
	
	@FindBy(xpath = "//*[@id=\"bondCashflow\"]/div/div/form/span[2]") //*[@id="bondCashflow"]/div/div/form/span[2]
	public WebElement cusipText;
	
	@FindBy(id = "select2-chosen-7")
	public WebElement clickChoseCusip;
	
	final static String exportButtonXpath = "//*[@id=\"bondCashflow\"]/div/div/form/button";  
	@FindBy(xpath = exportButtonXpath) //*[@id="btn-export-overview"]  //*[@id="btn-export-overview"] //*[@id="bondCashflow"]/div/div/form/button
	public WebElement exportButton;
	
	final static String clickExportAllConfidenceLevelXpath = "//*[@id=\"chk-confidence-bond\"]";
	@FindBy(xpath = clickExportAllConfidenceLevelXpath)
	public WebElement clickExportAllConfidenceLevels;
	
	@FindBy(xpath = "//*[@id=\"bondCashflowContent\"]/div[1]/div[1]") //*[@id="bondCashflowContent"]/div/div[1]
	public WebElement bondCashflowTitleText;
	
	@FindBy(xpath = "//*[@id=\"table-portfolio-alerts\"]/thead/tr")
	public WebElement bondCashflowHeaderRow;
	
	@FindBy(xpath = "//*[@id=\"table-portfolio-alerts\"]/tbody")
	public WebElement cashflowTableBody;
	
	
	public void exportBondCashflowByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectToScenario(scenario);
		this.selectToCusip(cusip);
		//Thread.sleep(1000*30);
		this.waitForButtonActive(exportButtonXpath);
		this.downloadFile(this.exportButton, new File("C:\\temp\\"));
		this.waitForAjaxLoaded();
	}
	
	public void exportAllConfidenceLevelsBondCashflowByScenarioAndCusip
	(String scenario, String cusip) throws Exception{
		this.selectToScenario(scenario);
		this.selectToCusip(cusip);
		this.waitForButtonActive(clickExportAllConfidenceLevelXpath);
		if(this.clickExportAllConfidenceLevels.isSelected()){
			// already checked all confidence levels, do nothing
		} else {
			this.clickExportAllConfidenceLevels.click();
			this.waitForAjaxLoaded();
		}
		this.downloadFile(this.exportButton, new File("C:\\temp\\"));
	}
	
	public String getTotalTrancheInterestByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectScenarioAndCusip(scenario, cusip);
		String totalTrancheInterest = null;
		totalTrancheInterest = this.cashflowTableBody.findElement(
				By.xpath("tr[1]/th[2]/span")).getText(); //*[@id="table-portfolio-alerts"]/tbody/tr[1]/th[2]/span
		return totalTrancheInterest;
	}
	
	public String getTotalTranchePrincipalByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectScenarioAndCusip(scenario, cusip);
		String totalTranchePrincipal = null;
		totalTranchePrincipal = this.cashflowTableBody.findElement(
				By.xpath("tr[1]/th[3]/span")).getText();
		return totalTranchePrincipal;
	}
	
	public String getTotalTrancheLossesByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectScenarioAndCusip(scenario, cusip);
		String totalTrancheLosses = null;
		totalTrancheLosses = this.cashflowTableBody.findElement(
				By.xpath("tr[1]/th[4]/span")).getText();
		return totalTrancheLosses;
	}
	
	public String getTotalTrancheReimbursedLossesByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectScenarioAndCusip(scenario, cusip);
		String totalTrancheReimbursedLosses = null;
		totalTrancheReimbursedLosses = this.cashflowTableBody.findElement(
				By.xpath("tr[1]/th[5]/span")).getText();
		return totalTrancheReimbursedLosses;
	}
	
	public String getDealUpdatedDateByScenarioAndCusip
	(String scenario,String cusip) throws Exception{
		String dealUpdatedDate = null;
		this.selectScenarioAndCusip(scenario, cusip);
		dealUpdatedDate = cashflowTableBody.findElement(
				By.xpath("tr[2]/td["+cashflowIndexMapping.get("Date")+"]")).getText();				
		return dealUpdatedDate;		
	}
	
	public int getCashflowSizeByScenarioAndCusip(String scenario, String cusip){
		int cashflowLength =  this.cashflowTableBody.findElements(By.xpath("tr")).size()-1;
		return cashflowLength;
	}
	
	public String getMaturityDateByScenarioAndCusip(String scenario, String cusip){
		int cashflowSize = this.getCashflowSizeByScenarioAndCusip(scenario, cusip);
		return this.cashflowTableBody.findElement(By.xpath("tr["+(cashflowSize-1)+"]/td["+this.cashflowIndexMapping.get("Date")+"]")).getText();
	}
	
	public String getFirstPayDateByScenarioAndCusip
	(String scenario,String cusip) throws Exception{
		String firstPayDate = null;
		this.selectScenarioAndCusip(scenario, cusip);
		int cashflowLength =  this.cashflowTableBody.findElements(By.xpath("tr")).size()-1;
		int dateCollumnIndex = cashflowIndexMapping.get("Date");
		int i = 2;
		String amortizedAmount = null;
		while(i <= cashflowLength + 1){
			amortizedAmount = this.cashflowTableBody.findElement(
					By.xpath("tr["+i+"]/td["+this.cashflowIndexMapping.get("Tranche Interest")+"]/span")).getText();
			//System.out.println("amortized amount for period "+(i-1)+": "+amortizedAmount);
			if(amortizedAmount.equals("0.00")){
				i++;
			} else {
				firstPayDate = this.cashflowTableBody.findElement(
						By.xpath("tr["+i+"]/td["
								+dateCollumnIndex+"]")).getText();
				break;
			}
			
		}
		
		return firstPayDate;		
	}
	
	public String[] getScenariosList(){	
		return this.getScenariosList(choseScenaio);
	}
	
	public String[] getCusipsList(){
		return this.getCusipsList(choseCusip);
	}
	
	public String[] getcashflowHearderFieldsByScenarioAndCusip(String scenario, String Cusip){
		int headerFiledsCount = this.bondCashflowHeaderRow.findElements(By.xpath("th")).size(); 
		String[] cashflowHearderFields = new String[headerFiledsCount];
		for(int i = 0; i < headerFiledsCount; i++ ){
			cashflowHearderFields[i] = this.bondCashflowHeaderRow.findElement(By.xpath("th["+(i+1)+"]")).getText();
		}			
		return cashflowHearderFields;		
	}
	
	public void selectScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectToScenario(scenario);
		this.selectToCusip(cusip);
	}

	public void selectToScenario(String scenario) throws Exception{
		
		if(clickChoseScenario.getText().equals(scenario)){
			//scenario alread selected, do nothing
		} else {
			clickChoseScenario.click();
			this.waitForAjaxLoaded();
			Select choseScenarioSelector = new Select(choseScenaio);
			choseScenarioSelector.selectByVisibleText(scenario);
			this.waitForAjaxLoaded();
		}
	}
	
	public void selectToCusip(String cusip) throws Exception{
		
		if(clickChoseCusip.getText().equals(cusip)){
			// cusip alread selected, do nothing
		} else {
			clickChoseCusip.click();
			this.waitForAjaxLoaded();
			Select choseCusipSelector = new Select(choseCusip);
			choseCusipSelector.selectByVisibleText(cusip);
			this.waitForAjaxLoaded();
		}
	}

}
