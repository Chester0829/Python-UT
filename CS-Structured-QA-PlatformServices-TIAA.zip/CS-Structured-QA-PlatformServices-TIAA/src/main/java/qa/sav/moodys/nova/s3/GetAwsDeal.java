package qa.sav.moodys.nova.s3;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.utils.StringUtils;

public class GetAwsDeal {
	SimpleStoreHandlerImpl getAwsDeal = new SimpleStoreHandlerImpl();
		
	public String getAwsDeals(String deal, String year, String month){
		List<Integer> dealIds = new ArrayList<Integer>();
		String dealIdPath = new String();
		List<StoreObjectSummary> cmmList = this.getAwsDeal.listObjects("moodys-sf-simulation-abs", "sav-tiaa/deal-sync-tiaa/"+deal+"/"+year+"/"+month);
		//System.out.println("keyPath: "+"moodys-sf-simulation-abs"+ "sav-tiaa/deal-sync-tiaa/"+deal+"/"+year+"/"+month);
		//List<StoreObjectSummary> cmmList = this.getAwsDeal.listObjects("moodys-sf-simulation-abs", "sav-tiaa/deal-sync-tiaa/cmbs_ccm070c6/2017/01");
		String keyPath = new String();
		
		for(int i = 0; i < cmmList.size(); i++){
			if(cmmList.get(i).getKey().contains(".zip")){
				keyPath = cmmList.get(i).getKey();
				
				String dealUpdate = StringUtils.getSubString(cmmList.get(i).getKey(), year+"/"+month+"/(.*?).zip");
				String dealUpdateString = dealUpdate.split("/")[0];
				
				
				System.out.println(dealUpdate);
				dealIds.add(Integer.parseInt(dealUpdateString));
				keyPath = StringUtils.getSubString(keyPath, "(.*?)/"+dealUpdate+".zip");				
			}
			
		}
		
		//System.out.println(this.findLatestUpdate(dealIds));
		dealIdPath = keyPath + "/"+ this.findLatestUpdate(dealIds)+"/";
		//System.out.println(dealIdPath);
		return dealIdPath;
		
	}
	
	String findLatestUpdate(List<Integer> update){
		int dealId = 0;
		for(int i = 0; i < update.size(); i++)
		{
			if(dealId < update.get(i)){
				dealId = update.get(i);
			}
		}
		
		return Integer.toString(dealId);
	}
	
	void downloadCmm(String deal, String year, String month, String dscrLtv, String scen, String forecast){
		String dealUpdatePath = this.getAwsDeals(deal, year, month);
		String filePathLocal = "C:\\SAV\\QA\\Nova\\runLocalCmm\\period\\" + year+month+"\\AWS\\";
		String fileName_batch_output = deal.toUpperCase()+"_"+dealUpdatePath.split("/")[dealUpdatePath.split("/").length-1] 
						  + "_" + scen + "_" + dscrLtv + "_" + forecast.replace(" ", "_") + "_batch_output.csv";
		
		String fileName_batch_input = deal.toUpperCase()+"_"+dealUpdatePath.split("/")[dealUpdatePath.split("/").length-1] 
				  + "_" + scen + "_" + dscrLtv + "_" + forecast.replace(" ", "_") + "_cmm_input.csv";
		
		String fileName_cmm_result = deal.toUpperCase()+"_"+dealUpdatePath.split("/")[dealUpdatePath.split("/").length-1] 
				  + "_" + scen + "_" + dscrLtv + "_" + forecast.replace(" ", "_") + "_CMM_RESULT.xml";
		
		String fileName_bak = deal.toUpperCase()+"_"+dealUpdatePath.split("/")[dealUpdatePath.split("/").length-1] 
				  + "_" + scen + "_" + dscrLtv + "_" + forecast.replace(" ", "_") + "_cmm_input_bak.csv";
		
		System.out.println(dealUpdatePath+fileName_batch_output + "\n"
				+ fileName_batch_input + "\n"
				+ fileName_cmm_result);
		//"CMBS_BAM13DSNY_3271494_CUSTOM_sherry_original_Spring_2016_batch_output.csv"
		File file_output = new File(filePathLocal+fileName_batch_output);
		File file_input = new File(filePathLocal + fileName_batch_input);
		File file_xml = new File(filePathLocal + fileName_cmm_result);
		File file_bak = new File(filePathLocal+fileName_bak);
		System.out.println(file_xml);
		System.out.println(file_output);
		this.getAwsDeal.downloadObjectToFile("moodys-sf-simulation-abs", dealUpdatePath+fileName_batch_output, file_output);
		this.getAwsDeal.downloadObjectToFile("moodys-sf-simulation-abs", dealUpdatePath+fileName_batch_input, file_input);
		this.getAwsDeal.downloadObjectToFile("moodys-sf-simulation-abs", dealUpdatePath+fileName_cmm_result, file_xml);
		//this.getAwsDeal.downloadObjectToFile("moodys-sf-simulation-qa", dealUpdatePath+fileName_bak, file_bak);
		//fileName_bak
				
		//moodys-sf-simulation-qa/sav-tiaa/deal-sync-tiaa/cmbs_ccm070c6/2016/05/3304913
	}
	
	public void downDealList() throws Exception{
		
		InputStream inp = new FileInputStream("C:\\SAV\\QA\\Nova\\runLocalCmm\\dealList.xlsx");
		 
	    Workbook wb = WorkbookFactory.create(inp);
	    
	    Sheet sheet = wb.getSheetAt(0);
	   
	    Row globalSetting = sheet.getRow(1); 
	    Row rowDealDir = sheet.getRow(1);
	    String year = globalSetting.getCell(1).getStringCellValue().replaceAll("\"", "");
	    String month = globalSetting.getCell(2).getStringCellValue().replaceAll("\"", "");
	    String dscrLtv = globalSetting.getCell(3).getStringCellValue();
	    String scen = globalSetting.getCell(4).getStringCellValue(); 
	    String forecast = globalSetting.getCell(5).getStringCellValue();
	    System.out.println(month);
	    int dealRowNum = 2;
	    while(sheet.getRow(dealRowNum).getCell(0).getStringCellValue() != null && sheet.getRow(dealRowNum).getCell(0).getStringCellValue() != " ")
	    {
	    	String deal = sheet.getRow(dealRowNum).getCell(0).getStringCellValue().toLowerCase();
	    	System.out.println("DEALNAME: "+deal);
	    	this.downloadCmm(deal, year, month, dscrLtv, scen, forecast);
	    	dealRowNum++;
	    }
	    //Cell cellOutputDir = rowOutputDir.getCell(1); Cell cellDealDir = rowDealDir.getCell(1);
	}
	
	@Test
	public void tttTest(){

		try {
			this.downDealList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}


