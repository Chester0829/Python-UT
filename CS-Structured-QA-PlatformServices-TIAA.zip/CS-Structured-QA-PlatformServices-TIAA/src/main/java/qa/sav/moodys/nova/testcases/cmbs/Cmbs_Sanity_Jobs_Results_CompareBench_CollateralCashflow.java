package qa.sav.moodys.nova.testcases.cmbs;

import java.util.ArrayList;
import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.pages.jobResult.CollateralCashflowsCmbs;
import qa.sav.moodys.nova.pages.jobResult.JobResultCmbs;
import qa.sav.moodys.nova.pages.jobResult.OverviewCmbs;

public class Cmbs_Sanity_Jobs_Results_CompareBench_CollateralCashflow extends Cmbs_Sanity_Jobs_Base{

	@Test(groups="job_submit_cmbs_compare2bench", dataProvider="cmbs_sanity_jobs_and_cusips",priority=6, description="compare job resutls to benchmark - collateral cashflow")
	public void compare_cmbs_sanity_job_results_to_benchmark_Overview(String jobName, String cusip) throws Exception{
		
		JobCmbs job = new JobCmbs(initialNewDriver(), this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		CollateralCashflowsCmbs collateralCashflow = cmbsResult.getCollateralCashflowInstance(job.driver);
		
		String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
		JobCmbs jobBench = this.getBenchJob(initialNewDriver(), benchJobNameType);

		JobResultCmbs cmbsResultBench = jobBench.getResult();
		CollateralCashflowsCmbs collateralCashflowBench = cmbsResultBench.getCollateralCashflowInstance(jobBench.driver);
				
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		
		try{
			collateralCashflow.selectToCusip(cusip);
			for(String scen:scenariosList){
				collateralCashflow.selectToScenario(scen);
				collateralCashflowBench.selectToCusip(cusip);
				collateralCashflowBench.selectToScenario(scen);
				
				String cashflowsContent = collateralCashflow.cashflowTableBody.getText();
				String cashflowsContentBench = collateralCashflow.cashflowTableBody.getText();
				Assert.assertEquals(cashflowsContent, cashflowsContentBench, 
						"Verify collateral cashflow table content is the same between test and bench job");	
			}
			
		} catch (Exception ex){
			throw ex;
		} finally {
			quitDriver(job.driver);
			quitDriver(jobBench.driver);
			quitDriver(cmbsResult.jobCmbs.driver);
			quitDriver(cmbsResultBench.jobCmbs.driver);
		}
	}
	
}
