package qa.sav.moodys.nova.testLogic;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class TestAsserts {

	public static boolean compareLists(ArrayList<String> list, String[] string){
		
		ArrayList<String> list2 = new ArrayList<String>();
		for(int i = 0; i < string.length; i++){
			list2.add(string[i]);
		}		
		return(compareLists(list, list2));
	}
	
	public static boolean compareLists(ArrayList<String> list1, ArrayList<String> list2){				
		return (list1.containsAll(list2)&&list2.containsAll(list1));		
	}
	
	public static boolean comapreLists(Set<String> set, String[] string){
		Set<String> set2 = new HashSet<String>();
		for(int i = 0; i < string.length; i++){
			set.add(string[i]);
		}
		return (set.containsAll(set2)&& set2.contains(set));
	}
	
}
