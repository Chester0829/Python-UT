package qa.sav.moodys.nova.testcases.cmbs;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.testcases.base.TestCaseBase;

public class Cmbs_Sanity_Jobs_Submit_Bench extends Cmbs_Sanity_Jobs_Base {
	
	//String job_benchmark_path = System.getProperty("user.dir")+File.separator+"data/cmbs_sanity_benchmark_job_records.json";
	String job_config_filePath = System.getProperty("user.dir")+ File.separator +"config/testcase/job_configue_cmbs_sanity.csv";
	String portfolioPath = System.getProperty("user.dir")+ File.separator +"config/testcase/launchCmbsSanity.csv";

	int jobsCount = 0;
	ArrayList<String> testedJobsName;
	HashMap<String, JobCmbs> testedJobs;
	JsonObject submittedJobs = new JsonObject();
	
	@BeforeTest
	public void clearEnvironment() throws Exception{
		testedJobsName = new ArrayList<String>();
		testedJobs = new HashMap<String,JobCmbs>();		
	}
	
	//@AfterTest(alwaysRun=true)
	public void writeToFile(){
		
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		//System.out.println("write to file: "+submittedJobs);
				
		try {
			FileWriter fileWriter;
			fileWriter = new FileWriter(job_records_path_benchmark);
			gson.toJson(submittedJobs, fileWriter);//FileWriter 继承自 OutputStreamWriter 继承自 Writer 实现了Appendable接口
			fileWriter.close();
		} catch (JsonIOException e) {
			System.out.println("json error");
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("io error");
			e.printStackTrace();
		}
	}
		
	//@Test(groups="job_submit_1",dataProvider="cmbs_sanity_jobs",priority=1, description="submit a set of cmbs sanity jobs, all the jobs should be submited successfully")
	public void submit_cmbs_sanity_job(JobCmbs jobCmbs,String jobName) throws Exception{		
		JobCmbs job = new JobCmbs(driver, jobCmbs.getJobSettings());
		String newJobName = jobName+"_"+new SimpleDateFormat("YYYYMMddHHmmssSSS").format(Calendar.getInstance().getTime());
		job.jobSettings.setJobName(newJobName); 		
		job = job.run(false);
		job.reFreshStatus();
		JsonElement element = new Gson().toJsonTree(job.jobSettings);
		submittedJobs.add(jobName, element);
		testedJobsName.add(newJobName);
		testedJobs.put(newJobName, job);		
		//quitDriver(job.driver);
	}
		

	@DataProvider(name = "cmbs_sanity_jobs")
	public Object[][] get_cmbs_sanity_jobs() throws Exception{
		JobCmbs jobs[];
		Object data[][];
		try {
			jobs = DataProviderJobConfigCmbs.readTestCasesConfig(job_config_filePath,portfolioPath);
			data= new Object[jobs.length][2];
			//System.out.println("jobs count to be run: "+jobs.length);
			for(int n = 0; n < jobs.length; n++){
				data[n][1] = jobs[n].getJobSettings().getJobName();
				data[n][0] = jobs[n];
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		return data;
	}
}
