package qa.sav.moodys.nova.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

import qa.sav.moodys.nova.Job;
import qa.sav.moodys.nova.data.JobSettings;
import qa.sav.moodys.nova.data.JobStatus;

public class Dashboard extends PageBase{
	
	String dashboardPageUrl = config.getProperty("website")+"/sf-simulation/dashboard";

		String tabIndex_jobName = "1";
		String tabIndex_businessType = "2";
		String tabIndex_submitTime = "3";
		String tabIndex_startTime = "4";
		String tabIndex_endTime = "5";
		String tabIndex_submitedBy = "6";
		String tabIndex_totalTasks = "7";
		String tabIndex_progress = "8";
		String tabIndex_failNum = "9";
		String tabIndex_runType = "10";
		String tabIndex_globalValue = "11";
		String tabIndex_runStatus = "12";
		String tabIndex_jobStatus = "13";
		String tabIndex_exportStatus = "14"; 
		String tabIndex_reload = "15";
		String tabIndex_reproduce = "16";
		String tabIndex_stop = "17";
		String tabIndex_destroy = "18";
		String tabIndex_export = "19";
	
	final static String searchBoxInputXpath = "//*[@id=\"dashboardTable_filter\"]/label/input";
	@FindBy(xpath = searchBoxInputXpath)
	public WebElement searchBox;
	
	final static String dashboardTable_lengthXpath = "//*[@id=\"dashboardTable_length\"]/label/select";
	@FindBy(xpath = dashboardTable_lengthXpath)
	public WebElement dashboardTablelength;
	
	final static String dashboardTableHeaderXpath = "//*[@id=\"dashboardTable\"]/thead";
	@FindBy(xpath = dashboardTableHeaderXpath)
	public WebElement dashboardTableHeader;
	
	final static String dashboardTableContentXpath = "//*[@id=\"dashboardTable\"]/tbody";
	@FindBy(xpath = dashboardTableContentXpath)
	public WebElement dashboardTableContent;
	
	final static String previoursPageXpath = "//*[@id=\"dashboardTable_previous\"]";
	@FindBy(xpath = previoursPageXpath)
	public WebElement previoursPageButton;
	
	final static String nextPageXpath = "//*[@id=\"dashboardTable_next\"]";
	@FindBy(how = How.XPATH, using = nextPageXpath) 
	public WebElement nextPageButton;
	
 	public Dashboard(WebDriver driver) throws Exception{

		super(driver);
		
		if(driver.getCurrentUrl().contains(dashboardPageUrl)){
			//do nothing
		} else {
			try {
				new HomePage(driver).goToDashboardPage();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.error("Not able to go to dashboard page, please check");
				log.error(e.getMessage());
				e.printStackTrace();
				throw e;
			}
		}
		// TODO Auto-generated constructor stub
	
	}

	public JobStatus getFirstJobStatusByName(String jobName) throws Exception{
		JobStatus jobStatus = new JobStatus();
		this.searchBox.clear();
		this.searchBox.sendKeys(jobName);
		this.searchBox.sendKeys(Keys.ENTER);
		this.waitForAjaxLoaded();
		int i = 1;
		jobStatus = getJobStatusByRowIndex(i);
		return jobStatus;		
	}
	
	public void goToJobResultsPage(String jobName) throws Exception{
		getFirstJobStatusByName(jobName);
		this.waitForAjaxLoaded();
		this.waitForElementPresent("//*[@id=\"dashboardTable\"]/tbody/tr[1]/td[1]/a");
		driver.findElement(By.xpath("//*[@id=\"dashboardTable\"]/tbody/tr[1]/td[1]/a")).click();
		this.waitForAjaxLoaded();
	}
	
	public void goToJobResultsPage(String jobName, int jobId) throws Exception{
		this.searchBox.clear();
		this.searchBox.sendKeys(jobName);
		this.searchBox.sendKeys(Keys.ENTER);
		this.waitForAjaxLoaded();
		
		for(int i = 1; i < 6; i++){
			List<WebElement> tableRows = dashboardTableContent.findElements(By.xpath("tr"));
			for(int j = 0; j < tableRows.size(); j++){
				if (Integer.parseInt(tableRows.get(j).findElement(By.xpath("td["+this.tabIndex_reload+"]/a")).getAttribute("href").split("jobId=")[1])==jobId){
					this.waitForAjaxLoaded();
					this.waitForElementPresent("//*[@id=\"dashboardTable\"]/tbody/tr[1]/td["+(j+1)+"]/a");
					driver.findElement(By.xpath("//*[@id=\"dashboardTable\"]/tbody/tr[1]/td["+(j+1)+"]/a")).click();
					this.waitForAjaxLoaded();
					return ;
				}
			}
		}	
		log.error("cannot find job with name = "+jobName+ "& id = "+jobId+", please check!");
	}
	
	/**
	 * 
	 * @param jobId
	 * @return find job by jobId and return job status, only considering the latest 500 jobs 
	 * @throws Exception
	 */
	public JobStatus getJobStatus(int jobId) throws Exception{
		JobStatus jobStatus = new JobStatus();
		setTablePageLength("100");
		for(int i = 1; i < 6; i++){
			List<WebElement> tableRows = dashboardTableContent.findElements(By.xpath("tr"));
			//System.out.println(tableRows.size());
			for(int j = 0; j < tableRows.size(); j++){
				if (Integer.parseInt(tableRows.get(j).findElement(By.xpath("td["+this.tabIndex_reload+"]/a")).getAttribute("href").split("jobId=")[1])==jobId){
					return this.getJobStatusByRowIndex(j+1);
				}
			}
		}				
		return jobStatus;		
	}
	
	public String getJobRunStatus(int jobId, String jobName) throws Exception{
		searchBox.clear();
		searchBox.sendKeys(jobName);
		searchBox.sendKeys(Keys.ENTER);
		waitForAjaxLoaded();
		for(int i = 1; i < 6; i++){
			List<WebElement> tableRows = dashboardTableContent.findElements(By.xpath("tr"));
			//System.out.println(tableRows.size());
			for(int j = 0; j < tableRows.size(); j++){
				if (Integer.parseInt(tableRows.get(j).findElement(By.xpath("td["+this.tabIndex_reload+"]/a")).getAttribute("href").split("jobId=")[1])==jobId){
					return tableRows.get(j).findElement(By.xpath("td["+this.tabIndex_runStatus+"]")).getText();
				}
			}
		}	
		log.error("cannot find job with name = "+jobName+ "& id = "+jobId+", please check!");
		return jobName;
	}
	
	public JobStatus getJobStatus(int jobId, String jobName) throws Exception{
		JobStatus jobStatus = new JobStatus();
		this.searchBox.clear();
		this.searchBox.sendKeys(jobName);
		this.searchBox.sendKeys(Keys.ENTER);
		this.waitForAjaxLoaded();
		jobStatus = getJobStatus(jobId);		
		return jobStatus;	
	}
	
	public void reproduceJob(Job job, boolean waitForJobCompleted, String newJobName) throws Exception{
		//Job newJob = job;
		ReproducePopUp reproducePopUp = new ReproducePopUp(driver,job);
		reproducePopUp.submitReproduceJob(job, newJobName);
		if(waitForJobCompleted){
			job.waitForJobCompleted();
		}
	}
	
	public Job clickToReproduceJob(Job job) throws Exception{
		JobStatus jobStatus = job.getJobStatus();
		JobSettings jobSettings = job.getJobSettings();
		if(jobStatus.getName()==null){
			jobStatus.setName(jobSettings.getJobName());
		}
		if(jobStatus.getJobID()==null&&jobStatus.getName()==null){
			log.error("Cannot reproduce a job without job name or job id, pelase check!");
			return job;
		} else if(job.jobStatus.getJobID()==null){
			jobStatus = this.getFirstJobStatusByName(jobStatus.getName());
			if(jobStatus.getJobID()==null){
				log.error("Cannot reproduce a job without job id, pelase check!");
				job.jobStatus = jobStatus;
				return job;
			}
			log.info("Reproduce job: name = "+jobStatus.getName()+
					", id = "+jobStatus.getJobID());			
			jobStatus.getReproduceButton().click();
			job.jobStatus = jobStatus;
			return job;
		} else if(jobStatus.getName()== null){
			jobStatus = this.getJobStatus(jobStatus.getJobID());
			if(jobStatus.getName()==null){
				log.error("Cannot reproduce a job without job name, pelase check!");
				job.jobStatus = jobStatus;
				return job;
			}			
			jobStatus.getReproduceButton().click();
			waitForAjaxLoaded();
			job.jobStatus = jobStatus;
			return job;
		} else {
			log.info("Reproduce job: name = "+jobStatus.getName()+
					", id = "+jobStatus.getJobID());
			jobStatus.getReproduceButton().click();		
			waitForAjaxLoaded();
			job.jobStatus = jobStatus;
			return job;
		}
	}
	
	public Job clickToReloadJob(Job job) throws Exception{

		JobStatus jobStatus = job.getJobStatus();
		JobSettings jobSettings = job.getJobSettings();
		if(jobStatus.getName() == null){
			jobStatus.setName(jobSettings.getJobName());
		}
		if(jobStatus.getJobID()==null&&jobStatus.getName()==null){
			log.error("Cannot reload a job without job name or job id, pelase check!");
			job.jobStatus = jobStatus;
			return job;
		} else if(jobStatus.getJobID()==null){
			jobStatus = getFirstJobStatusByName(jobStatus.getName());
			if(jobStatus.getJobID() == null){
				log.error("Cannot reload a job without job id, pelase check!");
				job.jobStatus = jobStatus;
				return job;
			}
			log.info("Reload job: name = "+jobStatus.getName()+
					", id = "+jobStatus.getJobID());
			jobStatus.getReloadButton().click();
		} else if(jobStatus.getName()== null){
			jobStatus = this.getJobStatus(jobStatus.getJobID());
			if(jobStatus.getName()==null){
				log.error("Cannot reload a job without job name, pelase check!");
				job.jobStatus = jobStatus;
				return job;
			}			
			jobStatus.getReloadButton().click();
			waitForAjaxLoaded();
			job.jobStatus = jobStatus;
			return job;
		} else {
			log.info("Reload job: name = "+jobStatus.getName()+
					", id = "+jobStatus.getJobID());
			jobStatus.getReloadButton().click();		
			waitForAjaxLoaded();
		}
		job.jobStatus = jobStatus;
		return job;
			
	}
	
	public void setTablePageLength(String length) throws Exception{
		this.waitForElementPresent(dashboardTable_lengthXpath);
		Select pageLength = new Select(dashboardTablelength);
		
		if(pageLength.getFirstSelectedOption().getText().equals(length)){
			//do nothing
		} else {
			pageLength.selectByVisibleText(length);
		}
		waitForAjaxLoaded();
	}
	
	public void clickToPrevioursPage() throws Exception{
		previoursPageButton.click();
		this.waitForAjaxLoaded();
	}
	
	public void clickToNextPage() throws Exception{
		nextPageButton.click();
		this.waitForAjaxLoaded();
	}

	private JobStatus getJobStatusByRowIndex(int i){
		JobStatus jobStatus = new JobStatus();
		jobStatus.setName(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_jobName+"]")).getText());
		jobStatus.setBusinessType(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_businessType+"]")).getText());
		jobStatus.setSubmitTime(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_submitTime+"]")).getText());
		jobStatus.setStartTime(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_startTime+"]")).getText());
		jobStatus.setEndTime(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_endTime+"]")).getText());
		jobStatus.setSubmittedBy(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_submitedBy+"]")).getText());
		jobStatus.setTotalTasks(Integer.parseInt(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_totalTasks+"]")).getText()));
		jobStatus.setFailNum(Integer.parseInt(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_failNum+"]")).getText()));
		jobStatus.setProgress(Integer.parseInt(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_progress+"]")).getText()));
		jobStatus.setRunType(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_runType+"]")).getText());
		jobStatus.setGlobalValuePopUp(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_globalValue+"]/a")));
		jobStatus.setRunStatus(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_runStatus+"]")).getText());
		jobStatus.setJobResultStatus(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_jobStatus+"]/a")).getText());
		jobStatus.setJobResultStatusPopUp(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_jobStatus+"]/a")));
		jobStatus.setExportStatus(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_exportStatus+"]")).getText());
		jobStatus.setReloadButton(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_reload+"]/a")));
		jobStatus.setJobID(Integer.parseInt(jobStatus.getReloadButton().getAttribute("href").split("jobId=")[1]));		
		jobStatus.setReproduceButton(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_reproduce+"]/a")));
		jobStatus.setStopButton(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_stop+"]/a/span")));
		jobStatus.setDestroyButton(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_destroy+"]/a/span")));
		jobStatus.setExportButton(dashboardTableContent.findElement(By.xpath("tr["+i+"]/td["+this.tabIndex_export+"]")));
			
		return jobStatus;
		
	}
	
	private int getJobRowIndex(int jobId, WebElement dasbboardTable){
		for(int i = 1; i < 6; i++){
			List<WebElement> tableRows = dasbboardTable.findElements(By.xpath("tr"));
			//System.out.println(tableRows.size());
			for(int j = 0; j < tableRows.size(); j++){
				if (Integer.parseInt(tableRows.get(j).findElement(By.xpath("td["+this.tabIndex_reload+"]/a")).getAttribute("href").split("jobId=")[1])==jobId){
					return j+1;
				}
			}
		}	
		log.error("cannot find job with id = "+jobId+", please check!");
		return -1;
	}
}
