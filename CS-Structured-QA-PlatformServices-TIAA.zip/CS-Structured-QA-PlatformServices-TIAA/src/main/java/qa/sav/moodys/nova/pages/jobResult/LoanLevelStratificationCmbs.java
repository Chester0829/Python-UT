package qa.sav.moodys.nova.pages.jobResult;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import qa.sav.moodys.nova.JobCmbs;

public class LoanLevelStratificationCmbs extends JobResultTabCmbs{
	
	public LoanLevelStratificationCmbs(WebDriver driver, JobCmbs job)
			throws Exception {
		
		super(driver, job);
		// TODO Auto-generated constructor stub
		this.goToLoanLevelStratificationTab();
	}
	
	public String propertyStratificationFields[] = {
		"Property Type (TOP 10)",
		"%",
		"DSCR",
		"LTV",
		"90+Del"
	}; 
	
	public String dscrStratificationFields[] = {
		"DSCR", "%", "LTV", "90+Del"	
	};
	
	public String ltvStratificationFields[] = {
		"LTV", "%", "DSCR","90+Del"
	};
	
	public String stateStratificationFields[] ={
		"STATE (TOP 10)", "%", "DSCR", "LTV", "90+Del"
	};
	
	public String loanSizeStratificationFields[] = {
		"Loan Size", "%", "DSCR", "LTV", "90+Del"	
	};
	
	public String delinquencyStratificationFields[] = {
		"Delinquency", "%", "DSCR", "LTV"
	};
	
	@FindBy(xpath = "//*[@id=\"loanStratiScenario\"]") //*[@id="pd_el_scenario"] //*[@id="loanStratiScenario"]
	public WebElement choseScenaio;

	@FindBy(xpath = "//*[@id=\"loanStratiCusip\"]") //*[@id="pd_el_cusip"]
	public WebElement choseCusip;
	
	@FindBy(xpath = "//*[@id=\"loanLevelStratification\"]/form/span[1]") //*[@id="loanLevelStratification"]/form/span[1]
	public WebElement scenarioText; 
	
	@FindBy(id = "select2-chosen-14")
	public WebElement clickChoseScenario;
	
	@FindBy(xpath = "//*[@id=\"loanLevelStratification\"]/form/span[2]") //*[@id="pd_el_mapping"]/div/div/form/span[2]
	public WebElement cusipText;
	
	@FindBy(id = "select2-chosen-13")
	public WebElement clickChoseCusip;	
	
	@FindBy(xpath = "//*[@id=\"loanLevelStratificationContent\"]/div[1]/div[1]")
	public WebElement top10PropertyTypeTitle;
	
	@FindBy(xpath = "//*[@id=\"loanLevelStratificationContent\"]/div[1]/div[2]/div[1]/table")
	public WebElement top10PropertyTypeTable;
	
	@FindBy(xpath = "//*[@id=\"loanLevelStratificationContent\"]/div[2]/div[1]")
	public WebElement dscrStratificationTitle;
	
	@FindBy(xpath = "//*[@id=\"loanLevelStratificationContent\"]/div[2]/div[2]/div[1]/table")
	public WebElement dscrStratificationTable;
	
	@FindBy(xpath = "//*[@id=\"loanLevelStratificationContent\"]/div[3]/div[1]")
	public WebElement ltvStratificationTitle;
	
	@FindBy(xpath = "//*[@id=\"loanLevelStratificationContent\"]/div[3]/div[2]/div[1]/table")
	public WebElement ltvStratificationTable;
	
	@FindBy(xpath = "//*[@id=\"loanLevelStratificationContent\"]/div[4]/div[1]")
	public WebElement top10StateTitle;
	
	@FindBy(xpath = "//*[@id=\"loanLevelStratificationContent\"]/div[4]/div[2]/div[1]/table")
	public WebElement top10StateTable;
	
	@FindBy(xpath = "//*[@id=\"loanLevelStratificationContent\"]/div[5]/div[1]")
	public WebElement loanSizeTitle;
	
	@FindBy(xpath = "//*[@id=\"loanLevelStratificationContent\"]/div[5]/div[2]/div[1]/table")
	public WebElement loanSizeTable;
	
	@FindBy(xpath = "//*[@id=\"loanLevelStratificationContent\"]/div[6]/div[1]")
	public WebElement delinquencyTitle;
	
	@FindBy(xpath = "//*[@id=\"loanLevelStratificationContent\"]/div[6]/div[2]/div[1]/table")
	public WebElement delinquencyTable;
	
	public String[] getScenariosList(){	
		return this.getScenariosList(choseScenaio);
	}
	
	public String[] getCusipsList(){
		return this.getCusipsList(choseCusip);
	}
	
	public void selectScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectToScenario(scenario);
		this.selectToCusip(cusip);
	}

	public void selectToScenario(String scenario) throws Exception{
		
		if(clickChoseScenario.getText().equals(scenario)){
			//scenario alread selected, do nothing
		} else {
			clickChoseScenario.click();
			this.waitForAjaxLoaded();
			Select choseScenarioSelector = new Select(choseScenaio);
			choseScenarioSelector.selectByVisibleText(scenario);
			this.waitForAjaxLoaded();
		}
	}
	
	public void selectToCusip(String cusip) throws Exception{
		
		if(clickChoseCusip.getText().equals(cusip)){
			// cusip alread selected, do nothing
		} else {
			clickChoseCusip.click();
			this.waitForAjaxLoaded();
			Select choseCusipSelector = new Select(choseCusip);
			choseCusipSelector.selectByVisibleText(cusip);
			this.waitForAjaxLoaded();
		}
	}

	
	
}
