package qa.sav.moodys.nova.testcases.cmbs;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.pages.jobResult.BondCashflowsCmbs;
import qa.sav.moodys.nova.pages.jobResult.CollateralCashflowsCmbs;
import qa.sav.moodys.nova.pages.jobResult.JobResultCmbs;
import qa.sav.moodys.nova.pages.jobResult.LoanLevelDetailsCmbs;
import qa.sav.moodys.nova.pages.jobResult.OverviewCmbs;

public class Cmbs_Sanity_Jobs_Results_CompareBench_LoanLevelDetails extends Cmbs_Sanity_Jobs_Base{

	JobCmbs job = null;
	JobResultCmbs cmbsResult = null;
	JobCmbs jobBench = null;
	JobResultCmbs cmbsResultBench = null;	
	
	//@Test(groups="job_submit_cmbs_compare2bench", dataProvider="cmbs_sanity_jobs_and_cusips",priority=6, description="compare job resutls to benchmark - bond cashflow")
	public void compare_cmbs_sanity_job_results_to_benchmark_loanLevelDetails(String jobName, String cusip) throws Exception{
		

		if(job == null || !job.getJobSettings().getJobName().equals(jobName)){			
			if(job == null){
				job = new JobCmbs(initialNewDriver(), this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
				job.reFreshStatus();
				cmbsResult = job.getResult();
			
				String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
				jobBench = this.getBenchJob(initialNewDriver(), benchJobNameType);
				jobBench.reFreshStatus();
				cmbsResultBench = jobBench.getResult();
			} else{
				job = new JobCmbs(job.driver, this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
				job.reFreshStatus();
				cmbsResult = job.getResult();
			
				String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
				jobBench = this.getBenchJob(jobBench.driver, benchJobNameType);	
				jobBench.reFreshStatus();
				cmbsResultBench = jobBench.getResult();
			}

		} else {
			//System.out.println("already in job result page, jobname: "+jobName+", benchName: "+ jobBench.getJobSettings().getJobName());
		}		
		
		LoanLevelDetailsCmbs loanLevelDetails = cmbsResult.getLoanLevelDetailsInstance(job.driver);
		LoanLevelDetailsCmbs loanLevelDetailsBench = cmbsResultBench.getLoanLevelDetailsInstance(jobBench.driver);
				
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		
		try{
			loanLevelDetails.selectToCusip(cusip);
			for(String scen:scenariosList){
				loanLevelDetails.selectToScenario(scen);
				loanLevelDetailsBench.selectToCusip(cusip);
				loanLevelDetailsBench.selectToScenario(scen);
								
				String loanDetailsContent = loanLevelDetails.loanLevelDetailTable.getText();
				String loanDetailsContentBench = loanLevelDetailsBench.loanLevelDetailTable.getText();
				System.out.println(loanDetailsContent);
				Assert.assertEquals(loanDetailsContent, loanDetailsContentBench, 
						"Verify loanlevel details content is the same between test and bench job");	
			}
			
		} catch (Exception ex){
			throw ex;
		} 
	}
	
	@Test(groups="job_submit_cmbs_compare2bench", dataProvider="cmbs_sanity_jobs_and_cusips",priority=6, description="compare job resutls to benchmark - bond cashflow")
	public void compare_cmbs_sanity_job_results_to_benchmark_loanLevelDetails_ProjectedPdLgd(String jobName, String cusip) throws Exception{
		

		if(job == null || !job.getJobSettings().getJobName().equals(jobName)){			
			if(job == null){
				job = new JobCmbs(initialNewDriver(), this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
				job.reFreshStatus();
				cmbsResult = job.getResult();
			
				String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
				jobBench = this.getBenchJob(initialNewDriver(), benchJobNameType);
				jobBench.reFreshStatus();
				cmbsResultBench = jobBench.getResult();
			} else{
				job = new JobCmbs(job.driver, this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
				job.reFreshStatus();
				cmbsResult = job.getResult();
			
				String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
				jobBench = this.getBenchJob(jobBench.driver, benchJobNameType);	
				jobBench.reFreshStatus();
				cmbsResultBench = jobBench.getResult();
			}

		} else {
			//System.out.println("already in job result page, jobname: "+jobName+", benchName: "+ jobBench.getJobSettings().getJobName());
		}		
		
		LoanLevelDetailsCmbs loanLevelDetails = cmbsResult.getLoanLevelDetailsInstance(job.driver);
		LoanLevelDetailsCmbs loanLevelDetailsBench = cmbsResultBench.getLoanLevelDetailsInstance(jobBench.driver);
				
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		
		try{
			loanLevelDetails.selectToCusip(cusip);
			for(String scen:scenariosList){
				loanLevelDetails.selectToScenario(scen);
				loanLevelDetailsBench.selectToCusip(cusip);
				loanLevelDetailsBench.selectToScenario(scen);
				List<WebElement> pdLgds = 	loanLevelDetails.loanLevelDetailTable.findElements(By.tagName("input"));
								
				System.out.println(pdLgds.size());
				String loanDetailsContent = "";
				String loanDetailsContentBench = ""; //loanLevelDetailsBench.loanLevelDetailTable.findElements(By.tagName("input")).toString();
			
				for(WebElement pdldg:pdLgds){
					String input = pdldg.getAttribute("value");
					loanDetailsContent = loanDetailsContent + input;
					System.out.println(loanDetailsContent);
				}
				
				System.out.println("loanleveldetails: "+loanDetailsContent);
				
				
				Assert.assertEquals(loanDetailsContent, loanDetailsContentBench, 
						"Verify loanlevel details content is the same between test and bench job");	
			}
			
		} catch (Exception ex){
			throw ex;
		} 
	}
	
	@AfterTest
	public void dearDownCurrentTest(){
		quitDriver(job.driver);
		quitDriver(jobBench.driver);
		quitDriver(cmbsResult.jobCmbs.driver);
		quitDriver(cmbsResultBench.jobCmbs.driver);	
	}
}
