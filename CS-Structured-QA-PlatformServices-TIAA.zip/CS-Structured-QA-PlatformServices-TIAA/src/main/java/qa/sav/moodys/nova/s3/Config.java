package qa.sav.moodys.nova.s3;
import java.io.FileInputStream;
import java.util.Properties;

public class Config {

    Properties configFile;
    public Config()
    {
        configFile = new java.util.Properties();
        try {
            configFile.load(new FileInputStream("src/main/resources/config/SFSimulationTest.config"));
        }catch(Exception eta){
            eta.printStackTrace();
        }
    }

    public String getProperty(String key)
    {
        String value = this.configFile.getProperty(key);
        return value;
    }
	
}
