package qa.sav.moodys.nova.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.testng.annotations.Test;

public class StringUtils {
	
	public static boolean isSavCalculated(String str) {
	    Pattern pattern = Pattern.compile("^[-\\+]?[\\d]+[.]?[\\d]*$");
	    return pattern.matcher(str).matches();
	}
	
	public static String getSubString(String orgString, String regx){
		//regx = "preString(.*?)endString"
		Pattern pattern = Pattern.compile(regx);
		Matcher matcher = pattern.matcher(orgString);
		String subString = new String();
		if (matcher.find())
		{
		    subString = matcher.group(1);
		}	
		return subString;
	}	

//	public static boolean compareStrings(String string1[], String string2[]){
//		
//		if(string1.length != string2.length){
//			return false;
//		}
//		
//		for(int i = 0; i < string1.length; i++){
//			if(!string1[i].equals(string2[i])){
//				return false;
//			}
//		}
//		
//		return true;
//		
//	}
//	
//	public static boolean compareStrings(String string1[][], String string2[][]){
//		
//		if(string1.length!=string2.length){
//			return false;
//		}
//		
//		for(int i = 0; i < string1.length; i++){
//			if(!StringUtils.compareStrings(string1[i], string2[i])){
//				return false;
//			}
//		}
//		
//		return true;	
//				
//	}
		
	@Test
	public void tttTest(){
		
		String[][] test1 ={ {"1","2"}, {"3","4"}};
		String[][] test2 ={ {"1","2"}, {"3","4"},};
		System.out.println(test1.length);
		System.out.println(test1[0].length);
		//System.out.println(compareStrings(test2,test1));
		
	}
}
