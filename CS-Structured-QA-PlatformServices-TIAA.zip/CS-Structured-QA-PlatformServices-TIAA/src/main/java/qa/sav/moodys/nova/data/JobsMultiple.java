package qa.sav.moodys.nova.data;

import qa.sav.moodys.nova.Job;
import qa.sav.moodys.nova.JobCmbs;

public class JobsMultiple {
	public Job originalJob;
	public Job newJob;
	
	public Job getOriginalJob() {
		return originalJob;
	}
	public void setOriginalJob(Job originalJob) {
		this.originalJob = originalJob;
	}

	public void setNewJob(Job newJob) {
		this.newJob = newJob;
	}
	public Job getNewjob() {
		// TODO Auto-generated method stub
		return newJob;
	}
	
}
