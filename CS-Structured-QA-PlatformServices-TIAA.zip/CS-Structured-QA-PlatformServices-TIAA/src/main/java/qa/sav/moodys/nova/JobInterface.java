package qa.sav.moodys.nova;

import qa.sav.moodys.nova.data.JobCmbsReloadOrReproduce;
import qa.sav.moodys.nova.data.JobsMultiple;

public interface JobInterface {
	
	Job run(boolean waitForJobCompleted) throws Exception;
	
	JobsMultiple reload(boolean waitForJobCompleted) throws Exception;
	
//	JobsMultiple reload(boolean waitForJobCompleted, JobSettings resetJobSettings) throws Exception;
	
	boolean waitForJobCompleted() throws Exception;

	JobsMultiple reproduce(boolean waitForJobCompleted, String newJobName) throws Exception;

	JobCmbsReloadOrReproduce reproduce(boolean waitForJobCompleted) throws Exception;
	

//	Job reproduce(boolean waitForJobCompleted, boolean useNewName)
//			throws Exception;
	
}
