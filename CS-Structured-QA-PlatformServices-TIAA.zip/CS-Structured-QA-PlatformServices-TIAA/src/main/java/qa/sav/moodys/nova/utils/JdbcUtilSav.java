package qa.sav.moodys.nova.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.*;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSourceFactory;

import qa.sav.moodys.nova.testcases.base.TestCaseBase;

import org.apache.logging.log4j.Logger;

public class JdbcUtilSav {
	private static DataSource ds = null;
	private static Logger log = TestCaseBase.log;
	
	static {
		//Initialise environment properties file
		try {
			Properties env = new Properties();
			String fileName = "env"+".properties";;
			FileInputStream inputFile = new FileInputStream(System.getProperty("user.dir")+ File.separator + "config" + File.separator+ fileName);
			env.load(inputFile);
			log.info("Environment = "+ env.getProperty("Environment"));

			fileName = "dbcpconfig_" + env.getProperty("Environment")+".properties";;
			
			InputStream in = new FileInputStream(new File(System.getProperty("user.dir")+ File.separator + "config" + File.separator+ fileName));
			log.info(System.getProperty("user.dir")+ File.separator + "config" + File.separator+ fileName);
			
			log.info(in.toString());
	        Properties prop = new Properties();
	        prop.load(in);
	        
			log.info("Connecting to database: " + prop.getProperty("url") );
			ds = BasicDataSourceFactory.createDataSource(prop);
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error(e.getMessage());
		}
	}
	
	
	public static Connection getConnection() throws SQLException{
		
		return ds.getConnection();
		
	}
	
	public static void release(Connection conn, Statement st, ResultSet rs){
		if(rs != null){
			try{
				rs.close();
			} catch (SQLException e){
				e.printStackTrace();
				log.error("SQLException: " + e.getMessage());
			    log.error("SQLState: " + e.getSQLState());
			    log.error("VendorError: " + e.getErrorCode());
			}
			
			if(st != null){
				try {
					st.close();
				} catch (SQLException e){
					log.error("SQLException: " + e.getMessage());
				    log.error("SQLState: " + e.getSQLState());
				    log.error("VendorError: " + e.getErrorCode());
				}
				if(conn != null){
					try {
						conn.close();
					} catch (SQLException e){
						log.error("SQLException: " + e.getMessage());
					    log.error("SQLState: " + e.getSQLState());
					    log.error("VendorError: " + e.getErrorCode());
					}
				}
			}
			
		}
	}

	
}
