package qa.sav.moodys.nova.utils;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils{
	
	Date date = null;
		
	public DateUtils(){		
		date = new Date();
	}
	
	public String getCurrentTimestamp(){
		String currentTimestamp = null;
		currentTimestamp = new SimpleDateFormat("YYYY-MM-DD-HH-MM-SS").format(date);
		return currentTimestamp;
	}
	
	public String getCurrentYear(){
		String currentYear = null;
		currentYear = new SimpleDateFormat("YYYY").format(date);
		return currentYear;
	}
	
	public String getCurrentMonth(){
		String currentMonth = null;
		currentMonth = new SimpleDateFormat("YYYY-MM").format(date);
		return currentMonth;
	}
	
	public String getCurrentDay(){
		String currentDay = null;
		currentDay = new SimpleDateFormat("YYYY-MM-DD").format(date);
		return currentDay;
	}

	public String getDayOfWeek(){
		String dayOfWeek = null;
		dayOfWeek = new SimpleDateFormat("EEEE").format(date);		
		return dayOfWeek;
		
	}
	
}
