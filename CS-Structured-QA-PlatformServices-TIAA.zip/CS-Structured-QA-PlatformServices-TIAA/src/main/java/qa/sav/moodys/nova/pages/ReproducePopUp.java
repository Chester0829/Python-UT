package qa.sav.moodys.nova.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import qa.sav.moodys.nova.Job;

public class ReproducePopUp extends PageBase{
	
	public final static String reproduceNameFieldXpath = "//*[@id=\"input-note\"]";
	@FindBy(xpath = reproduceNameFieldXpath)
	WebElement setNewJobName;
	
	public final static String reproduceJobOverviewXpath = "//*[@id=\"content-job-overview\"]";
	@FindBy(xpath = reproduceJobOverviewXpath)
	WebElement originalJobOverview;
	
	public final static String reproduceButtonXpath = "//*[@id=\"btn-reproduce\"]";
	@FindBy(xpath = reproduceButtonXpath)
	WebElement reproduceButton;
	
	public final static String closeButtonXpath = "//*[@id=\"modal-content-reproduce-simulation\"]/div[3]/button[2]";
	@FindBy(xpath = closeButtonXpath)
	WebElement closeButton;

	public ReproducePopUp(WebDriver driver, Job job) throws Exception {
		super(driver);
		// TODO Auto-generated constructor stub
		new Dashboard(driver).clickToReproduceJob(job);
	}
	
	public void submitReproduceJob(Job job, String useNewName) throws Exception{		
		waitForAjaxLoaded();
		setNewJobName.clear();
		setNewJobName.sendKeys(useNewName);				
		reproduceButton.click();
		waitForAjaxLoaded();
	}
	
//public Job submitReproduceJob(Job job, String newJobName) throws Exception{
//		
//		//String newJobName = job.getJobStatus().getName()+"reproduce_"+job.getJobStatus().getJobID();
//		JobSettings jobSetting = job.getJobSettings();
//		jobSetting.setJobName(newJobName);
//		JobStatus jobStatus = job.getJobStatus();
//		jobStatus.setName(newJobName);
//		job.setJobSettings(jobSetting);
//		job.setJobStatus(jobStatus);
//		
//		setNewJobName.clear();
//		setNewJobName.sendKeys(newJobName);
//				
//		reproduceButton.click();
//		waitForAjaxLoaded();		
//		return job;
//	}
	
	public void close() throws Exception{
		closeButton.click();
		waitForAjaxLoaded();
	}
	

}
