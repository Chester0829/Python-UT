package qa.sav.moodys.nova.pages.launch;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import qa.sav.moodys.nova.pages.HomePage;

public class LaunchRmbs extends Launch {
	
	String launchRmbsPagePath = "sf-simulation/launch?businessType=RMBS";
	
	final static String horizonYearXpath = "//*[@id=\"years-select\"]";
	@FindBy(xpath = horizonYearXpath)
	public WebElement horizon;
	
	final static String horizonMonXpath = "//*[@id=\"months-select\"]";		
	@FindBy(xpath = horizonMonXpath)
	public WebElement horizonMonth;
	
	final static String useTargetLgdXpath = "//*[@id=\"useTargetLGD\"]";
	@FindBy(xpath = useTargetLgdXpath)
	public WebElement useTargetLgd;
	
	final static String useSystemBookPriceXpath = "//*[@id=\"useSystemBookPrice\"]";
	@FindBy(xpath = useSystemBookPriceXpath)
	public WebElement useSystemBookPrice;
	
	final static String globalValueDashboradXpath = "//a[@href='/sf-simulation/dialog?modalType=globalValues&businessType=RMBS\']";
	@FindBy(xpath = globalValueDashboradXpath)
	public WebElement globalValue;	
	
	final static String defaultValuesXpath = "//a[@href='/sf-simulation/dialog?modalType=defaultValuesRMBS&businessType=RMBS\']";
	@FindBy(xpath = defaultValuesXpath)
	public WebElement defaultValuesLink;	 
	
	final static String econScenXpath = "//a[@href='/sf-simulation/dialog?modalType=economicScenarios&businessType=RMBS']";
	@FindBy(xpath = econScenXpath)
	public WebElement econScenLink;
	
	final static String rattingMapXpath = "//a[@href='/sf-simulation/dialog?modalType=rateMappings&businessType=RMBS']";
	@FindBy(xpath = rattingMapXpath)
	public WebElement rattingMapLink;
//	@FindBy(id="modal-global-values")
//	WebElement globalValuePopUp;
	
	@FindBy()
	WebElement lgdAlertBox;
	
	@FindBy()
	WebElement bookPriceAlertBox;
	
	public LaunchRmbs(WebDriver driver) throws Exception {
		super(driver);
		
		if(driver.getCurrentUrl().contains(launchRmbsPagePath)){
			//do nothing
		} else {
			try {
				new HomePage(driver).launchToModel(RMBS);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.error("Not able to go to Rmbs Launch page");
				e.printStackTrace();
				throw e;
			}
		}
		// TODO Auto-generated constructor stub
	}	


	public void setHorizon(String horizon) throws Exception{
		String year = horizon.split("-")[0];
		String month = horizon.split("-")[1];
		Select dropdownList = new Select(driver.findElement(By.xpath(horizonYearXpath)));
		dropdownList.selectByValue(year);
		waitForAjaxLoaded();
		dropdownList = new Select(driver.findElement(By.xpath(horizonMonXpath)));
		dropdownList.selectByValue(month);
		waitForAjaxLoaded();		
	}
	
	//@Override
	public String getHorizonValues(){
		String year = getHorizonYears();
		String month = getHorizonMonths();
		return year + "-" + month;		
	}
	
	//@Override
	public void setUseTargetLgd(boolean useTargetLgd) {
		if(useTargetLgd){
			if(driver.findElement(By.xpath(useTargetLgdXpath)).isSelected()){
				// use target lgd already set to true, do nothing
			} else {
				
				driver.findElement(By.xpath(useTargetLgdXpath)).click();
			}
		} else{
			if(driver.findElement(By.xpath(useTargetLgdXpath)).isSelected()){
				
				driver.findElement(By.xpath(useTargetLgdXpath)).click();
			} else {
				// use target Lgd has already set to false, do nothing
			}
		}	
		
	}
	
	//@Override
	public void setUseSystemBookPrice(boolean useBookPrice) {

		if(useBookPrice){
			if(driver.findElement(By.xpath(useSystemBookPriceXpath)).isSelected()){
				// use target lgd already set to true, do nothing
			} else {
				driver.findElement(By.xpath(useSystemBookPriceXpath)).click();
			}
		} else{
			if(driver.findElement(By.xpath(useSystemBookPriceXpath)).isSelected()){
				driver.findElement(By.xpath(useSystemBookPriceXpath)).click();
			} else {
				// use target Lgd has already set to false, do nothing
			}
		}		
	}
			
	//@Override
	public boolean isUseTargetLgd() {
		return (driver.findElement(By.xpath(useTargetLgdXpath)).isSelected());
	}

	//@Override
	public boolean isUseSystemBookPrice() {
		// TODO Auto-generated method stub
		return (driver.findElement(By.xpath(useSystemBookPriceXpath)).isSelected());
	}
	
	public void openGlobalValueDashboard() throws InterruptedException{
		driver.findElement(By.xpath(globalValueDashboradXpath)).click();
		waitForAjaxLoaded();
	}
	
	public void openDefaultValuesDashborad() throws Exception{
		defaultValuesLink.click();
		waitForAjaxLoaded();
	}
	
	public void openEconScenDashboard() throws Exception{
		this.econScenLink.click();
		waitForAjaxLoaded();
	}
	
	public void openRatingMapDashboard() throws Exception{
		this.rattingMapLink.click();
		this.waitForAjaxLoaded();
	}
	
	private String getHorizonYears(){
		return new Select(driver.findElement(By.xpath(horizonYearXpath))).getFirstSelectedOption().getText();
	}
	
	private String getHorizonMonths(){
		return new Select(driver.findElement(By.xpath(horizonMonXpath))).getFirstSelectedOption().getText();
	}
	
}
