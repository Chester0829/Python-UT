package qa.sav.moodys.nova.deprecated;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import org.supercsv.io.CsvListReader;
import org.supercsv.prefs.CsvPreference;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.data.JobStatus;
import qa.sav.moodys.nova.utils.JdbcUtilSav;

public class CreateTabeFromCsvHeader {

	public String readCsvHeader(String inputCsvFile, String businessType) throws IOException{
		
		File inputFile = new File(inputCsvFile);
		String pre_tableName = inputFile.getName();
	
		CsvListReader reader = new CsvListReader(new FileReader(inputCsvFile), CsvPreference.STANDARD_PREFERENCE);
		
		List<String> columns = null;
		columns = reader.read();
		String pre_sql = "create table " + businessType +"_" + pre_tableName.replace(".csv", "") + "( ";
		pre_sql = pre_sql + "DataSource	Varchar(500), " + "JobID Int NOT NULL, " + "JobType Varchar(500), " + "BusinessType Varchar(500),  BenchMark_1 boolean, BenchMark_2 boolean, ";
		
		Log.info(pre_sql);
		
		for(int i = 0; i < columns.size(); i++)
		{
			if(i < columns.size()-1){
				pre_sql = pre_sql + columns.get(i).replace(">", "LT").replace("+", "plus").replace("Default", "_Default").replace("-", "").replace(" ", "").replace(".", "").replace("/", "").replace("%", "").replace("(", "_").replace(")", "").replace("*", "") + " Varchar(500), ";
			} else {
				pre_sql = pre_sql + columns.get(i).replace(">", "LT").replace("+", "plus").replace("-", "").replace(" ", "").replace(".", "").replace("/", "").replace("%", "").replace("(", "_").replace(")", "").replace("*", "") + " Varchar(500) "; 
			}
		}
		
		pre_sql = pre_sql + ")";
		
		Log.info(pre_sql);
		
		reader.close();
		
		
		return pre_sql;		
		
	}
	
	@Test
	public void testtools() throws IOException{				
		JobStatus jobResult = new JobStatus();
		jobResult.setDataSource("UI_Expoort");
		jobResult.setJobID(1);
		jobResult.setBusinessType("cmbs");
		jobResult.setRunType("static");
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		
		 String path = "C:/Users/qins/Downloads/6522-test_defaultvalue_rmbs"; // 路径
		 File f = new File(path);
		 if (!f.exists()) {
			 System.out.println(path + " not exists");
			 return;
			}
		File fa[] = f.listFiles();
		
		String resultFileName = null;
		for (int i = 0; i < fa.length; i++){
			
			resultFileName = fa[i].getAbsolutePath();
			Log.info(resultFileName);
			String sql = readCsvHeader(resultFileName, "rmbs");
			
			try{
				
				connection = JdbcUtilSav.getConnection();
				statement = connection.prepareStatement(sql);
				statement.executeUpdate(sql);		 
				statement.close();
				
				
			} catch(Exception e){
				e.printStackTrace();
	        	  
			} finally{
				JdbcUtilSav.release(connection, statement, resultSet);
			}
		}
	}
}
