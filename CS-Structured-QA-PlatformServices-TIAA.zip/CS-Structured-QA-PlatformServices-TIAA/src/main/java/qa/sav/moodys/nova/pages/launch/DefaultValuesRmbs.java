package qa.sav.moodys.nova.pages.launch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import qa.sav.moodys.nova.pages.PageBase;

public class DefaultValuesRmbs extends PageBase {
	
	HashMap <String, String> defaultValueXpath;
	HashMap <String, String> defaultValueInputType;
	
	final static String TEXT = "text";
	final static String SELECT = "select";
	
	final static String AmortizationTerm = "Amortization Term";	
	final static String currentAmount = "Current Amount";	
	final static String cutOffAge = "Cutoff Age";	
	final static String documentation = "Documentation";	
	final static String fico = "FICO";		
	final static String grossCoupon = "Gross Coupon";		
	final static String grossMargin = "Gross Margin";		
	final static String helocMaxDrawAmount = "HELOC Max Draw Amount";		
	final static String juniorLTV = "Junior LTV";
	final static String lienPosition = "Lien Position";		
	final static String loadId = "Loan ID";		
	final static String loanStatus = "Loan Status";		
	final static String ltv = "LTV";		
	final static String mortgateType = "Mortgage Type";		
	final static String occupancyType = "Occupancy Type";		
	final static String originalAmount = "Original Amount";		
	final static String originalTerm = "Original Term";		
	final static String propertyType = "Property Type";		
	final static String purposeType = "Purpose Type";	
	final static String securitizedAmount = "Securitized Amount";		
	final static String seniorBalance = "Senior Balance";		
	final static String state = "State";		
	final static String zipCode = "Zip Code";
	
	final static String defaultValuesPopUpXpath = "//*[@id=\"modal-default-values\"]";	
	@FindBy(xpath = defaultValuesPopUpXpath)
	public WebElement defaultValuesPopUp;
	
	@FindBy(id="dv-collateral-type")
	public WebElement collateralType;
	
	final static String defaultValueTableXpath = "//*[@id=\"tb-defaultvalues\"]";
	@FindBy(xpath=defaultValueTableXpath)
	public WebElement defaultValuesTable;

	@FindBy(xpath = "//*[@id=\"modal-default-values\"]/div/div/div[3]/label")
	public WebElement importFromCsvButton;
	
	@FindBy(xpath = "//*[@id=\"export-default-values\"]")
	public WebElement exprotToCsvButton;
	
	@FindBy(xpath = "//*[@id=\"btn-create-default-values\"]")
	public WebElement saveAsNewTypeButton;
	
	@FindBy(xpath = "//*[@id=\"btn-delete-default-values\"]")
	public WebElement deleteCurrentTypeButton;
	
	@FindBy(xpath = "//*[@id=\"modal-default-values\"]/div/div/div[3]/button[5]")
	public WebElement applyChangesButton;
	
	@FindBy(xpath = "//*[@id=\"modal-default-values\"]/div/div/div[1]/button")
	public WebElement closeDashboardButton;
	
	@FindBy(xpath = "//*[@id=\"btn-save-default-values\"]")
	public WebElement saveChangesButton;
	
	@FindBy(xpath = "//*[@id=\"msg-default-values\"]")
	public WebElement alertMsgBox;
	
	@FindBy(xpath = "//*[@id=\"body-confirm-delete\"]")
	WebElement confirmDeleteMsgBox;
	
	@FindBy(xpath = "//*[@id=\"btn-confirm-delete\"]")
	WebElement confirmDeleteButton;
	
	@FindBy(xpath = "//*[@id=\"modal-confirm-delete\"]/div/div/div[3]/button")
	WebElement cancelDeleteButton;
	
	public void closeDashboard() throws Exception{
		closeDashboardButton.click();
		this.waitForAjaxLoaded();
		Thread.sleep(1000);
	}
	
	public void closeDashboard(boolean saveChange){		
		closeDashboardButton.click();
		this.acceptAlert(saveChange);
	}
	
	public void importValuesFromCsv(String inputCsvFileFullName){
		
	}
	
	public void exportValuesToCsv(String outputCsvFileFullName){
		
	}
	
	public void saveChangeAsNewType(String newTypeName, boolean forceSave){
		
		String popUpDialogXpath = "//*[@id=\"inputTypeName\"]";
		String savebuttonXpath = "//*[@id=\"saveNewDefaultValues\"]";
		String closeDialogXpath = "//*[@id=\"modal-create-default-values\"]/div/div/div[3]/button[2]";
		
		this.saveAsNewTypeButton.click();
		//*[@id="msg-default-values"]/div
		
		try{
			this.waitForElementPresent(popUpDialogXpath);
		} catch (Exception e){
			log.error("No \"Create new type of default values\" dialog pop-up, please check");
			throw e;
		}
		
		driver.findElement(By.xpath(popUpDialogXpath)).clear();
		driver.findElement(By.xpath(popUpDialogXpath)).sendKeys(newTypeName);
		
		if(forceSave){
			driver.findElement(By.xpath(savebuttonXpath)).click();
		} else {
			driver.findElement(By.xpath(closeDialogXpath)).click();
		}
		
	}
	
	public void saveChangesToCurrentType() throws Exception{
		this.saveChangesButton.click();
		this.waitForAjaxLoaded();
	}
	
	public String deleteByCollateralType(String collateralTypeName, boolean confirm) throws Exception{
		String deleteConfirmMsg = null;
		if(this.readCurrentCollateralType().equalsIgnoreCase(collateralTypeName)){
			//do nothing
		} else {
			this.setColateralTypeOption(collateralTypeName, false);
			this.waitForAjaxLoaded();
		}
		this.deleteCurrentTypeButton.click();	
		this.waitForAjaxLoaded();
		deleteConfirmMsg = this.readConfirmDeleteMsg();
		if(confirm){
			this.confirmDeleteButton.click();
		}else{
			this.cancelDeleteButton.click();
		}
		
		this.waitForAjaxLoaded();
		
		return deleteConfirmMsg;
	}
	
	public String readAlertMessage() throws Exception{
		this.waitForAjaxLoaded();
		String msg = null;		
		msg = alertMsgBox.getText().replace("×", "").replace("\n", "");
		log.warn("Captured Alert Message: \n"+msg);
		return msg;
	}
	
	public String readConfirmDeleteMsg(){
		String msg = null;
		msg = this.confirmDeleteMsgBox.getText();
		log.warn(msg);
		return msg;
	}
	
	
	public DefaultValuesRmbs(WebDriver driver) throws Exception {
		super(driver);
		// TODO Auto-generated constructor stub		
		try{
			if(defaultValuesPopUp.isDisplayed()){
			// default value pop up window alread opened, do nothing
			} else {
				new LaunchRmbs(driver).openDefaultValuesDashborad();
			}	
		}catch(Exception e){
			log.warn("defaultValue dashboard has not been opened");
			new LaunchRmbs(driver).openDefaultValuesDashborad();
		}
		
		//initial Input Type
		defaultValueInputType = new HashMap <String, String> ();		
		defaultValueInputType.put(AmortizationTerm, TEXT);
		defaultValueInputType.put(currentAmount, TEXT);
		defaultValueInputType.put(cutOffAge, TEXT);
		defaultValueInputType.put(documentation, SELECT);
		defaultValueInputType.put(fico, TEXT);
		defaultValueInputType.put(grossCoupon, TEXT);
		defaultValueInputType.put(grossMargin, TEXT);
		defaultValueInputType.put(helocMaxDrawAmount, TEXT);
		defaultValueInputType.put(juniorLTV, TEXT);
		defaultValueInputType.put(lienPosition, TEXT);
		defaultValueInputType.put(loadId, TEXT);
		defaultValueInputType.put(loanStatus, SELECT);
		defaultValueInputType.put(ltv, TEXT);
		defaultValueInputType.put(mortgateType, SELECT);
		defaultValueInputType.put(occupancyType, SELECT);
		defaultValueInputType.put(originalAmount, TEXT);
		defaultValueInputType.put(originalTerm, TEXT);
		defaultValueInputType.put(propertyType, SELECT);
		defaultValueInputType.put(purposeType, SELECT);
		defaultValueInputType.put(securitizedAmount, TEXT);
		defaultValueInputType.put(seniorBalance, TEXT);
		defaultValueInputType.put(state, SELECT);
		defaultValueInputType.put(zipCode, TEXT);
		
	}
	
	public HashMap<String, String> readFiledXpaths() throws Exception{
		defaultValueXpath = new HashMap <String, String>();
		String fieldName_xpath = null;
		String fieldValue_xpath = null;
		String fieldName = null;
		
		//this.waitForElementPresent(defaultValueTableXpath);
		this.waitForAjaxLoaded();
		
		for(int i = 1; i <= defaultValuesTable.findElements(By.xpath("tbody/tr")).size(); i++){
			fieldName_xpath = "tbody/tr[" + i + "]/td[1]";
			this.waitForElementPresent(defaultValueTableXpath+"/"+fieldName_xpath);
			fieldName = defaultValuesTable.findElement(By.xpath(fieldName_xpath)).getText();			 
			if(defaultValueInputType.get(fieldName).equalsIgnoreCase(TEXT)){
				fieldValue_xpath = "//*[@id=\"tb-defaultvalues\"]/tbody/tr[" + i + "]/td[2]"+"/input";
				//defaultValueXpath.put(defaultValuesTable.findElement(By.xpath(fieldName_xpath)).getText(), fieldValue_xpath);
			} else if(defaultValueInputType.get(fieldName).equalsIgnoreCase(SELECT)) {
				fieldValue_xpath = "//*[@id=\"tb-defaultvalues\"]/tbody/tr[" + i + "]/td[2]"+"/select";				
			}	
			
			defaultValueXpath.put(fieldName, fieldValue_xpath);
		}
		return defaultValueXpath;		
	}

	
	
	public String readCurrentCollateralType(){	
		
		Select collateralTypeSelector = new Select(collateralType);
		return collateralTypeSelector.getFirstSelectedOption().getText();			
	}
	
	public void setColateralTypeOption(String collType, boolean saveChangeForCurrentType){
		Select collateralTypeSelector = new Select(collateralType);
		collateralTypeSelector.selectByValue(collType);
		this.acceptAlert(saveChangeForCurrentType);
	}
	
	public String[] readCollateralTypeOptions(){
		
		Select collateralTypeSelector = new Select(collateralType);
		List<WebElement> collTypeOptions = collateralTypeSelector.getOptions();		
		int collTypeCounts = collTypeOptions.size();		
		String[] collateral = new String[collTypeCounts];
	
		for(int i = 0; i < collTypeCounts; i++){
			collateral[i] = collTypeOptions.get(i).getText();
		}
		return collateral;		
	}
	
	public void setDefaultValueByFieldName(String fieldName, String fieldValue){
		for(Map.Entry<String, String> entry : defaultValueXpath.entrySet()){
			if(entry.getKey().equalsIgnoreCase(fieldName)){
				this.findElement(entry.getValue());
				if(entry.getValue().contains("input")){
					driver.findElement(By.xpath(entry.getValue())).clear();
					driver.findElement(By.xpath(entry.getValue())).sendKeys(fieldValue);
				} else {
					new Select(driver.findElement(By.xpath(entry.getValue()))).selectByVisibleText(fieldValue);
				}
				break;
			} else {
				continue;
			}
		}
	}

	
	private WebElement findElement(String xpath){	
		
		WebElement webElement = null;	
		
		try{
			log.info("Find element by xpath: " + xpath);
			webElement = driver.findElement(By.xpath(xpath));
		} catch(NoSuchElementException e){
			log.warn("Cannot find element in current page, move mouse to find element");
			
			try{
				webElement = driver.findElement(By.xpath(xpath));
				this.mouseOverToElement(webElement);
			} catch (NoSuchElementException e2) {
				log.error("Cannot find element by xpath: " + xpath);
				webElement = null;
				throw e;
			}			
		} 
		
		return webElement;
	}
	
	public static String getText() {
		return TEXT;
	}

	public static String getSelect() {
		return SELECT;
	}

	public static String getDefaultvaluespopupid() {
		return defaultValuesPopUpXpath;
	}

	public WebElement getDefaultValuesPopUp() {
		return defaultValuesPopUp;
	}

	public WebElement getCollateralType() {
		return collateralType;
	}

	public WebElement getDefaultValuesTable() {
		return defaultValuesTable;
	}

	public static String getAmortizationterm() {
		return AmortizationTerm;
	}

	public static String getCurrentamount() {
		return currentAmount;
	}

	public static String getCutoffage() {
		return cutOffAge;
	}

	public static String getDocumentation() {
		return documentation;
	}

	public static String getFico() {
		return fico;
	}

	public static String getGrosscoupon() {
		return grossCoupon;
	}

	public static String getGrossmargin() {
		return grossMargin;
	}

	public static String getHelocmaxdrawamount() {
		return helocMaxDrawAmount;
	}

	public static String getJuniorltv() {
		return juniorLTV;
	}

	public static String getLienposition() {
		return lienPosition;
	}

	public static String getLoadid() {
		return loadId;
	}

	public static String getLoanstatus() {
		return loanStatus;
	}

	public static String getLtv() {
		return ltv;
	}

	public static String getMortgatetype() {
		return mortgateType;
	}

	public static String getOccupancytype() {
		return occupancyType;
	}

	public static String getOriginalamount() {
		return originalAmount;
	}

	public static String getOriginalterm() {
		return originalTerm;
	}

	public static String getPropertytype() {
		return propertyType;
	}

	public static String getPurposetype() {
		return purposeType;
	}

	public static String getSecuritizedamount() {
		return securitizedAmount;
	}

	public static String getSeniorbalance() {
		return seniorBalance;
	}

	public static String getState() {
		return state;
	}

	public static String getZipcode() {
		return zipCode;
	}

	public HashMap<String, String> getDefaultValueXpath() {
		return defaultValueXpath;
	}

	public HashMap<String, String> getDefaultValueInputType() {
		return defaultValueInputType;
	}
	
	
	
}
