package qa.sav.moodys.nova.pages.jobResult;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import qa.sav.moodys.nova.Job;
import qa.sav.moodys.nova.pages.PageBase;

public class JobResultTabBase extends PageBase{	
	
	final static String overViewTabBlockXpath = "//*[@id=\"resultTabs\"]/li[1]/a";	//*[@id="resultTabs"]/li[1]/a
	@FindBy(xpath = overViewTabBlockXpath)
	WebElement overViewTab;
	
	final static String collateralCashflowsTabBlockXpath = "//*[@id=\"resultTabs\"]/li[2]/a";	
	@FindBy(xpath = collateralCashflowsTabBlockXpath)
	WebElement collateralCashflowsTab;
	
	final static String bondCashflowsTabBlockXpath = "//*[@id=\"resultTabs\"]/li[3]/a";
	@FindBy(xpath = bondCashflowsTabBlockXpath)
	WebElement bondCashflowsTab;
	
	final static String annualPDsELsMappinsTabBlockXpath = "//*[@id=\"resultTabs\"]/li[4]/a";
	@FindBy(xpath = annualPDsELsMappinsTabBlockXpath)
	WebElement annualPDsELsMappinsTab;

	public JobResultTabBase(WebDriver driver, Job job) throws Exception{
		super(driver);
		String jobResultUrl = "result?jobId="
				+job.getJobStatus().getJobID()
				+"&jobName=" + job.getJobSettings().getJobName().toLowerCase()
				+"&jobType=" + job.getJobStatus().getRunType()
				+ "&businessType="+job.getJobStatus().getBusinessType();
		if(driver.getCurrentUrl().contains(jobResultUrl)){
			//do nothing
		} else {
			try {	
				if(job.getJobStatus().getJobID() == null){
					job.goToJobResultsPage(job.getJobStatus().getName());
				} else {
					job.goToJobResultsPage(job.jobSettings.getJobName(), job.getJobStatus().getJobID());
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.error("Unable to go to job result page for job: "+job.getJobStatus().getName()+", please check");
				log.error(e.getMessage());
				e.printStackTrace();
				throw e;
			}
		}
		// TODO Auto-generated constructor stub
	}

	public void goToOverviewTab() throws Exception{
		this.waitForAjaxLoaded();
		this.waitForElementPresent(overViewTabBlockXpath);
		if(driver.findElement(By.xpath(overViewTabBlockXpath)).getAttribute("class").equals("active")){
			// already in overveiw tab, do nothing
		} else {
			this.overViewTab.click();
			this.waitForAjaxLoaded();
		}
	}
	
	public void goToCollateralCashflowsTab() throws Exception{
		this.waitForAjaxLoaded();
		this.waitForElementPresent(collateralCashflowsTabBlockXpath);
		if(driver.findElement(By.xpath(collateralCashflowsTabBlockXpath)).getAttribute("class").equals("active")){
			// already in collateral cashflow tab, do nothing
		} else {
			this.collateralCashflowsTab.click();
			this.waitForAjaxLoaded();
		}
	}
	
	public void goToBondCashflowsTab() throws Exception{
		this.waitForAjaxLoaded();
		this.waitForElementPresent(bondCashflowsTabBlockXpath);
		if(driver.findElement(By.xpath(bondCashflowsTabBlockXpath)).getAttribute("class").equals("active")){
			// already in bond cashflow tab, do nothing
		} else {
			this.bondCashflowsTab.click();
			this.waitForAjaxLoaded();
		}
	}
	
	public void goToAnnualPDsELsMappingsTab() throws Exception{
		this.waitForAjaxLoaded();
		this.waitForElementPresent(annualPDsELsMappinsTabBlockXpath);
		if(driver.findElement(By.xpath(annualPDsELsMappinsTabBlockXpath)).getAttribute("class").equals("active")){
			// already in anual PDs ELs mapping tab, do nothing
		} else {
			this.annualPDsELsMappinsTab.click();
			this.waitForAjaxLoaded();
		}
	}
	
}
