package qa.sav.moodys.nova.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Login extends PageBase{	
		
	public String url = null;
	public String user = null;
	public String pwd = null;
	
	public String xPathUserName = "//*[@id=\"username\"]";
	public String xPathPassWord = "//*[@id=\"password\"]";
	public String xPathCheckBoxLocalAuthentication = "//*[@id=\"localAuthon\"]";
	public String xPathTextLocalAuthentication = "//*[@id=\"checkbox-rememberme\"]/text()";
	public String xPathSignInButton = "//*[@id=\"login\"]/div[5]/input[2]";	
	
	public Login(WebDriver driver){	
		super(driver);
		this.url = config.getProperty("url");
		this.user = config.getProperty("user");
		this.pwd = config.getProperty("pwd");
	}

	public void accessLoginPage() throws InterruptedException{
		
		// Go to Nova website 
		log.info("Go to Nova web page: " + url); 		
		driver.get(url);
		
		this.waitForAjaxLoaded();
		
		log.info("Maximal current browser windows");
		
		driver.manage().window().maximize();
		
	}
	
	public void loginToDashboard() throws Exception {		
		this.accessLoginPage();
        this.userName().clear();
        this.userName().sendKeys(user);
        this.password().clear();
        this.password().sendKeys(pwd);
        this.localAuthentication().click();
        this.signIn().submit(); 
        this.waitForAjaxLoaded();
	}
		
	public void loginToDashboard(String username, String password) throws InterruptedException{		
		this.accessLoginPage();
        this.userName().clear();
        this.userName().sendKeys(username);
        this.password().clear();
        this.password().sendKeys(password);
        this.localAuthentication().click();
        this.signIn().submit();      
	
	}
	
	public WebElement userName(){
		if(waitForElementPresent(xPathUserName)){
			return driver.findElement(By.xpath(xPathUserName));
		} else{
			log.warn("Cannot find User name text box at page " + driver.getCurrentUrl() + " ,please check ... ");
			return null;
		}		
	}
	
	public WebElement password(){
		if(waitForElementPresent(this.xPathPassWord)){
			// Log.info("Password text box is present");
			return driver.findElement(By.xpath(this.xPathPassWord));
		} else{
			log.warn("Cannot find Password at page " + driver.getCurrentUrl() + " ,please check ... ");
			return null;
		}		
	}
	
	public WebElement signIn(){
		if(waitForButtonActive(this.xPathSignInButton)){
			// Log.info("Sign In button is present and Activity");
			return driver.findElement(By.xpath(this.xPathPassWord));
		} else{
			log.warn("Cannot find Sign In button at page " + driver.getCurrentUrl() + " ,please check ... ");
			return null;
		}		
	}

	public WebElement localAuthentication(){
		if(waitForElementPresent(this.xPathCheckBoxLocalAuthentication)){
			// Log.info("Local Authentication check box is present");
			return driver.findElement(By.xpath(this.xPathCheckBoxLocalAuthentication));
		} else{
			log.warn("Cannot find Local Authentication check box at page " + driver.getCurrentUrl() + " , please check ... ");
			return null;
		}		
			
	}

}	

	
