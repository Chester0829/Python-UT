package qa.sav.moodys.nova.s3;

import java.io.File;
import java.util.List;

public interface SimpleStoreHandler {
	
//	public void createObjectFromFile(String bucketname, String key, File file) throws RuntimeException;
//	public void createObjectFromInputStream(String bucketname, String key, InputStream inputStream) throws RuntimeException;
//	public void createObjectFromInputStream(String bucketname, String key, InputStream inputStream, ObjectMetadata metadata) throws RuntimeException;
//	public void deleteObject(String bucketname, String key) throws RuntimeException;
//	public void deleteMultiObjects(String bucketName,List<String> keys)throws RuntimeException;
//	public void createBucket(String bucketname) throws RuntimeException;
//	public void deleteBucket(String bucketname) throws RuntimeException;
//	public void uploadFileToStore(File file, String bucket, String key) throws RuntimeException;
	
	public StoreObject retrieveObject(String bucketname, String key) throws RuntimeException;

	public ObjectMetadata retrieveObjectToFile(String bucketname, String key, File destFile) throws RuntimeException;

	public StoreObject retrieveObject(String bucketname, String key, String versionId) throws RuntimeException;

	public List<StoreObjectSummary> listObjects(String bucketname) throws RuntimeException;

	public List<StoreObjectSummary> listObjects(String bucketname, String prefix, boolean fuzzy, String... delimiters) throws RuntimeException;
	public List<StoreObjectSummary> listObjects(String bucketname, String prefix) throws RuntimeException;

	public List<Bucket> listBuckets() throws RuntimeException;

	public String retrieveObjectStringContent(String bucketname, String key)throws Exception;
	public void downloadObjectToFile(String bucket, String key,File file)throws RuntimeException;
}
