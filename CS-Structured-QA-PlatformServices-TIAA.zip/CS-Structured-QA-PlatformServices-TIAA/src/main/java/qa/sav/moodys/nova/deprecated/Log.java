package qa.sav.moodys.nova.deprecated;

import java.io.File;
import java.io.FileInputStream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.ConfigurationSource;
import org.apache.logging.log4j.core.config.Configurator;

	/** 
	 *   
	 * @version 1.0
	 * @since 2017/11/08
	 * @author QinS
	 * 
	 */
	public class Log {
		
		public Log() {
			System.out.println("init log file");
		}

		private static final String LOG4J_XML_NAME = "C:\\SAV\\QA\\Nova\\Auto\\NovaTest\\config\\log4j2.xml";
	    private static Log instance = null;
	    public static Logger logger = null;
	    
	    static{
	    	try{
	    	ConfigurationSource source = new ConfigurationSource(new FileInputStream(LOG4J_XML_NAME));
			File config=new File(LOG4J_XML_NAME);
			source = new ConfigurationSource(new FileInputStream(config),config);
			String path= LOG4J_XML_NAME;
			source = new ConfigurationSource(new FileInputStream(path),new File(path).toURL());
			Configurator.initialize(null, source);                
			logger = LogManager.getLogger(Log.class.getName());    }
	    	catch (Exception e) {
				e.printStackTrace();
			}    
	    }
	    	    

	    public static Log getInstance() {
	        synchronized (Log.class) {
	            if (instance == null) {
	                instance = new Log();
	            }
	        }
	        return instance;
	    }

	    public static void debug(String msg) {
	        logger.debug(msg);
	    
	    }

	    public static void debug(String msg, Exception e) {
	        logger.debug(msg, e);
	    }
	    
	    public static void info(String msg) {
	        logger.info(msg);
	   
	    }
	    
	    public static void info(String msg, Exception e) {
	        logger.info(msg, e);
	    }

	    public static void warn(String msg) {
	        logger.warn(msg);
	    }
	    
	    public static void warn(String msg, Exception e) {
	        logger.warn(msg, e);
	    }

	    public static void error(String msg) {
	        logger.error(msg);
	    }

	    public static void error(String msg, Exception e) {
	        logger.error(msg, e);
	    }
	    
	    public static void fatal(String msg) {
	        logger.fatal(msg);
	    
	    }
	    
	    public static void fatal(String msg, Exception e) {
	        logger.fatal(msg, e);
	    }
	    
	    
	}
