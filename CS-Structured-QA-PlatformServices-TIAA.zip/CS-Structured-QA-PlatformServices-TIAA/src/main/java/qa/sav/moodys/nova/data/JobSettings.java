package qa.sav.moodys.nova.data;

import java.util.ArrayList;
import java.util.HashMap;

//import com.moodys.sav.sfs.data.bean.DefaultValues;

public class JobSettings {
	
	public ArrayList<String> getCusipsList() {
		return cusipsList;
	}

	public void setCusipsList(ArrayList<String> cusipsList) {
		this.cusipsList = cusipsList;
	}

	protected String portfolioFilePath = null;
    protected String businessType = null;	
    protected String runType = null; //run type, simulation/static
	protected String jobName = null;	
	protected String tailPercentageLevl = null;
	protected String confidenceLevelPercentage = null;
	protected String optimizationPercentageLevel = null;
	protected HashMap<String, String> scenarios = null; // scenarios and Blend Weight%
	public boolean scenarioBlended = false;
	protected String asOfDate = null; //deal as of date: year-month-day
	protected ArrayList<String> cusipsList = null;

	// settings for cmbs only
	protected Boolean forceSync = null;
	protected String dscrLtv = null;
	protected String cmmForecast = null;
	protected String cmmVersion = null;
	protected String simPaths = null;
	protected Boolean hopeNotesOverride = null;
	protected Boolean applyFullPdInFinalYear = null;
	protected Boolean noiGrowthRateCapFlag = null;
	protected String noiGrowthRateCapValue = null;
	
	// settings for rmbs only
	
	public String getPortfolioFilePath() {
		return portfolioFilePath;
	}

	public String getAsOfDate() {
		return asOfDate;
	}

	public void setAsOfDate(String asOfDate) {
		this.asOfDate = asOfDate;
	}

	public void setPortfoliofile(String portfoliofile) {
		this.portfolioFilePath = portfoliofile;
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getRunType() {
		return runType;
	}

	public void setRunType(String runType) {
		this.runType = runType;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public HashMap<String, String> getScenarios() {
		return scenarios;
	}

	public void setScenarios(HashMap<String, String> scenarios) {
		this.scenarios = scenarios;
	}

	public boolean isScenarioBlended() {
		return scenarioBlended;
	}

	public void setScenarioBlended(boolean scenarioBlended) {
		this.scenarioBlended = scenarioBlended;
	}

	public void setPortfolioFilePath(String portfolioFilePath) {
		this.portfolioFilePath = portfolioFilePath;
	}

	public String getTailPercentageLevl() {
		return tailPercentageLevl;
	}

	public void setTailPercentageLevl(String tailPercentageLevl) {
		this.tailPercentageLevl = tailPercentageLevl;
	}

	public String getConfidenceLevelPercentage() {
		return confidenceLevelPercentage;
	}

	public void setConfidenceLevelPercentage(String confidenceLevelPercentage) {
		this.confidenceLevelPercentage = confidenceLevelPercentage;
	}

	public String getOptimizationPercentageLevel() {
		return optimizationPercentageLevel;
	}

	public void setOptimizationPercentageLevel(String optimizationPercentageLevel) {
		this.optimizationPercentageLevel = optimizationPercentageLevel;
	}

	public Boolean getForceSync() {
		return forceSync;
	}

	public void setForceSync(Boolean forceSync) {
		this.forceSync = forceSync;
	}

	public String getDscrLtv() {
		return dscrLtv;
	}

	public void setDscrLtv(String dscrLtv) {
		this.dscrLtv = dscrLtv;
	}

	public String getCmmForecast() {
		return cmmForecast;
	}

	public void setCmmForecast(String cmmForecast) {
		this.cmmForecast = cmmForecast;
	}

	public String getCmmVersion() {
		return cmmVersion;
	}

	public void setCmmVersion(String cmmVersion) {
		this.cmmVersion = cmmVersion;
	}

	public String getSimPaths() {
		return simPaths;
	}

	public void setSimPaths(String simPaths) {
		this.simPaths = simPaths;
	}

	public Boolean getHopeNotesOverride() {
		return hopeNotesOverride;
	}

	public void setHopeNotesOverride(Boolean hopeNotesOverride) {
		this.hopeNotesOverride = hopeNotesOverride;
	}

	public Boolean getApplyFullPdInFinalYear() {
		return applyFullPdInFinalYear;
	}

	public void setApplyFullPdInFinalYear(Boolean applyFullPdInFinalYear) {
		this.applyFullPdInFinalYear = applyFullPdInFinalYear;
	}

	public Boolean getNoiGrowthRateCapFlag() {
		return noiGrowthRateCapFlag;
	}

	public void setNoiGrowthRateCapFlag(Boolean noiGrowthRateCapFlag) {
		this.noiGrowthRateCapFlag = noiGrowthRateCapFlag;
	}

	public String getNoiGrowthRateCapValue() {
		return noiGrowthRateCapValue;
	}

	public void setNoiGrowthRateCapValue(String noiGrowthRateCapValue) {
		this.noiGrowthRateCapValue = noiGrowthRateCapValue;
	}
	
}
