package qa.sav.moodys.nova.s3;

import java.util.Date;

public class Bucket {
	private static final long serialVersionUID = -8646831898339939580L;

	/** The name of this S3 bucket */
	private String name = null;

	/** The details on the owner of this bucket */
	private String owner = null;

	/** The date this bucket was created */
	private Date creationDate = null;

	/**
	 * Constructs a bucket without any name specified.
	 * 
	 * @see Bucket#Bucket(String)
	 */
	public Bucket() {
	}

	/**
	 * Creates a bucket with a name. All buckets in Amazon S3 share a single
	 * namespace; ensure the bucket is given a unique name.
	 * 
	 * @param name
	 *            The name for the bucket.
	 * 
	 * @see Bucket#Bucket()
	 */
	public Bucket(String name) {
		this.name = name;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return "S3Bucket [name=" + getName() + ", creationDate="
				+ getCreationDate() + ", owner=" + getOwner() + "]";
	}

	/**
	 * Gets the bucket's owner. Returns <code>null</code> if the bucket's owner
	 * is unknown.
	 * 
	 * @return The bucket's owner, or <code>null</code> if it is unknown.
	 * 
	 * @see Bucket#setOwner(Owner)
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * For internal use only. Sets the bucket's owner in Amazon S3. This should
	 * only be used internally by the AWS Java client methods that retrieve
	 * information directly from Amazon S3.
	 * 
	 * @param owner
	 *            The bucket's owner.
	 * 
	 * @see @link Bucket#getOwner()
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}

	/**
	 * Gets the bucket's creation date. Returns <code>null</code> if the
	 * creation date is not known.
	 * 
	 * @return The bucket's creation date, or <code>null</code> if not known.
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * For internal use only. Sets the bucket's creation date in S3. This should
	 * only be used internally by AWS Java client methods that retrieve
	 * information directly from Amazon S3.
	 * 
	 * @param creationDate
	 *            The bucket's creation date.
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * Gets the name of the bucket.
	 * 
	 * @return The name of this bucket.
	 * 
	 * @see Bucket#setName(String)
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name of the bucket. All buckets in Amazon S3 share a single
	 * namespace; ensure the bucket is given a unique name.
	 * 
	 * @param name
	 *            The name for the bucket.
	 */
	public void setName(String name) {
		this.name = name;
	}

}
