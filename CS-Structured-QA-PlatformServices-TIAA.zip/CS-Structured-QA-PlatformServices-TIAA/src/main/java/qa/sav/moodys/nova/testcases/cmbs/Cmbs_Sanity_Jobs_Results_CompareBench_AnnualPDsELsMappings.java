package qa.sav.moodys.nova.testcases.cmbs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.pages.jobResult.AnnualPDsELsMappingsCmbs;
import qa.sav.moodys.nova.pages.jobResult.BondCashflowsCmbs;
import qa.sav.moodys.nova.pages.jobResult.CollateralCashflowsCmbs;
import qa.sav.moodys.nova.pages.jobResult.JobResultCmbs;
import qa.sav.moodys.nova.pages.jobResult.OverviewCmbs;

public class Cmbs_Sanity_Jobs_Results_CompareBench_AnnualPDsELsMappings extends Cmbs_Sanity_Jobs_Base{
	
	JobCmbs job = null;
	JobResultCmbs cmbsResult = null;
	JobCmbs jobBench = null;
	JobResultCmbs cmbsResultBench = null;	


	@Test(groups="job_submit_cmbs_compare2bench", dataProvider="cmbs_sanity_jobs_and_cusips",priority=6, description="compare job resutls to benchmark - annaul rattings >> confidence level")
	public void compare_cmbs_sanity_job_results_to_benchmark_Rattings_Average_Summary(String jobName, String cusip) throws Exception{
		
		if(job == null || !job.getJobSettings().getJobName().equals(jobName)){			
			if(job == null){
				job = new JobCmbs(initialNewDriver(), this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
				job.reFreshStatus();
				cmbsResult = job.getResult();
			
				String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
				jobBench = this.getBenchJob(initialNewDriver(), benchJobNameType);
				jobBench.reFreshStatus();
				cmbsResultBench = jobBench.getResult();
			} else{
				job = new JobCmbs(job.driver, this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
				job.reFreshStatus();
				cmbsResult = job.getResult();
			
				String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
				jobBench = this.getBenchJob(jobBench.driver, benchJobNameType);	
				jobBench.reFreshStatus();
				cmbsResultBench = jobBench.getResult();
			}

		} else {
			//System.out.println("already in job result page, jobname: "+jobName+", benchName: "+ jobBench.getJobSettings().getJobName());
		}
		
		AnnualPDsELsMappingsCmbs annualPdElResults = cmbsResult.getAnnualPDsELsMappingInstance(job.driver);
				
		AnnualPDsELsMappingsCmbs annualPdElResultsBench = cmbsResultBench.getAnnualPDsELsMappingInstance(jobBench.driver);
				
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
							
		for(String scen:scenariosList){
			annualPdElResults.selectToScenario(scen);
			annualPdElResults.selectToCusip(cusip);
			annualPdElResultsBench.selectToScenario(scen);
			annualPdElResultsBench.selectToCusip(cusip);
			String averageMappingContent = annualPdElResults.averageSummaryTable.getText();
			String averageMappingContentBench = annualPdElResultsBench.averageSummaryTable.getText();
									
			Assert.assertEquals(averageMappingContent, averageMappingContentBench,
					"Verify the AnnualPdElsMapping >> average summary annual pds els mappings is the same between test job and bench");
		}								
	}	
	
	@Test(groups="job_submit_cmbs_compare2bench", dataProvider="cmbs_sanity_jobs_and_cusips",priority=6, description="compare job resutls to benchmark - annaul rattings >> average overall rattings")
	public void compare_cmbs_sanity_job_results_to_benchmark_Rattings_Average_Overall(String jobName, String cusip) throws Exception{
		
		if(job == null || !job.getJobSettings().getJobName().equals(jobName)){			
			if(job == null){
				job = new JobCmbs(initialNewDriver(), this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
				job.reFreshStatus();
				cmbsResult = job.getResult();
			
				String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
				jobBench = this.getBenchJob(initialNewDriver(), benchJobNameType);
				jobBench.reFreshStatus();
				cmbsResultBench = jobBench.getResult();
			} else{
				job = new JobCmbs(job.driver, this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
				job.reFreshStatus();
				cmbsResult = job.getResult();
			
				String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
				jobBench = this.getBenchJob(jobBench.driver, benchJobNameType);	
				jobBench.reFreshStatus();
				cmbsResultBench = jobBench.getResult();
			}

		} else {
			//System.out.println("already in job result page, jobname: "+jobName+", benchName: "+ jobBench.getJobSettings().getJobName());
		}
		
		AnnualPDsELsMappingsCmbs annualPdElResults = cmbsResult.getAnnualPDsELsMappingInstance(job.driver);
				
		AnnualPDsELsMappingsCmbs annualPdElResultsBench = cmbsResultBench.getAnnualPDsELsMappingInstance(jobBench.driver);
				
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
	
						
		for(String scen:scenariosList){
			annualPdElResults.selectToScenario(scen);
			annualPdElResults.selectToCusip(cusip);
			annualPdElResultsBench.selectToScenario(scen);
			annualPdElResultsBench.selectToCusip(cusip);
			String averageMappingContent = annualPdElResults.averageOverallRattingTable.getText();
			String averageMappingContentBench = annualPdElResultsBench.averageOverallRattingTable.getText();
									
			Assert.assertEquals(averageMappingContent, averageMappingContentBench,
					"Verify the AnnualPdElsMapping >> average overall annual pds els mappings is the same between test job and bench");
		}								
	}
	
	@Test(groups="job_submit_cmbs_compare2bench", dataProvider="cmbs_sanity_jobs_and_cusips",priority=6, description="compare job resutls to benchmark - annaul rattings >> confidence level")
	public void compare_cmbs_sanity_job_results_to_benchmark_Rattings_Average_Projected(String jobName, String cusip) throws Exception{
		
		if(job == null || !job.getJobSettings().getJobName().equals(jobName)){			
			if(job == null){
				job = new JobCmbs(initialNewDriver(), this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
				job.reFreshStatus();
				cmbsResult = job.getResult();
			
				String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
				jobBench = this.getBenchJob(initialNewDriver(), benchJobNameType);
				jobBench.reFreshStatus();
				cmbsResultBench = jobBench.getResult();
			} else{
				job = new JobCmbs(job.driver, this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
				job.reFreshStatus();
				cmbsResult = job.getResult();
			
				String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
				jobBench = this.getBenchJob(jobBench.driver, benchJobNameType);	
				jobBench.reFreshStatus();
				cmbsResultBench = jobBench.getResult();
			}

		} else {
			//System.out.println("already in job result page, jobname: "+jobName+", benchName: "+ jobBench.getJobSettings().getJobName());
		}
		
		AnnualPDsELsMappingsCmbs annualPdElResults = cmbsResult.getAnnualPDsELsMappingInstance(job.driver);
				
		AnnualPDsELsMappingsCmbs annualPdElResultsBench = cmbsResultBench.getAnnualPDsELsMappingInstance(jobBench.driver);
				
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
	
						
		for(String scen:scenariosList){
			annualPdElResults.selectToScenario(scen);
			annualPdElResults.selectToCusip(cusip);
			annualPdElResultsBench.selectToScenario(scen);
			annualPdElResultsBench.selectToCusip(cusip);
			String averageMappingContent = annualPdElResults.averageProjectedRattingMapTable.getText();
			String averageMappingContentContentBench = annualPdElResultsBench.averageProjectedRattingMapTable.getText();
									
			Assert.assertEquals(averageMappingContent, averageMappingContentContentBench,
					"Verify the AnnualPdElsMapping >> average overall annual pds els mappings is the same between test job and bench");
		}								
	}
	
	
	@Test(groups="job_submit_cmbs_compare2bench", dataProvider="cmbs_sanity_jobs_and_cusips",priority=6, description="compare job resutls to benchmark - annaul rattings >> confidence level")
	public void compare_cmbs_sanity_job_results_to_benchmark_Rattings_Confidence_Overall(String jobName, String cusip) throws Exception{
		
		if(job == null || !job.getJobSettings().getJobName().equals(jobName)){			
			if(job == null){
				job = new JobCmbs(initialNewDriver(), this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
				job.reFreshStatus();
				cmbsResult = job.getResult();
			
				String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
				jobBench = this.getBenchJob(initialNewDriver(), benchJobNameType);
				jobBench.reFreshStatus();
				cmbsResultBench = jobBench.getResult();
			} else{
				job = new JobCmbs(job.driver, this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
				job.reFreshStatus();
				cmbsResult = job.getResult();
			
				String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
				jobBench = this.getBenchJob(jobBench.driver, benchJobNameType);	
				jobBench.reFreshStatus();
				cmbsResultBench = jobBench.getResult();
			}

		} else {
			System.out.println("already in job result page, jobname: "+jobName+", benchName: "+ jobBench.getJobSettings().getJobName());
		}
		
		AnnualPDsELsMappingsCmbs annualPdElResults = cmbsResult.getAnnualPDsELsMappingInstance(job.driver);
				
		AnnualPDsELsMappingsCmbs annualPdElResultsBench = cmbsResultBench.getAnnualPDsELsMappingInstance(jobBench.driver);
				
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
	
		try{
			if(job.getJobStatus().getRunType().equalsIgnoreCase("simulation")){
				try{				
					for(String scen:scenariosList){
						annualPdElResults.selectToScenario(scen);
						annualPdElResults.selectToCusip(cusip);
						annualPdElResults.goToConfidenceSubtab();
						annualPdElResultsBench.selectToScenario(scen);
						annualPdElResultsBench.selectToCusip(cusip);
						annualPdElResultsBench.goToConfidenceSubtab();
						String confidenceOverallMappingContent = annualPdElResults.confidenceOverallRattingTable.getText();
						String confidenceOverallMappingContentBench = annualPdElResultsBench.confidenceOverallRattingTable.getText();
												
						Assert.assertEquals(confidenceOverallMappingContent, confidenceOverallMappingContentBench,
								"Verify the AnnualPdElsMapping >> confidence level overall ratting mapping is the same between test job and bench");
						}								
				} catch(Exception ex) {
					throw ex;
				} 
			}
			
		} catch (Exception ex){
			throw ex;
		} 
		
	}
	
	@Test(groups="job_submit_cmbs_compare2bench", dataProvider="cmbs_sanity_jobs_and_cusips",priority=6, description="compare job resutls to benchmark - annual ratting >> confidence level projected")
	public void compare_cmbs_sanity_job_results_to_benchmark_Rattings_Confidence_Projected(String jobName, String cusip) throws Exception{
		if(job == null || !job.getJobSettings().getJobName().equals(jobName)){			
			if(job == null){
				job = new JobCmbs(initialNewDriver(), this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
				job.reFreshStatus();
				cmbsResult = job.getResult();
			
				String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
				jobBench = this.getBenchJob(initialNewDriver(), benchJobNameType);
				jobBench.reFreshStatus();
				cmbsResultBench = jobBench.getResult();
			} else{
				job = new JobCmbs(job.driver, this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
				job.reFreshStatus();
				cmbsResult = job.getResult();
			
				String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
				jobBench = this.getBenchJob(jobBench.driver, benchJobNameType);	
				jobBench.reFreshStatus();
				cmbsResultBench = jobBench.getResult();
			}
		} else {
			System.out.println("already in job result page, jobname: "+jobName+", benchName: "+ jobBench.getJobSettings().getJobName());
		}
		
		AnnualPDsELsMappingsCmbs annualPdElResults = cmbsResult.getAnnualPDsELsMappingInstance(job.driver);
				
		AnnualPDsELsMappingsCmbs annualPdElResultsBench = cmbsResultBench.getAnnualPDsELsMappingInstance(jobBench.driver);
				
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
	
		try{
			if(job.getJobStatus().getRunType().equalsIgnoreCase("simulation")){
				try{				
					for(String scen:scenariosList){
						annualPdElResults.selectToScenario(scen);
						annualPdElResults.selectToCusip(cusip);
						annualPdElResults.goToConfidenceSubtab();
						annualPdElResultsBench.selectToScenario(scen);
						annualPdElResultsBench.selectToCusip(cusip);
						annualPdElResultsBench.goToConfidenceSubtab();
						String confidenceProjectedMappingContent = annualPdElResults.confidenceProjectedRattingMapTable.getText();
						String confidenceProjectedMappingContentContentBench = annualPdElResultsBench.confidenceProjectedRattingMapTable.getText();
											
						Assert.assertEquals(confidenceProjectedMappingContent, confidenceProjectedMappingContentContentBench,
							"Verify the AnnualPdElsMapping >> confidence level projected ratting mapping is the same between test job and bench");
					}							
				} catch(Exception ex) {
					throw ex;
				} 
			}
			
		} catch (Exception ex){
			throw ex;
		} 
	}
	
	
	@AfterTest
	public void dearDownCurrentTest(){
		quitDriver(job.driver);
		quitDriver(jobBench.driver);
		quitDriver(cmbsResult.jobCmbs.driver);
		quitDriver(cmbsResultBench.jobCmbs.driver);	
	}
	
}
