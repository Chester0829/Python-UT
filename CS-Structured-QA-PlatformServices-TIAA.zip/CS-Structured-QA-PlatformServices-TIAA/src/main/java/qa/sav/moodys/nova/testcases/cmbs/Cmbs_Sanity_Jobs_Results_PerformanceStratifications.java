package qa.sav.moodys.nova.testcases.cmbs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.pages.jobResult.JobResultCmbs;
import qa.sav.moodys.nova.pages.jobResult.PerformanceStratificationCmbs;

public class Cmbs_Sanity_Jobs_Results_PerformanceStratifications extends Cmbs_Sanity_Jobs_Base{
	
	@Test(groups="job_submit_cmbs_results", dataProvider="cmbs_sanity_jobs_and_cusips",priority=6, description="job results sanity check - performance stratifications")
	public void check_cmbs_sanity_job_results_PerformanceStratifications(String jobName, String cusip) throws Exception{
		JobCmbs job = new JobCmbs(initialNewDriver(), this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		PerformanceStratificationCmbs perforemanceStra = cmbsResult.getPerformanceStratificationInstance(job.driver);
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		perforemanceStra.selectToCusip(cusip);
		
		try{	
			for(String scen:scenariosList){
				perforemanceStra.selectToScenario(scen);
				Assert.assertTrue(perforemanceStra.scenarioText.getText().equals("Scenario:"), "Verify the scenario list title is showing");
				Assert.assertTrue(perforemanceStra.cusipText.getText().equals("CUSIP:"),"Verify the cusip list title is displaying");
				Assert.assertEquals(perforemanceStra.top10PropertyTypeTitle.getText(), "PROPERTY TYPE (TOP 10)");
				Assert.assertEquals(perforemanceStra.dscrStratificationTitle.getText(), "DSCR");
				Assert.assertEquals(perforemanceStra.ltvStratificationTitle.getText(), "LTV");
				Assert.assertEquals(perforemanceStra.top10StateTitle.getText(), "STATE (TOP 10)");
				Assert.assertEquals(perforemanceStra.loanSizeTitle.getText(), "LOAN SIZE");			
				
				String starTypeHeaders = Arrays.toString(perforemanceStra.propertyStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(perforemanceStra.top10PropertyTypeTable.findElement(By.xpath("thead/tr")).getText().equals(starTypeHeaders));				
				int straEntrySize = perforemanceStra.top10PropertyTypeTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(straEntrySize >= 2);
				//System.out.println(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("tbody")).getText().replace("\n", " "));
				Assert.assertEquals(perforemanceStra.top10PropertyTypeTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, straEntrySize*perforemanceStra.propertyStratificationFields.length);
				
				
				starTypeHeaders = Arrays.toString(perforemanceStra.dscrStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(perforemanceStra.dscrStratificationTable.findElement(By.xpath("thead/tr")).getText().equals(starTypeHeaders));				
				straEntrySize = perforemanceStra.dscrStratificationTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(straEntrySize >= 2);
				//System.out.println(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("tbody")).getText().replace("\n", " "));
				Assert.assertEquals(perforemanceStra.dscrStratificationTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, straEntrySize*perforemanceStra.dscrStratificationFields.length);
				
				starTypeHeaders = Arrays.toString(perforemanceStra.ltvStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(perforemanceStra.ltvStratificationTable.findElement(By.xpath("thead/tr")).getText().equals(starTypeHeaders));				
				straEntrySize = perforemanceStra.ltvStratificationTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(straEntrySize >= 2);
				//System.out.println(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("tbody")).getText().replace("\n", " "));
				Assert.assertEquals(perforemanceStra.ltvStratificationTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, straEntrySize*perforemanceStra.ltvStratificationFields.length);
				
				starTypeHeaders = Arrays.toString(perforemanceStra.stateStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(perforemanceStra.top10StateTable.findElement(By.xpath("thead/tr")).getText().equals(starTypeHeaders));				
				straEntrySize = perforemanceStra.top10StateTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(straEntrySize >= 2);
				//System.out.println(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("tbody")).getText().replace("\n", " "));
				Assert.assertEquals(perforemanceStra.top10StateTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, straEntrySize*perforemanceStra.stateStratificationFields.length);
				
				starTypeHeaders = Arrays.toString(perforemanceStra.loanSizeStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(perforemanceStra.loanSizeTable.findElement(By.xpath("thead/tr")).getText().equals(starTypeHeaders));				
				straEntrySize = perforemanceStra.loanSizeTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(straEntrySize >= 2);
				//System.out.println(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("tbody")).getText().replace("\n", " "));
				Assert.assertEquals(perforemanceStra.loanSizeTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, straEntrySize*perforemanceStra.loanSizeStratificationFields.length);				
			}
		} catch(Exception ex) {
			throw ex;
		} finally{		
				quitDriver(job.driver);
				quitDriver(cmbsResult.jobCmbs.driver);
		}
	}
}
