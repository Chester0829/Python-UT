package qa.sav.moodys.nova.testcases.cmbs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.pages.jobResult.AnnualPDsELsMappingsCmbs;
import qa.sav.moodys.nova.pages.jobResult.JobResultCmbs;

public class Cmbs_Sanity_Jobs_Results_AnnualPDsELsMappings extends Cmbs_Sanity_Jobs_Base{
	
	@Test(groups="job_submit_cmbs_results", dataProvider="cmbs_sanity_jobs_and_cusips",priority=6, description="job results sanity check - annualPdElsMapping")
	public void check_cmbs_sanity_job_results_AnnualPDsELsMappings(String jobName, String cusip) throws Exception{
		JobCmbs job = new JobCmbs(initialNewDriver(), this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		AnnualPDsELsMappingsCmbs annualPdElResults = cmbsResult.getAnnualPDsELsMappingInstance(job.driver);
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		if(job.getJobSettings().getRunType().equalsIgnoreCase("simulation")){
			try{				
				HashMap<String, String> confidenceSummaryValues = new HashMap<String, String>();
				//HashMap<String, String> averageOverallRattings = new HashMap<String, String>();
				HashMap<String, String> confidenceProjectedRattings[] = new HashMap[10];
				
				//annualPdElResults.selectToCusip(cusip);
				for(String scen:scenariosList){
					annualPdElResults.selectToScenario(scen);
					annualPdElResults.selectToCusip(cusip);
					annualPdElResults.goToConfidenceSubtab();
					
					confidenceSummaryValues.clear();
					confidenceSummaryValues.clear();
										
					Assert.assertTrue(annualPdElResults.scenarioText.getText().equals("Scenario:"), "Verify the scenario list title is showing");
					Assert.assertTrue(annualPdElResults.cusipText.getText().equals("CUSIP:"),"Verify the cusip list title is displaying");
					//System.out.println("Test title: "+annualPdElResults.confidenceOverallRattingTitleText.getText());
					Assert.assertTrue(annualPdElResults.confidenceOverallRattingTitleText.getText().equals("PROJECTED SUMMARY")
							, "Verify the average tab >> summmary title is \"PROJECTED SUMMARY\"");
								
					Assert.assertEquals(annualPdElResults.confidenceProjectedRattingMapTitleText.getText(), "YEARS"
							, "Verify the average tab >> projected ratting mapping title is \"YEARS\"");
					
					Assert.assertEquals(Arrays.toString(annualPdElResults.getConfidenceOverallRattingHeadersByScenarioAndCusip(scen, cusip))
							, Arrays.toString(annualPdElResults.confidenceOverallRattingFields));
					
					Assert.assertEquals(Arrays.toString(annualPdElResults.getConfidenceProjectedRattingMapHeadersByScenarioAndCusip(scen, cusip))
							, Arrays.toString(annualPdElResults.projectedRattingFields));
										
					confidenceSummaryValues = annualPdElResults.getConfidenceOverallRattingByScenarioAndCusip(scen, cusip);
					confidenceSummaryValues.values().removeIf(value->value.equals(""));
					Assert.assertEquals(confidenceSummaryValues.size(), annualPdElResults.confidenceOverallRattingFields.length);
					
					confidenceProjectedRattings = annualPdElResults.getConfidenceProjectedRattingMapByScenarioAndCusip(scen, cusip);
					int tempSize = 0;
					for(int i = 0; i < 10; i++){
						confidenceProjectedRattings[i].values().removeIf(value->value.equals(""));
						tempSize += confidenceProjectedRattings[i].size();
					}
					Assert.assertEquals(tempSize, annualPdElResults.projectedRattingFields.length*10);
				}		
					
			} catch(Exception ex) {
				throw ex;
			} finally{		
				
			}
		}
		try{
			annualPdElResults.selectToCusip(cusip);
			
			HashMap<String, String> averageSummaryValues = new HashMap<String, String>();
			HashMap<String, String> averageOverallRattings = new HashMap<String, String>();
			HashMap<String, String> averageProjectedRattings[] = new HashMap[10];
			
			annualPdElResults.selectToCusip(cusip);
			for(String scen:scenariosList){
				
				averageSummaryValues.clear();
				averageOverallRattings.clear();
				
				annualPdElResults.selectToScenario(scen);
				
				Assert.assertTrue(annualPdElResults.scenarioText.getText().equals("Scenario:"), "Verify the scenario list title is showing");
				Assert.assertTrue(annualPdElResults.cusipText.getText().equals("CUSIP:"),"Verify the cusip list title is displaying");
				//System.out.println(collCashflow.collateralCashflowTitleText.getText());
				Assert.assertTrue(annualPdElResults.averageSummaryTitleText.getText().equals("SUMMARY")
						, "Verify the average tab >> summmary title is \"SUMMARY\"");
				Assert.assertEquals(annualPdElResults.averageOverallRattingTitleText.getText(), "AVERAGE"
						, "Verify the average tab >> overall ratting title is \"AVERAGE\"");
				
				Assert.assertEquals(annualPdElResults.averageProjectedRattingMapTitleText.getText(), "YEARS"
						, "Verify the average tab >> projected ratting mapping title is \"YEARS\"");
				
				Assert.assertEquals(Arrays.toString(annualPdElResults.getAverageRattingMappingSummaryHeadersByScenarioAndCusip(scen, cusip))
						, Arrays.toString(annualPdElResults.averageSummaryFields));
				
				Assert.assertEquals(Arrays.toString(annualPdElResults.getAverageOverallRattingHeadersByScenarioAndCusip(scen, cusip))
						, Arrays.toString(annualPdElResults.averageOverallRattingFields));
				
				Assert.assertEquals(Arrays.toString(annualPdElResults.getAveragePorjectedRattingHeadersByScenarioAndCusip(scen, cusip))
						, Arrays.toString(annualPdElResults.projectedRattingFields));
				
				averageSummaryValues = annualPdElResults.getAverageRattingMapSummaryByScenarioAndCusip(scen, cusip);
				averageSummaryValues.values().removeIf((value)->value.equals(""));
				//Assert.assertEquals(averageSummaryValues.size(), annualPdElResults.averageSummaryFields.length);
				
				averageOverallRattings = annualPdElResults.getAverageOverallRattingByScenarioAndCusip(scen, cusip);
				averageOverallRattings.values().removeIf(value->value.equals(""));
				Assert.assertEquals(averageOverallRattings.size(), annualPdElResults.averageOverallRattingFields.length);
				
				averageProjectedRattings = annualPdElResults.getAverageProjectedRattingMapByScenarioAndCusip(scen, cusip);
				int tempSize = 0;
				for(int i = 0; i < 10; i++){
					averageProjectedRattings[i].values().removeIf(value->value.equals(""));
					tempSize += averageProjectedRattings[i].size();
				}
				Assert.assertEquals(tempSize, annualPdElResults.projectedRattingFields.length*10);
			}		
				
		} catch(Exception ex) {
			throw ex;
		} finally{		
			quitDriver(job.driver);
			quitDriver(cmbsResult.jobCmbs.driver);
		}
			
	}
}
