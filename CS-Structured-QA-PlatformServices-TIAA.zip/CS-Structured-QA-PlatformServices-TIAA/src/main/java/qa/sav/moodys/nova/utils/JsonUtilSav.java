package qa.sav.moodys.nova.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;

import org.testng.annotations.Test;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class JsonUtilSav {

    public static boolean compareJson(JsonObject json1, JsonObject json2) {
    	
    	if(json1.equals(json2)){    		
    		return true;
	    } else {
	    	if(json1.keySet().containsAll(json2.keySet())&&json2.keySet().containsAll(json1.keySet())){
	    		
	    	} else {
	    		    		
	    		return false;
	    	}
	    	
	        Iterator<String> i = json1.keySet().iterator();
	        
	        String key;
	        while (i.hasNext()) {       	
	            key = i.next();
	            
	            if(!compareJson(json1.get(key), json2.get(key), key)){ 
	            	return false;
	            };
	            
	        }
	       
	        return true;
	    }
		
    }
 
   
    private static boolean compareJson(Object json1, Object json2, String key) {

    	if(json1.equals(json2)){
    		
    		return true;
    	}
        if (json1 instanceof JsonObject) {
        	if(json2 instanceof JsonObject){
        		return compareJson((JsonObject) json1, (JsonObject) json2);
            } else {
            	return false;
            }
        } else if (json1 instanceof JsonArray) {
        	if(json2 instanceof JsonArray){
        		return compareJson((JsonArray) json1, (JsonArray) json2, key);
        	} else {
        		return false;
        	}
        } else if (json1 instanceof String) {
        	if(json2 instanceof String) {        	
	            try {
	                String json1ToStr = json1.toString();
	                String json2ToStr = json2.toString();
	                return compareJson(json1ToStr, json2ToStr, key);
	            } catch (Exception e) {
	                
	                e.printStackTrace();
	            }
        	} else {
        		return false;
        	}
        } else {
            return compareJson(json1.toString(), json2.toString(), key);
        }
		return true;
    }
 
    private static boolean compareJson(String str1, String str2, String key) {
    	
    	if(str1.equals(str2)){    		
    		return true;
    		
    	} else if(StringUtils.isSavCalculated(str1.replaceAll("(\\\")(.*?)(\\\")", "$2"))){
    		str1 = str1.replaceAll("(\\\")(.*?)(\\\")", "$2");
    		str2 = str2.replaceAll("(\\\")(.*?)(\\\")", "$2");
    		
    		if(!StringUtils.isSavCalculated(str2)){    			
    			return false;
    		} else {
    			if(Double.parseDouble(str1)*Double.parseDouble(str2) < 0){
    				
    				return false;
    			}
    			if(Double.parseDouble(str1)==0 || Double.parseDouble(str2) ==0 ){
    				if(Math.abs(Double.parseDouble(str1)-Double.parseDouble(str2)) > 0.0001){
    					
    					return false;
    				} else {
    					return true;
    				}
    			} else {
    				Double d = Math.abs(Double.parseDouble(str1)-Double.parseDouble(str2))/
        					Math.min(Math.abs(Double.parseDouble(str2)), Math.abs(Double.parseDouble(str1)));
    				if( d > 0.000001 ){
    					
    					return false;
	    			} else {
	    				
	    				return true;
	    			}
    			}
    		}
    	} else {
    		
    		return false;
    	}
    }
 
	private static boolean compareJson(JsonArray json1, JsonArray json2, String key) {
    	
    	if(json1.size()!= json2.size()){
    		return false;
    	
    	} else {
    	
	        if (json1 != null && json2 != null) {
	            Iterator<JsonElement> i1 = json1.iterator();
	            Iterator<JsonElement> i2 = json2.iterator();
	            
	            while (i1.hasNext()) {
	            	JsonElement jsonElement1 = i1.next();
	            	JsonElement jsonElement2 = null;
	            	int j = 1;
	            	i2 = json2.iterator();
	            	
	            	while(i2.hasNext()){
	            		jsonElement2 = i2.next();
	            		if(compareJson(jsonElement1,jsonElement2,  key)){
	            			System.out.println("jsonElement1 exsit in jsonArray2 "+jsonElement1.toString() );
	                 	   	break;
	                    } else {
	                    	j++;
	                    };
	            	}
	            	
	            	if(j > json2.size()){           		
	            		System.out.println("jsonElement1 do not exsit in jsonArray2 "+jsonElement1.toString());
	            		return false;
	            	} else {
	            		json2.remove(jsonElement2);
	            	}
	            }
	            return true;
	        } else {
	            
				return false;
	        }
    	}		
    }	

	@Test
	public void testtest(){
	JsonParser parser = new JsonParser();
	JsonParser parser2 = new JsonParser();
    try {     
         Object obj = parser.parse(new FileReader("C:\\Users\\qins\\Downloads\\collateralCashflows.json"));

         JsonObject jsonObject =  (JsonObject) obj;
       //  System.out.println(jsonObject);
 		
         Object obj2 = parser.parse(new FileReader("C:\\Users\\qins\\Downloads\\citiSchema.json"));

         JsonObject jsonObject2 =  (JsonObject) obj2;
         
         Object obj3 = parser2.parse(new FileReader("C:\\Users\\qins\\Downloads\\collateralCashflows_3.json"));

         JsonObject jsonObject3 =  (JsonObject) obj3;
       //  System.out.println(jsonObject3);
         
         System.out.println(compareJson(jsonObject, jsonObject3));
        // System.out.println(compareJson(jsonObject2, jsonObject3));
        
        // System.out.println(parser.parse(jsonObject.get("collateralCashflows").toString()).getAsJsonObject().keySet());
       
    } catch (FileNotFoundException ex) {
         ex.printStackTrace();
     } catch (IOException ex1) {
         ex1.printStackTrace();
     } finally {
    	 //
     }
 
	}
		
}
