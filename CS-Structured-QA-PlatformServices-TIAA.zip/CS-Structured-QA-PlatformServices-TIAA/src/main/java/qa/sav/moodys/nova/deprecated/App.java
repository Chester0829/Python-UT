package qa.sav.moodys.nova.deprecated;

import java.util.ArrayList;
import java.util.List;

import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        XmlSuite suite = new XmlSuite();
        suite.setName("TmpSuite");
         
        XmlTest test = new XmlTest(suite);
        test.setName("TmpTest");
        List<XmlClass> classes = new ArrayList<XmlClass>();
        classes.add(new XmlClass("test.failures.Child"));
        test.setXmlClasses(classes) ;
    }
}
