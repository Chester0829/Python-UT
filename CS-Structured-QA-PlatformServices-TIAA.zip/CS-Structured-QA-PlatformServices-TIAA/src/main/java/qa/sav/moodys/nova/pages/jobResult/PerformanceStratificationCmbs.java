package qa.sav.moodys.nova.pages.jobResult;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import qa.sav.moodys.nova.JobCmbs;

public class PerformanceStratificationCmbs extends JobResultTabCmbs{
	
	public PerformanceStratificationCmbs(WebDriver driver, JobCmbs job)
			throws Exception {		
		super(driver, job);
		// TODO Auto-generated constructor stub
		this.goToPerformanceStratificationTab();
	}
	
	public String propertyStratificationFields[] = {
		"Property Type", "Percentage of total(%)", "PD(%)", "LGD(%)", "EL(%)", "TRC(%)"	
	};
	
	public String dscrStratificationFields[] = {
		"DSCR", "Percentage of total(%)", "PD(%)", "LGD(%)", "EL(%)", "TRC(%)"
	};
	
	public String ltvStratificationFields[] = {
		"LTV", "Percentage of total(%)", "PD(%)", "LGD(%)", "EL(%)", "TRC(%)"	
	}; 
	
	public String stateStratificationFields[] = {
		"State(Top 10)", "Percentage of total(%)", "PD(%)", "LGD(%)", "EL(%)", "TRC(%)"		
	};
	
	public String loanSizeStratificationFields[] = {
		"Loan Size", "Percentage of total(%)", "PD(%)", "LGD(%)", "EL(%)", "TRC(%)"		
	};
	
	
	@FindBy(xpath = "//*[@id=\"performance_scenario\"]") //*[@id="pd_el_scenario"] //*[@id="loanStratiScenario"]
	public WebElement choseScenaio;

	@FindBy(xpath = "//*[@id=\"performance_cusip\"]") //*[@id="pd_el_cusip"]
	public WebElement choseCusip;
	
	@FindBy(xpath = "//*[@id=\"performanceStratification\"]/form/span[1]") //*[@id="loanLevelStratification"]/form/span[1]
	public WebElement scenarioText; 
	
	@FindBy(id = "select2-chosen-15")
	public WebElement clickChoseScenario;
	
	@FindBy(xpath = "//*[@id=\"performanceStratification\"]/form/span[2]") //*[@id="pd_el_mapping"]/div/div/form/span[2]
	public WebElement cusipText;
	
	@FindBy(id = "select2-chosen-16")
	public WebElement clickChoseCusip;	
	
	@FindBy(xpath = "//*[@id=\"performanceStratificationContent\"]/div[1]/div[1]") //*[@id="performanceStratificationContent"]/div[1]/div[1]
	public WebElement top10PropertyTypeTitle;
	
	@FindBy(xpath = "//*[@id=\"performanceStratificationContent\"]/div[1]/div[2]/table") //*[@id="performanceStratificationContent"]/div[1]/div[2]/table
	public WebElement top10PropertyTypeTable;
	
	@FindBy(xpath = "//*[@id=\"performanceStratificationContent\"]/div[2]/div[1]")
	public WebElement dscrStratificationTitle;
	
	@FindBy(xpath = "//*[@id=\"performanceStratificationContent\"]/div[2]/div[2]/table")
	public WebElement dscrStratificationTable;
	
	@FindBy(xpath = "//*[@id=\"performanceStratificationContent\"]/div[3]/div[1]")
	public WebElement ltvStratificationTitle;
	
	@FindBy(xpath = "//*[@id=\"performanceStratificationContent\"]/div[3]/div[2]/table")
	public WebElement ltvStratificationTable;
	
	@FindBy(xpath = "//*[@id=\"performanceStratificationContent\"]/div[4]/div[1]")
	public WebElement top10StateTitle;
	
	@FindBy(xpath = "//*[@id=\"performanceStratificationContent\"]/div[4]/div[2]/table")
	public WebElement top10StateTable;
	
	@FindBy(xpath = "//*[@id=\"performanceStratificationContent\"]/div[5]/div[1]")
	public WebElement loanSizeTitle;
	
	@FindBy(xpath = "//*[@id=\"performanceStratificationContent\"]/div[5]/div[2]/table")
	public WebElement loanSizeTable;
	
	
	public String[] getScenariosList(){	
		return this.getScenariosList(choseScenaio);
	}
	
	public String[] getCusipsList(){
		return this.getCusipsList(choseCusip);
	}
	
	public void selectScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectToScenario(scenario);
		this.selectToCusip(cusip);
	}

	public void selectToScenario(String scenario) throws Exception{
		
		if(clickChoseScenario.getText().equals(scenario)){
			//scenario alread selected, do nothing
		} else {
			clickChoseScenario.click();
			this.waitForAjaxLoaded();
			Select choseScenarioSelector = new Select(choseScenaio);
			choseScenarioSelector.selectByVisibleText(scenario);
			this.waitForAjaxLoaded();
		}
	}
	
	public void selectToCusip(String cusip) throws Exception{
		
		if(clickChoseCusip.getText().equals(cusip)){
			// cusip alread selected, do nothing
		} else {
			clickChoseCusip.click();
			this.waitForAjaxLoaded();
			Select choseCusipSelector = new Select(choseCusip);
			choseCusipSelector.selectByVisibleText(cusip);
			this.waitForAjaxLoaded();
		}
	}

	
	
}
