package qa.sav.moodys.nova.testcases.cmbs;

import java.util.ArrayList;
import java.util.Set;

import org.testng.Assert;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.pages.jobResult.BondCashflowsCmbs;
import qa.sav.moodys.nova.pages.jobResult.CollateralCashflowsCmbs;
import qa.sav.moodys.nova.pages.jobResult.JobResultCmbs;
import qa.sav.moodys.nova.pages.jobResult.OverviewCmbs;

public class Cmbs_Sanity_Jobs_Results_CompareBench_BondCashflow extends Cmbs_Sanity_Jobs_Base{

	@Test(groups="job_submit_cmbs_compare2bench", dataProvider="cmbs_sanity_jobs_and_cusips",priority=6, description="compare job resutls to benchmark - bond cashflow")
	public void compare_cmbs_sanity_job_results_to_benchmark_Overview(String jobName, String cusip) throws Exception{
		
		JobCmbs job = new JobCmbs(initialNewDriver(), this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));		
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		BondCashflowsCmbs bondCashflow = cmbsResult.getBondCashflowsInstance(job.driver);
		
		String benchJobNameType = jobName.replaceAll("_[0-9]{17}", "");
		JobCmbs jobBench = this.getBenchJob(initialNewDriver(), benchJobNameType);

		JobResultCmbs cmbsResultBench = jobBench.getResult();
		BondCashflowsCmbs bondCashflowBench = cmbsResultBench.getBondCashflowsInstance(jobBench.driver);
				
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		
		try{
			bondCashflow.selectToCusip(cusip);
			for(String scen:scenariosList){
				bondCashflow.selectToScenario(scen);
				bondCashflowBench.selectToCusip(cusip);
				bondCashflowBench.selectToScenario(scen);
				
				String cashflowsContent = bondCashflow.cashflowTableBody.getText();
				String cashflowsContentBench = bondCashflow.cashflowTableBody.getText();
				Assert.assertEquals(cashflowsContent, cashflowsContentBench, 
						"Verify bond cashflow table content is the same between test and bench job");	
			}
			
		} catch (Exception ex){
			throw ex;
		} finally {
			quitDriver(job.driver);
			quitDriver(jobBench.driver);
			quitDriver(cmbsResult.jobCmbs.driver);
			quitDriver(cmbsResultBench.jobCmbs.driver);
		}
	}
	
}
