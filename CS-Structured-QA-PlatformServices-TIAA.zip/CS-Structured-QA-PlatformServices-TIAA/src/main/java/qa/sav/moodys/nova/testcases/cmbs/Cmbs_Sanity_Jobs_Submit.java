package qa.sav.moodys.nova.testcases.cmbs;

import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;

import qa.sav.moodys.nova.JobCmbs;

public class Cmbs_Sanity_Jobs_Submit extends Cmbs_Sanity_Jobs_Base {
		
	int jobsCount = 0;
	ArrayList<String> testedJobsName;
	HashMap<String, JobCmbs> testedJobs;
	JsonObject submittedJobsTmp = new JsonObject();
	JsonObject submittedJobs = new JsonObject();
	
	@BeforeTest
	public void clearEnvironment() throws Exception{
		testedJobsName = new ArrayList<String>();
		testedJobs = new HashMap<String,JobCmbs>();			
	}
	
	@BeforeMethod
	public void checkRecordJobs(){
		try{
			submittedJobs = (JsonObject) new JsonParser().parse(
				new JsonReader(new FileReader(job_records_path)));
		} catch (Exception ex){
			//
		}
	}
	
	@AfterMethod
	public void writeToFile(){
		
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		
		try {
			FileWriter fileWriter,fileWriter2;
			fileWriter = new FileWriter(job_records_path);
			gson.toJson(submittedJobs, fileWriter);
			fileWriter.close();
			
			fileWriter2 = new FileWriter(job_records_path_tmp);
			gson.toJson(submittedJobsTmp, fileWriter2);
			fileWriter2.close();
		} catch (Exception e) {
			System.out.println("json error");
			
			e.printStackTrace();
		}
	}
		
	@Test(groups="job_submit_cmbs",dataProvider="cmbs_sanity_jobs",priority=1, description="submit a set of cmbs sanity jobs, all the jobs should be submited successfully")
	public void submit_cmbs_sanity_job(JobCmbs jobCmbs,String jobName) throws Exception{			
		JobCmbs job = new JobCmbs(driver, jobCmbs.getJobSettings());
		String newJobName = jobName+"_"+new SimpleDateFormat("YYYYMMddHHmmssSSS").format(Calendar.getInstance().getTime());
		job.jobSettings.setJobName(newJobName); 		
		job = job.run(false);
		job.reFreshStatus();
		JsonElement element = new Gson().toJsonTree(job.jobSettings);
		submittedJobsTmp.add(newJobName, element);
		testedJobsName.add(newJobName);
		testedJobs.put(newJobName, job);
	}
		
	//@Test(groups="job_submit_cmbs_status", dependsOnGroups = "job_submit_cmbs", dataProvider="cmbs_sanity_jobs_submitted",threadPoolSize = 3, priority=3, 
	//description="Wait for job completed and check failed numbers: compared to benchmark")
	public void wait_for_job_to_be_completed(String jobName) throws Exception{
		WebDriver newDriver = initialNewDriver();
		JobCmbs job = new JobCmbs(newDriver, this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));
		job.waitForJobCompleted();
		job.reFreshStatus();
		testedJobs.get(jobName).setJobStatus(job.jobStatus);
		Assert.assertEquals(job.getJobStatus().getRunStatus(), "finish");

		int scenariosCount = job.getJobSettings().getScenarios().size();
		int cusipCount = job.getJobSettings().getCusipsList().size();

		try	{
			
			Assert.assertEquals(scenariosCount*cusipCount,(int)job.getJobStatus().getTotalTasks(),
					"Expected total task number to be ["+scenariosCount*cusipCount+"] "
							+ "but found ["+(int)job.getJobStatus().getTotalTasks()+"]");
			Assert.assertEquals(scenariosCount*cusipCount,(int)job.getJobStatus().getProgress(),
					"Expected total progressed tasks number to be ["+scenariosCount*cusipCount+"] but found ["+(int)job.getJobStatus().getProgress()+"]");
			Assert.assertEquals(job.getJobStatus().getJobResultStatus(), "success", 
					"Expected job result status to be [success] but found "+job.getJobStatus().getJobResultStatus());
			Assert.assertEquals((int)job.getJobStatus().getFailNum(), 0, 
					"Expected 0 failnums but found "+job.getJobStatus().getFailNum());		
			//quitDriver(job.driver);
		} catch (Exception ex){
			
		} finally{
			submittedJobs.remove(jobName.replace("_"+jobName.split("_")[jobName.split("_").length-1], ""));
			submittedJobs.add(jobName.replace("_"+jobName.split("_")[jobName.split("_").length-1], ""), new Gson().toJsonTree(job.jobSettings));
			quitDriver(job.driver);
		}
	}
	
		
}
