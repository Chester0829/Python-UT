package qa.sav.moodys.nova.deprecated;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import qa.sav.moodys.nova.pages.HomePage;
import qa.sav.moodys.nova.pages.launch.Launch;

public class LaunchRmbsOrg extends Launch {
	
	String launchRmbsPagePath = "sf-simulation/launch?businessType=RMBS";
	
	final static String horizonYearXpath = "//*[@id=\"years-select\"]";
	@FindBy(xpath = horizonYearXpath)
	public WebElement horizon;
	
	final static String horizonMonXpath = "//*[@id=\"months-select\"]";		
	@FindBy(xpath = horizonMonXpath)
	public WebElement horizonMonth;
	
	final static String useTargetLgdXpath = "//*[@id=\"useTargetLGD\"]";
	@FindBy(xpath = useTargetLgdXpath)
	public WebElement useTargetLgd;
	
	final static String useSystemBookPriceXpath = "//*[@id=\"useSystemBookPrice\"]";
	@FindBy(xpath = useSystemBookPriceXpath)
	public WebElement useSystemBookPrice;
	
	final static String globalValueDashboradXpath = "//a[@href='/sf-simulation/dialog?modalType=globalValues&businessType=RMBS\']";
	@FindBy(xpath = globalValueDashboradXpath)
	public WebElement globalValue;	
	
	@FindBy(id="modal-global-values")
	WebElement globalValuePopUp;
	
	public LaunchRmbsOrg(WebDriver driver) throws Exception {
		super(driver);
		
		if(driver.getCurrentUrl().contains(launchRmbsPagePath)){
			//do nothing
		} else {
			try {
				new HomePage(driver).launchToModel(RMBS);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.error("Not able to go to Rmbs Launch page");
				e.printStackTrace();
				throw e;
			}
		}
		// TODO Auto-generated constructor stub
	}	

	public void setHorizon(String horizon) throws Exception{
		String year = horizon.split("-")[0];
		String month = horizon.split("-")[1];
		Select dropdownList = new Select(driver.findElement(By.xpath(horizonYearXpath)));
		dropdownList.selectByValue(year);
		waitForAjaxLoaded();
		dropdownList = new Select(driver.findElement(By.xpath(horizonMonXpath)));
		dropdownList.selectByValue(month);
		waitForAjaxLoaded();		
	}
	
	public String getHorizonValues(){
		String year = getHorizonYears();
		String month = getHorizonMonths();
		return year + "-" + month;		
	}

	
	public void setUseTargetLgd(boolean useTargetLgd) {
		if(useTargetLgd){
			if(driver.findElement(By.xpath(useTargetLgdXpath)).isSelected()){
				// use target lgd already set to true, do nothing
			} else {
				
				driver.findElement(By.xpath(useTargetLgdXpath)).click();
			}
		} else{
			if(driver.findElement(By.xpath(useTargetLgdXpath)).isSelected()){
				
				driver.findElement(By.xpath(useTargetLgdXpath)).click();
			} else {
				// use target Lgd has already set to false, do nothing
			}
		}	
		
	}
	

	public void setUseSystemBookPrice(boolean useBookPrice) {

		if(useBookPrice){
			if(driver.findElement(By.xpath(useSystemBookPriceXpath)).isSelected()){
				// use target lgd already set to true, do nothing
			} else {
				driver.findElement(By.xpath(useSystemBookPriceXpath)).click();
			}
		} else{
			if(driver.findElement(By.xpath(useSystemBookPriceXpath)).isSelected()){
				driver.findElement(By.xpath(useSystemBookPriceXpath)).click();
			} else {
				// use target Lgd has already set to false, do nothing
			}
		}	
		
	
		
	}

			
	public boolean isUseTargetLgd() {
		return (driver.findElement(By.xpath(useTargetLgdXpath)).isSelected());
	}

	public boolean isUseSystemBookPrice() {
		// TODO Auto-generated method stub
		return (driver.findElement(By.xpath(useSystemBookPriceXpath)).isSelected());
	}
	
	public void openGlobalValueDashboard() throws InterruptedException{
		driver.findElement(By.xpath(globalValueDashboradXpath)).click();
		waitForAjaxLoaded();
	}
	
	private String getHorizonYears(){
		return new Select(driver.findElement(By.xpath(horizonYearXpath))).getFirstSelectedOption().getText();
	}
	
	private String getHorizonMonths(){
		return new Select(driver.findElement(By.xpath(horizonMonXpath))).getFirstSelectedOption().getText();
	}


	
	
	
}
