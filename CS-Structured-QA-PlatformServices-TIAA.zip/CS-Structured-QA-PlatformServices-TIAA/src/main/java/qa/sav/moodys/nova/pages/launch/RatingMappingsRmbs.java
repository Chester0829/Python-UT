package qa.sav.moodys.nova.pages.launch;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RatingMappingsRmbs extends RatingMappingsBase{

	@FindBy(xpath = "//*[@id=\"modal-rating-mappings\"]")
	WebElement ratingMapPopUP;
	
	public RatingMappingsRmbs(WebDriver driver) throws Exception {
		super(driver);
		// TODO Auto-generated constructor stub
		
		try{
			if(ratingMapPopUP.isDisplayed()){
				//do nothing
			} else {
				new LaunchRmbs(driver).openRatingMapDashboard();;
			}
		}catch(Exception e){
			new LaunchRmbs(driver).openRatingMapDashboard();
		}
	}
}
