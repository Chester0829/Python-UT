package qa.sav.moodys.nova.pages.launch;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class EconomicScenarioCmbs extends EconomicScenarioBase{
	
	@FindBy(id="modal-economic-scenario")
	WebElement econScenPopUp;
	
	@FindBy(xpath = "//*[@id=\"modal-economic-scenario\"]/div/div/div[3]/button[4]")
	public WebElement elementApplyChangeButton;
	
	@Override
	public String applyCurrentChanges() throws Exception{
		this.elementApplyChangeButton.click();
		this.waitForAjaxLoaded();
		Thread.sleep(1000);
		return this.readAlertMessage();
	}

	public EconomicScenarioCmbs(WebDriver driver) throws Exception {
		super(driver);
		// TODO Auto-generated constructor stub
		try{
			if(econScenPopUp.isDisplayed()){
				//do nothing
			} else {
				new LaunchCmbs(driver).openEconScenDashboard();
			}
		}catch(Exception e){
			new LaunchCmbs(driver).openEconScenDashboard();
		}
	}

}
