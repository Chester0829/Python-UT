package qa.sav.moodys.nova.s3;


public class Wrapper  {

	public static  Bucket wrapBucket(com.amazonaws.services.s3.model.Bucket object) {
		Bucket result = new Bucket();
		result.setCreationDate(object.getCreationDate());
		result.setName(object.getName());
		result.setOwner(object.getOwner().getId());
		return result;
	}
	
	public static StoreObjectSummary wrapStoreObjectSummary(com.amazonaws.services.s3.model.S3ObjectSummary object) {
		StoreObjectSummary result = new StoreObjectSummary();
		result.setBucketName(object.getBucketName());
		result.setETag(object.getETag());
		result.setKey(object.getKey());
		result.setLastModified(object.getLastModified());
		if(object.getOwner()!=null){
			result.setOwner(object.getOwner().getId());
		}
		result.setSize(object.getSize());
		return result;
	}
	
	public static  StoreObject wrapStoreObject(com.amazonaws.services.s3.model.S3Object object) {
		if(object==null)
			return  null;
		StoreObject result = new StoreObject();
		result.setBucketName(object.getBucketName());
		result.setKey(object.getKey());
		result.setObjectContent(object.getObjectContent());
		result.setObjectMetadata(wrapObjectMetadata(object.getObjectMetadata()));
		return result;
	}
	public static ObjectMetadata wrapObjectMetadata(com.amazonaws.services.s3.model.ObjectMetadata object) {
		ObjectMetadata metadata = new ObjectMetadata();
		metadata.setUserMetadata(object.getUserMetadata());
		metadata.setContentType(object.getContentType());
		metadata.setCacheControl(object.getCacheControl());
		metadata.setContentDisposition(object.getContentDisposition());
		metadata.setContentEncoding(object.getContentEncoding());
		metadata.setContentLength(object.getContentLength());
		metadata.setContentMD5(object.getContentMD5());
		metadata.setLastModified(object.getLastModified());
		metadata.setServerSideEncryption(object.getServerSideEncryption());
		return metadata;
	}
	public static qa.sav.moodys.nova.s3.Instance wrapInstance(com.amazonaws.services.ec2.model.Instance ec2Instance) {
		qa.sav.moodys.nova.s3.Instance result = new Instance();
		result.setImageId(ec2Instance.getImageId());
		result.setInstanceId(ec2Instance.getInstanceId());
		result.setInstanceType(ec2Instance.getInstanceType());
		result.setKernelId(ec2Instance.getKernelId());
		result.setKeyName(ec2Instance.getKeyName());
		result.setLaunchTime(ec2Instance.getLaunchTime());
		result.setPlatform(ec2Instance.getPlatform());
		result.setPrivateDnsName(ec2Instance.getPrivateDnsName());
		result.setPublicDnsName(ec2Instance.getPublicDnsName());
		result.setPublicIpAddress(ec2Instance.getPublicIpAddress());
		result.setPrivateIpAddress(ec2Instance.getPrivateIpAddress());
		if(ec2Instance.getState()!=null){
			result.setState(ec2Instance.getState().getName());
		}
		result.setSourceDestCheck(ec2Instance.getSourceDestCheck());
		return result;
	}
	
	public  static Image wrapImage(com.amazonaws.services.ec2.model.Image image){
		Image result=new Image();
		result.setDescription(image.getDescription());
		result.setImageId(image.getImageId());
		result.setName(image.getName());
		result.setPlatform(image.getPlatform());
		result.setState(image.getState());
		result.setVirtualizationType(image.getVirtualizationType());
		return result;
	}

}
