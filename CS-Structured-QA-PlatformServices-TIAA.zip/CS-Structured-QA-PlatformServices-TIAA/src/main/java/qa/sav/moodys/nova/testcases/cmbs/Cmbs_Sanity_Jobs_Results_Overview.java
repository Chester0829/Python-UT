package qa.sav.moodys.nova.testcases.cmbs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.pages.jobResult.JobResultCmbs;
import qa.sav.moodys.nova.pages.jobResult.OverviewCmbs;
import qa.sav.moodys.nova.testLogic.TestAsserts;

public class Cmbs_Sanity_Jobs_Results_Overview extends Cmbs_Sanity_Jobs_Base{
	
	@Test(groups="job_submit_cmbs_results", dataProvider="cmbs_sanity_jobs_and_cusips",threadPoolSize = 3,priority=6, description="job results sanity check - overview")
	public void check_cmbs_sanity_job_results_overview(String jobName, String cusip) throws Exception{
		WebDriver newDriver = initialNewDriver();
		JobCmbs job = new JobCmbs(newDriver, this.readJobSettingsFromJsonFile(this.job_records_path_tmp, jobName));
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		OverviewCmbs overview = cmbsResult.getOverviewInstance(job.driver);
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		
		try{
			overview.selectToCusip(cusip);
			Assert.assertTrue(overview.scenarioText.getText().equals("Scenario:"), "Verify the scenario list title is showing");
			Assert.assertTrue(overview.cusipText.getText().equals("CUSIP:"),"Verify the cusip list title is displaying");
			Assert.assertTrue(overview.profileTitle.getText().equals("PROFILE")
					,"Verify the profile title is displaying as \"PROFILE\"");
			Assert.assertTrue(overview.summaryTitle.getText().equals("SUMMARY")
					,"Verify the profile title is displaying as \"SUMMARY\"");			
			Assert.assertTrue(TestAsserts.compareLists(scenariosList, overview.getScenariosList())
					, "Verify all the scenarios in config file are listed in scen dropdown list");			
			HashMap<String, String> profileValues = new HashMap<String, String>();
			HashMap<String, String> summaryValues = new HashMap<String, String>();
			for(String scen:scenariosList){
				profileValues.clear();
				summaryValues.clear();
				overview.selectToScenario(scen);
				
				for(int i = 0; i < overview.profileKeys.length; i ++){
					overview.profileTable.getText();
					Assert.assertEquals(overview.profileTable.findElement(By.xpath("tr["+(i+1)+"]/td[1]")).getText()
							, overview.profileKeys[i], "Verify profile table: the "+(i+1)+"field is "+overview.profileKeys[i]+ " but found "
					+ overview.profileTable.findElement(By.xpath("tr["+(i+1)+"]/td[1]")));
				}
				
				for(int i = 0; i < overview.summaryKeys.length; i ++){
					Assert.assertEquals(overview.summaryTable.findElement(By.xpath("tr["+(i+1)+"]/td[1]")).getText()
							, overview.summaryKeys[i], "Verify summary table: the "+(i+1)+"field is "+overview.profileKeys[i]+ " but found "
					+overview.summaryTable.findElement(By.xpath("tr["+(i+1)+"]/td[1]")));				
				}
				
				profileValues = overview.readProfileByScenAndCusip(scen, cusip);
				summaryValues = overview.readSummaryByScenAndCusip(scen, cusip);
				//System.out.println("expected profile fields count: "+profileValues.size());
				profileValues.values().removeIf(value->value.equals(""));
				
				Assert.assertTrue(profileValues.size() > 13 && profileValues.size() <= overview.profileKeys.length
						, "Verify not-blank profile fields count is larger than 13 --- "+profileValues.size());
							
				summaryValues.values().removeIf(value->value.equals(""));
				
				Assert.assertTrue(summaryValues.size() > 2 && profileValues.size() <= overview.profileKeys.length
						, "Verify not-blank profile fields count is larger than 2 --- "+summaryValues.size());
				
			}	
		} catch(Exception ex) {
			throw ex;
		} finally{		
			quitDriver(job.driver);
			quitDriver(cmbsResult.jobCmbs.driver);
		}
	}
}
