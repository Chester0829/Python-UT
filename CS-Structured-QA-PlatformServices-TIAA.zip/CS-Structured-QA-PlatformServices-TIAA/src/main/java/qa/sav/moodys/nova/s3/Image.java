/**
 * Filename:	Image.java
 * Description: 
 * Copyright:   Copyright (c)2013
 * Company:     Moody's Analytics
 * @author:     Changqing.Yang
 * @version:    1.0
 * Create at:   Jul 11, 2013 5:07:49 PM
 *
 * Modification History:
 * Date			Author		Version		Description
 * ------------------------------------------------------------------
 * Jul 11, 2013   Changqing.Yang		1.0	    1.0 Version
 */
package qa.sav.moodys.nova.s3;

import java.io.Serializable;

/**
 * @ClassName: Image
 * @Description: TODO
 * @author Changqing.Yang
 * @date Jul 11, 2013 5:07:49 PM
 * 
 */
public class Image  implements Serializable  {

	private static final long serialVersionUID = -3992133435675391669L;

	/**
     * The unique ID of the AMI.
     */
    private String imageId;

    /**
     * Current state of the AMI. If the operation returns available, the
     * image is successfully registered and available for launching. If the
     * operation returns deregistered, the image is deregistered and no
     * longer available for launching.
     * <p>
     * <b>Constraints:</b><br/>
     * <b>Allowed Values: </b>available, deregistered
     */
    private String state;

    /**
     * The operating platform of the AMI.
     */
    private String platform;

    /**
     * The name of the AMI that was provided during image creation.
     */
    private String name;

    /**
     * The description of the AMI that was provided during image creation.
     */
    private String description;

    private String virtualizationType;


    /**
     * The unique ID of the AMI.
     *
     * @return The unique ID of the AMI.
     */
    public String getImageId() {
        return imageId;
    }
    
    /**
     * The unique ID of the AMI.
     *
     * @param imageId The unique ID of the AMI.
     */
    public void setImageId(String imageId) {
        this.imageId = imageId;
    }
    
    /**
     * The unique ID of the AMI.
     * <p>
     * Returns a reference to this object so that method calls can be chained together.
     *
     * @param imageId The unique ID of the AMI.
     *
     * @return A reference to this updated object so that method calls can be chained 
     *         together. 
     */
    public Image withImageId(String imageId) {
        this.imageId = imageId;
        return this;
    }
    
    
    /**
     * Current state of the AMI. If the operation returns available, the
     * image is successfully registered and available for launching. If the
     * operation returns deregistered, the image is deregistered and no
     * longer available for launching.
     * <p>
     * <b>Constraints:</b><br/>
     * <b>Allowed Values: </b>available, deregistered
     *
     * @return Current state of the AMI. If the operation returns available, the
     *         image is successfully registered and available for launching. If the
     *         operation returns deregistered, the image is deregistered and no
     *         longer available for launching.
     *
     * @see ImageState
     */
    public String getState() {
        return state;
    }
    
    /**
     * Current state of the AMI. If the operation returns available, the
     * image is successfully registered and available for launching. If the
     * operation returns deregistered, the image is deregistered and no
     * longer available for launching.
     * <p>
     * <b>Constraints:</b><br/>
     * <b>Allowed Values: </b>available, deregistered
     *
     * @param state Current state of the AMI. If the operation returns available, the
     *         image is successfully registered and available for launching. If the
     *         operation returns deregistered, the image is deregistered and no
     *         longer available for launching.
     *
     * @see ImageState
     */
    public void setState(String state) {
        this.state = state;
    }
    
    
    /**
     * The operating platform of the AMI.
     *
     * @return The operating platform of the AMI.
     */
    public String getPlatform() {
        return platform;
    }
    
    /**
     * The operating platform of the AMI.
     *
     * @param platform The operating platform of the AMI.
     */
    public void setPlatform(String platform) {
        this.platform = platform;
    }
    
    
    /**
     * The name of the AMI that was provided during image creation.
     *
     * @return The name of the AMI that was provided during image creation.
     */
    public String getName() {
        return name;
    }
    
    /**
     * The name of the AMI that was provided during image creation.
     *
     * @param name The name of the AMI that was provided during image creation.
     */
    public void setName(String name) {
        this.name = name;
    }
    
    
    /**
     * The description of the AMI that was provided during image creation.
     *
     * @return The description of the AMI that was provided during image creation.
     */
    public String getDescription() {
        return description;
    }
    
    /**
     * The description of the AMI that was provided during image creation.
     *
     * @param description The description of the AMI that was provided during image creation.
     */
    public void setDescription(String description) {
        this.description = description;
    }
    
    /**
     * Returns the value of the VirtualizationType property for this object.
     * <p>
     * <b>Constraints:</b><br/>
     * <b>Allowed Values: </b>hvm, paravirtual
     *
     * @return The value of the VirtualizationType property for this object.
     *
     * @see VirtualizationType
     */
    public String getVirtualizationType() {
        return virtualizationType;
    }
    
    /**
     * Sets the value of the VirtualizationType property for this object.
     * <p>
     * <b>Constraints:</b><br/>
     * <b>Allowed Values: </b>hvm, paravirtual
     *
     * @param virtualizationType The new value for the VirtualizationType property for this object.
     *
     * @see VirtualizationType
     */
    public void setVirtualizationType(String virtualizationType) {
        this.virtualizationType = virtualizationType;
    }
    
}