package qa.sav.moodys.nova.deprecated;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.supercsv.io.CsvListReader;
import org.supercsv.io.CsvListWriter;
import org.supercsv.prefs.CsvPreference;

import qa.sav.moodys.nova.data.JobStatus;

/**
 * 
 * @author QinS
 * @since 2017/11/23
 * 
 */

public class CsvUtils_JobResults {
	
	public String addJobInfomation(JobStatus jobResult, String inputCsvFile) throws IOException{
		
		String outputFile = inputCsvFile.replace(".csv", "_") + "Out.csv";
		
		CsvListReader reader = new CsvListReader(new FileReader(inputCsvFile), CsvPreference.STANDARD_PREFERENCE);
		CsvListWriter writer = new CsvListWriter(new FileWriter(outputFile), CsvPreference.STANDARD_PREFERENCE);
		
		List<String> columns = null;
		columns = reader.read();
		columns.add(0, "DataSource");
		columns.add(1, "JobID");
		columns.add(2, "JobType");
		columns.add(3, "BusinessType");		
		writer.write(columns);
		
		
		while((columns = reader.read())!=null){
			columns.add(0, jobResult.getDataSource());
			columns.add(1, Integer.toString(jobResult.getJobID()));
			columns.add(2, jobResult.getRunType());
			columns.add(3, jobResult.getBusinessType());
			writer.write(columns);
		}		
		
		reader.close();
		writer.close();
		
		return outputFile;
		
	}
			
}
