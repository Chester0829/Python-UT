package qa.sav.moodys.nova.testcases.cmbs;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.HashMap;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.data.JobSettings;

public class DataProviderJobConfigCmbs {
	
	static int group_index = 0;
	static int sequencial_index = 1;
	static int name_index = 2;
	static int businessType_index = 3;
	static int runType_index = 4;
	static int simConfig_index = 5;
	static int asOfDate_index = 6;
	static int cmmForecast_index = 7;
	static int cmmVerion_index = 8;
	static int dscrLtv_index = 9;
	static int blended_index = 10;
	static int scenarios_index = 11;
	static int forceSync_index = 12;
	
	public static JobCmbs[] readTestCasesConfig(String job_config_filePath, String portfolioPath) throws Exception{
		
		ArrayList<String> cusipsList = DataProviderJobConfigCmbs.readCusipsListFromPortfolio(portfolioPath);
		System.out.println("CUSIP list: "+cusipsList);
		
		JobCmbs jobs[];
		BufferedReader reader;
		int jobsCount;
		LineNumberReader lineReader = null;
		
	    try {
	    	lineReader = new LineNumberReader(new FileReader(job_config_filePath));
	        while ((lineReader.readLine()) != null);
	        jobsCount = lineReader.getLineNumber();
	    } catch (Exception ex) {
	    	jobsCount = -1;
	    } finally { 
	        if(lineReader != null) 
	        	lineReader.close();
	    }
		
		try {
			reader = new BufferedReader(new FileReader(job_config_filePath));

			jobs = new JobCmbs[jobsCount-1];
			String line = reader.readLine();

			int n = 0;
			while (line != null) {
				line = reader.readLine();
				
				if(line == null){
					System.out.println("empty line, exit");
					break;
				}
				
				String config[] = line.split(",");
				JobCmbs job = new JobCmbs();
				JobSettings jobSettings = new JobSettings();
				
				jobSettings.setPortfolioFilePath(portfolioPath);
				jobSettings.setCusipsList(cusipsList);
				jobSettings.setJobName(config[name_index]);
				
				job.sequencial = config[sequencial_index].equals("Y");
				jobSettings.setBusinessType(config[businessType_index]);
				jobSettings.setRunType(config[runType_index]);
				if(jobSettings.getRunType().equals("static")){
					// do nothing
				} else {						
					//set simulation configuration
					String sim[] = config[simConfig_index].split("/");
					jobSettings.setSimPaths(sim[3]);
					jobSettings.setConfidenceLevelPercentage(sim[0]);
					jobSettings.setTailPercentageLevl(sim[1]);
					jobSettings.setOptimizationPercentageLevel(sim[2]);
				}
				jobSettings.setAsOfDate(formatAsOfDate(config[asOfDate_index]));
				jobSettings.setCmmForecast(config[cmmForecast_index]);
				jobSettings.setCmmVersion(config[cmmVerion_index]);
				jobSettings.setDscrLtv(config[dscrLtv_index]);
				jobSettings.setScenarioBlended(config[blended_index].equals("Y"));
				HashMap<String,String> scenarios = new HashMap<String, String>();
				
				String scenColl[] = config[scenarios_index].split("/");
				int i = 0;
				while(i < scenColl.length){
					scenarios.put(scenColl[i].split(":")[0], scenColl[i].split(":")[1]);
					i++;
				}
				jobSettings.setScenarios(scenarios);
				jobSettings.setForceSync(config[forceSync_index].equals("Y"));
				job.setJobSettings(jobSettings);
				jobs[n++]=job;
			}
			reader.close();
		} catch (IOException e) {			
			e.printStackTrace();
			throw e;
		}
		return jobs;		
	}
	
	static String formatAsOfDate(String orgDate){
		String asOfDate = orgDate;
		if(orgDate.matches("^[\\d]{1,2}/[\\d]{1,2}/[\\d]{2}([\\d]{2})?$")){
			asOfDate = orgDate.split("/")[2]+"-"+orgDate.split("/")[0]+"-"+orgDate.split("/")[1];
		}	
		return asOfDate;		
	}
	
	static ArrayList<String> readCusipsListFromPortfolio(String portfolioPath) throws IOException{
		ArrayList<String> cusipList = new ArrayList<String>();
		LineNumberReader lineReader = null;
		String line = null;
		
	    try {
	    	lineReader = new LineNumberReader(new FileReader(portfolioPath));
	    	line = lineReader.readLine();
	        while ((line = lineReader.readLine()) != null){
	        	cusipList.add(line.split(",")[0]);
	        };
	    } catch (Exception ex) {
	    	throw ex;
	    } finally { 
	        if(lineReader != null) 
	        	lineReader.close();
	    }
		return cusipList;	    
	}
	
}
