package qa.sav.moodys.nova.pages.jobResult;

import org.openqa.selenium.WebDriver;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.pages.PageBase;

public class JobResultCmbs extends PageBase{
	
	public JobCmbs jobCmbs;
	
	public JobResultCmbs(WebDriver driver, JobCmbs job) throws Exception{
		super(driver);
		job.driver = driver;
		if(job.getJobStatus()==null){
			job.reFreshStatus();
		}
		jobCmbs = job;
	}	
	
	public OverviewCmbs getOverviewInstance(WebDriver driver) throws Exception{
		OverviewCmbs overviewCmbs = new OverviewCmbs(driver, jobCmbs);
		return overviewCmbs;
	}
	
	public CollateralCashflowsCmbs getCollateralCashflowInstance(WebDriver driver) throws Exception{
		return new CollateralCashflowsCmbs(driver, jobCmbs);
	}
	
	public BondCashflowsCmbs getBondCashflowsInstance(WebDriver driver) throws Exception{
		return new BondCashflowsCmbs(driver, jobCmbs);
	}
	
	public AnnualPDsELsMappingsCmbs getAnnualPDsELsMappingInstance(WebDriver driver) throws Exception{
		return new AnnualPDsELsMappingsCmbs(driver, jobCmbs);
	}
	
	public LoanLevelDetailsCmbs getLoanLevelDetailsInstance(WebDriver driver) throws Exception{
		return new LoanLevelDetailsCmbs(driver, jobCmbs);
	}
	
	public LoanLevelStratificationCmbs getLoanLevelStratificationInstance(WebDriver driver) throws Exception{
		return new LoanLevelStratificationCmbs(driver, jobCmbs);
	}
	
	public PerformanceStratificationCmbs getPerformanceStratificationInstance(WebDriver driver) throws Exception{
		return new PerformanceStratificationCmbs(driver, jobCmbs);
	}
	
	
	
}
