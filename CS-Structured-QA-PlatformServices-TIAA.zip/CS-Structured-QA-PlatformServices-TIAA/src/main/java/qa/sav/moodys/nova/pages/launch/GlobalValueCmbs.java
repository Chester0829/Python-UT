package qa.sav.moodys.nova.pages.launch;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GlobalValueCmbs extends GlobalValueBase{	
	
	
	@FindBy(id="modal-global-values")
	WebElement globalValuePopUp; 	
	
	@FindBy(xpath = "//*[@id=\"tb-globalValues\"]")
	WebElement globalValuesTable;
	
	@FindBy(xpath = "//*[@id=\"modal-global-values\"]/div/div/div[2]/form/div[1]")
	WebElement tailPctLevelEntry;
	
	@FindBy(xpath="//*[@id=\"modal-global-values\"]/div/div/div[2]/form/div[2]")
	WebElement optimationPctLevelEntry;
	
	@FindBy(xpath="//*[@id=\"modal-global-values\"]/div/div/div[2]/form/div[3]")
	WebElement hopeNotesOverrideEntry;
	
	@FindBy(xpath="//*[@id=\"modal-global-values\"]/div/div/div[2]/form/div[4]")
	WebElement noiGrowthRateCapEntry;
	
	@FindBy(xpath = "//*[@id=\"modal-global-values\"]/div/div/div[2]/form/div[5]")
	WebElement globalValuesTypeEntry;
	
	@FindBy(id="gv-collateral-type")
	WebElement globalValuesTypeSelect;
	
	@FindBy(xpath = "//*[@id=\"modal-global-values\"]/div/div/div[2]/form/div[6]")
	WebElement usePdDscrLtvRulesEntry;
	
	@FindBy(xpath = "//*[@id=\"modal-global-values\"]/div/div/div[2]/form/div[7]")
	WebElement useLgdDscrLtvRulesEntry;
	
	@FindBy(id="input-pdMultiplier")
	public WebElement pdMultiplier;	
	
	@FindBy(id="input-lgdMultiplier")
	public WebElement lgdMultiplier;
	
	@FindBy(id="input-pdCap")
	public WebElement pdCap;
	
	@FindBy(id="input-lgdCap")
	public WebElement ldgCap;
	
	@FindBy(id="input-pdFloor")
	public WebElement pdFloor;
	
	@FindBy(id="input-lgdFloor")
	public WebElement ldgFloor;
	
	@FindBy(id="input-delinqPd30")
	public WebElement thirtyDayDelinq;
	
	@FindBy(id="input-delinqPd60")
	public WebElement sixtyDayDelinq;
	
	@FindBy(id="input-bookPrice")
	public WebElement bookPrice;
	
	@FindBy(id="input-insuranceCoveragePct")
	public WebElement insuranceCoverage;
	
	@FindBy(id="input-correlationMultiplier")
	public WebElement correlationMultiplier;
	
	@FindBy(id="input-prepayRate")
	public WebElement prepayRate;
	
	@FindBy(id="input-prepayType")
	public WebElement prepayTypeSelect;
	
	@FindBy(id="input-recoveryRateVolatility")
	public WebElement recoveryRateVolatility;
	
	@FindBy(id="input-globalRecoveryCorrelation")
	public WebElement globalRecoveryCorrelation;
	
	@FindBy(id="input-assetDefaultRecoveryCorrelation")
	public WebElement assetDefaultRecoveryCorrelation;
		
	final static String disableServerityCapXpath = "//*[@id=\"chk-disable-caps\"]";
	@FindBy(xpath = disableServerityCapXpath)
	public WebElement disableServerityCap;

	final static String importXpath = "//*[@id=\"modal-global-values\"]/div/div/div[3]/label";
	@FindBy(xpath = importXpath)
	public WebElement importGlobalValues;
	
	final static String exportXpath = "//*[@id=\"export-global-values\"]";
	@FindBy(xpath = exportXpath)
	public WebElement exportGlobalValues;
	
	final static String saveChangeXpath = "//*[@id=\"btn-save-global-values\"]";
	@FindBy(xpath = saveChangeXpath)
	public WebElement saveChange;
	
	final static String applyChangeXpath = "//*[@id=\"modal-global-values\"]/div/div/div[3]/button[3]";
	@FindBy(xpath = applyChangeXpath)
	public WebElement applyChange;

		
	public GlobalValueCmbs(WebDriver driver) throws Exception{
		super(driver);	
		try{
			if(globalValuePopUp.isDisplayed()){
				//do nothing
			} else {
				new LaunchCmbs(driver).openGlobalValueDashboard();
			}
		}catch(Exception e){
			new LaunchCmbs(driver).openGlobalValueDashboard();
		}
	}

	public void setHopeNotesOverride(Boolean enabled) throws InterruptedException{
		if(hopeNotesOverrideEntry.findElement(By.xpath("div[1]/input")).isSelected()==enabled){
			// do nothing
		} else {
			
			hopeNotesOverrideEntry.findElement(By.xpath("div[1]/input")).click();
			waitForAjaxLoaded();
			
		}
		
	}
	
	
	public void setNoiGrowthRateCapPctEnable(boolean enable) throws InterruptedException{
		if(enable == noiGrowthRateCapEntry.findElement(By.xpath("div[2]/input")).isSelected()){
			//do nothing
			log.info("Enabled NOI Growth Rate Cap(%): "+enable);
		} else {
			noiGrowthRateCapEntry.findElement(By.xpath("div[2]/input")).click();
			waitForAjaxLoaded();
			log.info("Enabled NOI Growth Rate Cap(%): "+enable);
		}
	}
	
	public void setNoiGrowthRateCapPctValue(String value){
		if(!noiGrowthRateCapEntry.findElement(By.xpath("div[2]/input")).isSelected()){
			//do nothing
			log.error("NOI Growth Rate Cap(%) does not enable, return");
		} else {
			noiGrowthRateCapEntry.findElement(By.xpath("div[1]/input")).clear();
			noiGrowthRateCapEntry.findElement(By.xpath("div[1]/input")).sendKeys(value);
			log.info("Set CMBS NOI Growth Rate Cap(%) = "+value);
		}
	}
	
	public Boolean getHopeNotesOverride(){
		Boolean overrideEnable = null;
		overrideEnable = hopeNotesOverrideEntry.findElement(By.xpath("div[1]/input")).isSelected();	
		return overrideEnable;
	}
	
	public void importGlobalValue(String importFilePath) throws Exception{
		importGlobalValues.click();
		autoItUploadFile(importFilePath);
	}
	
	public String exportGlobalValue(String exportFilePath) throws Exception{
		File file = null;
		try {
			file = downloadFile(driver.findElement(By.xpath(exportXpath)), new File(exportFilePath));
		} catch (Exception e) {
			log.error("Failed to download RMBS sample portfolio file");
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		return file.getName();
	}
	
	public void saveChange(){
		saveChange.click();
	}
	
	public void applyChange(){
		applyChange.click();
	}		
	
	public void setDisableServerityCap(boolean disableServerity){
		if(disableServerity){
			if(disableServerityCap.isSelected()){
				//do nothing
			} else{
				disableServerityCap.click();
			}
		} else {
			if(disableServerityCap.isSelected()){
				disableServerityCap.click();
			} else{
				// do nothing
			}				
		}
	}
		
	
}
