package qa.sav.moodys.nova.testcases.cmbs;

import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.pages.jobResult.AnnualPDsELsMappingsCmbs;
import qa.sav.moodys.nova.pages.jobResult.BondCashflowsCmbs;
import qa.sav.moodys.nova.pages.jobResult.CollateralCashflowsCmbs;
import qa.sav.moodys.nova.pages.jobResult.JobResultCmbs;
import qa.sav.moodys.nova.pages.jobResult.LoanLevelDetailsCmbs;
import qa.sav.moodys.nova.pages.jobResult.LoanLevelStratificationCmbs;
import qa.sav.moodys.nova.pages.jobResult.OverviewCmbs;
import qa.sav.moodys.nova.pages.jobResult.PerformanceStratificationCmbs;
import qa.sav.moodys.nova.testLogic.TestAsserts;
import qa.sav.moodys.nova.testcases.base.TestCaseBase;

public class Cmbs_Sanity_Test_AllInOne extends TestCaseBase{
	String job_records_path = System.getProperty("user.dir")+File.separator+"data/tmp/cmbs_sanity_test_job_records.csv";
	String job_benchmark_path = System.getProperty("user.dir")+File.separator+"data/cmbs_sanity_benchmark_job_records.csv";
	String job_config_filePath = System.getProperty("user.dir")+ File.separator +"config/testcase/job_configue_cmbs_smoke.csv";
	String portfolioPath = System.getProperty("user.dir")+ File.separator +"config/testcase/launchCmbsSmoke.csv";
	
	int cusipCount = 0;
	int jobsCount = 0;
	ArrayList<String> cusipList;
	ArrayList<String> testedJobsName;
	HashMap<String, JobCmbs> testedJobs;
	
	@BeforeTest
	public void clearEnvironment() throws Exception{
		//clear cmbs_sanity_test_job_records;
		//jobsCount = DataProviderJobConfigCmbs.readTestCasesConfig(job_config_filePath,portfolioPath).length;
		testedJobsName = new ArrayList<String>();
		testedJobs = new HashMap<String,JobCmbs>();
		cusipList = new ArrayList<String>();
	
		LineNumberReader lineReader = null;
		String line = null;
		
	    try {
	    	lineReader = new LineNumberReader(new FileReader(portfolioPath));
	    	line = lineReader.readLine();
	        while ((line = lineReader.readLine()) != null){
	        	cusipList.add(line.split(",")[0]);
	        };
	        cusipCount = lineReader.getLineNumber()-1;
	    } catch (Exception ex) {
	    	cusipCount = -1;
	    	throw ex;
	    } finally { 
	        if(lineReader != null) 
	        	lineReader.close();
	    }	    
	}	

	@Test(groups="job_submit_1",dataProvider="cmbs_sanity_jobs",priority=1, description="submit a set of cmbs sanity jobs, all the jobs should be submited successfully")
	public void submit_cmbs_sanity_job(JobCmbs jobCmbs,String jobName) throws Exception{
		WebDriver newDriver = initialNewDriver();
		JobCmbs job = new JobCmbs(newDriver, jobCmbs.getJobSettings());
		String newJobName = jobName+"_"+new SimpleDateFormat("YYYYMMddHHmmssSSS").format(Calendar.getInstance().getTime());
		job.jobSettings.setJobName(newJobName);   	
		job = job.run(false);
		job.reFreshStatus();
		testedJobsName.add(newJobName);
		testedJobs.put(newJobName, job);
		quitDriver(job.driver);
	}
		
	@Test(groups="job_submit", dependsOnGroups = "job_submit_1", dataProvider="cmbs_sanity_jobs_run",threadPoolSize = 3,priority=3, 
	description="Wait for job completed and check failed numbers: compared to benchmark")
	public void wait_for_job_to_be_completed(String jobName) throws Exception{
		WebDriver newDriver = initialNewDriver();
		JobCmbs job = new JobCmbs(newDriver, this.testedJobs.get(jobName).getJobSettings());
		job.waitForJobCompleted();
		job.reFreshStatus();
		testedJobs.get(jobName).setJobStatus(job.jobStatus);
		Assert.assertEquals(job.getJobStatus().getRunStatus(), "finish");
		//int progressNum = job.getJobStatus().getProgress();
		//boolean blended = job.getJobSettings().scenarioBlended;
		int scenariosCount = job.getJobSettings().getScenarios().size();;
//		if(blended){
//			scenariosCount = job.getJobSettings().getScenarios().size()+1;
//		} else {
//			scenariosCount = job.getJobSettings().getScenarios().size();
//		}
		try	{
			Assert.assertEquals(scenariosCount*cusipCount,(int)job.getJobStatus().getTotalTasks(),
					"Expected total task number to be ["+scenariosCount*cusipCount+"] but found ["+(int)job.getJobStatus().getTotalTasks()+"]");
			Assert.assertEquals(scenariosCount*cusipCount,(int)job.getJobStatus().getProgress(),
					"Expected total progressed tasks number to be ["+scenariosCount*cusipCount+"] but found ["+(int)job.getJobStatus().getProgress()+"]");
			Assert.assertEquals(job.getJobStatus().getJobResultStatus(), "success", 
					"Expected job result status to be [success] but found "+job.getJobStatus().getJobResultStatus());
			Assert.assertEquals((int)job.getJobStatus().getFailNum(), 0, 
					"Expected 0 failnums but found "+job.getJobStatus().getFailNum());		
			quitDriver(newDriver);
		} catch (Exception ex){
			throw ex;
		}	
		quitDriver(job.driver);
	}
	
		
	
	//@Test(dependsOnGroups = "job_submit", dataProvider="cmbs_sanity_jobs_run",priority=5, description="job results smoke checking")
	public void smoke_check_cmbs_sanity_job_results_overall(String jobName) throws Exception{
			JobCmbs job = new JobCmbs(initialNewDriver(), this.testedJobs.get(jobName).getJobSettings());
			job.reFreshStatus();
			JobResultCmbs cmbsResult = job.getResult();
			
			Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
			ArrayList<String> scenariosList = new ArrayList<String>();
			scenariosSet.forEach((scenario)->
			{
				scenariosList.add(scenario);
			});
			
			if(job.getJobSettings().isScenarioBlended()){
				scenariosList.add("Blended Scenario");
			} else {
				// do nothing
			}
			
			try{
				Assert.assertEquals(TestAsserts.compareLists(cusipList, cmbsResult.getOverviewInstance(job.driver).getCusipsList()),true, 
					"overview page cusips list is equaled to cusips list in portfolio file");
				Assert.assertEquals(true, TestAsserts.compareLists(scenariosList, 
					cmbsResult.getOverviewInstance(job.driver).getScenariosList()));
				Assert.assertTrue(cmbsResult.getOverviewInstance(job.driver).readProfileByScenAndCusip().get("Current CUSIP")
					!=null, "verify cusip value in profile table is showing");
			} catch(Exception ex){
				throw ex;
			}finally{
				quitDriver(job.driver);
				quitDriver(cmbsResult.jobCmbs.driver);
			}
	}
		
	//@Test(dependsOnGroups = "job_submit", dataProvider="cmbs_sanity_jobs_run_cusip",priority=6, description="job results sanity check - overview")
	public void check_cmbs_sanity_job_results_overview(String jobName, String cusip) throws Exception{
		JobCmbs job = new JobCmbs(initialNewDriver(), this.testedJobs.get(jobName).getJobSettings());
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		OverviewCmbs overview = cmbsResult.getOverviewInstance(job.driver);
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		
		try{
			overview.selectToCusip(cusip);
			Assert.assertTrue(overview.scenarioText.getText().equals("Scenario:"), "Verify the scenario list title is showing");
			Assert.assertTrue(overview.cusipText.getText().equals("CUSIP:"),"Verify the cusip list title is displaying");
			Assert.assertTrue(overview.profileTitle.getText().equals("PROFILE")
					,"Verify the profile title is displaying as \"PROFILE\"");
			Assert.assertTrue(overview.summaryTitle.getText().equals("SUMMARY")
					,"Verify the profile title is displaying as \"SUMMARY\"");			
			Assert.assertTrue(TestAsserts.compareLists(scenariosList, overview.getScenariosList())
					, "Verify all the scenarios in config file are listed in scen dropdown list");			
			HashMap<String, String> profileValues = new HashMap<String, String>();
			HashMap<String, String> summaryValues = new HashMap<String, String>();
			for(String scen:scenariosList){
				profileValues.clear();
				summaryValues.clear();
				overview.selectToScenario(scen);
				
				for(int i = 0; i < overview.profileKeys.length; i ++){
					overview.profileTable.getText();
					Assert.assertEquals(overview.profileTable.findElement(By.xpath("tr["+(i+1)+"]/td[1]")).getText()
							, overview.profileKeys[i], "Verify profile table: the "+(i+1)+"field is "+overview.profileKeys[i]+ " but found "
					+ overview.profileTable.findElement(By.xpath("tr["+(i+1)+"]/td[1]")));
				}
				
				for(int i = 0; i < overview.summaryKeys.length; i ++){
					Assert.assertEquals(overview.summaryTable.findElement(By.xpath("tr["+(i+1)+"]/td[1]")).getText()
							, overview.summaryKeys[i], "Verify summary table: the "+(i+1)+"field is "+overview.profileKeys[i]+ " but found "
					+overview.summaryTable.findElement(By.xpath("tr["+(i+1)+"]/td[1]")));				
				}
				
				profileValues = overview.readProfileByScenAndCusip(scen, cusip);
				summaryValues = overview.readSummaryByScenAndCusip(scen, cusip);
				//System.out.println("expected profile fields count: "+profileValues.size());
				profileValues.values().removeIf(value->value.equals(""));
				
				Assert.assertTrue(profileValues.size() > 13 && profileValues.size() <= overview.profileKeys.length
						, "Verify not-blank profile fields count is larger than 13 --- "+profileValues.size());
							
				//System.out.println("expected summary fields count: "+summaryValues.size());
				summaryValues.values().removeIf(value->value.equals(""));
				//System.out.println("expected not-blank profile fields count: "+summaryValues.size());
				Assert.assertTrue(summaryValues.size() > 2 && profileValues.size() <= overview.profileKeys.length
						, "Verify not-blank profile fields count is larger than 2 --- "+summaryValues.size());
				
			}	
		} catch(Exception ex) {
			throw ex;
		} finally{		
			quitDriver(job.driver);
			quitDriver(cmbsResult.jobCmbs.driver);
		}
	}

	//@Test(dependsOnGroups = "job_submit", dataProvider="cmbs_sanity_jobs_run_cusip",priority=6, description="job results sanity check - collateral cashflows")
	public void check_cmbs_sanity_job_results_collateral_cashflow(String jobName, String cusip) throws Exception{
		JobCmbs job = new JobCmbs(initialNewDriver(), this.testedJobs.get(jobName).getJobSettings());
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		CollateralCashflowsCmbs collCashflow = cmbsResult.getCollateralCashflowInstance(job.driver);
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		
		try{
			collCashflow.selectToCusip(cusip);
			Assert.assertTrue(collCashflow.scenarioText.getText().equals("Scenario:"), "Verify the scenario list title is showing");
			Assert.assertTrue(collCashflow.cusipText.getText().equals("CUSIP:"),"Verify the cusip list title is displaying");
			//System.out.println(collCashflow.collateralCashflowTitleText.getText());
			Assert.assertTrue(collCashflow.collateralCashflowTitleText.getText().equals("COLLATERAL CASHFLOW")
					, "Verify the collateral cashflow title is \"COLLATERAL CASHFLOW\"");
			
			for(String scen:scenariosList){
				Reporter.log("Verify the collateral cashflow headers are displaying as predefined: " + Arrays.toString(collCashflow.cashflowFields));
				Assert.assertTrue(Arrays.toString(collCashflow.getcashflowHearderFieldsByScenarioAndCusip(scen, cusip)).equals(Arrays.toString(collCashflow.cashflowFields))
						, "Verify the collateral cashflow headers are displaying as predefined: " + collCashflow.getcashflowHearderFieldsByScenarioAndCusip(scen, cusip));
				Assert.assertTrue(Float.parseFloat(collCashflow.getTotalAmortizedAmountByScenarioAndCusip(scen, cusip).replaceAll(",", "")) > 0
						, "Verify the total amortize amout is greater then 0");
				Assert.assertTrue(Float.parseFloat(collCashflow.getTotalInterstPaymentByScenarioAndCusip(scen, cusip).replaceAll(",", "")) > 0
						, "Verify the total amortize amout is greater then 0");
				Assert.assertTrue(collCashflow.getCashflowSizeByScenarioAndCusip(scen, cusip)>1
						,"Verify Collateral cashflow size is greater then 2");
				
				String dealUpdatedDate[] = collCashflow.getDealUpdatedDateByScenarioAndCusip(scen, cusip).split("-");
				String asOfDate[] = job.getJobSettings().getAsOfDate().split("-");
				String firstPaymentDate[] = collCashflow.getFirstPayDateByScenarioAndCusip(scen, cusip).split("-");
				LocalDate date1 = LocalDate.of(Integer.parseInt(dealUpdatedDate[0]), Integer.parseInt(dealUpdatedDate[1]), 1);
		        LocalDate date2 = LocalDate.of(Integer.parseInt(asOfDate[0]), Integer.parseInt(asOfDate[1]), 1);
		        LocalDate date3 = LocalDate.of(Integer.parseInt(firstPaymentDate[0]), Integer.parseInt(firstPaymentDate[1]), 1);
				Assert.assertTrue((date2.plusMonths(1).isEqual(date3)), "Verify first payment date is 1 month later then as of date");	
		        Assert.assertTrue(date1.isEqual(date2)||date1.isBefore(date2), "Verify deal updated date is equal to or before as of date");			
			}		
				
		} catch(Exception ex) {
			throw ex;
		} finally{		
			quitDriver(job.driver);
			quitDriver(cmbsResult.jobCmbs.driver);
		}
	}
		
	//@Test(dependsOnGroups = "job_submit", dataProvider="cmbs_sanity_jobs_run_cusip",priority=6, description="job results sanity check - bond cashflows")
	public void check_cmbs_sanity_job_results_bond_cashflow(String jobName, String cusip) throws Exception{
		JobCmbs job = new JobCmbs(initialNewDriver(), this.testedJobs.get(jobName).getJobSettings());
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		BondCashflowsCmbs cashflow = cmbsResult.getBondCashflowsInstance(job.driver);
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		
		try{
			cashflow.selectToCusip(cusip);
			Assert.assertTrue(cashflow.scenarioText.getText().equals("Scenario:"), "Verify the scenario list title is showing");
			Assert.assertTrue(cashflow.cusipText.getText().equals("CUSIP:"),"Verify the cusip list title is displaying");
			//System.out.println(collCashflow.collateralCashflowTitleText.getText());
			Assert.assertTrue(cashflow.bondCashflowTitleText.getText().equals("BOND CASHFLOW")
					, "Verify the bond cashflow title is \"BOND CASHFLOW\"");
			
			for(String scen:scenariosList){
				Reporter.log("Verify the collateral cashflow headers are displaying as predefined: " + Arrays.toString(cashflow.cashflowFields));
				Assert.assertTrue(Arrays.toString(cashflow.getcashflowHearderFieldsByScenarioAndCusip(scen, cusip)).equals(Arrays.toString(cashflow.cashflowFields))
						, "Verify the collateral cashflow headers are displaying as predefined: " + cashflow.getcashflowHearderFieldsByScenarioAndCusip(scen, cusip));
				Assert.assertTrue(Float.parseFloat(cashflow.getTotalTrancheInterestByScenarioAndCusip(scen, cusip).replaceAll(",", "")) > 0
						, "Verify the total Tranche Interest is greater then 0");
				Assert.assertTrue(Float.parseFloat(cashflow.getTotalTranchePrincipalByScenarioAndCusip(scen, cusip).replaceAll(",", "")) > 0
						, "Verify the total Tranche Principal is greater then 0");
				Assert.assertTrue(cashflow.getCashflowSizeByScenarioAndCusip(scen, cusip)>1
						,"Verify Collateral cashflow size is greater then 2");
				
				String dealUpdatedDate[] = cashflow.getDealUpdatedDateByScenarioAndCusip(scen, cusip).split("-");
				String asOfDate[] = job.getJobSettings().getAsOfDate().split("-");
				String firstPaymentDate[] = cashflow.getFirstPayDateByScenarioAndCusip(scen, cusip).split("-");
				LocalDate date1 = LocalDate.of(Integer.parseInt(dealUpdatedDate[0]), Integer.parseInt(dealUpdatedDate[1]), 1);
		        LocalDate date2 = LocalDate.of(Integer.parseInt(asOfDate[0]), Integer.parseInt(asOfDate[1]), 1);
		        LocalDate date3 = LocalDate.of(Integer.parseInt(firstPaymentDate[0]), Integer.parseInt(firstPaymentDate[1]), 1);
				Assert.assertTrue((date2.plusMonths(1).isEqual(date3)), "Verify first payment date is 1 month later then as of date");	
		        Assert.assertTrue(date1.isEqual(date2)||date1.isBefore(date2), "Verify deal updated date is equal to or before as of date");			
			}		
				
		} catch(Exception ex) {
			throw ex;
		} finally{		
			quitDriver(job.driver);
			quitDriver(cmbsResult.jobCmbs.driver);
		}
	}
		
	//@Test(dependsOnGroups = "job_submit", dataProvider="cmbs_sanity_jobs_run_cusip",priority=6, description="job results sanity check - bond cashflows")
	public void check_cmbs_sanity_job_results_AnnualPDsELsMappings(String jobname, String cusip) throws Exception{
		JobCmbs job = new JobCmbs(initialNewDriver(), this.testedJobs.get(jobname).getJobSettings());
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		AnnualPDsELsMappingsCmbs annualPdElResults = cmbsResult.getAnnualPDsELsMappingInstance(job.driver);
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
			
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		if(job.getJobSettings().getRunType().equalsIgnoreCase("simulation")){
			try{				
				HashMap<String, String> confidenceSummaryValues = new HashMap<String, String>();
				//HashMap<String, String> averageOverallRattings = new HashMap<String, String>();
				HashMap<String, String> confidenceProjectedRattings[] = new HashMap[10];
				
				//annualPdElResults.selectToCusip(cusip);
				for(String scen:scenariosList){
					annualPdElResults.selectToScenario(scen);
					annualPdElResults.selectToCusip(cusip);
					annualPdElResults.goToConfidenceSubtab();
					
					confidenceSummaryValues.clear();
					confidenceSummaryValues.clear();
										
					Assert.assertTrue(annualPdElResults.scenarioText.getText().equals("Scenario:"), "Verify the scenario list title is showing");
					Assert.assertTrue(annualPdElResults.cusipText.getText().equals("CUSIP:"),"Verify the cusip list title is displaying");
					//System.out.println("Test title: "+annualPdElResults.confidenceOverallRattingTitleText.getText());
					Assert.assertTrue(annualPdElResults.confidenceOverallRattingTitleText.getText().equals("PROJECTED SUMMARY")
							, "Verify the average tab >> summmary title is \"PROJECTED SUMMARY\"");
								
					Assert.assertEquals(annualPdElResults.confidenceProjectedRattingMapTitleText.getText(), "YEARS"
							, "Verify the average tab >> projected ratting mapping title is \"YEARS\"");
					
					Assert.assertEquals(Arrays.toString(annualPdElResults.getConfidenceOverallRattingHeadersByScenarioAndCusip(scen, cusip))
							, Arrays.toString(annualPdElResults.confidenceOverallRattingFields));
					
					Assert.assertEquals(Arrays.toString(annualPdElResults.getConfidenceProjectedRattingMapHeadersByScenarioAndCusip(scen, cusip))
							, Arrays.toString(annualPdElResults.projectedRattingFields));
										
					confidenceSummaryValues = annualPdElResults.getConfidenceOverallRattingByScenarioAndCusip(scen, cusip);
					confidenceSummaryValues.values().removeIf(value->value.equals(""));
					Assert.assertEquals(confidenceSummaryValues.size(), annualPdElResults.confidenceOverallRattingFields.length);
					
					confidenceProjectedRattings = annualPdElResults.getConfidenceProjectedRattingMapByScenarioAndCusip(scen, cusip);
					int tempSize = 0;
					for(int i = 0; i < 10; i++){
						confidenceProjectedRattings[i].values().removeIf(value->value.equals(""));
						tempSize += confidenceProjectedRattings[i].size();
					}
					Assert.assertEquals(tempSize, annualPdElResults.projectedRattingFields.length*10);
				}		
					
			} catch(Exception ex) {
				throw ex;
			} finally{		
				
			}
		}
		try{
			annualPdElResults.selectToCusip(cusip);
			
			HashMap<String, String> averageSummaryValues = new HashMap<String, String>();
			HashMap<String, String> averageOverallRattings = new HashMap<String, String>();
			HashMap<String, String> averageProjectedRattings[] = new HashMap[10];
			
			annualPdElResults.selectToCusip(cusip);
			for(String scen:scenariosList){
				
				averageSummaryValues.clear();
				averageOverallRattings.clear();
				
				annualPdElResults.selectToScenario(scen);
				
				Assert.assertTrue(annualPdElResults.scenarioText.getText().equals("Scenario:"), "Verify the scenario list title is showing");
				Assert.assertTrue(annualPdElResults.cusipText.getText().equals("CUSIP:"),"Verify the cusip list title is displaying");
				//System.out.println(collCashflow.collateralCashflowTitleText.getText());
				Assert.assertTrue(annualPdElResults.averageSummaryTitleText.getText().equals("SUMMARY")
						, "Verify the average tab >> summmary title is \"SUMMARY\"");
				Assert.assertEquals(annualPdElResults.averageOverallRattingTitleText.getText(), "AVERAGE"
						, "Verify the average tab >> overall ratting title is \"AVERAGE\"");
				
				Assert.assertEquals(annualPdElResults.averageProjectedRattingMapTitleText.getText(), "YEARS"
						, "Verify the average tab >> projected ratting mapping title is \"YEARS\"");
				
				Assert.assertEquals(Arrays.toString(annualPdElResults.getAverageRattingMappingSummaryHeadersByScenarioAndCusip(scen, cusip))
						, Arrays.toString(annualPdElResults.averageSummaryFields));
				
				Assert.assertEquals(Arrays.toString(annualPdElResults.getAverageOverallRattingHeadersByScenarioAndCusip(scen, cusip))
						, Arrays.toString(annualPdElResults.averageOverallRattingFields));
				
				Assert.assertEquals(Arrays.toString(annualPdElResults.getAveragePorjectedRattingHeadersByScenarioAndCusip(scen, cusip))
						, Arrays.toString(annualPdElResults.projectedRattingFields));
				
				averageSummaryValues = annualPdElResults.getAverageRattingMapSummaryByScenarioAndCusip(scen, cusip);
				averageSummaryValues.values().removeIf((value)->value.equals(""));
				//Assert.assertEquals(averageSummaryValues.size(), annualPdElResults.averageSummaryFields.length);
				
				averageOverallRattings = annualPdElResults.getAverageOverallRattingByScenarioAndCusip(scen, cusip);
				averageOverallRattings.values().removeIf(value->value.equals(""));
				Assert.assertEquals(averageOverallRattings.size(), annualPdElResults.averageOverallRattingFields.length);
				
				averageProjectedRattings = annualPdElResults.getAverageProjectedRattingMapByScenarioAndCusip(scen, cusip);
				int tempSize = 0;
				for(int i = 0; i < 10; i++){
					averageProjectedRattings[i].values().removeIf(value->value.equals(""));
					tempSize += averageProjectedRattings[i].size();
				}
				Assert.assertEquals(tempSize, annualPdElResults.projectedRattingFields.length*10);
			}		
				
		} catch(Exception ex) {
			throw ex;
		} finally{		
			quitDriver(job.driver);
			quitDriver(cmbsResult.jobCmbs.driver);
		}
			
	}
	
	//@Test(dependsOnGroups = "job_submit", dataProvider="cmbs_sanity_jobs_run_cusip",priority=6, description="job results sanity check - loan level details")
	public void check_cmbs_sanity_job_results_LoanLevelDetails(String jobname, String cusip) throws Exception{
		JobCmbs job = new JobCmbs(initialNewDriver(), this.testedJobs.get(jobname).getJobSettings());
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		LoanLevelDetailsCmbs loanLevelDetails = cmbsResult.getLoanLevelDetailsInstance(job.driver);
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		loanLevelDetails.selectToCusip(cusip);
		try{	
			for(String scen:scenariosList){
				loanLevelDetails.selectToScenario(scen);
				Assert.assertTrue(loanLevelDetails.scenarioText.getText().equals("Scenario:"), "Verify the scenario list title is showing");
				Assert.assertTrue(loanLevelDetails.cusipText.getText().equals("CUSIP:"),"Verify the cusip list title is displaying");
				String loanLevelFields = loanLevelDetails.loanLevelDetailTable.findElement(By.xpath("thead/tr")).getText() + " ";
				String expectedLoanLevelFields = "";
				for(int k = 0; k < loanLevelDetails.loanLevelDetailsFields.length; k++){
					expectedLoanLevelFields = expectedLoanLevelFields + loanLevelDetails.loanLevelDetailsFields[k] + " ";
				}
				System.out.println(expectedLoanLevelFields); 
				Assert.assertEquals(loanLevelFields,expectedLoanLevelFields);
				int expectedloanLevelFeildsSize = loanLevelDetails.loanLevelDetailsFields.length;
				int loanSizes = loanLevelDetails.loanLevelDetailTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(loanSizes > 0);
				for(int i = 0; i < loanSizes; i++){
					//System.out.println("i = "+i);
					int loanLevelFeildsSize = loanLevelDetails.loanLevelDetailTable.findElements(By.xpath("tbody/tr["+(i+1)+"]/td")).size();
					Assert.assertEquals(loanLevelFeildsSize, expectedloanLevelFeildsSize+1);
				}
			}
		} catch(Exception ex) {
			throw ex;
		} finally{		
			quitDriver(job.driver);
			quitDriver(cmbsResult.jobCmbs.driver);
		}
		
	}
	
	//@Test(dependsOnGroups = "job_submit", dataProvider="cmbs_sanity_jobs_run_cusip",priority=6, description="job results sanity check - loan level stratifications")
	public void check_cmbs_sanity_job_results_LoanLevelStratifications(String jobname, String cusip) throws Exception{
		JobCmbs job = new JobCmbs(initialNewDriver(), this.testedJobs.get(jobname).getJobSettings());
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		LoanLevelStratificationCmbs loanLevelStra = cmbsResult.getLoanLevelStratificationInstance(job.driver);
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		loanLevelStra.selectToCusip(cusip);
		try{	
			for(String scen:scenariosList){
				loanLevelStra.selectToScenario(scen);
				Assert.assertTrue(loanLevelStra.scenarioText.getText().equals("Scenario:"), "Verify the scenario list title is showing");
				Assert.assertTrue(loanLevelStra.cusipText.getText().equals("CUSIP:"),"Verify the cusip list title is displaying");
				Assert.assertEquals(loanLevelStra.top10PropertyTypeTitle.getText(), "PROPERTY TYPE (TOP 10)");
				Assert.assertEquals(loanLevelStra.dscrStratificationTitle.getText(), "DSCR");
				Assert.assertEquals(loanLevelStra.ltvStratificationTitle.getText(), "LTV");
				Assert.assertEquals(loanLevelStra.top10StateTitle.getText(), "STATE (TOP 10)");
				Assert.assertEquals(loanLevelStra.loanSizeTitle.getText(), "LOAN SIZE");
				Assert.assertEquals(loanLevelStra.delinquencyTitle.getText(), "DELINQUENCY");				
				
				String propertyTypeHeaders = Arrays.toString(loanLevelStra.propertyStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("thead/tr")).getText().equals(propertyTypeHeaders));				
				int propertyTypeEntrySize = loanLevelStra.top10PropertyTypeTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(propertyTypeEntrySize >= 2);
				//System.out.println(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("tbody")).getText().replace("\n", " "));
				Assert.assertEquals(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("tbody")).getText().replaceAll("\n", " ").split(" ").length
						, propertyTypeEntrySize*loanLevelStra.propertyStratificationFields.length);
				
				String dscrHeaders = Arrays.toString(loanLevelStra.dscrStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(loanLevelStra.dscrStratificationTable.findElement(By.xpath("thead/tr")).getText().equals(dscrHeaders));				
				int dscrEntrySize = loanLevelStra.dscrStratificationTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(dscrEntrySize >= 2);
				//System.out.println(loanLevelStra.dscrStratificationTable.findElement(By.xpath("tbody")).getText());
				Assert.assertEquals(loanLevelStra.dscrStratificationTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, dscrEntrySize*loanLevelStra.dscrStratificationFields.length);	
				
				String ltvHeaders = Arrays.toString(loanLevelStra.ltvStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(loanLevelStra.ltvStratificationTable.findElement(By.xpath("thead/tr")).getText().equals(ltvHeaders));				
				int ltvEntrySize = loanLevelStra.ltvStratificationTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(ltvEntrySize >= 2);
				//System.out.println(loanLevelStra.dscrStratificationTable.findElement(By.xpath("tbody")).getText());
				Assert.assertEquals(loanLevelStra.ltvStratificationTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, ltvEntrySize*loanLevelStra.ltvStratificationFields.length);	
				
				String stateHeaders = Arrays.toString(loanLevelStra.stateStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(loanLevelStra.top10StateTable.findElement(By.xpath("thead/tr")).getText().equals(stateHeaders));				
				int stateEntrySize = loanLevelStra.top10StateTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(stateEntrySize >= 2);
				//System.out.println(loanLevelStra.dscrStratificationTable.findElement(By.xpath("tbody")).getText());
				Assert.assertEquals(loanLevelStra.top10StateTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, stateEntrySize*loanLevelStra.stateStratificationFields.length);
				
				String loanSizeHeaders = Arrays.toString(loanLevelStra.loanSizeStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(loanLevelStra.loanSizeTable.findElement(By.xpath("thead/tr")).getText().equals(loanSizeHeaders));				
				int loanSizeEntrySize = loanLevelStra.loanSizeTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(loanSizeEntrySize >= 2);
				//System.out.println(loanLevelStra.dscrStratificationTable.findElement(By.xpath("tbody")).getText());
				Assert.assertEquals(loanLevelStra.loanSizeTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, loanSizeEntrySize*loanLevelStra.loanSizeStratificationFields.length);
				
				String delinquencyHeaders = Arrays.toString(loanLevelStra.delinquencyStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(loanLevelStra.delinquencyTable.findElement(By.xpath("thead/tr")).getText().equals(delinquencyHeaders));				
				int delinquencyEntrySize = loanLevelStra.delinquencyTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(delinquencyEntrySize >= 2);
				//System.out.println(loanLevelStra.dscrStratificationTable.findElement(By.xpath("tbody")).getText());
				Assert.assertEquals(loanLevelStra.delinquencyTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, delinquencyEntrySize*loanLevelStra.delinquencyStratificationFields.length);								
			}
		
		} catch(Exception ex) {
			throw ex;
		} finally{		
			quitDriver(job.driver);
			quitDriver(cmbsResult.jobCmbs.driver);
		}
	}
		
	//@Test(dependsOnGroups = "job_submit", dataProvider="cmbs_sanity_jobs_run_cusip",priority=6, description="job results sanity check - performance stratifications")
	public void check_cmbs_sanity_job_results_PerformanceStratifications(String jobname, String cusip) throws Exception{
		JobCmbs job = new JobCmbs(initialNewDriver(), this.testedJobs.get(jobname).getJobSettings());
		job.reFreshStatus();
		JobResultCmbs cmbsResult = job.getResult();
		PerformanceStratificationCmbs perforemanceStra = cmbsResult.getPerformanceStratificationInstance(job.driver);
		Set<String> scenariosSet = job.getJobSettings().getScenarios().keySet();
		ArrayList<String> scenariosList = new ArrayList<String>();
		scenariosSet.forEach((scenario)->
		{
			scenariosList.add(scenario);
		});
		if(job.getJobSettings().isScenarioBlended()){
			scenariosList.add("Blended Scenario");
		} else {
			// do nothing
		}
		perforemanceStra.selectToCusip(cusip);
		
		try{	
			for(String scen:scenariosList){
				perforemanceStra.selectToScenario(scen);
				Assert.assertTrue(perforemanceStra.scenarioText.getText().equals("Scenario:"), "Verify the scenario list title is showing");
				Assert.assertTrue(perforemanceStra.cusipText.getText().equals("CUSIP:"),"Verify the cusip list title is displaying");
				Assert.assertEquals(perforemanceStra.top10PropertyTypeTitle.getText(), "PROPERTY TYPE (TOP 10)");
				Assert.assertEquals(perforemanceStra.dscrStratificationTitle.getText(), "DSCR");
				Assert.assertEquals(perforemanceStra.ltvStratificationTitle.getText(), "LTV");
				Assert.assertEquals(perforemanceStra.top10StateTitle.getText(), "STATE (TOP 10)");
				Assert.assertEquals(perforemanceStra.loanSizeTitle.getText(), "LOAN SIZE");			
				
				String starTypeHeaders = Arrays.toString(perforemanceStra.propertyStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(perforemanceStra.top10PropertyTypeTable.findElement(By.xpath("thead/tr")).getText().equals(starTypeHeaders));				
				int straEntrySize = perforemanceStra.top10PropertyTypeTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(straEntrySize >= 2);
				//System.out.println(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("tbody")).getText().replace("\n", " "));
				Assert.assertEquals(perforemanceStra.top10PropertyTypeTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, straEntrySize*perforemanceStra.propertyStratificationFields.length);
				
				
				starTypeHeaders = Arrays.toString(perforemanceStra.dscrStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(perforemanceStra.dscrStratificationTable.findElement(By.xpath("thead/tr")).getText().equals(starTypeHeaders));				
				straEntrySize = perforemanceStra.dscrStratificationTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(straEntrySize >= 2);
				//System.out.println(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("tbody")).getText().replace("\n", " "));
				Assert.assertEquals(perforemanceStra.dscrStratificationTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, straEntrySize*perforemanceStra.dscrStratificationFields.length);
				
				starTypeHeaders = Arrays.toString(perforemanceStra.ltvStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(perforemanceStra.ltvStratificationTable.findElement(By.xpath("thead/tr")).getText().equals(starTypeHeaders));				
				straEntrySize = perforemanceStra.ltvStratificationTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(straEntrySize >= 2);
				//System.out.println(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("tbody")).getText().replace("\n", " "));
				Assert.assertEquals(perforemanceStra.ltvStratificationTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, straEntrySize*perforemanceStra.ltvStratificationFields.length);
				
				starTypeHeaders = Arrays.toString(perforemanceStra.stateStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(perforemanceStra.top10StateTable.findElement(By.xpath("thead/tr")).getText().equals(starTypeHeaders));				
				straEntrySize = perforemanceStra.top10StateTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(straEntrySize >= 2);
				//System.out.println(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("tbody")).getText().replace("\n", " "));
				Assert.assertEquals(perforemanceStra.top10StateTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, straEntrySize*perforemanceStra.stateStratificationFields.length);
				
				starTypeHeaders = Arrays.toString(perforemanceStra.loanSizeStratificationFields).replaceAll("(\\[)(.*?)(\\])", "$2").replaceAll(", ", " ");
				Assert.assertTrue(perforemanceStra.loanSizeTable.findElement(By.xpath("thead/tr")).getText().equals(starTypeHeaders));				
				straEntrySize = perforemanceStra.loanSizeTable.findElements(By.xpath("tbody/tr")).size();
				Assert.assertTrue(straEntrySize >= 2);
				//System.out.println(loanLevelStra.top10PropertyTypeTable.findElement(By.xpath("tbody")).getText().replace("\n", " "));
				Assert.assertEquals(perforemanceStra.loanSizeTable.findElement(By.xpath("tbody"))
						.getText().replaceAll("\n", " ").replaceAll("> ", "").replaceAll("<= ", "<=").split(" ").length
						, straEntrySize*perforemanceStra.loanSizeStratificationFields.length);				
			}
		} catch(Exception ex) {
			throw ex;
		} finally{		
				quitDriver(job.driver);
				quitDriver(cmbsResult.jobCmbs.driver);
		}
	}	
		
	@DataProvider(name = "cmbs_sanity_jobs")
	public Object[][] get_cmbs_sanity_jobs() throws Exception{
		JobCmbs jobs[];
		Object data[][];
		try {
			jobs = DataProviderJobConfigCmbs.readTestCasesConfig(job_config_filePath,portfolioPath);
			data= new Object[jobs.length][2];
			//System.out.println("jobs count to be run: "+jobs.length);
			for(int n = 0; n < jobs.length; n++){
				data[n][1] = jobs[n].getJobSettings().getJobName();
				data[n][0] = jobs[n];
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		return data;
	}
	
	
	@DataProvider(name = "cmbs_sanity_jobs_run",parallel=true)
	public Object[][] get_cmbs_sanity_jobs_run() throws Exception{
		log.info("get data for submitted jobs.");
		Object data[][];
		String jobName = null;
		try {
			//jobs = DataProviderJobConfigCmbs.readTestCasesConfig(job_config_filePath,portfolioPath);
			data= new Object[testedJobsName.size()][1];
			System.out.println("jobs count to be run: "+testedJobsName.size());
			for(int n = 0; n < testedJobsName.size(); n++){
				jobName = testedJobsName.get(n);
				data[n][0] = jobName;
				//data[n][0] = testedJobs.get(jobName);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		return data;
	}	
	
	@DataProvider(name = "cmbs_sanity_jobs_run_cusip",parallel=true)
	public Object[][] get_cmbs_sanity_jobs_run_cusip() throws Exception{
		Object data[][];
		String jobName = null;
		try {
			//jobs = DataProviderJobConfigCmbs.readTestCasesConfig(job_config_filePath,portfolioPath);
			data= new Object[testedJobsName.size()* cusipCount][2];
			//System.out.println("jobs count to be run: "+jobs.length);
			for(int n = 0; n < testedJobsName.size(); n++){
				jobName = testedJobsName.get(n);
				for(int j = 0; j < cusipCount; j++){
					//data[n*cusipCount+j][0] = testedJobs.get(jobName);
					data[n*cusipCount+j][0] = jobName;					
					data[n*cusipCount+j][1] = cusipList.get(j);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		return data;
	}
		
	@DataProvider(name = "cmbs_sanity_jobs_run_cusip_test",parallel=false)
	public Object[][] get_cmbs_sanity_jobs_run_cusip_test() throws Exception{
		Object data[][];
		//String jobName = null;
		HashMap<String, String> scenariosList = new HashMap<String, String>();
		scenariosList.put("CustomScen","25");
		scenariosList.put("MEDC Base","35");
		scenariosList.put("MEDC S4","40");
		try {
			//jobs = DataProviderJobConfigCmbs.readTestCasesConfig(job_config_filePath,portfolioPath);
			data= new Object[4][3];
			String jobName1 = "cmbs_sanity_sim_v3_sherry_20190118145627095";
			String jobName2 = "cmbs_sanity_static_v2_sherry_20190118145607576";
			JobCmbs job1 = new JobCmbs();
			job1.jobSettings.setJobName(jobName1);
			job1.jobSettings.setScenarioBlended(true);
			job1.jobSettings.setScenarios(scenariosList);
			job1.jobSettings.setAsOfDate("2018-10-31");
			job1.jobSettings.setRunType("simulation");
			JobCmbs job2 = new JobCmbs();
			job2.jobSettings.setJobName(jobName2);
			job2.jobSettings.setScenarioBlended(true);
			job2.jobSettings.setScenarios(scenariosList);
			job2.jobSettings.setAsOfDate("2018-10-31");
			job2.jobSettings.setRunType("static");
			this.testedJobs.put(jobName1, job1);
			this.testedJobs.put(jobName2, job2);
			data[0][0] = job1;
			data[0][1] = jobName1;
			data[0][2] = "55375KAL0";
			data[1][0] = job1;
			data[1][1] = jobName1;
			data[1][2] = "05524HAE8";
			data[2][0] = job2;
			data[2][1] = jobName2;
			data[2][2] = "55375KAL0";
			data[3][0] = job2;
			data[3][1] = jobName2;
			data[3][2] = "05524HAE8";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		return data;
	}
	
	@DataProvider(name = "cmbs_sanity_jobs_run_cusip_test2",parallel=false)
	public Object[][] get_cmbs_sanity_jobs_run_cusip_test2() throws Exception{
		Object data[][];
		//String jobName = null;
		HashMap<String, String> scenariosList = new HashMap<String, String>();
		scenariosList.put("CustomScen","25");
		scenariosList.put("MEDC Base","35");
		scenariosList.put("MEDC S4","40");
		try {
			//jobs = DataProviderJobConfigCmbs.readTestCasesConfig(job_config_filePath,portfolioPath);
			data= new Object[4][2];
			String jobName1 = "cmbs_sanity_sim_v3_sherry_20190118145627095";
			String jobName2 = "cmbs_sanity_static_v2_sherry_20190118145607576";
			JobCmbs job1 = new JobCmbs();
			job1.jobSettings.setJobName(jobName1);
			job1.jobSettings.setScenarioBlended(true);
			job1.jobSettings.setScenarios(scenariosList);
			job1.jobSettings.setAsOfDate("2018-10-31");
			job1.jobSettings.setRunType("simulation");
			
			JobCmbs job2 = new JobCmbs();
			
			job2.jobSettings.setJobName(jobName2);
			job2.jobSettings.setScenarioBlended(true);
			job2.jobSettings.setScenarios(scenariosList);
			job2.jobSettings.setAsOfDate("2018-10-31");
			job2.jobSettings.setRunType("static");
			
			this.testedJobs.put(jobName1, job1);
			this.testedJobs.put(jobName2, job2);
			
			data[0][0] = jobName1;
			data[0][1] = "55375KAL0";
			
			data[1][0] = jobName1;
			data[1][1] = "05524HAE8";
			
			data[2][0] = jobName2;
			data[2][1] = "55375KAL0";
			
			data[3][0] = jobName2;
			data[3][1] = "05524HAE8";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
		return data;
	}

}
