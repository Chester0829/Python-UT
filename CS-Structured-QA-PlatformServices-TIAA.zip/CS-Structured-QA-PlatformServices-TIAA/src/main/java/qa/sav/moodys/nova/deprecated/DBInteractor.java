package qa.sav.moodys.nova.deprecated;

import java.sql.*;


public class DBInteractor {
	
	private String hostname = null;
	private String database = null;
	private String user = null;
	private String password = null;
	
	private Connection connector = null;
	private Statement statement = null;
	private ResultSet resultSet = null;
	
	public DBInteractor(){};
	
	public DBInteractor(String hostname1, String database1, String user1, String password1){
		hostname = hostname1;
		database = database1;
		user = user1;
		password = password1;
	}
	
	private void initConnection() throws SQLException, ClassNotFoundException{
		if(connector == null ){	
			
			connector = DriverManager.getConnection("jdbc:mysql://"+hostname+"/"+database+"?" + "user="+user+"&password="+password);
			Log.info("Connecting to mysql with user " +user +"...");
			Log.info("jdbc:mysql://"+hostname+"/"+database+"?" + "user="+user+"&password=******");
			
            Class.forName("com.mysql.jdbc.Driver");
            Log.info("Succefully loaded mysql jdbc driver");
                
            statement = this.getConnector().createStatement();  
            Log.info("Succefully connected to database ");

			   
//			} catch (SQLException ex) {
//			    // handle any errors
//			    Log.error("SQLException: " + ex.getMessage());
//			    Log.error("SQLState: " + ex.getSQLState());
//			    Log.error("VendorError: " + ex.getErrorCode());
//			}
		}
		else {
			Log.info("connector has been created ");
		}
	}
	
	public void closeConnection() throws SQLException{
		
		if(!resultSet.isClosed()){
			resultSet.close();
		}
		

		if(!statement.isClosed()){
			statement.close();
		}
		
		if(!connector.isClosed()){
			connector.close();
		}
		
		Log.info("Connector closed : " + (connector.isClosed()));
		Log.info("Statement closed : " + (statement.isClosed()));
		Log.info("ResultSet closed : " + (statement.isClosed()));
	
	}
	
	
	public ResultSet databaseOperator(String sql) throws SQLException, ClassNotFoundException{
 
			if(connector == null){
				initConnection();
			}
 
            resultSet = statement.executeQuery(sql);//
            Log.info("Execute SQL Statement: \n" + sql);
            
            return resultSet;

	}
	
	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getDatabase() {
		return database;
	}

	public void setDatabase(String database) {
		this.database = database;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Connection getConnector() {
		return connector;
	}	
	
	public void setConnector(Connection connector){
		this.connector = connector;  
	}
	

	
}

