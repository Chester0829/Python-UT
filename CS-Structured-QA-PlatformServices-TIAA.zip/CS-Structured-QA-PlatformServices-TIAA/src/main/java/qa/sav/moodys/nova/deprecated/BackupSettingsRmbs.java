package qa.sav.moodys.nova.deprecated;

import org.openqa.selenium.WebDriver;

import qa.sav.moodys.nova.pages.PageBase;
import qa.sav.moodys.nova.pages.launch.DefaultValuesRmbs;

public class BackupSettingsRmbs extends PageBase{
	

	public BackupSettingsRmbs(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public boolean backupDefaultValues() throws Exception{
		String outputCsvFileFullName = config.getProperty("rmbs_defaultValue");
		
		DefaultValuesRmbs defaultValuesRmbs = new DefaultValuesRmbs(driver);
		defaultValuesRmbs.exportValuesToCsv(outputCsvFileFullName);
		
		return false;
	}
	
	public boolean backupGlobalValues(String currentDate){
		return false;
	}
	
	public boolean backupRattingMappins(String currentDate){
		return false;
	}
	
	private String getbackupFolder(){
		String backupFolder = null;
		
		return backupFolder;
	}
	
}
