package qa.sav.moodys.nova.pages.jobResult;

import java.io.File;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import qa.sav.moodys.nova.JobCmbs;

public class CollateralCashflowsCmbs extends JobResultTabCmbs{
	
	public CollateralCashflowsCmbs(WebDriver driver, JobCmbs job)
			throws Exception {
		
		super(driver, job);

		// TODO Auto-generated constructor stub
		this.goToCollateralCashflowsTab();
	}

	public String cashflowFields[] = {
			"Date",
			"LIBOR(6month)",
			"Amortized Amount",
			"Interest Payment",
			"Prepayment Amount",
			"Defaulted Balance",
			"Recovery Amount",
			"Loss Amount",
			"Pool Balance",
			"Non IO Pool Balance",
			"CDR",
			"CPR",
			"Severity",
			"LCDR"
	};
	
	public HashMap<String, Integer> cashflowIndexMapping = new HashMap<String, Integer>(){
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
	
		{
			put("Date",1);
			put("LIBOR(6month)",2);
			put("Amortized Amount",3);
			put("Interest Payment",4);
			put("Prepayment Amount",5);
			put("Defaulted Balance",6);
			put("Recovery Amount",7);
			put("Loss Amount",8);
			put("Pool Balance",9);
			put("Non IO Pool Balance",10);
			put("CDR",11);
			put("CPR",12);
			put("Severity",13);
			put("LCDR",14);
		}		
	};
	
	@FindBy(xpath = "//*[@id=\"colla_scenario\"]")
	public WebElement choseScenario;

	@FindBy(xpath = "//*[@id=\"colla_cusip\"]")
	public WebElement choseCusip;
	
	@FindBy(xpath = "//*[@id=\"collaCashflow\"]/div/div/form/span[1]")
	public WebElement scenarioText;
	
	@FindBy(id = "select2-chosen-3")
	public WebElement clickChoseScenario;
	
	@FindBy(xpath = "//*[@id=\"collaCashflow\"]/div/div/form/span[2]")
	public WebElement cusipText;
	
	@FindBy(id = "select2-chosen-4")
	public WebElement clickChoseCusip;
		
	@FindBy(xpath="//*[@id=\"btn-export-overview\"]")
	public WebElement exportButton;
	
	@FindBy(xpath = "//*[@id=\"chk-confidence-colla\"]")
	public WebElement clickExportAllConfidenceLevels;
	
	@FindBy(xpath = "//*[@id=\"collaCashflowContent\"]/div[1]/div[1]")
	public WebElement collateralCashflowTitleText;
	
	@FindBy(xpath = "//*[@id=\"table-portfolio-alerts\"]/thead/tr")
	public WebElement collateralCashflowHeaderRow;
	
	@FindBy(xpath = "//*[@id=\"table-portfolio-alerts\"]/tbody")
	public WebElement cashflowTableBody;
		
	public void exportCollateralCashflowByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectToScenario(scenario);
		this.selectToCusip(cusip);
		this.downloadFile(this.exportButton, new File("C:\\temp\\"));
		this.waitForAjaxLoaded();
	}
	
	public void exportAllConfidenceLevelsCollateralCashflowByScenarioAndCusip
	(String scenario, String cusip) throws Exception{
		this.selectToScenario(scenario);
		this.selectToCusip(cusip);
		if(this.clickExportAllConfidenceLevels.isSelected()){
			// already checked all confidence levels, do nothing
		} else {
			this.clickExportAllConfidenceLevels.click();
			this.waitForAjaxLoaded();
		}
		this.downloadFile(this.exportButton, new File("C:\\temp\\"));
	}
	
	public String getTotalAmortizedAmountByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectScenarioAndCusip(scenario, cusip);
		String totalAmortizedAmount = null;
		totalAmortizedAmount = this.cashflowTableBody.findElement(
				By.xpath("tr[1]/th[2]/span")).getText();
		return totalAmortizedAmount;
	}
	
	public String getTotalInterstPaymentByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectScenarioAndCusip(scenario, cusip);
		String totalInterestPayment = null;
		totalInterestPayment = this.cashflowTableBody.findElement(
				By.xpath("tr[1]/th[3]/span")).getText();
		return totalInterestPayment;
	}
	
	public String getTotalPrepaymentAmountByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectScenarioAndCusip(scenario, cusip);
		String totalPrepaymentAmount = null;
		totalPrepaymentAmount = this.cashflowTableBody.findElement(
				By.xpath("tr[1]/th[4]/span")).getText();
		return totalPrepaymentAmount;
	}
	
	public String getTotalDefaultedBalanceByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectScenarioAndCusip(scenario, cusip);
		String totalDefaultedBalance = null;
		totalDefaultedBalance = this.cashflowTableBody.findElement(
				By.xpath("tr[1]/th[5]/span")).getText();
		return totalDefaultedBalance;
	}
	
	public String getTotalRecoveryAmountByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectScenarioAndCusip(scenario, cusip);
		String totalRecoveryAmount = null;
		totalRecoveryAmount = this.cashflowTableBody.findElement(
				By.xpath("tr[1]/th[6]/span")).getText();
		return totalRecoveryAmount;
	}
	
	public String getTotalLossAmountByScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectScenarioAndCusip(scenario, cusip);
		String totalLossAmount = null;
		totalLossAmount = this.cashflowTableBody.findElement(
				By.xpath("tr[1]/th[7]/span")).getText();
		return totalLossAmount;
	}
	
	public String getDealUpdatedDateByScenarioAndCusip
	(String scenario,String cusip) throws Exception{
		String dealUpdatedDate = null;
		this.selectScenarioAndCusip(scenario, cusip);
		dealUpdatedDate = cashflowTableBody.findElement(
				By.xpath("tr[2]/td["+cashflowIndexMapping.get("Date")+"]")).getText();				
		return dealUpdatedDate;		
	}
	
	public int getCashflowSizeByScenarioAndCusip(String scenario, String cusip){
		int cashflowLength =  this.cashflowTableBody.findElements(By.xpath("tr")).size()-1;
		return cashflowLength;
	}
	
	public String getMaturityDateByScenarioAndCusip(String scenario, String cusip){
		int cashflowSize = this.getCashflowSizeByScenarioAndCusip(scenario, cusip);
		return this.cashflowTableBody.findElement(By.xpath("tr["+(cashflowSize-1)+"]/td["+this.cashflowIndexMapping.get("Date")+"]")).getText();
	}
	
	public String getFirstPayDateByScenarioAndCusip
	(String scenario,String cusip) throws Exception{
		String firstPayDate = null;
		this.selectScenarioAndCusip(scenario, cusip);
		int cashflowLength =  this.cashflowTableBody.findElements(By.xpath("tr")).size()-1;
		int dateCollumnIndex = cashflowIndexMapping.get("Date");
		int i = 2;
		String amortizedAmount, interestPayment = null;
		while(i <= cashflowLength + 1){
			amortizedAmount = this.cashflowTableBody.findElement(
					By.xpath("tr["+i+"]/td["+this.cashflowIndexMapping.get("Amortized Amount")+"]/span")).getText();
			interestPayment = this.cashflowTableBody.findElement(
					By.xpath("tr["+i+"]/td["+this.cashflowIndexMapping.get("Interest Payment")+"]/span")).getText();
			//System.out.println("amortized amount for period "+(i-1)+": "+amortizedAmount);
			if(amortizedAmount.equals("0.00")&&interestPayment.equals("0.00")){
				i++;
			} else {
				firstPayDate = this.cashflowTableBody.findElement(
						By.xpath("tr["+i+"]/td["
								+dateCollumnIndex+"]")).getText();
				break;
			}
			
		}
		
		return firstPayDate;		
	}
	
	public String[] getcashflowHearderFieldsByScenarioAndCusip(String scenario, String Cusip){
		int headerFiledsCount = this.collateralCashflowHeaderRow.findElements(By.xpath("th")).size(); 
		String[] collateralCashflowHearderFields = new String[headerFiledsCount];
		for(int i = 0; i < headerFiledsCount; i++ ){
			collateralCashflowHearderFields[i] = this.collateralCashflowHeaderRow.findElement(By.xpath("th["+(i+1)+"]")).getText();
		}			
		return collateralCashflowHearderFields;		
	}
	
	public String[] getScenariosList() throws Exception{	
		clickChoseScenario.click();
		this.waitForAjaxLoaded();
		return this.getScenariosList(choseScenario);
	}
	
	public String[] getCusipsList() throws Exception{
		clickChoseCusip.click();
		this.waitForAjaxLoaded();
		return this.getCusipsList(choseCusip);
	}
	
	public void selectScenarioAndCusip(String scenario, String cusip) throws Exception{
		this.selectToScenario(scenario);
		this.selectToCusip(cusip);
	}
	
	public void selectToScenario(String scenario) throws Exception{
		
		if(clickChoseScenario.getText().equals(scenario)){
			//scenario alread selected, do nothing
		} else {
			clickChoseScenario.click();
			this.waitForAjaxLoaded();
			Select choseScenarioSelector = new Select(choseScenario);
			choseScenarioSelector.selectByVisibleText(scenario);
			this.waitForAjaxLoaded();
		}
	}
	
	public void selectToCusip(String cusip) throws Exception{
		
		if(clickChoseCusip.getText().equals(cusip)){
			// cusip alread selected, do nothing
		} else {
			clickChoseCusip.click();
			this.waitForAjaxLoaded();
			Select choseCusipSelector = new Select(choseCusip);
			choseCusipSelector.selectByVisibleText(cusip);
			this.waitForAjaxLoaded();
		}
	}
}
