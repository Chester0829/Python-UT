#if [ -z $JAVA_HOME ]; then
#	echo "the JAVA_HOME is  empty."
#	javaExe=${JAVA_HOME}/bin/java
#fi

if command -v java >/dev/null 2>&1; then 
  javaExe=java 
else
	echo  "can't find java commond"
	exit  1;
fi

scriptPath=`readlink  -f  "$0"`
scriptFolder=`dirname "$scriptPath"`

classPath=""
for  f in "$scriptFolder"/lib/*.jar; do 
	classPath=${classPath}${f}":"
done
classPath=${classPath}"${scriptFolder}"/conf
#-agentlib:jdwp=transport=dt_socket,address=8000,server=y,suspend=y
echo $javaExe  -DbasePath=$scriptFolder  -classpath $classPath   qa.sav.moodys.nova.test.App
nohup $javaExe  -DbasePath=$scriptFolder  -classpath $classPath   qa.sav.moodys.nova.test.App&
