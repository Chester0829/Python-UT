package qa.sav.moodys.nova.test;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import com.google.common.collect.MapDifference.ValueDifference;

import qa.sav.moodys.nova.utils.CsvUtils_Map;
import qa.sav.moodys.nova.utils.MapDiffUtil;

public class testMapDiffUtil {

	@Test
    public void compareJobResults() throws Exception{
    	HashMap<String, String> benchCmbsScen01 = (new CsvUtils_Map()).mapJobResultToKeyValue("C:\\TIAA\\AUTO\\5425\\AWS\\TrancheCashFlows.csv");
    	HashMap<String, String> regCmbsScen01 = (new CsvUtils_Map()).mapJobResultToKeyValue("C:\\TIAA\\AUTO\\5425\\AWS\\TrancheCashFlows2.csv");
    	HashMap<String, String> reg3CmbsScen01 = (new CsvUtils_Map()).mapJobResultToKeyValue("C:\\TIAA\\AUTO\\5425\\AWS\\TrancheCashFlows3.csv");

    	MapDiffUtil mapDiff = new MapDiffUtil(benchCmbsScen01,reg3CmbsScen01);
    	mapDiff.validateEqual();
    	System.out.println(mapDiff.isDifferentFlag());
    	
    	Map<String, String> leftMap = mapDiff.getOnlyOnLeft();
    	Map<String, ValueDifference<String>> differMap = mapDiff.getDiffering();
    	System.out.println(leftMap.size());
    	for(String key : leftMap.keySet()){
			System.out.println(key);
			System.out.println(leftMap.get(key)+"\n");
		}    	
    	
    	for(String key:differMap.keySet()){
    		System.out.println(key);
    		System.out.println(differMap.get(key)+"\n");
    	}
    }
	
}
