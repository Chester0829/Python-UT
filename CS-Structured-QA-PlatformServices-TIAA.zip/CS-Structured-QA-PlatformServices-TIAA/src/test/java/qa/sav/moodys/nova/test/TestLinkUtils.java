package qa.sav.moodys.nova.test;


import org.testng.annotations.Test;




import qa.sav.moodys.nova.testcases.base.TestCaseBase;
import testlink.api.java.client.TestLinkAPIClient;
import testlink.api.java.client.TestLinkAPIException;
import testlink.api.java.client.TestLinkAPIResults;


public class TestLinkUtils extends TestCaseBase {

public static String DEV_KEY = "e9c0efd024370756b20bca1158505972"; //Your API  b7b92611e8ff60e20f7410b593e5b25f

public static String SERVER_URL = "http://sf1-lgsdwktst.analytics.moodys.net:81/testlink/lib/api/xmlrpc/v1/xmlrpc.php"; //"http://localhost/testlink/site/index.php"; //your testlink server url
public static String PROJECT_NAME = "NOVA"; 
public static String PLAN_NAME = "Testing";
public static String BUILD_NAME = "TestBuild";


@Test
public void TestOne() throws Exception
{
	String result = "";
	String exception = null;
	try{
	
	result = TestLinkAPIResults.TEST_PASSED;
	updateTestLinkResult("TIAA-3", null, result);
	} 
	catch (Exception e){
	result = TestLinkAPIResults.TEST_FAILED;
	exception = e.getMessage();
	updateTestLinkResult("TIAA-3", exception, result);
	}
	try {
	
	result = TestLinkAPIResults.TEST_PASSED;
	updateTestLinkResult("TIAA-4", null, result);
	} 
	catch (Exception e) {
	result = TestLinkAPIResults.TEST_FAILED;
	exception = e.getMessage();
	updateTestLinkResult("TIAA-4", exception, result);
	}
	}
	private void updateTestLinkResult(String testCase, String exception, String result) throws TestLinkAPIException{
		TestLinkAPIClient testlinkAPIClient = new TestLinkAPIClient(DEV_KEY, SERVER_URL);
		testlinkAPIClient.reportTestCaseResult(PROJECT_NAME, PLAN_NAME, testCase, BUILD_NAME, exception, result);
	}
	
}