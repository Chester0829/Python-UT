package qa.sav.moodys.nova.test;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.pages.Login;
import qa.sav.moodys.nova.testcases.base.TestCaseBase;

public class TestLoginPage extends TestCaseBase {
 

	@Test
	public void testLoginPageNormal() throws Throwable{
		
		Login login = new Login(driver);
		
			try {
				login.loginToDashboard();
				log.info("Jumped to page " + driver.getCurrentUrl());
				Assert.assertEquals(true, driver.getCurrentUrl().contains("dashboard"));
			} catch(AssertionError | Exception err){
				screenShot.getScreenshot(driver, getClass().getSimpleName());
				log.error("Failed to login to "+ env.getProperty("Environment")+" with user = "+ login.user);
				err.printStackTrace();
				throw err;
			}	
	}
	
	@Test
	public void testLoginPageNormal2() throws Throwable {
		
		Login login = new Login(driver);
		
			try {
				log.info("Login to " + login.url + "with user \"qins\"");
				login.loginToDashboard("qins","Rdis2fun");
				log.info("Jumped to page " + driver.getCurrentUrl());
				Assert.assertEquals(true, driver.getCurrentUrl().contains("dashboard"));				
			} catch(AssertionError | InterruptedException err){
				screenShot.getScreenshot(driver, getClass().getSimpleName());
				log.error("Failed to login to "+ env.getProperty("Environment")+" with user = "+ "qins");
				err.printStackTrace();
				throw err;
			}
	
	}
	
	//@Test
	public void testLoginPageErrorPassword() throws Throwable{
		Login login = new Login(driver);

			try {
				log.info("Login to " + login.url + " with user \"qins\" and a wrong password");				
				login.loginToDashboard("qins","123456"); 
				String errorMsg = driver.findElement(By.xpath("//*[@id=\"login\"]/div[1]/div")).getText();
				Assert.assertEquals(errorMsg, "Login failed. The username or password is not correct!");
			} catch(AssertionError | InterruptedException err){
				screenShot.getScreenshot(driver, getClass().getSimpleName());
				log.error("Failed to login to "+ env.getProperty("Environment")+" with user = "+ login.user);
				err.printStackTrace();
				throw err;
			}
	
	}
	
	
}
