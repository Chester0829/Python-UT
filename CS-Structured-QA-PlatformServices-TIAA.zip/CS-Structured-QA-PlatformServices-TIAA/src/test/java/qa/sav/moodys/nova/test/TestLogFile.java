package qa.sav.moodys.nova.test;

import org.testng.annotations.Test;

import qa.sav.moodys.nova.testcases.base.TestCaseBase;

public class TestLogFile extends TestCaseBase {
	
	@Test
	public void ttTestLog(){		
		log.info("This is an info log message");
		log.debug("This is a debug log message");
		log.error("This is an error log message");
		
	}
}
