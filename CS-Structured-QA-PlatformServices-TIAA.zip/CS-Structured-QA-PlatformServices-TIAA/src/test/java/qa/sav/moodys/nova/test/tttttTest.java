package qa.sav.moodys.nova.test;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.pages.Login;

public class tttttTest {
	
	WebDriver driver;
	@FindBy(xpath = "//*[@id=\"username\"]")
	public WebElement usrNameSet;
	
	public tttttTest(){
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")
				+ File.separator+"driver"+File.separator+"chromedriver.exe");
		this.driver = new ChromeDriver();
	}
	@Test
	public void test() throws Exception{
		tttttTest tttest = new tttttTest();
		//WebDriver driver = new ChromeDriver();
		tttest.driver.get("http://10.32.167.228:8080/sf-simulation/login");
		Thread.sleep(1000*30);
		tttest.usrNameSet.clear();
	}
}
