package qa.sav.moodys.nova.test;

import org.testng.annotations.Test;

import qa.sav.moodys.nova.pages.DscrLtvOverrideCmbs;
import qa.sav.moodys.nova.pages.EconomicScenarioCmbs;
import qa.sav.moodys.nova.pages.GlobalValueCmbs;
import qa.sav.moodys.nova.pages.LaunchCmbs;
import qa.sav.moodys.nova.testcases.base.TestCaseBase;

public class testCmbsLaunch extends TestCaseBase {

	//@Test
	public void tttest() throws Exception{
		LaunchCmbs cmbs = new LaunchCmbs(driver);
		
		cmbs.setCmmVersion("V3");
		cmbs.setSimulationPaths("1000");
		cmbs.setCmmForecastValue("Fall 2017");
		log.info("Cmm Forecast: " + cmbs.getCmmForecastValue());
		log.info("Cmm Model Vesion: " + cmbs.getCmmVersion());
		log.info("simulation paths: " + cmbs.getSimulationPathsValue());
		
		GlobalValueCmbs gCmbs = new GlobalValueCmbs(driver);
		gCmbs.setOptimizationPercentageLevel("11");
		log.info(gCmbs.readOptimizationPercentageLevel());
		gCmbs.setTailPercetageLevel("5.5");
		log.info(gCmbs.readTailPercentageLevel());
		gCmbs.setHopeNotesOverride(true);
		
		gCmbs.setNoiGrowthRateCapPctEnable(true);
		gCmbs.setNoiGrowthRateCapPctValue("55");
		
		gCmbs.setCollateralType("Other");
		gCmbs.saveChangeIfAlerts(false);
		log.info(gCmbs.readCollateralType());
		
		gCmbs.setCollateralType("CMBS - Single Borrower");
		gCmbs.saveChangeIfAlerts(true);
		log.info(gCmbs.readCollateralType());
		gCmbs.closeGlobalValuePopUp();
		Thread.sleep(1000*3);		
		Thread.sleep(1000*30);
	}

	@Test
	public void ttestDscrLtvValues() throws Exception{
		DscrLtvOverrideCmbs dlcmbs = new DscrLtvOverrideCmbs(driver);
		dlcmbs.setUseAverageValueSetting(false);
		dlcmbs.setDscrLtvType("Sherry");
		dlcmbs.applySettings();
		
		//Thread.sleep(1000);		
		dlcmbs = new DscrLtvOverrideCmbs(driver);
		
		dlcmbs.setUseAverageValueSetting(false);
		dlcmbs.applySettings();
		
		EconomicScenarioCmbs ecoCmbs = new EconomicScenarioCmbs(driver);
		
		//Map scenMap = new HashMap(<String>);
		//ecoCmbs.checkedScenarios(scenariosBlendedMap, blended);
		Thread.sleep(1000*30);
		
	}
	
	
}
