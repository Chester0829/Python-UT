package qa.sav.moodys.nova.test;

import java.util.HashMap;

import org.testng.annotations.Test;

import qa.sav.moodys.nova.JobCmbs;
import qa.sav.moodys.nova.data.JobSettings;
import qa.sav.moodys.nova.data.JobStatus;
import qa.sav.moodys.nova.data.JobsMulCmbs;
import qa.sav.moodys.nova.testcases.base.TestCaseBase;

public class TestJobCmbs extends TestCaseBase{	
	
	@Test
	public void ttest() throws Exception{

		HashMap<String, String> economics = new HashMap<String, String>();
		economics.put("MEDC Base", "40");
		economics.put("CustomScen", "25");
		economics.put("MEDC S4", "35");
		
		JobSettings settings = new JobSettings();
		settings.setPortfoliofile("C:\\SAV\\QA\\TIAA\\Release\\20180907\\nova_911\\launchCmbsInput_1.csv");
		settings.setRunType("simulation");
		settings.setAsOfDate("2018-08-31");
		settings.setCmmForecast("Summer 2018");
		settings.setForceSync(false);
		settings.setConfidenceLevelPercentage("95");
		settings.setTailPercentageLevl("10");
		settings.setOptimizationPercentageLevel("5");
		settings.setCmmVersion("V2");
		settings.setSimPaths("10000");
		settings.setDscrLtv("use average");
		settings.setScenarios(economics);
		settings.setScenarioBlended(false);
		settings.setJobName("sanity_test_automation");
		
		JobCmbs job = new JobCmbs(driver,settings);	
		job.run(false);
		JobStatus status = job.status();
		System.out.println("new luanched cmbs job: \n"+status.getName()
				+ "\n" + status.getBusinessType()
				+ "\n" + status.getJobID()
				+ "\n" + status.getSubmitTime()
				+ "\n" + status.getStartTime()
				+ "\n" + status.getEndTime()
				+ "\n" + status.getSubmittedBy()
				+ "\n" + status.getJobResultStatus()
				+ "\n" + status.getRunStatus()
		);	
		JobsMulCmbs jobReproduce = job.reload(false,"cmbs_reproduce");
		//job.setJobStatus(job.status());		
		status = jobReproduce.getNewjob().status();
		System.out.println("reloaded cmbs job: \n"+status.getName()
				+ "\n" + status.getBusinessType()
				+ "\n" + status.getJobID()
				+ "\n" + status.getSubmitTime()
				+ "\n" + status.getStartTime()
				+ "\n" + status.getEndTime()
				+ "\n" + status.getSubmittedBy()
				+ "\n" + status.getJobResultStatus()
				+ "\n" + status.getRunStatus()
		);
		status = jobReproduce.getOriginalJob().getJobStatus();
		System.out.println("reloaded cmbs job-old: \n"+status.getName()
				+ "\n" + status.getBusinessType()
				+ "\n" + status.getJobID()
				+ "\n" + status.getSubmitTime()
				+ "\n" + status.getStartTime()
				+ "\n" + status.getEndTime()
				+ "\n" + status.getSubmittedBy()
				+ "\n" + status.getJobResultStatus()
				+ "\n" + status.getRunStatus()
		);
		
		
	}
}
