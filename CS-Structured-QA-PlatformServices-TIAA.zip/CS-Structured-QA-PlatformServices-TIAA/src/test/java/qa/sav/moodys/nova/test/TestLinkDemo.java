package qa.sav.moodys.nova.test;

import qa.sav.moodys.nova.testcases.base.TestCaseBase;

public class TestLinkDemo extends TestCaseBase {

}
