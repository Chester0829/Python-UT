package qa.sav.moodys.nova.test;

import java.io.IOException;
import java.sql.*;

import org.testng.annotations.Test;

import qa.sav.moodys.nova.data.JobStatus;
import qa.sav.moodys.nova.deprecated.CsvUtils_JobResults;
import qa.sav.moodys.nova.testcases.base.TestCaseBase;
import qa.sav.moodys.nova.utils.JdbcUtils_DBCP;

import org.apache.logging.log4j.Logger;

public class TestCsvUtils_JobResults {
	
	private static Logger log = TestCaseBase.log;
	
	@Test
	public void testCsvWriting() throws IOException, ClassNotFoundException, SQLException{
		
		JobStatus jobResult = new JobStatus();
		jobResult.setDataSource("UI_Expoort");
		jobResult.setJobID(1);
		jobResult.setBusinessType("cmbs");
		jobResult.setRunType("static");
		
		CsvUtils_JobResults csv = new CsvUtils_JobResults();
		String inputCsvData = csv.addJobInfomation(jobResult, "C:/SAV/QA/Nova/Auto/try/OverviewProfile.csv");
		
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;

		String sql = " LOAD DATA LOCAL INFILE '"+inputCsvData+"' INTO TABLE cmbs_overview_profile "+
				  "FIELDS TERMINATED BY ',' "
				  +"LINES TERMINATED BY '\r\n' "
				  + "IGNORE 1 LINES";
		
		try{
			
			connection = JdbcUtils_DBCP.getConnection();
			statement = connection.prepareStatement(sql);
			statement.executeQuery(sql);
		 
			statement.close();
			
			statement = connection.prepareStatement("select * from cmbs_overview_profile");
			resultSet = statement.executeQuery("select * from cmbs_overview_profile");
			
			while (resultSet.next()){
            log.info(resultSet.getString("datasource")+"/"
             			+ Integer.toString(resultSet.getInt("JobID"))+"/" 
             			+ resultSet.getString("JobType") + "/"
             			+ resultSet.getString("BusinessType")
             			);
          } 
			
		} catch(Exception e){
			e.printStackTrace();
        	  
		} finally{
			JdbcUtils_DBCP.release(connection, statement, resultSet);
		}
		
	}
		
	
	
}
