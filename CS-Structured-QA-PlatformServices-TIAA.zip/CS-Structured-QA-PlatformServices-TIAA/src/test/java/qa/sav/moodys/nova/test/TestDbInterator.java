package qa.sav.moodys.nova.test;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.testng.annotations.Test;
import org.apache.logging.log4j.Logger;

import qa.sav.moodys.nova.deprecated.CsvUtils_JobResults;
import qa.sav.moodys.nova.deprecated.DBInteractor;
import qa.sav.moodys.nova.testcases.base.TestCaseBase;


public class TestDbInterator {
	private static Logger log = TestCaseBase.log;

	@Test
	public void testDbConnection() throws ClassNotFoundException, SQLException{
		DBInteractor db1 = new DBInteractor("localhost","novatesting","qins","Rdis2fun");
		CsvUtils_JobResults csvOperator = new CsvUtils_JobResults();
		
		ResultSet resultSet = db1.databaseOperator("select * from abs_overview_profile");
		while (resultSet.next()){
            log.info(resultSet.getString("datasource")+"/"
             			+ Integer.toString(resultSet.getInt("JobID"))+"/" 
             			+ resultSet.getString("JobType") + "/"
             			+ resultSet.getString("BusinessType")
             			);
          }
		db1.closeConnection();
	}
	
}
