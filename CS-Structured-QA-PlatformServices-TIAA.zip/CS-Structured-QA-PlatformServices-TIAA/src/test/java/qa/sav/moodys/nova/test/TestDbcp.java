package qa.sav.moodys.nova.test;

import java.sql.*;

import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.testcases.base.TestCaseBase;
import qa.sav.moodys.nova.utils.JdbcUtils_DBCP;

public class TestDbcp {
	private static Logger log = TestCaseBase.log;
	
	@Test
	public void dbcpDataSourceTest(){
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {
            //get database connection
            connection = JdbcUtils_DBCP.getConnection();
            String sql = "select * from cmbs_overview_profile";
            statement = connection.prepareStatement(sql);
            resultSet = statement.executeQuery(sql);
            while (resultSet.next()){
                log.info(resultSet.getString("datasource")+"/"
                 			+ Integer.toString(resultSet.getInt("JobID"))+"/" 
                 			+ resultSet.getString("JobType") + "/"
                 			+ resultSet.getString("BusinessType")
                 			);
              }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
             //release connection
           JdbcUtils_DBCP.release(connection, statement, resultSet);
        }
    }
}
