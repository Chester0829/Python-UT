package qa.sav.moodys.nova.test;

import org.testng.annotations.Test;

import qa.sav.moodys.nova.data.JobStatus;
import qa.sav.moodys.nova.pages.Dashboard;
import qa.sav.moodys.nova.testcases.base.TestCaseBase;

public class TestDashboadPage extends TestCaseBase {

	@Test
	public void ttest() throws Exception{
		Dashboard dashboard = new Dashboard(driver);
//		dashboard.setTablePageLength("10");
//		dashboard.clickToNextPage();
//		Thread.sleep(1000*20);
//		dashboard.clickToPrevioursPage();
//		Thread.sleep(1000*20);
		JobStatus status = null; //dashboard.getFirstJobStatusByName("abs_sanity_sim");
//		System.out.println(status.getName()
//				+ "\n" + status.getBusinessType()
//				+ "\n" + status.getJobID()
//				+ "\n" + status.getSubmitTime()
//				+ "\n" + status.getStartTime()
//				+ "\n" + status.getEndTime()
//				+ "\n" + status.getSubmittedBy()
//				+ "\n" + status.getJobID()
//		);
		status = dashboard.getJobStatus(7907, "sanity");
		
		System.out.println(status.getName()
				+ "\n" + status.getBusinessType()
				+ "\n" + status.getJobID()
				+ "\n" + status.getSubmitTime()
				+ "\n" + status.getStartTime()
				+ "\n" + status.getEndTime()
				+ "\n" + status.getSubmittedBy()
				+ "\n" + status.getJobID()
		);
		
		Thread.sleep(1000*10);
		
	}
	
}
