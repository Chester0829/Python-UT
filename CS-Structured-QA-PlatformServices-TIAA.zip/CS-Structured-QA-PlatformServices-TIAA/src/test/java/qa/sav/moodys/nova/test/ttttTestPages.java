package qa.sav.moodys.nova.test;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import qa.sav.moodys.nova.data.JobSettingsRmbs;
import qa.sav.moodys.nova.pages.DefaultValuesRmbs;
import qa.sav.moodys.nova.pages.EconomicScenarioRmbs;
import qa.sav.moodys.nova.pages.GlobalValueRmbs;
import qa.sav.moodys.nova.pages.HomePage;
import qa.sav.moodys.nova.pages.LaunchRmbs;
import qa.sav.moodys.nova.pages.Login;
import qa.sav.moodys.nova.pages.RatingMappingsRmbs;
import qa.sav.moodys.nova.testcases.base.TestCaseBase;

public class ttttTestPages extends TestCaseBase{
	
	JobSettingsRmbs jobrmbs = new JobSettingsRmbs();
	
	private void setJobConfigRmbs(){
		jobrmbs.setAsOfDate("2016-12-30");
		jobrmbs.setBusinessType("rmbs");
		jobrmbs.setRunType("simulation");
		jobrmbs.setHorizon("20-1");
		//jobrmbs.setRunType("static");
		jobrmbs.setConfidenceLevelPercentage("95.6");
		jobrmbs.setTailPercentageLevl("6");
		jobrmbs.setOptimizationPercentageLevel("11");
		jobrmbs.setUseTargeLgd(true);
		jobrmbs.setUseSystemBookPrice(false);
	}
	
	//@Test
	public void testLaunchRmbs() throws Exception{
		LaunchRmbs launchRmbs = new LaunchRmbs(driver);
		launchRmbs.loadPortfolio("C:\\SAV\\QA\\Nova\\lauch_csv\\rmbs_auto_sync_launch.csv");
		
		launchRmbs.autoSyncDeal(true);
		log.info(launchRmbs.readSubmitJobAlert());
		Thread.sleep(1000*30);
	}
	
	//@Test
	public void testRmbsRatingMap() throws Exception{
		RatingMappingsRmbs rmbsRating = null;
		
		if(rmbsRating == null){
			rmbsRating = new RatingMappingsRmbs(driver);
		}	
		
		rmbsRating.selectRatingMapType("Default");
		rmbsRating.switchToDefaultMappingTab();
		rmbsRating.importFromCsv("C:\\SAV\\QA\\Nova\\lauch_csv\\rating\\backup\\rmbs\\RatingMapping-Default.csv");	
		
		rmbsRating.switchToExpectLossTab();
		rmbsRating.importFromCsv("C:\\SAV\\QA\\Nova\\lauch_csv\\rating\\backup\\rmbs\\RatingMapping-ExpectLoss.csv");
		
		rmbsRating.saveChanges();
		
		rmbsRating.applyToClose();
		Thread.sleep(1000*30);
	}
	
	
	@Test
	public void testRmbsEconScenario() throws Exception{
		this.setJobConfigRmbs();
		HashMap<String, String> scenariosList = new HashMap<String, String>();
		scenariosList.put("MA Base - Base Case", "20");
		scenariosList.put("FEDS", "");
		scenariosList.put("BNY_FEDB", "80");
		EconomicScenarioRmbs econScenRmbs =  null; 
		
		if(econScenRmbs == null){
			econScenRmbs = new EconomicScenarioRmbs(driver);
		} 
		
		econScenRmbs.setScenarios(scenariosList, true);
		
		econScenRmbs.applyCurrentChanges();
		
		econScenRmbs = new EconomicScenarioRmbs(driver);
		econScenRmbs.goToCreateNewEconWindow();
		econScenRmbs.importNewEconSetting("C:\\Users\\qins\\Downloads\\rmbs_economic_scenario_sample.csv");
		econScenRmbs.fillScenName("auto_test_20171225");

		econScenRmbs.saveNewEconomic();
		
		
		econScenRmbs.closeEconContentPage();
		econScenRmbs.clearUpAllselectedScenarios();
		
		scenariosList = new HashMap<String, String>();
		scenariosList.put("auto_test_20171225", "100");
		
		econScenRmbs.setScenarios(scenariosList, true);
		econScenRmbs.deleteSelectedScen(true);
		
		Thread.sleep(1000*30);
	}
	
	//@Test
	public void testLuanchRmbs() throws Exception{
		this.setJobConfigRmbs();	
	//	LaunchRmbs launchRmbs = new LaunchRmbs(driver);
		GlobalValueRmbs globalValueRmbs = null;
		DefaultValuesRmbs defaultValuesRmbs = null;
//		launchRmbs.setJob(jobrmbs);
//		launchRmbs.setRunMode(jobrmbs.getRunType());
//		launchRmbs.setHorizon(jobrmbs.getHorizon());
//		launchRmbs.setAsOfDate(jobrmbs.getAsOfDate());
//		launchRmbs.setConfidenceLevel(jobrmbs.getConfidenceLevelPercentage());
//		launchRmbs.setOptimization(jobrmbs.getOptimizationPercentageLevel());
//		launchRmbs.setTailPercent(jobrmbs.getTailPercentageLevl());
//		launchRmbs.setUseTargetLgd(jobrmbs.isUseTargeLgd());
//		launchRmbs.setUseSystemBookPrice(jobrmbs.isUseSystemBookPrice());
//		System.out.println(launchRmbs.getConfidenceLevelValue());
//		System.out.println(launchRmbs.getOptimizationValue());
//		System.out.println(launchRmbs.getTailPercentValue());
//		System.out.println(launchRmbs.isUseSystemBookPrice());
//		System.out.println(launchRmbs.isUseTargetLgd());		
//		
//		if(globalValueRmbs == null){
//			globalValueRmbs = new GlobalValueRmbs(driver);
//		}
//		System.out.println(globalValueRmbs.readCollateralType());
//		System.out.println(globalValueRmbs.readOptimizationPercentageLevel());
//		System.out.println(globalValueRmbs.readTailPercentageLevel());
//		System.out.println(globalValueRmbs.readIsDisableServerityCap());
//		globalValueRmbs.setDisableServerityCap(true);
//		System.out.println(globalValueRmbs.readIsDisableServerityCap());
//		globalValueRmbs.closeGlobalValuePopUp(true);
		
		if(defaultValuesRmbs == null){
			defaultValuesRmbs = new DefaultValuesRmbs(driver);
		}
		defaultValuesRmbs.readFiledXpaths();
		
//		for(Map.Entry<String, String> entry : defaultValuesRmbs.getDefaultValueInputType().entrySet()){
//			System.out.println("key = " + entry.getKey() + ", value = " + entry.getValue());
//		}
//		
//		for(Map.Entry<String, String> entry : defaultValuesRmbs.getDefaultValueXpath().entrySet()){
//			System.out.println("key = " + entry.getKey() + ", value = " + entry.getValue());
//			if(entry.getValue().contains("input")){
//				System.out.println(driver.findElement(By.xpath(entry.getValue())).getAttribute("value"));
//			} else {
//				System.out.println(new Select(driver.findElement(By.xpath(entry.getValue()))).getFirstSelectedOption().getText());
//			}
//		}
		
//		String[] collateralTypes = defaultValuesRmbs.readCollateralTypeOptions();
//		System.out.println("collateral types for: \n"+defaultValuesRmbs.readCurrentCollateralType());
//		for(int i = 0; i < collateralTypes.length; i++){
//			System.out.println(collateralTypes[i]);
//		}
		
		defaultValuesRmbs.setColateralTypeOption("Alt-A", false);
		defaultValuesRmbs.readFiledXpaths();
		defaultValuesRmbs.setDefaultValueByFieldName(DefaultValuesRmbs.getGrossmargin(), "5");
		defaultValuesRmbs.setDefaultValueByFieldName(DefaultValuesRmbs.getMortgatetype(), "EOMs");
		defaultValuesRmbs.setDefaultValueByFieldName(DefaultValuesRmbs.getZipcode(),"111111");
		defaultValuesRmbs.setDefaultValueByFieldName(DefaultValuesRmbs.getAmortizationterm(), "2");
		defaultValuesRmbs.saveChangesToCurrentType();
		System.out.println(defaultValuesRmbs.readAlertMessage());
		
		defaultValuesRmbs.setColateralTypeOption("HEL", true);
		defaultValuesRmbs.readFiledXpaths();
		defaultValuesRmbs.setDefaultValueByFieldName(DefaultValuesRmbs.getAmortizationterm(), "5");
		
		defaultValuesRmbs.saveChangeAsNewType("test_qins_111111", true);
		System.out.println(defaultValuesRmbs.readAlertMessage());
		
		System.out.println(defaultValuesRmbs.deleteByCollateralType("test_qins_111111", false));
		defaultValuesRmbs.waitForAjaxLoaded();
		defaultValuesRmbs.closeDashboard(false);
	}
	
	//@Test
	public void testLuanchPage() throws Exception{
		Login login = new Login(driver);
		login.loginToDashboard();
		HomePage dashboard = new HomePage(driver);
		dashboard.launchToModel("rmbs");
		Thread.sleep(1000*10);
		dashboard.get(dashboard.getPageUrl());	
		dashboard.waitForAjaxLoaded();
		dashboard.launchToModel("cmbs");
		Thread.sleep(1000*10);
		driver.get(dashboard.getPageUrl());
		dashboard.waitForAjaxLoaded();
		dashboard.launchToModel("abs");
		Thread.sleep(1000*10);	
	}
	
	// @Test
	public void testLoginPage() throws InterruptedException{
		Login login = new Login(driver);
		login.accessLoginPage();
	}
	
	//@Test
	public void testLoginPage2() throws Exception{
		Login login = new Login(driver);
		login.loginToDashboard();
		log.info(driver.getCurrentUrl());
	}
		
}
