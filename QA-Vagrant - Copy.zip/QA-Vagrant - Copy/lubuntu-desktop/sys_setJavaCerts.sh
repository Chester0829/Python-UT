echo "setting up java certs"
echo 'changeit' | keytool -keystore $(find $JAVA_HOME -name cacerts) -import -alias PTC-WBRTCERT702 -file /usr/share/ca-certificates/private/PTC-WBRTCERT702.crt -noprompt
echo 'changeit' | keytool -keystore $(find $JAVA_HOME -name cacerts) -import -alias PTC-WBISCERT702 -file /usr/share/ca-certificates/private/PTC-WBISCERT702.crt -noprompt