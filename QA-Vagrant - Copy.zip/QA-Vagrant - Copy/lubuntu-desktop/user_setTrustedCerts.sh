# set trusted certs for ubuntu user
vagrant_user=$1
echo "Setting trusted certs for user $vagrant_user"
export user_home=/home/$vagrant_user
rm -rf $user_home/.pki/nssdb
mkdir -p $user_home/.pki/nssdb
certutil -N --empty-password -d sql:$user_home/.pki/nssdb
sudo certutil -d sql:$user_home/.pki/nssdb -A -t "CT,c,c" -n "PTC-WBRTCERT702" -i /usr/share/ca-certificates/private/PTC-WBRTCERT702.crt
sudo certutil -d sql:$user_home/.pki/nssdb -A -t "CT,c,c" -n "PTC-WBISCERT702" -i /usr/share/ca-certificates/private/PTC-WBISCERT702.crt
