# QA-Vagrant Project README

## How to set up Vagrant on your machine

    Vagrant is required for our automation development environment.
    Vagrant 1.9.7 will require powershell update from https://msdn.microsoft.com/powershell (MS WMF 5.1)

1. Set host PC proxy env variables

        HTTP_PROXY="http://wwwproxy.nslb.ad.moodys.net:80"
        HTTPS_PROXY="http://wwwproxy.nslb.ad.moodys.net:80"
        NO_PROXY="localhost, .moodys.net, 127.0.0.1"
        VAGRANT_PREFER_SYSTEM_BIN=1
    
2. Insall Vagrant 2.x.x

    3.1 incompatible encoding UTF-8 issue refer to
        https://stackoverflow.com/questions/27944875/error-while-installing-gem-on-windows-8-incompatible-character-encoding/47652255#47652255?newreg=65ab79247ea04445bc004aacfd25bb31
        if still cannot resolve download the gem file and do plugin install locally (vagrant plugin install /path/to/gem file)
        
3. Install Vagrant Plugins

    3.1. cat QA-Vagrant/global/moodys/*.crt and append to the end of
    
        <Vagrant Path>/embedded/cacert.pem file

    3.2. open cmd or cygwin in admin/elevated mode and run

        cmd> vagrant plugin install micromachine --plugin-version "~> 2.0.0"
        cmd> vagrant plugin install vagrant-share
        cmd> vagrant plugin install vagrant-vbguest
        cmd> vagrant plugin install vagrant-proxyconf
        cmd> vagrant plugin install vagrant-ca-certificates
        cmd> vagrant plugin install vagrant-winrm
        cmd> vagrant plugin install vagrant-timezone
        
    3.3. check installed plugins
    
        $ vagrant plugin list
        micromachine (2.0.0)
          - Version Constraint: ~> 2.0.0
        vagrant-ca-certificates (1.3.0)
        vagrant-proxyconf (1.5.2)
        vagrant-share (1.1.9)
        vagrant-timezone (1.2.0)
        vagrant-vbguest (0.15.1)
        vagrant-winrm (0.7.0)


## How to checkout QA-Vagrant project and launch automation VMs

    To run automation and develop in Chrome brower you only need Ubuntu system desktop01.
    To run and develop in IE browser you need both Ubuntu desktop01 and a Windows system.

1. Checkout QA-Vagrant project to your ~/Projects folder

        $ cd ~/Projects
        $ git clone git@SF1-LGSDWKtst.ANALYTICS.MOODYS.NET:SAVQA/QA-Vagrant.git

2. To Launch desktop01 for chrome automation development in ubuntu-desktop env

        $ cd ~/Projects/QA-Vagrant/ubuntu-desktopv2
        $ vagrant up desktop01

3. To lauch win7ie11-01 and win7ie11-02 for IE automation development in windows 7 env (development also requires desktop01 above)

    win7ie11-01 to win7ie11-04 are pre-configured to support selenium and IE automation. Their ports are arranged to avoid conflicts, therefore they can be brought up in parellel.

        $ cd ~Projects/QA-Vagrant/windows-ie
        $ vagrant up win7ie11-01
        $ vagrant up win7ie11-02
    
    These VMs do not have Virtualbox console UI. For console UI access use RDP to localhost:<rdp_host_port> (look inside Vagrantfile) and login as \IEUser/Passw0rd!
    These VMs are ssh enabled. For cmd access run "ssh IEUser@localhost:<ssh_host_port>
    A few CMD commands that are useful in controlling IE browser and selenium-server (as scheduled task):
    
        CMD> tasklist
        CMD> tasklist /FI "imagename eq iexplore.exe"
        CMD> taskkill /FI "imagename eq iexplore.exe" /F
        CMD> schtasks /Query /fo list /tn selenium-server
        CMD> schtasks /End /tn selenii,-server
        CMD> schtasks /Run /tn selenium-server

## How to build windows base boxes

Below are the configuration steps for the windows base boxes in case you need to rebuild them

1. To Launch win7ie11_base and Configure for Vagrant control

        $ cd ~/Projects/QA-Vagrant/windows-ie
        $ vagrant up win7ie11_base
        in VirtualBox GUI
            GUI: select "Work Network"
            GUI: set IE browser homepage to "Use new tab"
            CMD: open cmd in Administraor role, paste in the following commands
                winrm quickconfig -q
                winrm set winrm/config/winrs @{MaxMemoryPerShellMB="512"}
                winrm set winrm/config @{MaxTimeoutms="1800000"}
                winrm set winrm/config/service @{AllowUnencrypted="true"}
                winrm set winrm/config/service/auth @{Basic="true"}
                sc config WinRM start= auto
                shutdown /r
            GUI: click 'yes' to reboot

2. To re-launch win7ie11_base under Vagrant control

        $ cd ~/Projects/QA-Vagrant/windows-ie
        $ vagrant reload win7-ie11
        
3. Set up Network connect

        1) Set new tab as IE default page
        2) Import Moodys certificate
            File Manager browse to and double click
            C:\Users\IEUser\Projects\QA-Vagrant\global\moodys\PTC-WBRTCERT702.crt
            Install it under "Trusted Root Certification Authorities"
        3) Set borwser proxy
            In IE browser set proxy to wwwproxy.nslb.ad.moodys.net:80, and no proxy for local network
        4) Try to load google.com and www.sfportal.com, both pages should load

4. Set up for Selenium automation

        1) Setup browser security level to Custom with Protected Mode
        IE -> Internet Options -> security 
            change 4 zone setting:
            click Enable Protected Mode
            custom level -> enable the first three options
            you can see security level for this zone is 'Custom'
        2) Set PATH for selenium binary
            Windows Selenium binary is loaded in
            C:\Users\IEUser\Projects\QA-Vagrant\global\win-selenium
            This path needs to be in the System PATH env
        3) Install Java
            Install Java and verify IE with Java
        4) Setup automatic scheduled task for selenium-server
            CMD> java -jar C:\Users\IEUser\Projects\QA-Vagrant\global\win-selenium\selenium-server-standalone-3.4.0.jar
    
5. IE 11 Additional set up

        1) As Administrator set or add Registry
            HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BFCACHE
        2) In Registry FEATURE_BFCACHE add DWORD (x32) name=iexplore.exe and value=0
    
        Refer to https://github.com/SeleniumHQ/selenium/wiki/InternetExplorerDriver for more details

6. Windows 7 Additional set up for extending Windows trial

        1) Start CMD as Administrator and run
             slmgr -rearm
        2) As Administrator run Regedit
             HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\WindowsNT\CurrentVersion\SoftwareProtectionPlatform
             set SkipRearm from 0 Hex to 1 Hex
            
7. Windwos 7 Additional set up for SSH

        1) Install SSH server application
        2) Open incoming SSH port
        3) Set up SSH service and auto-start

8. Build and publish pre-built (above steps) base box 

        1) In Virtualbox, link clone the pre-built VM and name it as "win7ie11_base" or "win10edge_base"
        2) In windows-ie directory run command "vagrant package --base win7ie11_base --output win7ie11_base.box"
        3) cp win7ie11_base.box Q:/Automation/VM-Exports/win7ie11_base.box(full dir:\\WSAFILE2\MWSAShare\ProductDevelopment\QA\Automation\VM-Exports)
        