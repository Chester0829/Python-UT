echo "installing user npm packages"
rm -f ~/.npmrc
cat << END2 > ~/.npmrc
# for NPM (uncmment below options temporarily during npm install to overcome proxy issue)
insecure=true
rejectUnauthorized=false
strict-ssl=false
registry=http://registry.npmjs.org
http-proxy=http://proxy-sfo.ad.moodys.net:80
https-proxy=https://proxy-sfo.ad.moodys.net:443
chromedriver-cdnurl=http://chromedriver.storage.googleapis.com
selenium-release-cdnurl=http://selenium-release.storage.googleapis.com
END2

# npm set registry http://registry.npmjs.org/
npm cache clean --force
export NODE_VERSION=v6.12.3
if [ -d "$HOME/.nvm" ] ; then
  export NVM_DIR="$HOME/.nvm"
  [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"  # This loads nvm
  PATH=$HOME/.nvm/versions/node/$NODE_VERSION/bin:$PATH
  nvm install $NODE_VERSION
  nvm use --delete-prefix $NODE_VERSION
fi
nvm install $NODE_VERSION
nvm use --delete-prefix $NODE_VERSION
npm set registry http://registry.npmjs.org/
npm cache -g clean --force

cp ~/Projects/SFPortal-JS/package.json ~/package.json
npm install node-inspector
npm install accounting
npm install chimp
npm install json-stable-stringify
npm install cucumber-html-reporter
npm install cucumber-junit
npm install mssql
npm install robotjs
npm install
npm rebuild
