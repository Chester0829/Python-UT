echo "installing MA Certs"
#cp -r /vagrant/moodys /usr/local/share/ca-certificates
update-ca-certificates

