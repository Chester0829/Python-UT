echo "installing UnicodeData"
(cd /usr/share; gzip -cd /vagrant/UnicodeData.tgz | sudo tar xvf -)
