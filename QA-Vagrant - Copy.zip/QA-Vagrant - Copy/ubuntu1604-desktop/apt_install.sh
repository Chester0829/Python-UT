echo "installing apt packages"
export DEBIAN_FRONTEND=noninteractive
# rm -fv /var/lib/apt/lists/*
apt update -q && apt autoremove -y
apt install -q -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" ntpdate autofs tree xvfb xdotool ansible docker.io python python-pip python-software-properties wmctrl xclip ffmpeg nodejs-legacy nodejs npm
apt install -q -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" build-essential g++ gyp git-crypt linux-headers-4.4.0-22-generic dkms tesseract-ocr
apt install -q -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" libssl-dev libreadline-dev libyaml-dev libsqlite3-dev libxml2-dev libxslt1-dev libcurl4-openssl-dev libffi-dev libxtst-dev libpng-dev libxtst-dev libpng++-dev libopencv-dev libtesseract-dev zlib1g-dev libgtk2-perl libnss3 libnss3-tools
apt install -q -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" unixodbc unixodbc-dev tdsodbc sqlite3 freetds-bin rdesktop
