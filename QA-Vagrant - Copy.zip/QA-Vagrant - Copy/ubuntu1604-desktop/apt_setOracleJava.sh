echo "setting oracle-java ppa"
cat << END > /etc/apt/sources.list.d/oracle-java.list
## Oracle Java PPA
deb http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main
deb-src http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main
END

echo "installing apt extra packages"
export DEBIAN_FRONTEND=noninteractive
apt-key adv --keyserver-options http-proxy=http://wwwproxy.nslb.ad.moodys.net:80/ --keyserver keyserver.ubuntu.com --recv-keys C2518248EEA14886
add-apt-repository ppa:webupd8team/java --yes --update
apt update -q 
echo oracle-java8-installer shared/accepted-oracle-license-v1-1 select true | /usr/bin/debconf-set-selections
apt install -q -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" --allow-unauthenticated oracle-java8-set-default
