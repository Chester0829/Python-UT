locale-gen "en_US.UTF-8"
localectl set-locale LANG="en_US.UTF-8"