echo "setting apt proxy"
http_proxy_host_port=$1
cat << END > /etc/apt/apt.conf
Acquire::http::proxy "http://${http_proxy_host_port}";
Acquire::https::proxy "http://${http_proxy_host_port}";
Acquire::ftp::proxy "http://${http_proxy_host_port}";
END
