fgrep -v "autologin-user" /etc/lightdm/lightdm.conf > /tmp/lightdm.conf
mv /tmp/lightdm.conf /etc/lightdm/lightdm.conf