vagrant_user=$1
shift
echo "setting $vagrant_user user env"
http_proxy_host_port=$1
shift
no_proxy=$1

IFS=':' read http_proxy_host http_proxy_port <<<$http_proxy_host_port

cat << END1 > ~/.userEnv
export TZ="America/Los_Angeles"
export LANG="en-US"
export http_proxy=http://${http_proxy_host_port}
export https_proxy=https://${http_proxy_host_port}
export HTTP_PROXY=http://${http_proxy_host_port}
export HTTPS_PROXY=https://${http_proxy_host_port}
export no_proxy=${no_proxy}
export DBUS_SESSION_BUS_ADDRESS="unix:path=/dev/null"
export JAVA_HOME="/usr/lib/jvm/java-8-oracle/"
export _JAVA_OPTIONS="-Xms512m -Xmx512m -Dcom.sun.net.ssl.checkRevocation=false"

# set node to ignore certificate error
export NODE_TLS_REJECT_UNAUTHORIZED=0

# set NVM
export NODE_VERSION=v6.12.3
if [ -d "\$HOME/.nvm" ] ; then
  export NVM_DIR="\$HOME/.nvm"
  [ -s "\$NVM_DIR/nvm.sh" ] && . "\$NVM_DIR/nvm.sh"  # This loads nvm
  PATH="\$HOME/.nvm/versions/node/\$NODE_VERSION/bin:\$PATH"
  nvm use --delete-prefix \$NODE_VERSION
fi
# set NPM path
if [ -d "\$HOME/node_modules/.bin" ] ; then
    PATH="\$HOME/node_modules/.bin:\$PATH"
fi
npm config --global set proxy \$http_proxy

END1

fgrep -v ".userEnv" ~/.profile > /tmp/temp_profile
echo ". ~/.userEnv" >> /tmp/temp_profile
mv /tmp/temp_profile ~/.profile

# set pre-canned X desktop env
mkdir -p ~/.config/dconf
rm -f ~/.config/dconf/user
cp /vagrant/dconf_user ~/.config/dconf/user
