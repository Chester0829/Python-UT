# set trusted certs for ubuntu user
vagrant_user=$1
echo "Setting trusted certs for user $vagrant_user"
export user_home=/home/$vagrant_user
rm -rf $user_home/.pki/nssdb
mkdir -p $user_home/.pki/nssdb
certutil -N --empty-password -d sql:$user_home/.pki/nssdb
sudo certutil -d sql:$user_home/.pki/nssdb -A -t "CT,c,c" -n "PTC-WCRTCERT701" -i /usr/share/ca-certificates/private/PTC-WCRTCERT701.crt
sudo certutil -d sql:$user_home/.pki/nssdb -A -t "CT,c,c" -n "PTC-WCISCERT701" -i /usr/share/ca-certificates/private/PTC-WCISCERT701.crt
sudo certutil -d sql:$user_home/.pki/nssdb -A -t "CT,c,c" -n "PTC-WBRTCERT702" -i /usr/share/ca-certificates/private/PTC-WBRTCERT702.crt
sudo certutil -d sql:$user_home/.pki/nssdb -A -t "CT,c,c" -n "PTC-WBISCERT702" -i /usr/share/ca-certificates/private/PTC-WBISCERT702.crt
# sudo certutil -d sql:$user_home/.pki/nssdb -A -t "CT,c,c" -n "proxy-ptc" -i /usr/share/ca-certificates/private/proxy-ptc.crt
# sudo certutil -d sql:$user_home/.pki/nssdb -A -t "CT,c,c" -n "proxy-ftc" -i /usr/share/ca-certificates/private/proxy-ftc.crt
# sudo certutil -d sql:$user_home/.pki/nssdb -A -t "CT,c,c" -n "proxy-sfo" -i /usr/share/ca-certificates/private/proxy-sfo.crt

