vagrant_user=$1
shift
http_proxy_host_port=$1
shift
no_proxy=$1
echo "installing Docker"
export DEBIAN_FRONTEND=noninteractive
apt remove -q -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" docker docker-engine docker.io
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | apt-key add -
add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu xenial stable"
apt update -q && apt autoremove -y
apt install -q -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" docker-ce
mkdir -p /etc/systemd/system/docker.service.d

cat << END1 > /etc/systemd/system/docker.service.d/http-proxy.conf
[Service]
Environment="HTTP_PROXY=http://${http_proxy_host_port}" "NO_PROXY=${no_proxy}"
END1

cat << END2 > /etc/systemd/system/docker.service.d/https-proxy.conf
[Service]
Environment="HTTP_PROXY=http://${http_proxy_host_port}" "NO_PROXY=${no_proxy}"
END2

cat << END3 > /etc/docker/daemon.json
{
  "storage-driver":"aufs",
  "debug":true,
  "insecure-registries":["sf1-lgwsawik201.analytics.moodys.net:5000"]
}
END3

systemctl daemon-reload
systemctl restart docker
