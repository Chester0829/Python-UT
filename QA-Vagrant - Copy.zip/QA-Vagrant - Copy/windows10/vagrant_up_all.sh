ACTION=$1
ACTION=${ACTION:=up}
vagrant ${ACTION} \
win10selenium01 \
win10selenium02 \
win10selenium03 \
win10selenium04 \
win10selenium05 \
win10selenium06 \
win10selenium07 \
win10selenium08
