##QA Selenium Winboxes
```
cygwin$ communicator=ssh vagrant up win10Base
cygwin$ vagrant reload win10Base --provision
cygwin$ vagrant reload win10Base
cygwin$ vagrant package --base win10Base --output win10selenium.box
update Vagrant file to hide the win10Base and expose the win10selenium VMs
```
