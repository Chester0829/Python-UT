ACTION=$1
ACTION=${ACTION:=up}
vagrant ${ACTION} \
win7selenium01 \
win7selenium02 \
win7selenium03 \
win7selenium04 \
win7selenium05 \
win7selenium06 \
win7selenium07 \
win7selenium08
