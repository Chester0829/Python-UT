echo "Setting docker to use http"
mkdir -p /etc/systemd/system/docker.service.d
cat > /etc/systemd/system/docker.service.d/http-proxy.conf <<EOF
[Service]
EnvironmentFile=-/etc/sysconfig/docker
EOF
cat > /etc/systemd/system/docker.service.d/docker.conf <<EOF
[Service]
ExecStart=
ExecStart=/usr/bin/docker daemon --insecure-registry sf1-lgwsawik201.analytics.moodys.net:5000
EOF
systemctl daemon-reload
service docker restart
