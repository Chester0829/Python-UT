echo "Replacing epel mirror https to http"
sed -i 's|mirrorlist=https|mirrorlist=http|' /etc/yum.repos.d/epel*.repo
