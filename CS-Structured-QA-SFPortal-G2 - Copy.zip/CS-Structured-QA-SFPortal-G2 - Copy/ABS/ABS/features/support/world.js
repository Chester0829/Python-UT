module.exports = function() {
  this.World = require(process.env.ProjectFullPath + '/global/support/world').World;
}