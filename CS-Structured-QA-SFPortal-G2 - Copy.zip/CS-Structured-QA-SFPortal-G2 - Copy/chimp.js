// Recommended filename: chimp.js
module.exports = require('./default_chimp.js');
