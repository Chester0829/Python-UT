// Recommended filename: When_I_click_the_#_button_in_the_#_card.js
module.exports = function() {
  this.When(/^I click the "([^"]*)" button in the "([^"]*)" card$/, {timeout: process.env.StepTimeoutInMS}, function (buttonName, cardName) {
    // Write code here that turns the phrase above into concrete actions

    const dataViewerPage_xpath = this.xpath_lib.xpathRequire('dataViewerPage_xpath');
    if (cardName.toLowerCase() == 'current')
    {
      cardName = this.visualizeName;
    }
    var myVisualization_card = dataViewerPage_xpath.titled_Visualization_card.replace('__TITLE__', cardName);
    var myButton = myVisualization_card + dataViewerPage_xpath.named_Button.replace('__NAME__', buttonName);
    browser.waitForVisible(myButton, this.waitDefault);
    browser.click(myButton);
    // wait for button to vanish
    browser.pause(500);
    browser.waitForVisible(myButton, this.waitDefault*2, true);
    this.browser_session.waitForLoading(browser);
  });
}