// Recommended filename: When_I_click_on_the_#_icon_in_the_#_panel.js
module.exports = function() {
  this.When(/^I click on the "([^"]*)" icon in the action bar$/, {timeout: process.env.StepTimeoutInMS}, function (actionName) {
    // Write code here that turns the phrase above into concrete actions
    const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
    const dataViewerPage_xpath = this.xpath_lib.xpathRequire('dataViewerPage_xpath');
    
    var myActionIcon = dataViewerPage_xpath.titled_actionIcon.replace('__TITLE__', actionName);
    var myactionMessage = dataViewerPage_xpath.actionMessage;
    var mysaveButton = dataViewerPage_xpath.saveButton;
    var myrunButton = dataViewerPage_xpath.runButton;

    this.browser_session.waitForLoading(browser);
    browser.waitForVisible(myActionIcon, this.waitDefault);

    // if action bar is collasped let's expand it
    var myCollaspedActionBar_xpath = dataViewerPage_xpath.actionBar_collasped;
    var myExpandActionBar_icon = dataViewerPage_xpath.titled_actionIcon.replace('__TITLE__', 'Expand Action Bar');
    if (browser.isVisible(myCollaspedActionBar_xpath)) {
      browser.click(myExpandActionBar_icon);
    }

    switch (actionName) {
      case "Create A New Visualization":
        browser.click(myActionIcon);
        this.browser_session.waitForLoading(browser);
        //GUI has this name as default, so set this to global
        this.visualizeName = "My Visualization"; 
        browser.waitForVisible(myrunButton, 2*(this.waitDefault));
        break;
      case "Edit Current Dashboard Settings":
        browser.click(myActionIcon);
        // this.robot_session.moveMouseToLink(browser, myActionIcon, true);
        this.browser_session.waitForLoading(browser);
        //Wait to see the Save Button on the Dashboard setting.
        browser.waitForVisible(mysaveButton, 2*this.waitDefault);
        break;
      case "Save Current Dashboard":
        browser.click(myActionIcon);
        this.browser_session.waitForLoading(browser);
        //wait for the save message to show up and vanish
        try {
          browser.waitForVisible(myactionMessage, this.waitDefault);
          browser.waitForVisible(myactionMessage, this.waitDefault/2, true);
        } catch(e) {}
        break;
      default:
         console.log("ACTION: " + actionName + " NOT Implemented yet.");
    } //End of switch (actionName) {
  });
}