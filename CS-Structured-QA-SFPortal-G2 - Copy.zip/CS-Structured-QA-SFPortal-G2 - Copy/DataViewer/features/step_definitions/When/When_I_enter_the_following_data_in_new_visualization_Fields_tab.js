// Recommended filename: When_I_enter_the_following_data_in_new_visualization_#_tab.js
module.exports = function() {
  this.When(/^I enter the following data in new visualization Fields tab$/,
    {timeout: process.env.StepTimeoutInMS*30},
    function (table) {
    // Write code here that turns the phrase above into concrete actions
    const dataViewerPage_xpath = this.xpath_lib.xpathRequire('dataViewerPage_xpath');
    var data_item_list = table.hashes();
    var cardName = this.visualizeName;
    var myVisualization_card = dataViewerPage_xpath.titled_Visualization_card.replace('__TITLE__', cardName);

    var myConfigFieldsTab = myVisualization_card + dataViewerPage_xpath.named_Visualization_configTab.replace('__NAME__', 'Fields');
    var myConfigFieldsSelector = myVisualization_card + dataViewerPage_xpath.fieldSelector;
    var myConfigFieldsFilter = myConfigFieldsSelector + dataViewerPage_xpath.named_Input.replace('__NAME__', 'Search Available Fields');

    var browser_session = this.browser_session;
    var robot_session = this.robot_session;
    var waitDefault = this.waitDefault;
    // console.log("=== xpath: " + myConfigFieldsTab);
    browser.waitForVisible(myConfigFieldsTab, waitDefault);
    browser.pause(150)
    browser.click(myConfigFieldsTab);
    // here we clear any preset items
    var myFieldFilters = myVisualization_card + dataViewerPage_xpath.fieldFilters;
    var myPresetItemDismiss = myVisualization_card + dataViewerPage_xpath.sfpPill + dataViewerPage_xpath.presetItemDismiss;
    browser.pause(1000);
    // here we clear all preset items
    browser.waitForVisible(myFieldFilters, waitDefault);
    try {
      browser.waitForVisible(myPresetItemDismiss, waitDefault/3);
    } catch (e) {}

    console.log("===Before Entering the preset clearing loop: " + myPresetItemDismiss);
    while (browser.isExisting(myPresetItemDismiss)) {
      console.log("===Inside the preset clearing loop: " + myPresetItemDismiss);
      browser.click(myPresetItemDismiss);
      browser.pause(150);
    }
    var myLastSubtab = null;
    var myLastSelectorId = null;
    var myNamed_ID = null;
    data_item_list.forEach(function(data_item) {
      console.log('SETTING VALUE FOR: ' + data_item['subtab'] + '->' + data_item['label']);
      switch (data_item['subtab']) {
        case "Cohorts":
        case "Metrics":
        case "Filters":
        // case "Loan Fields":
        case "Data Fields":
          var selectorIdName = (data_item['subtab'] == "Cohorts") ? "buckets":data_item['subtab'].toLowerCase();
          // if (data_item['subtab'] == "Loan Fields")
          if (data_item['subtab'] == "Data Fields")
          {
            selectorIdName = "metrics";
          }
          if (myLastSelectorId != selectorIdName) {
            myNamed_ID = dataViewerPage_xpath.named_ID.replace('__NAME__', selectorIdName);
            myLastSelectorId = selectorIdName;
          }

          var choosing_field_xpath = myConfigFieldsSelector
                                   + dataViewerPage_xpath.availableField
                                   + dataViewerPage_xpath.named_Span.replace('__NAME__', data_item['label']);
          var selected_field_xpath = myConfigFieldsSelector + myNamed_ID
                                   + dataViewerPage_xpath.named_Pill.replace('__NAME__', data_item['label']);

          if (myLastSubtab != data_item['subtab']) {
            var myConfigSubTabTarget = myConfigFieldsSelector
                                     + dataViewerPage_xpath.named_Visualization_configTab.replace('__NAME__', data_item['subtab']);
            browser.waitForVisible(myConfigSubTabTarget, waitDefault);
            browser.click(myConfigSubTabTarget);
            browser.pause(100);
            myLastSubtab = data_item['subtab'];
          }

          // Here we enter filter name and double-click on it
          browser.click(myConfigFieldsFilter);
          browser.setValue(myConfigFieldsFilter, data_item['label']);
          browser.doubleClick(choosing_field_xpath);
          browser.pause(100);

          if (data_item['dropdown_icon']) {
            // var dropdown_icon_xpath = selected_field_xpath + '//i[contains(@class, "icon") and contains(@class, "dropdown")]';
            var dropdown_icon_xpath = selected_field_xpath + dataViewerPage_xpath.presetItemDropdown;
            var dropdown_icon_selection = selected_field_xpath + dataViewerPage_xpath.named_Preset.replace('__NAME__', data_item['dropdown_icon']);

            //Click on the arrow down to show the selection list
            // console.log(dropdown_icon_xpath);
            browser.click(dropdown_icon_xpath);
            browser.pause(100);
            //Then selection the option from the dropdown
            // console.log(dropdown_icon_selection);
            browser.click(dropdown_icon_selection);
            browser.pause(100);
          }
          if (data_item['selector1']) {
            var my_selector_xpath = selected_field_xpath + dataViewerPage_xpath.descendantSelect1;
            console.log("\tSelector 1: " + data_item['selector1'] + ". xpath: " + my_selector_xpath);
            browser.waitForVisible(my_selector_xpath, waitDefault);
            browser.selectByVisibleText(my_selector_xpath, data_item['selector1']);
            browser.pause(100);
          }
          if (data_item['selector2']) {
            var my_selector_xpath = selected_field_xpath + dataViewerPage_xpath.descendantSelect2;
            console.log("\tSelector 2: " + data_item['selector2'] + ". xpath: " + my_selector_xpath);
            browser.waitForVisible(my_selector_xpath, waitDefault);
            browser.selectByVisibleText(my_selector_xpath, data_item['selector2']);
            browser.pause(100);
          }
          // in the following condition we need to delete extra dropdown
          if (data_item['subtab'] == 'Filters' && data_item['label'] == 'Period' && data_item['dropdown_icon'] == 'Range') {
            var extra_dropdown_xpath = selected_field_xpath + dataViewerPage_xpath.extraPillConfig;
            // console.log("\tExtra column path for Period Range: " + extra_dropdown_xpath);
            while (browser.isVisible(extra_dropdown_xpath)) {
              browser.click(extra_dropdown_xpath);
              browser.pause(100);
            }
          }
          // code for input and input1 is the same here
          if (data_item['input'] || data_item['input1']) {
            var selected_field_input_xpath = selected_field_xpath + dataViewerPage_xpath.descendantInput1;
            // console.log("Input field for " + data_item['label'] + " xpath: " + selected_field_input_xpath);
            browser.waitForVisible(selected_field_input_xpath, waitDefault);
            browser.clearElement(selected_field_input_xpath);
            var token_list;
            if (data_item['input']) {
              token_list = data_item['input'].split(' :: ');
            } else {
              token_list = data_item['input1'].split(' :: ');
            }      
            token_list.forEach(function(token) {
              browser.click(selected_field_input_xpath);
              browser.keys(token);
              browser.pause(2000);
              browser.keys('\uE006');
              browser.pause(500);
            });
          }
          if (data_item['input2']) {
            var selected_field_input_xpath = selected_field_xpath + dataViewerPage_xpath.descendantInput2;
            // console.log("Input field for " + data_item['label'] + " xpath: " + selected_field_input_xpath);
            browser.waitForVisible(selected_field_input_xpath, waitDefault);
            browser.clearElement(selected_field_input_xpath);
            var token_list = data_item['input2'].split(' :: ');
            token_list.forEach(function(token) {
              browser.click(selected_field_input_xpath);
              browser.keys(token);
              browser.pause(2000);
              browser.keys('\uE006');
              browser.pause(500);
            });
          }
          // for certain fields we need to remove extra input lines
          if ((data_item['subtab'] == 'Filters') && (['IO Term'].indexOf(data_item['label']) >= 0)) {
            var extra_line_x = selected_field_xpath + dataViewerPage_xpath.extraPillInput;
            browser.waitForExist(extra_line_x, waitDefault);
            browser.click(extra_line_x);
          }
          break;
      }
    });
  });
}
