// Recommended filename: When_I_click_on_the_#_tab_under_the_#_nested-card.js
module.exports = function() {
  this.When(/^I select "([^"]*)" option from the "([^"]*)" selector list under the "([^"]*)" nested\-card$/,
    {timeout: process.env.StepTimeoutInMS},
    function (optionName, optionLabel, cardName) {
    // Write code here that turns the phrase above into concrete actions
    const dataViewerPage_xpath = this.xpath_lib.xpathRequire('dataViewerPage_xpath');
    if(cardName.toLowerCase() == 'current')
    {
      cardName = this.visualizeName;
    }
    var myVisualization_card = dataViewerPage_xpath.titled_Visualization_card.replace('__TITLE__', cardName);
    var myFieldSelector = myVisualization_card + dataViewerPage_xpath.fieldSelector;

    //This is just a dummy default for the available list
    var selectOption_xpath;

    if(optionLabel == "Filter By")
    {
      selectOption_xpath = myFieldSelector + dataViewerPage_xpath.labeled_Select.replace('__LABEL__', 'Filter by:');
    } else {
      selectOption_xpath = myFieldSelector + dataViewerPage_xpath.fieldSelect + dataViewerPage_xpath.named_Option.replace('__NAME__', optionName);
    }

    console.log("SELECT Option: " + optionName +"XPATH: " + selectOption_xpath);
    browser.waitForExist(selectOption_xpath, this.waitDefault*2);
    browser.selectByVisibleText(selectOption_xpath, optionName);
    browser.pause(5000);
  });
};