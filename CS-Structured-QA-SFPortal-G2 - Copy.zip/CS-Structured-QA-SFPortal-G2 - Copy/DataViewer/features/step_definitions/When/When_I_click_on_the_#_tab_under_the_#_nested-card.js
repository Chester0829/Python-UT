// Recommended filename: When_I_click_on_the_#_tab_under_the_#_nested-card.js
module.exports = function() {
  this.When(/^I click on the "([^"]*)" tab under the "([^"]*)" nested\-card$/,
    {timeout: process.env.StepTimeoutInMS*5}, function (tabName, cardName) {
    // Write code here that turns the phrase above into concrete actions
    const dataViewerPage_xpath = this.xpath_lib.xpathRequire('dataViewerPage_xpath');
    if(cardName.toLowerCase() == 'current')
    {
      cardName = this.visualizeName;
    }
    var myVisualization_card = dataViewerPage_xpath.titled_Visualization_card.replace('__TITLE__', cardName);
    var myVisualization_configTab = myVisualization_card + dataViewerPage_xpath.named_Visualization_configTab.replace('__NAME__', tabName);
    console.log("XPATH: " + myVisualization_configTab);
    browser.waitForVisible(myVisualization_configTab, this.waitDefault);
    browser.click(myVisualization_configTab);

    // here we clear any preset items
    var waitDefault = this.waitDefault;
    var myFieldFilters = myVisualization_card + dataViewerPage_xpath.fieldFilters;
    var myPresetItemDismiss = myVisualization_card + dataViewerPage_xpath.sfpPill + dataViewerPage_xpath.presetItemDismiss;
    browser.pause(300);

    // here we clear all preset items
    browser.waitForVisible(myFieldFilters, waitDefault);
    try {
      browser.waitForVisible(myPresetItemDismiss, waitDefault/3);
      while (browser.isVisible(myPresetItemDismiss)) {
        browser.click(myPresetItemDismiss);
        browser.pause(300);
      }
    } catch (e) {}    
  });
};