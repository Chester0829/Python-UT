// Recommended filename: When_I_enter_the_following_data_in_new_visualization_General_tab.js
module.exports = function() {
  this.When(/^I enter the following data in new visualization General tab$/,
    {timeout: process.env.StepTimeoutInMS*10},
    function (table) {
    // Write code here that turns the phrase above into concrete actions
    const dataViewerPage_xpath = this.xpath_lib.xpathRequire('dataViewerPage_xpath');
    var data_item_list = table.hashes();
    var cardName = this.visualizeName;
    var myVisualization_card = dataViewerPage_xpath.titled_Visualization_card.replace('__TITLE__', cardName);
    var myConfigGeneralTab = myVisualization_card + dataViewerPage_xpath.named_Visualization_configTab.replace('__NAME__', 'General');
    var browser_session = this.browser_session;
    var robot_session = this.robot_session;
    var waitDefault = this.waitDefault;
    browser.waitForVisible(myConfigGeneralTab, waitDefault);
    browser_session.waitForLoading(browser);
    browser.click(myConfigGeneralTab);

    data_item_list.forEach(function(data_item) {
      console.log('setting value for: ' + data_item['label']);
      switch (data_item['type']) {
        case "input":
          try{
            var input_xpath = myVisualization_card + dataViewerPage_xpath.labeled_Input.replace('__LABEL__', data_item['label']);
            browser.setValue(input_xpath, data_item['data']);
          }
          catch(e){
            var input_xpath = myVisualization_card + dataViewerPage_xpath.labeled_Input1.replace('__LABEL__', data_item['label']);
            browser.setValue(input_xpath, data_item['data']);
          }

          // When we change the tab name tab title changes together, thus we need to re-calculate the card and tab xpath
          if(data_item['label'] == "Name" && data_item['data'] != cardName)
          {
            cardName = data_item['data'];
            myVisualization_card = dataViewerPage_xpath.titled_Visualization_card.replace('__TITLE__', cardName);
            myConfigGeneralTab = myVisualization_card + dataViewerPage_xpath.named_Visualization_configTab.replace('__NAME__', 'General');
          }

          break;
        case "select":
          var select_xpath = myVisualization_card
                           + dataViewerPage_xpath.labeled_Node.replace('__LABEL__', data_item['label'])
                           + dataViewerPage_xpath.descendantMDSelect1;
          var select_dropdown = select_xpath + dataViewerPage_xpath.descendantMDSelect_icon;
          var select_target = dataViewerPage_xpath.named_MDOption.replace('__NAME__', data_item['data']);
          browser.waitForExist(select_dropdown, waitDefault*4);
          browser.waitForEnabled(select_dropdown, waitDefault*2);
          browser.click(select_dropdown);
          var maxTap = 100;
          while (!browser.isVisible(select_target) && (maxTap > 0)) {
            browser.keys('down');
            maxTap--;
            browser.pause(100);
          }
          browser.pause(100);
          browser.click(select_target);
          browser.pause(100);
          break;
        case "slider":
          var slider_xpath = myVisualization_card + dataViewerPage_xpath.labeled_Node.replace('__LABEL__', data_item['label']);
          var slider_pointer = slider_xpath + dataViewerPage_xpath.sliderPoint;
          browser.waitForVisible(slider_pointer);
          console.log(browser.getAttribute(slider_pointer, dataViewerPage_xpath.sliderPoint_ValMin));
          var slider_min = browser.getAttribute(slider_pointer, dataViewerPage_xpath.sliderPoint_ValMin)[0];
          var slider_max = browser.getAttribute(slider_pointer, dataViewerPage_xpath.sliderPoint_ValMax)[0];
          var slider_val = browser.getAttribute(slider_pointer, dataViewerPage_xpath.sliderPoint_ValNow)[0];
          browser.doubleClick(slider_pointer);
          browser.pause(100);
          for (var i = 0; i < (slider_val - slider_min); i++) {
            browser.keys('ArrowLeft');
            browser.pause(100);
          }
          for (var i = 0; i < (data_item['data'] - slider_min); i++) {
            browser.keys('ArrowRight');
            browser.pause(100);
          }
          break;
      }
    });
    this.visualizeName = cardName; //Ensure the name change to global.
  });
}
