// Recommended filename: Then_I_should_see_the_following_graphs_on_the_page.js
module.exports = function() {
  this.Then(/^I should see the following graphs on the page$/, {timeout: process.env.StepTimeoutInMS}, function(table) {
    // Write the automation code here
    browser.pause(5000);
    var robot_session = this.robot_session;
    var expected_data = table.hashes();
    expected_data.forEach(function(list_row) {
      var check_result = robot_session.findImage(null, list_row['graph_file']);
      console.log('checking ' + list_row['graph_name']);
      console.log(check_result);
      expect(check_result).not.toBe(null);
    }); //End of forEach loop
  });
}