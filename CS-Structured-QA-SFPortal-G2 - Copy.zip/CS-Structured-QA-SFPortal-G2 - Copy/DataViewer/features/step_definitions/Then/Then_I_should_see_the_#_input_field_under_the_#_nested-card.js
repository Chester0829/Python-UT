// Recommended filename: Then_I_should_see_the_#_input_field_under_the_#_nested-card.js
module.exports = function() {
   this.Then(/^I should see the "([^"]*)" input field under the "([^"]*)" nested\-card$/,
    {timeout: process.env.StepTimeoutInMS},
    function (placeHolderText, cardName) {
     // Write code here that turns the phrase above into concrete actions
    const dataViewerPage_xpath = this.xpath_lib.xpathRequire('dataViewerPage_xpath');
    if(cardName.toLowerCase() == 'current')
    {
      cardName = this.visualizeName;
    }
    var myVisualization_card = dataViewerPage_xpath.titled_Visualization_card.replace('__TITLE__', cardName);
    var myInput = myVisualization_card + dataViewerPage_xpath.named_Input.replace('__NAME__', placeHolderText);
    browser.waitForVisible(myInput, this.waitDefault);
   });
};