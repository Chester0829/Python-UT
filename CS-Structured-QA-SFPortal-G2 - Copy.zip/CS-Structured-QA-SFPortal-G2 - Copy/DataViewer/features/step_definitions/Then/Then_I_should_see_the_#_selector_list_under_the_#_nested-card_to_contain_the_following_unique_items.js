// Recommended filename: Then_I_should_see_the_available_selector_list_to_contain_the_following_unique_items.js
module.exports = function() {
  // we need to increase the timeout by 20x due to IE11 slowness in verifying long list
  this.Then(/^I should see the "([^"]*)" selector list under the "([^"]*)" nested-card to contain the following unique items$/,
    {timeout: process.env.StepTimeoutInMS*10},
    function (listName, cardName, table) {
    // Write code here that turns the phrase above into concrete actions
    const dataViewerPage_xpath = this.xpath_lib.xpathRequire('dataViewerPage_xpath');
    if(cardName.toLowerCase() == 'current')
    {
      cardName = this.visualizeName;
    }
    var expectedRow_list = table.hashes();
    var myVisualization_card = dataViewerPage_xpath.titled_Visualization_card.replace('__TITLE__', cardName);    
    // Below will include the Filter by and everything under it.
    var myFieldSelector = myVisualization_card + dataViewerPage_xpath.fieldSelector;
    var expectedItems_count = expectedRow_list.length;
    var myDisplayedList, myDisplayedListItem;
    //all available fields
    switch(listName)
    {
      case "Filter By":
        myDisplayedList = myFieldSelector + dataViewerPage_xpath.labeled_Select.replace('__LABEL__', 'Filter by:');
        myDisplayedListItem = myFieldSelector + dataViewerPage_xpath.labeled_SelectOptions.replace('__LABEL__', 'Filter by:');
        break;
      case "Available Fields":
        myDisplayedList = myFieldSelector + dataViewerPage_xpath.availableField;
        myDisplayedListItem = myFieldSelector + dataViewerPage_xpath.availableFieldItems;
        break;        
      default:
        console.log("OPTION: " + listName + "NOT IMPLEMENTED");
    }

    browser.waitForExist(myDisplayedListItem, this.waitDefault);
    var displayedList_elements = browser.elements(myDisplayedListItem).value;
    var displayedItems_count;
    var displayedField_text;
    displayedItems_count = displayedList_elements.length;
    console.log('checking displayed ::' + displayedItems_count + ':: vs expected ::' + expectedItems_count + '::');
    expect(displayedItems_count).toBe(expectedItems_count);
    browser.waitForExist(myDisplayedList, this.waitDefault*4);
    browser.waitForExist(myDisplayedListItem, this.waitDefault*4);
    displayedList_elements.forEach(function(displayedElement, index) {
      displayedField_text = browser.elementIdText(displayedElement.ELEMENT).value;
      console.log(displayedField_text);
      console.log('checking displayed ::' + displayedField_text + ':: vs expected ::' + expectedRow_list[index]['item_name'] + '::');
      expect(displayedField_text).toBe(expectedRow_list[index]['item_name']);     
    })
  });
};
