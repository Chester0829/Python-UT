// Recommended filename: Then_I_should_see_the_#_#_table_under_the_#_card_to_#_the_following_table_#_#.js
module.exports = function() {
  this.Then(/^I should see the (only|1st|2nd|3rd|4th) (simple|pivot) table under the "([^"]*)" card to (contain|match) the following table (header|row\-data|regex) (in\-any\-row|row\-by\-row)$/,
    {timeout: process.env.StepTimeoutInMS*5},
    function(tableIndex, tableType, cardName, testAction, contentType, checkMethod, table) {
    // Write the automation code here
    const dataViewerPage_xpath = this.xpath_lib.xpathRequire('dataViewerPage_xpath');
    if(cardName.toLowerCase() == 'current')
    {
      cardName = this.visualizeName;
    }

    var expected_row_list = table.hashes();
    var myVisualization_card = dataViewerPage_xpath.titled_Visualization_card.replace('__TITLE__', cardName);
    var myTableIndex;
    var myDisplayToCheck_xpath;
    var myDisplayToCheck_text;
    var robot_session = this.robot_session;

    switch (tableIndex) {
      default:
      case "1st":
        myTableIndex = 1;
        break;
      case "2nd":
        myTableIndex = 2;
        break;
      case "2nd":
        myTableIndex = 3;
        break;
      case "4th":
        myTableIndex = 4;
        break;
    }
    var myTable = myVisualization_card + dataViewerPage_xpath.masterTable;
    var myTableHdr = myTable + '/thead';
    var myTableBdy = myTable + '/tbody';
    console.log(myTable);

    browser.waitForVisible(myTable, this.waitDefault);
    browser.getLocationInView(myTable);

    expected_row_list.forEach(function(expected_row, rowIndex) {
      switch (checkMethod) {
        case "in-any-row":
          // set displayed content
          switch (contentType) {
            case 'header':
              myDisplayToCheck_xpath = myTableHdr;
              myDisplayToCheck_text = browser.getText(myDisplayToCheck_xpath).replace(/[\r\n]/g, ' :: ');
              break;
            case 'row-data':
              myDisplayToCheck_xpath = myTableBdy;
              // '/../..' to get text from parent div for the entire table
              myDisplayToCheck_text = browser.getText(myDisplayToCheck_xpath + '/ancestor::div[1]').replace(/[\r\n]/g, ' :: ');
              console.log("DEBUG xpath: " + myDisplayToCheck_xpath + "\nTEXT " + myDisplayToCheck_text);
              break;
          };
          break;
        case "row-by-row":
          switch (contentType) {
            case 'header':
              myDisplayToCheck_xpath = '(' + myTableHdr + '//tr)[' + (rowIndex + 1) + ']';
              myDisplayToCheck_text = browser.getText(myDisplayToCheck_xpath).replace(/[\r\n]/g, ' :: ');
              break;
            case 'row-data':
              myDisplayToCheck_xpath = '(' + myTableBdy + '//tr)[' + (rowIndex + 1) + ']';
              myDisplayToCheck_text = browser.getText(myDisplayToCheck_xpath).replace(/[\r\n]/g, ' :: ');
              break;
          };
          break;  
      }
      robot_session.moveMouseToLink(browser, myDisplayToCheck_xpath);
      browser.pause(500);
      switch (testAction) {
        case 'contain':
          if (expected_row['row_data']) {
            expect(myDisplayToCheck_text).toContain(expected_row['row_data']);
            // console.log("DEBUG in contain option: " + myDisplayToCheck_text);
          }
          break;
        case 'match':
          if (expected_row['row_data']) {
            expect(myDisplayToCheck_text).toMatch(expected_row['row_data']);
            // console.log("DEBUG in match option: " + myDisplayToCheck_text);
          }
          break;
      };
      // robot_session.keyTap('down');
    });
    browser.pause(500);
  });
}