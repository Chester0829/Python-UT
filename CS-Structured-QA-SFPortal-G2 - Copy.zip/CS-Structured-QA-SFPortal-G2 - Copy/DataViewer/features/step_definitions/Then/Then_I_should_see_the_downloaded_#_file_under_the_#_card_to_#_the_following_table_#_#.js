// Recommended filename: Then_I_should_see_the_download_file_under_the_#_card_to_#_the_following_table_#_#.js
module.exports = function() {
  this.Then(/^I should see the downloaded (XLS|CSV|PDF) file under the "([^"]*)" card to (contain|match) the following table (header|row\-data|regex) (in\-any\-row|row\-by\-row)$/,
    {timeout: process.env.StepTimeoutInMS*5},
    function(fileType, cardName, testAction, contentType, checkMethod, table) {
    // Write the automation code here

    const dataViewerPage_xpath = this.xpath_lib.xpathRequire('dataViewerPage_xpath');
    const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
    var myVisualization_card = dataViewerPage_xpath.titled_Visualization_card.replace('__TITLE__', cardName);

    var moment = require('moment');
    var expected_row_list = table.hashes();
    var myExportXLSIcon = myVisualization_card + dataViewerPage_xpath.exportXLS_icon;
    var today = moment().local().format('DD-MMM-YYYY');
    var file_name = cardName + '_' + today;
    var file_name_ext;
    var file_ext = 'xls';
    var displayedToCheck_text;
    var expectedToCheck_Text;

    switch (fileType) {
      case 'XLS':
        file_name_ext = file_name + '.xls';
        break;
      case 'CSV':
        file_name_ext = file_name + '.csv';
        break;
      case 'PDF':
        file_name_ext = file_name + '.pdf';
        break;
    }

    // if action bar is expanded let's collaspe it
    var myExpandedActionBar_xpath = dataViewerPage_xpath.actionBar_expanded;
    var myCollaspeActionBar_icon = dataViewerPage_xpath.titled_actionIcon.replace('__TITLE__', 'Collapse Action Bar');
    if (browser.isVisible(myExpandedActionBar_xpath)) {
      browser.click(myCollaspeActionBar_icon);
    }

    var my_download_file;
    // skip file download part if file is downloaded in the header step
    if ( (contentType == 'header') || (this.my_download_file_from_header_step == null)) {
      browser.pause(10*1000);
      // Delete file of the same name before download test
      this.file_session.deleteFiles(file_name);
      this.browser_session.waitForLoading(browser);
      browser.waitForVisible(myExportXLSIcon, this.waitDefault);
      // click somewhere to avoid selenium-IE not clicking the same spot issue
      browser.click(header_xpath.noWhere);
      browser.pause(500);
      console.log('clicking exportIcon: ' + myExportXLSIcon);
      browser.click(myExportXLSIcon);
      browser.pause(1000);
      // For IE we need to click the save button
      if (process.env.BROWSER == 'IE11') {
        browser.pause(5*1000);
        this.robot_session.clickImage(null, 'IE11_DownloadSave.png');
        browser.pause(10*1000);
        this.robot_session.clickImage(null, 'IE11_DownloadDismissX.png');
        browser.pause(1000);
      }
      my_download_file = this.file_session.waitForDownload(browser, file_name_ext);
      this.my_download_file_from_header_step = my_download_file;
    } else {
      console.log('re-use download from previous step.')
      my_download_file = this.my_download_file_from_header_step;
    }

    console.log('my download file: ' + my_download_file);
    var table_json = this.file_session.readHtmlAsJsonString(my_download_file);
    var table_csv = this.file_session.readHtmlAsCsvString(my_download_file);
    var table_array = table_csv.split('\n');
    var table_body = table_csv;
    // console.log(table_json);
    // console.log(table_csv);
    expected_row_list.forEach(function(expected_row, rowIndex) {
      if (expected_row['row_count']) {
        var [rowOp, rowCount] = expected_row['row_count'].split(/ +/);
        switch (rowOp) {
          case "=": 
            expect(table_array.length).toBe(rowCount);
            break;
          case ">":
            // expect(table_array.length.toString()).toBeGreaterThan(rowCount);
            expect(table_array.length).toBeGreaterThan(parseFloat(rowCount));
              break;
          case '>=':
            expect(table_array.length).not.toBeLessThan(parseFloat(rowCount));
              break;
          case "<":
            // expect(table_array.length.toString()).toBeLessThan(rowCount);
            expect(table_array.length).toBeLessThan(parseFloat(rowCount));
              break;
          case "<=":
            // expect(table_array.length.toString()).not.toBeGreaterThan(rowCount);
            expect(table_array.length).not.toBeGreaterThan(parseFloat(rowCount));
              break;
          default:
            expect(table_array.length.toString()).toBe(expected_row['row_count']);
        }
      }
      switch (checkMethod) {
        case "in-any-row":
          // set displayed content
          switch (contentType) {
            case 'header':
              displayedToCheck_text = table_body;
              break;
            case 'row-data':
              displayedToCheck_text = table_body;
              break;
          };
          break;
        case "row-by-row":
          var expected_row_count = expected_row_list.length;
          switch (contentType) {
            case 'header':
              displayedToCheck_text = table_array[rowIndex];
              break;
            case 'row-data':
              displayedToCheck_text = table_array[rowIndex];
              break;
          };
          break;  
      }

      if (expected_row['left'] && !expected_row['right']) {
        expectedToCheck_Text = expected_row['left'];
      } else if (expected_row['right'] && !expected_row['left']) {
        expectedToCheck_Text = expected_row['right'];
      } else if (expected_row['left'] && expected_row['right']) {
        expectedToCheck_Text = expected_row['left'] + ',' + expected_row['right'];
      } else {
        expectedToCheck_Text = expected_row['row_data'];
      }

      switch (testAction) {
        case 'contain':
          expect(displayedToCheck_text).toContain(expectedToCheck_Text);
          break;
        case 'match':
          expect(displayedToCheck_text).toMatch(expectedToCheck_Text);
          break;
      };
    });
  });
}