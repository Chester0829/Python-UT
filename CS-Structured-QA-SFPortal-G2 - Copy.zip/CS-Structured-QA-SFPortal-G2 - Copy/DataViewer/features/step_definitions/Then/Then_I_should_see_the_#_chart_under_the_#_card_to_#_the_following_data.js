// Recommended filename: Then_I_should_see_the_#_expandable-table_under_the_#_card_to_#_the_following_table_#_#.js
module.exports = function() {
  this.Then(/^I should see the (only|1st|2nd|3rd|4th) chart under the "([^"]*)" card to (contain|match) the following data$/,
    {timeout: process.env.StepTimeoutInMS*5},
    function(tableIndex, cardName, testAction, table) {
    // Write the automation code here
    const dataViewerPage_xpath = this.xpath_lib.xpathRequire('dataViewerPage_xpath');
    if(cardName.toLowerCase() == 'current')
    {
      cardName = this.visualizeName;
    }
    var myVisualization_card = dataViewerPage_xpath.titled_Visualization_card.replace('__TITLE__', cardName);
    var myChartWidget = myVisualization_card + dataViewerPage_xpath.chartWidget;
    var myChartInner = myChartWidget + dataViewerPage_xpath.chartInner;
    var myTableIndex;
    var displayedToCheck_xpath;
    var displayedToCheck_text;

    //Wait for chart to be displayed
    browser.waitForVisible(myChartInner, 2*this.waitDefault);
    browser.pause(600);

    var actualTable_xpath = myVisualization_card + myChartWidget;
    // var actualTable_txt = browser.getText(actualTable_xpath);
    var actualTable_txt = browser.getText(actualTable_xpath).split('\n').toString();
    var chart_count = browser.elements(myChartInner).value.length;

    expect(chart_count).toBeGreaterThan(0);
    console.log("Chart Count: " + chart_count);
    console.log("actualTable_xpath: " + actualTable_xpath);
    console.log("==== chart text split: " + actualTable_txt);

    console.log("NoneSplit: \n" + browser.getText(actualTable_xpath));
    //FIXME: This is a quick validation, of text in the chart.
    var expected_data = table.hashes();
    expected_data.forEach(function(list_row)
    {
      switch (testAction) {
        case 'contain':
          if (list_row['row_data']) {
            expect(actualTable_txt).toContain(list_row['row_data']);
          }
          break;
        case 'match':
          if (list_row['row_data']) {
            expect(actualTable_txt).toMatch(list_row['row_data']);
          }
          break;
      };
    }); //End of forEach loop

  });
}