exports.mwsa_report_service_config = {
  user: 'dummy_user',
  password: 'dummy_password',
  server: 'dummy.FQDN.or.ip',
  database: 'dummy_database',
  options: {
    encrypt: true
	}
};

