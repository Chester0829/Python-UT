exports.getPassword = function(user_name) {
  switch(user_name) {
  	case "dummy_user1":
  	  return "dummy_password1";
    case "dummy_user2":
      return "dummy_password2";
  }
};
