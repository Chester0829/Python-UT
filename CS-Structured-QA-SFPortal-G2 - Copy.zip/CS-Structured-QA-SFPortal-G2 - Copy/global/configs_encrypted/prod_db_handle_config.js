// db_handle_config.js
// THIS FILE SHOULD BE ENCRYPTED!!
// This file contains sensitive information. It should be encrypted before check-in.
// It should only be decrypted on a private local system, and should have RO permission
// by the file owner.
// Please report and issue if:
//   1. If you can see the content of this file in github/gitlab;
//   2. If you see the file permission is not Unix 600 or equivalent. 

// mssql db_handle config for accessing staff table in database
exports.mwsa_report_service_config = {
  user: 'mwsa_report_reader',
  password: 'mascone2w3@',
  server: 'mwsareporting-1.cmcw5xhgw6vu.us-west-2.rds.amazonaws.com',
  database: 'MWSAReporting',
  options: {
    encrypt: true
	}
};

