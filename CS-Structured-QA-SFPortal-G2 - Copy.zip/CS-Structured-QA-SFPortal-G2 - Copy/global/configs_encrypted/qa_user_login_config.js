// user_login_config.js
// THIS FILE SHOULD BE ENCRYPTED!!
// This file contains sensitive information. It should be encrypted before check-in.
// It should only be decrypted on a private local system, and should have RO permission
// by the file owner.
// Please report and issue if:
//   1. If you can see the content of this file in github/gitlab;
//   2. If you see the file permission is not Unix 600 or equivalent. 

// muser_login config
exports.getPassword = function(user_name) {
  switch(user_name) {
  	case "SFPQA001":
  	  return "SFPQA001";
  	case "SFPQA002":
  	  return "SFPQA002";
  	case "SFPQA003":
  	  return "SFPQA003";
  	case "SFPQA004":
  	  return "SFPQA004";
  	case "SFPQA005":
  	  return "SFPQA005";
  	case "SFPQA006":
  	  return "SFPQA006";
  	case "SFPQA007":
  	  return "SFPQA007";
  	case "SFPQA008":
  	  return "SFPQA008";
  	case "SFPQA009":
  	  return "SFPQA009";
  	case "SFPQA010":
  	  return "SFPQA010";
    case "SFPQA011":
      return "SFPQA011";
    case "SFPQA012":
      return "SFPQA012";
  	case "SAVQARegModuleY":
  	  return "SAVQARegModuleY";
  	case "SAVQARegModuleN":
  	  return "SAVQARegModuleN";
    case "qa_under50":
      return "qa_under50";
    case "SAVQAPermTestN":
      return "SAVQAPermTestN";
    case "aChung":
  	  return "aChung1205";
    case "QinS":
  	  return "SQ2015";
    case "SAVQA009":
     return "SAVQA009";
    case "SAVQAPermTestX":
     return "SAVQAPermTestX";
     case "kHo":
     return "wsa4dinner";
     case "SAVQA003":
     return "WSAQA003!";
     case "SAVQA004":
     return "WSAQA004!";
     case "SAVQA006":
     return "WSAQA006!";
     case "SAVQA007":
     return "WSAQA007!";
     case "SAVQA011":
     return "WSAQA011!"
  	default:
  	  return user_name;
  }
};
