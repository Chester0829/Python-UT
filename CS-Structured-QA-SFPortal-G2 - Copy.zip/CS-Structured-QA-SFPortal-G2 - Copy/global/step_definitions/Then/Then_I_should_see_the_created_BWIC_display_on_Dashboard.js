//// Recommended filename: Then_I_should_see_the_created_BWIC_display_under_the_#_panel-heading.js
module.exports = function() {
	this.Then(/^I should see the created BWIC display under the "([^"]*)" panel\-heading$/, function (panelName) {
		// Write code here that turns the phrase above into concrete actions
		// return 'pending';
		const bwic_xpath = this.xpath_lib.xpathRequire('bwic_xpath');

		const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
		const dashboardPage_xpath = this.xpath_lib.xpathRequire('dashboardPage_xpath');
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    var portfoliosSection = content_xpath.titledSection.replace('__TITLE__', 'Portfolios');
		var myPanel = bwic_xpath.nameTitle;
		var dashboard_button = header_xpath.mainDashboard_button;
		
		var entriesInfo = browser.getText(myPanel + bwic_xpath.showEntries).trim().split(' ');
		console.log('entriesInfo: ' + entriesInfo);
		var totalEntris = entriesInfo[entriesInfo.length-2];
		console.log('totalEntris: ' + totalEntris);
		var bwicTitle = browser.getText(bwic_xpath.bwicPanel);
		var bwicName = Array.isArray(bwicTitle) ? bwicTitle[0].split(':')[1].trim() : bwicTitle.split(':')[1].trim();
		console.log(bwicName);

		// go to dashboard
    try {
      	this.browser_session.waitForLoadingSection(browser, portfoliosSection);
        browser.waitForVisible(content_xpath.maskOff, this.waitDefault);
        browser.waitForVisible(dashboard_button, this.waitDefault);
        browser.click(dashboard_button);
    } catch (e) {
        // go to dashboard directly
        var dashboard_url = this.test_url + '/dashboard';
        browser.url(dashboard_url);
    }
    this.browser_session.waitForLoadingSection(browser, portfoliosSection);
		this.browser_session.waitForResource(browser);

		var bwicTableOnDashbord = bwic_xpath.bwicTableOnDashbord;
		console.log(bwicTableOnDashbord);
		browser.waitForVisible(bwicTableOnDashbord,this.wait30);

		// show Item
		var showItems = bwicTableOnDashbord + bwic_xpath.showItems;
		console.log(showItems);
		browser.click(showItems);
		var selectMenu = bwic_xpath.selectMenu;
		browser.waitForVisible(selectMenu,this.waitDefault);
		browser.click(selectMenu + '//*[text()="100"]');


		// search item
		var searchXpath = bwicTableOnDashbord + bwic_xpath.search_xpath;
		browser.setValue(searchXpath,bwicName.split('_')[0]);
		browser.pause(500);

		
		var htmls = browser.getHTML(bwicTableOnDashbord);
		var table_json = this.tabletojson.convert(htmls)[0];
		console.log(table_json);
		var flag = false;
		for(var i=0;i<table_json.length;i++){
			if(table_json[i]['Name'] == bwicName){
				flag = true;
				expect(parseInt(table_json[i]['Identifiers'])).toEqual(parseInt(totalEntris));
			}
			// delete automation bwic
			try{
				var deleteIcon = bwicTableOnDashbord + bwic_xpath.deleteIcon;
				console.log(deleteIcon);
				browser.click(deleteIcon);
				this.robot_session.keyTap();
			}catch(e){
				this.robot_session.keyTap();
			}
			browser.pause(500);
		}
		if(!flag){
			expect(false).toBe(true,'can not find the bwicName:' + bwicName);	
		}
		
	
	});
}