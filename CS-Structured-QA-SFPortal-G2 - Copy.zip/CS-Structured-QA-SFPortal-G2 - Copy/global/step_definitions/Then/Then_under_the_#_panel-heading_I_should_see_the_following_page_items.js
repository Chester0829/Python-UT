// Recommended filename: Then_under_the_#_panel-heading_I_should_see_the_following_page_items.js
module.exports = function() {
  this.Then(/^under the "([^"]*)" panel-heading I should see the following page items$/, function (panelName, table) {
    // Write the automation code here
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const portfolioPage_xpath = this.xpath_lib.xpathRequire('portfolioPage_xpath');
    const managerPage_xpath = this.xpath_lib.xpathRequire('managerPage_xpath');
    const dealPage_xpath = this.xpath_lib.xpathRequire('dealPage_xpath');
    const issuerPage_xpath = this.xpath_lib.xpathRequire('issuerPage_xpath');

    browser.pause(1000);
    this.browser_session.waitForLoading(browser);
    var myPanel_xpath = content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase());
    var myBrowserSession = this.browser_session;
    var expected_item_list = table.hashes();
    var myWaitDefault = this.waitDefault;
    expected_item_list.forEach(function(expected_item) {
      var myExpected_xpath = myPanel_xpath + eval(expected_item['item']);
      if (myExpected_xpath) {
        if (expected_item['replace_text']) {
          myExpected_xpath = myExpected_xpath.replace(/__.*__/, expected_item['replace_text']);
        }
        console.log('expected page item: ' + expected_item['item']);
        console.log('xpath: ' + myExpected_xpath);
        browser.waitForVisible(myExpected_xpath, myWaitDefault*2);
        browser.getLocationInView(myExpected_xpath);
        expect(myBrowserSession.elementSomeVisible(browser, myExpected_xpath)).toBe(true);
      } else {
        console.log('**NOTE**: ' + expected_item['item'] + ' yield null in ' + process.env.NODE_ENV + ' xpath file.');
      }
    });
  });
};
