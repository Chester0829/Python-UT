// Then_I_should_see_the_success_message_and_refresh_page.js
module.exports = function() {
  this.Then(/^I should see the (success|fail) message and (refresh|cannot refresh) page$/,
    {timeout:process.env.StepTimeoutInMS*5},
    function (tag,arg1) {
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');

      switch(tag){
        case 'success':
          var alertXpath = '//div[contains(@class,"growl-item alert alert-success")]';
          var alertXpath1 = '//div[contains(@class,"alert alert-success")]';
          break;
        case 'fail':
          var alertXpath = '//div[contains(@class,"growl-item alert alert-fail")]';
          var alertXpath1 = '//div[contains(@class,"growl-item alert alert-fail")]';
          break;
      }
      

      try{
          browser.waitForVisible(alertXpath,this.waitDefault);
          console.log(browser.getText(alertXpath));
         }catch(e){
          console.log('try again...');
          var button_xpath = content_xpath.namedButton.replace('__NAME__', "Save");
          browser.click(button_xpath);
          browser.waitForVisible(alertXpath1,this.waitDefault);
          console.log(browser.getText(alertXpath1));
         }  
      browser.pause(2*1000);
      if(arg1 == 'refresh'){
        browser.refresh();
        this.browser_session.waitForLoading(browser);
        this.browser_session.waitForResource(browser);
        browser.pause(5000);
      }

    });
}