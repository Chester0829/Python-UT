// Recommended filename: Then_I_should_see_#_#_#_displayed_in_the_#.js
module.exports = function() {
  this.Then(/^I should see (no|the|\d|some|one) "([^"]*)" (message|text|button) displayed in the (page|page body|page content|search result|banner section|banner extension|header section|footer section|historical charts|compare page|specified historical charts)$/, function (count, expectedText, textType, targetSection) {
    const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
    const footer_xpath = this.xpath_lib.xpathRequire('footer_xpath');
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    var targetSection_xpath;
    switch (targetSection) {
      case "page content":
        targetSection_xpath = content_xpath.uiViewContent;
        break;
      case "search result":
        targetSection_xpath = header_xpath.searchResult;
        break;
      case "banner section":
        targetSection_xpath = content_xpath.contentBannerContainer;
        break;
      case "banner extension":
        targetSection_xpath = content_xpath.contentBannerExtension;
        break;
      case "header section":
        targetSection_xpath = header_xpath.headerSection;
        break;
      case "footer section":
        targetSection_xpath = footer_xpath.footerSection;
        break;
      case "page body":
        targetSection_xpath = '//body';
        break;
      case "historical charts":
        targetSection_xpath = content_xpath.history_charts1;
        break;
      case "specified historical charts":
        targetSection_xpath = content_xpath.history_charts2;
        var expected_list = this.expected_list;
        var charts_set=new Set(expected_list['charts'])
        break;
      // case 'compare page':
      //   targetSection_xpath = '//body';
      //   break; 
      default:
        targetSection_xpath = '//html';
    }
    // console.log(targetSection_xpath);
    if (targetSection=='specified historical charts'){
      for(var item of charts_set){
        var targetChart = '('+targetSection_xpath+')['+item+']'
        var displayedText = browser.getText(targetChart)
        console.log(displayedText)
        expect(displayedText).not.toContain(expectedText);
      }
      return;
    }
    var displayedText = browser.getText(targetSection_xpath);
    // console.log(displayedText);
    var expected_count;
    var displayed_count;
    switch (count) {
      case 'no':
      case '0':
        expect(displayedText).not.toContain(expectedText);
        expected_count = 0;
      break;
      case 'one':
          expect(displayedText).toContain(expectedText);
          expected_count = 1;
          break;
      default:
        expect(displayedText).toContain(expectedText);
        if (count == 'the') { expected_count = 1 } else { expected_count = count }
        break;
    }
    displayed_count = displayedText.split(expectedText).length -1;
    if (count == 'some') {
      expect(displayed_count).toBeGreaterThan(0);
    } else {
      expect(displayed_count).toEqual(parseInt(expected_count));
    }
  });
};
