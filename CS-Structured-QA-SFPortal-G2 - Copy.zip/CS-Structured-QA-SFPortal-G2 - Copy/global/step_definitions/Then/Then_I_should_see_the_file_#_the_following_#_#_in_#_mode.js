// Recommended filename: Then_I_should_see_the_file_#_the_following_#_#_in_#_mode.js
module.exports = function() {
	this.Then(/^I should see the file (contains|contain|match) the following (header|data|data regex) (row|row by row) in (manager) mode$/,
		{timeout: process.env.StepTimeoutInMS*5},
		function (testAction,contentType,compareType,mode,table){
			this.browser_session.waitForResource(browser);
			var expected_item_list = table.hashes();
			console.log(expected_item_list);
			var self = this;
			var index = 0;
			var index1 = 0

			function compareData(targetData,row_data,index){
				switch(contentType){
					case 'header':
						var check_data = targetData[0]; // ['as']
						break;
					case 'data regex':
					case 'data':
						var check_data = targetData.slice(1); // [[],[]]
						break;
				}
				console.log(check_data);
				switch(testAction){
					case 'contains':
					case 'contain':
						// for header
						var tmp = row_data.replace(/ :: /g,',').trim();
						if( tmp.endsWith(' ::') ){
							var data = tmp.replace(' ::',',');
						}else{
							var data = tmp;
						}
						expect(check_data.replace(/"/g,'')).toContain(data);
						break;
					case 'match':
						// no data
						if(check_data.length == 0){
							console.log(row_data);
							for(var j=0;j<self.no_data_text_list.length;j++){
								// console.log(self.no_data_text_list);
								if(row_data.indexOf(self.no_data_text_list[j]) != -1){
									return;
								}
							}
							expect(false).toBe(true);
						}
						// for header match
						if(typeof(check_data) === 'string') {
							expect(check_data.replace(/,/g, ' :: ').replace(/"/g, '')).toMatch(row_data);
							return;
						}
						if(compareType == 'row'){
							for(var i=0;i<check_data.length;i++){
								if(check_data[i] == ''){continue}
								// var tmp = check_data[i].split('","').join(' :: ');
								var tmp = check_data[i].split('","').map(function(curValue){return curValue.trim()}).join(' :: ');
								console.log(tmp);
								expect(tmp).toMatch(row_data);
							}
						}else if(compareType == 'row by row'){
							if(check_data[index] != ''){
								var tmp = check_data[index].split('","').map(function(curValue){return curValue.trim()}).join(' :: ');
								console.log(tmp);
								expect(tmp).toMatch(row_data);
								// index = index + 1;
							}
						}
						break;
				}
			}


			expected_item_list.forEach(function(expected_item){
				if(expected_item['row_data']){
					// for table 1
					// console.log('********* for first table ***********');
					var row_data = contentType.indexOf('regex') != -1 ? self.regex_lib.replaceRegex(expected_item['row_data']) : expected_item['row_data'];
					var targetData = self.file_target_data[0];
					// console.log(targetData);
					compareData(targetData,row_data,index);
					index = index + 1;
				}

				if(expected_item['row_data1']){
					// for table 2
					// console.log('********* for second table ***********');
					var row_data1 = contentType.indexOf('regex') != -1 ? self.regex_lib.replaceRegex(expected_item['row_data1']) : expected_item['row_data1'];
					var targetData = self.file_target_data[1];
					// console.log(targetData);
					compareData(targetData,row_data1,index1);
					index1 = index1 + 1;
				}

			})


		})
}