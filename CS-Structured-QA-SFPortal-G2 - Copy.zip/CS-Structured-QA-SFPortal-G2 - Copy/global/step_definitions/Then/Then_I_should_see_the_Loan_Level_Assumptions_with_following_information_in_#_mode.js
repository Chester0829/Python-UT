// Then_I_should_see_the_Loan_Level_Assumptions_with_following_information_in_#_mode.js
// for cmbs deal cashflow Loan Level Assumptions
module.exports = function() {
  this.Then(/^I should see the Loan Level Assumptions with following information in (Deal) mode$/,function(mode,table){
    const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
    var tableList = table.hashes();
    var tbody = cashflow_xpath.loanLevelTbody;
    // for loan.inputAssumpOption
    var inputAssumpOption = {'Default to Strat/Deal Settings':'default','Input Loan Assumptions':'input'};
    for(var i=0;i<tableList.length;i++){
      var index = tableList[i]['index'];
      var column = tableList[i]['column'];
      var value = tableList[i]['value'];
      if(index == 'all'){
        var tmp = browser.isVisible(tbody + '//tr');
        var allTr = Array.isArray(tmp) ? tmp.length : 1;
        for(var j=0;j<allTr;j++){
          var tr = tbody + '/tr[' + (j+1) + ']';
          switch(column){
            case 'loan.inputAssumpOption':
              var select = cashflow_xpath.select.replace('__NAME__',column);
              // var select = '//select[@ng-model="loan.inputAssumpOption"]';
              var tmp = tr + select;
              // console.log(tmp);
              expect(inputAssumpOption[value]).toEqual(browser.getValue(tmp));
              break;
          }
        }
      }else{
        var tr = tbody + '/tr[' + index + ']';
        switch(column){
          case 'loan.inputAssumpOption':  //Default to Strat/Deal Settings --> default,Input Loan Assumptions-->input
            var select = cashflow_xpath.select.replace('__NAME__',column);
            // var select = '//select[@ng-model="loan.inputAssumpOption"]';
            var tmp = tr + select;
            console.log(tmp);
            expect(inputAssumpOption[value]).toEqual(browser.getValue(tmp));
            break;
        }
      }
    }


  })


}
