  //Then_I_click_#_tab_and_see_the_frame_should_match_following_table.js
  module.exports = function() {
       this.Then(/^I click "([^"]*)" tab and see the frame should match following table$/, function (arg1, table) {
         // Write code here that turns the phrase above into concrete actions
          const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath'); 
          var expect_row_list = table.hashes();
          var editTab = cashflow_xpath.editDealFrame + cashflow_xpath.editDealTab.replace('__TAB__',arg1);
          browser.getLocationInView(editTab);
          browser.click(editTab);
          this.browser_session.waitForResource(browser,cashflow_xpath.editDealFrame);
          var table_html = browser.getHTML(cashflow_xpath.editDealTable);
          var editDealTable_json = this.tabletojson.convert(table_html)[0];
          var self = this;
          expect_row_list.forEach(function(expect_row){
              if(arg1 == 'Tranches'){
                var trancheName = expect_row.Class;
                var balance_override = cashflow_xpath.editTrancheDealRow.replace('__NAME__',trancheName)+cashflow_xpath.editDealBalance;
                expect(expect_row['Balance Override']).toEqual(browser.getValue(balance_override));
                var coupon_spread = cashflow_xpath.editTrancheDealRow.replace('__NAME__',trancheName)+cashflow_xpath.editDealCouponSpread;
                console.log("expect_row['Coupon/Spread']:"+expect_row['Coupon/Spread']);
                expect(expect_row['Coupon/Spread']).toEqual(browser.getValue(coupon_spread));
              }
              if(arg1 == 'Collateral'){
                var collateral_Index = expect_row.Index;
                var balance_override = "("+cashflow_xpath.editCollateralDealRow+cashflow_xpath.editDealBalance+")["+collateral_Index+"]";
                try{
                    browser.waitForText(balance_override,5000);
                }catch(e){
                }

                console.log('balance_override:'+ balance_override);
                expect(expect_row['Balance Override']).toEqual(browser.getValue(balance_override));
                var coupon_spread = "("+cashflow_xpath.editCollateralDealRow+cashflow_xpath.editDealCouponSpread+")["+collateral_Index+"]";
                expect(expect_row['Coupon/Spread']).toEqual(browser.getValue(coupon_spread));
              }
          });
          this.browser_session.waitForResource(browser,cashflow_xpath.editDealFrame);
       });
}