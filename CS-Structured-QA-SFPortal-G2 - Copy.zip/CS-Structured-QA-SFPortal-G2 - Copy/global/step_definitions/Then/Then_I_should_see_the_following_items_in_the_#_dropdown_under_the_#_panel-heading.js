// Recommended filename: Then_I_should_see_the_following_items_in_the_#_dropdown_under_the_#_panel-heading.js
module.exports = function() {
  this.Then(/^I should see the following items in the "([^"]*)" dropdown under the "([^"]*)" panel-heading$/, 
    {timeout: process.env.StepTimeoutInMS*5},
    function (dropdownName, panelName, table) {
    // Write the automation code here
    
    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const selectOption_xpath = this.xpath_lib.xpathRequire('selectOption_xpath');
    const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
    const scenarioManager_xpath = this.xpath_lib.xpathRequire('scenarioManager_xpath');
    const regulatory_xpath = this.xpath_lib.xpathRequire('regulatory_xpath');

    var myPanel_xpath;
    var mySelect_xpath;
    var mySelectDropdown_xpath;
    var mySelectCaret_xpath;
    var mySelectInput_xpath;
    var mySelectMatched_xpath;
    var expected_row_list = table.hashes();

    switch (dropdownName) {
        case "pool-select":
        case "deal-select":
            myPanel_xpath = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase());
            mySelectDropdown_xpath = myPanel_xpath + selectOption_xpath.selectDropdown;
            mySelectCaret_xpath = myPanel_xpath + selectOption_xpath.selectCaret;
            mySelectInput_xpath = myPanel_xpath + selectOption_xpath.selectInput;
            console.log(mySelectCaret_xpath);
            console.log(mySelectDropdown_xpath);
            browser.getLocationInView(myPanel_xpath);
            browser.waitForVisible(mySelectCaret_xpath,this.waitDefault);
            browser.click(mySelectCaret_xpath);
            browser.waitForText(mySelectDropdown_xpath,2000);
            var selectList_text = browser.getText(mySelectDropdown_xpath);
            var selectList_textArray = selectList_text.split('\n');
            console.log(selectList_text);
            expected_row_list.forEach(function(row, index) {
                console.log("real item value:"+selectList_textArray[index]);
                console.log("expect item value:"+row['item']);
                expect(selectList_textArray[index]).toBe(row['item']);
            });
            break;
        case "Choose Report":
            myPanel_xpath = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase());
            mySelect_xpath = myPanel_xpath + selectOption_xpath.labeledSelect.replace('__LABEL__', dropdownName);
            mySelectDropdown_xpath = selectOption_xpath.reportSelectDropdown;
            mySelectCaret_xpath = mySelect_xpath + selectOption_xpath.selectCaret;
            console.log(mySelectCaret_xpath);
            console.log(mySelectDropdown_xpath);
            browser.getLocationInView(myPanel_xpath);
            browser.waitForVisible(mySelectCaret_xpath,this.waitDefault);
            browser.click(mySelectCaret_xpath);
            browser.waitForText(mySelectDropdown_xpath,2000);
            var selectList_text = browser.getText(mySelectDropdown_xpath);
            var selectList_textArray = selectList_text.split('\n');
            console.log(selectList_text);
            expected_row_list.forEach(function(row, index) {
                expect(selectList_textArray[index]).toBe(row['item']);
            });
            break;
        case "scen.solve_for":
        case "scen.forward_curve":
        case "scen.prepay_type":
        case "scen.default_type":
        case "scen.loss_type": 
        case "scen.delinquency_type": 
        case "scen.delinquency_type":
        case "scen.servicer_basis":
        case "scen.servicer_type":
        case "scen.repay_type":
        case "scen.purchase_type":
        case "scen.portfolio_yield_type":
        case "scen.portfolio_loss_type":
        case "scen.deferment_type":
        case "scen.grace_type":
        case "scen.forbear_type":
        case "scen.interest_cap_freq":
        case "scen.BB_type": 
        case "scen.call_option":
        case "scen.force_call":
        case "scen.reinvest_price_type":
        case "scen.reinvest_pool":
        case "scen.reinvest_rules":
            if (panelName == "Add Scenario"){
                var deal_CfSfpSelect = scenarioManager_xpath.scenarioManagerfpSelect.replace('__NAME__',dropdownName);
            } else{
                var deal_CfSfpSelect = '(' + cashflow_xpath.dealCfSfpSelect.replace('__NAME__',dropdownName) + ')[1]';
            }   
            console.log(deal_CfSfpSelect);
            browser.getLocationInView(deal_CfSfpSelect);
            browser.waitForVisible(deal_CfSfpSelect,this.waitDefault);
            browser.click(deal_CfSfpSelect);
            if (panelName == "Add Scenario"){
                browser.waitForVisible(scenarioManager_xpath.scenarioManagerSelDropDown.replace('__NAME__',dropdownName),this.waitDefault);
            }else{
                browser.waitForVisible(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__',dropdownName),this.waitDefault);
            }
            browser.waitForText(deal_CfSfpSelect,2000);
            var selectList_text = browser.getText(deal_CfSfpSelect);
            console.log(selectList_text);
            var selectList_textArray = selectList_text.split('\n');
            console.log(selectList_text);
            expected_row_list.forEach(function(row, index) {
                expect(selectList_textArray[index]).toBe(row['item']);
            });
            browser.click(deal_CfSfpSelect);
            break;
        case "scen.scenType":
        case "scen.scenTypeSelected":
            if(panelName == "Add Scenario"){
                var deal_CfSfpSelect = scenarioManager_xpath.scenarioManagerfpSelect.replace('__NAME__',dropdownName);
            }else{
                var deal_CfSfpSelect = '(' + cashflow_xpath.mdSelect.replace('__NAME__',dropdownName) + ')[1]';
            }
            console.log(deal_CfSfpSelect);
            browser.waitForVisible(deal_CfSfpSelect,this.waitDefault);
            browser.click(deal_CfSfpSelect);
            browser.pause(300);
            if(panelName == "Add Scenario"){
                var selectList_text = browser.getText(deal_CfSfpSelect);
                var selectList_textArray = selectList_text.split('\n');
            }else{
                var selectPanel = content_xpath.selectPanel;
                browser.waitForText(selectPanel,2000);            
                var selectList_textArray = browser.getText(selectPanel);
            }
            console.log(selectList_textArray);
            //var selectList_textArray = selectList_text.split('\n');
            //console.log(selectList_text);
            expected_row_list.forEach(function(row, index) {
                expect(selectList_textArray[index]).toBe(row['item']);
            });
            if(panelName == "Add Scenario"){
                var select_item = scenarioManager_xpath.scenarioManagerDropDSelItem.replace('__NAME__', dropdownName).replace('__ITEM__', 'User Defined');
            }else{
                var select_item = content_xpath.namedSelectItem.replace('__NAME__', 'User Defined');
            }
            console.log(select_item);
            browser.click(select_item);
            break;
        case "analyticsCtrl.scenarioMethod":
        case "analyticsCtrl.scenarioInput":
        case "analyticsCtrl.outputType":
        case "scenarioManagerCtrl.scenarioMethod":
        case "scenarioManagerCtrl.scenarioInput":
        case "scenarioManagerCtrl.outputType":
            if(panelName == "Add Scenario"){
                var deal_CfSfpSelect = scenarioManager_xpath.scenarioManagerfpSelect.replace('__NAME__',dropdownName);
            }else{
                var deal_CfSfpSelect = cashflow_xpath.dealCfSfpSelect.replace('__NAME__',dropdownName);
            }
            console.log(deal_CfSfpSelect);
            browser.waitForVisible(deal_CfSfpSelect,this.waitDefault);
            browser.click(deal_CfSfpSelect);
            if (panelName == "Add Scenario"){
                browser.waitForVisible(scenarioManager_xpath.scenarioManagerSelDropDown.replace('__NAME__',dropdownName),this.waitDefault);
            }else{
                browser.waitForVisible(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__',dropdownName),this.waitDefault);
            }
            var selectList_text = browser.getText(deal_CfSfpSelect);
            var selectList_textArray = selectList_text.split('\n');
            console.log(selectList_text);
            expected_row_list.forEach(function(row, index) {
                expect(selectList_textArray[index]).toBe(row['item']);
            });
            browser.click(deal_CfSfpSelect);
            break;
        case "tranche.prepay_type":
            var assumption_div = content_xpath.assumptionsPanel;
            var target_set = '(' + assumption_div + cashflow_xpath.selectButton.replace('__NAME__',dropdownName) + ')[1]';
            console.log(target_set);
            browser.waitForVisible(target_set,this.waitDefault)
            browser.click(target_set);
            //browser.waitForVisible(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__',dropdownName),this.waitDefault);
            var selectList_text = browser.getText(target_set);
            console.log(selectList_text);
            var selectList_textArray = selectList_text.split('\n');
            console.log(selectList_text);
            expected_row_list.forEach(function(row, index) {
                expect(selectList_textArray).toContain(row['item']);
            });
            browser.click(target_set);
            break;
        case "CMM Forecast":
            var regCustomScenCMMSelect = regulatory_xpath.regCustomScenCMMSelect.replace('__NAME__',dropdownName);
            console.log(regCustomScenCMMSelect);
            browser.waitForVisible(regCustomScenCMMSelect,this.waitDefault);
            browser.click(regCustomScenCMMSelect);
            var selectList_text = browser.getText(regCustomScenCMMSelect);
            console.log(selectList_text);
            var selectList_textArray = selectList_text.split('\n');
            console.log(selectList_text);
            expected_row_list.forEach(function(row, index) {
                expect(selectList_textArray[index]).toBe(row['item']);
            });
            browser.click(regCustomScenCMMSelect);
            break;
    }    
    // certain select requires reset after click checking
    switch (dropdownName) {
    case "pool-select":
    case "deal-select":
      browser.waitForVisible(mySelectInput_xpath,this.waitDefault)
      browser.click(mySelectInput_xpath);
      browser.keys('Enter');
      break;
    }
  });
};
