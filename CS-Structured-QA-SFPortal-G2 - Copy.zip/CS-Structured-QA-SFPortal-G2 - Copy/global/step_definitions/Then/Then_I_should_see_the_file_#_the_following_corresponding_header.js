// Recommended filename: Then_I_should_see_the_file_#_the_following_corresponding_header.js
// only for performance charts page
module.exports = function() { 
  this.Then(/^I should see the file (match|contain) the following corresponding header$/, 
  {timeout: process.env.StepTimeoutInMS*3},
  function (testAction,table) {
    // Write code here that turns the phrase above into concrete actions
    // return 'pending';
    var expectList = table.hashes();
    console.log(expectList.length)
    for(var i=0;i<expectList.length;i++){
      // var item = expectList[i]['row_data'].replace(/ :: /g,',');
      console.log(expectList[i]['index'])
      var index =  parseInt(expectList[i]['index'])-1
      console.log(index)
      var item = expectList[i]['row_data'];
      console.log(item)
      console.log(this.fileContentList[index]['header']);
      var csvHeader = this.fileContentList[index]['header'].replace(/"/,'');
       console.log('expect header: ' + item);
       console.log('csv header: ' + csvHeader);
      switch(testAction){
        case 'match':
          break;
        case 'contain': 
          var tmp = item.split(' :: ');
          for(var j=0;j<tmp.length;j++){ 
            if( tmp[j].endsWith(")?") ){
              expect(csvHeader).not.toContain(tmp[j].slice(1,-2).trim());
            }else{
              expect(csvHeader).toContain(tmp[j].trim());  
            }
            
          }
          break;
      }
    }



  });
}