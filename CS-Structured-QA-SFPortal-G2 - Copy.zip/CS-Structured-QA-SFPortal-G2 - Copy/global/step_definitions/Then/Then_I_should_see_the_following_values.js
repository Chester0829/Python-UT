// Recommended filename: Then_I_should_see_the_following_values.js
module.exports = function() {
  this.Then(/^I should see the following values$/,
    {timeout: process.env.StepTimeoutInMS}, function (table) {
    var expected_item_list = table.hashes();
    var self = this;
    expected_item_list.forEach(function(expected_item) {
      var myVarString = expected_item['var'].replace('this', 'self');
      console.log(expected_item['var']);
      var myVarValue = eval(myVarString).toString();
      console.log(myVarString + ' : ' + myVarValue);
      if (expected_item['equal']) {
        expect(myVarValue).toBe(expected_item['equal'])
      }
      if (expected_item['contains']) {
        expect(myVarValue).toContain(expected_item['contains'])
      }
      if (expected_item['match']) {
        expect(myVarValue).toMatch(expected_item['match'])
      }
    });
  });
}
