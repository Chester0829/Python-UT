//Recommended filename : Then_I_get_the_range_value_from_#_column_and_check_the_range.js     
module.exports = function() { 
  this.Then(/^I get the range value from "([^"]*)" column and check the range$/, function (columnName) {
   // Write code here that turns the phrase above into concrete actions
    const portfolioPage_xpath = this.xpath_lib.xpathRequire('portfolioPage_xpath');
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const dealPage_xpath = this.xpath_lib.xpathRequire('dealPage_xpath');
    const bwic_xpath = this.xpath_lib.xpathRequire('bwic_xpath');
    this.browser_session.waitForResource(browser);
    console.log(this.widgetName);
    var myPanel = content_xpath.titledSectionLowercaseBWIC.replace('__TITLE__', this.widgetName.toLowerCase());
    var myTable = myPanel + bwic_xpath.enhancedBWICTable;
    var myHeader = myPanel + bwic_xpath.enhancedBWICTable + '//thead//th';
    var tableBody = myPanel + bwic_xpath.enhancedBWICTable + '//tbody/tr';
    var date = new Date();
    // var title_array = browser.getText(myHeader);
    this.browser_session.waitForResource(browser,tableBody);
    var header_array = browser.getText(myHeader) ;
    console.log('title_array:',header_array);
    // console.log('title_array a',browser.getText(myHeader+"/a"));
    var titleIndex = header_array.indexOf(columnName)+1;
    var tableTrLength = browser.elements(tableBody).value.length-1;
    console.log(tableTrLength);
    var column_min = browser.getText("("+tableBody+")[1]//td["+(titleIndex)+"]");
    var column_max = browser.getText("("+tableBody+")["+tableTrLength+"]//td["+(titleIndex)+"]");
    if (column_min=='-'){
      for(var i=1;i<tableTrLength;i++){
        var tableTdText=browser.getText("("+tableBody+")["+i+"]//td["+(titleIndex)+"]");
        if(tableTdText!='-'){
          column_min =tableTdText;
          break;
        }
      }
    }
    if (column_max=='-'){
      for(var i=tableTrLength-1;i>=0;i--){
        var tableTdText=browser.getText("("+tableBody+")["+i+"]//td["+(titleIndex)+"]");
        if(tableTdText!='-'&&tableTdText!=column_min){
          column_max =tableTdText;
          break;
        }
      }
      if(column_max=='-'){
        column_max=column_min;
      }
    }
    console.log('column_min aa,',column_min);
    console.log('column_max bb,',column_max);
    if(/20\d{2}-\d{2}-\d{2}/.test(column_min)){
      if(new Date(Date.parse(column_min))>new Date(Date.parse(column_max)))
         [column_min,column_max] = [column_max,column_min];
    }else if(column_min.indexOf(',')>-1 ||column_max.indexOf(',')>-1){
      column_min = parseFloat(column_min.replace(/,/g,''));
      column_max = parseFloat(column_max.replace(/,/g,''));
      if(column_min>column_max){
        [column_min,column_max] = [column_max,column_min];
      }
      if(column_min==column_max){
        [column_min,column_max] = [column_min,column_max+1];
      }
    }else if(column_min.indexOf('%')>-1||column_max.indexOf('%')>-1){
      ///\d{1,3}.\d{2}\%/.test(column_min)
      column_min = parseFloat(column_min.replace(/%/g,''));
      column_max = parseFloat(column_max.replace(/%/g,''));
      if(column_min>column_max){
        [column_min,column_max] = [column_max,column_min];
      }
      if(column_min==column_max){
        [column_min,column_max] = [column_min,column_max+1];
      }
    }else if(parseFloat(column_min)>parseFloat(column_max)){
        [column_min,column_max] = [column_max,column_min];
    }
    var filterChoose = "("+myPanel + bwic_xpath.enhancedBWICTable + '//thead//td)['+(titleIndex)+"]//a";
    browser.click(filterChoose);
    var rangeOption = bwic_xpath.rangeOption;
    browser.waitForVisible(rangeOption,this.waitDefault);
    browser.click(rangeOption);
    var filterRow = myTable + '//thead/tr[3]';
    var filterField1 = filterRow + '/td[' + titleIndex + ']//input[1]';
    var filterField2 = filterRow + '/td[' + titleIndex + ']//input[2]';
    browser.setValue(filterField1,column_min);
    browser.setValue(filterField2,column_max);
    // this.browser_session.waitForLoading(browser);
    browser.waitForVisible(tableBody,this.waitDefault);
    this.browser_session.waitForResource(browser,tableBody);
    var tableTrLength = browser.elements(tableBody).value.length-1
    console.log(tableTrLength);
    expect(tableTrLength>0).toBe(true,"length is 0 ");
    for (var i = 1; i <= tableTrLength; i++) {
      var columnValue = browser.getText(tableBody+"["+i+"]//td["+titleIndex+"]//span[@ng-switch-default]/span");
      console.log('columnValue:',columnValue);
      if(/20\d{2}-\d{2}-\d{2}/.test(columnValue)){
        expect(new Date(Date.parse(columnValue))<=new Date(Date.parse(column_max)) && new Date(Date.parse(columnValue))>=new Date(Date.parse(column_min)))
      }else{
        expect(parseFloat(columnValue.replace(/,/g,'').replace(/%/g,''))<=parseFloat(column_max) && parseFloat(columnValue.replace(/,/g,'').replace(/%/g,'')) >= parseFloat(column_min)).toBe(true);
      }
    }
  });
}; 