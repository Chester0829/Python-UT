// Then_I_should_see_the_dropdown_list_in_#_sfpSelect_for_scenario_#.js
module.exports=function(){
  this.Then(/^I should see the dropdown list in "([^"]*)" sfpSelect for scenario "([^"]*)"$/, function (arg1, arg2, table) {
    // Write code here that turns the phrase above into concrete actions
    const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
    var name = arg1;
    var index = arg2;
    var table_list = table.hashes();
    for(var i=0;i<table_list.length;i++){
      var row_item = table_list[i]['row_item'];
      var affect = table_list[i]['affect'];

      if(row_item){
        var deal_CfSfpSelect = '(' + cashflow_xpath.dealCfSfpSelect.replace('__NAME__',name) + ')[' + index + ']';
        console.log(deal_CfSfpSelect);
        browser.click(deal_CfSfpSelect);
        browser.pause(500);
        console.log(cashflow_xpath.dealCfsDropDSelItem.replace('__NAME__',name).replace('__ITEM__',row_item));
        // browser.waitForVisible(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__',name),this.waitDefault);
        browser.click(cashflow_xpath.dealCfsDropDSelItem.replace('__NAME__',name).replace('__ITEM__',row_item));
        browser.pause(1000);
      }
      if(affect){
        var status = table_list[i]['status'];
        var type = table_list[i]['type'];
        var assumptions_xpath = '';
        switch(type){
          case 'input':
            assumptions_xpath = '(' + cashflow_xpath.dealCfsInput.replace('__NAME__',affect) + ')[' + index + ']';
            // console.log(assumptions_xpath);
            break;
          case 'fpSelect':
            assumptions_xpath = '(' + cashflow_xpath.dealCfSfpSelect.replace('__NAME__',affect) + ')[' + index + ']';
            // console.log(assumptions_xpath);
            break;
        }
        console.log(assumptions_xpath);
        switch(status){
          case 'disabled':
            expect(browser.getAttribute(assumptions_xpath, 'disabled')).toEqual('true');
            break;
          case 'enabled':
            expect(browser.getAttribute(assumptions_xpath, 'disabled')).toEqual(null);
            break;
          case 'disappear':
            expect(browser.isVisible(assumptions_xpath)).toBe(false);
            break;
          case 'display':
          expect(browser.isVisible(assumptions_xpath)).toBe(true);
            break
          }
      }


    }

    
  });


}


