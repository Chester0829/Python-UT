// Recommended filename: Then_I_should_see_the_#_mlayerpie-chart_follow_#_heading_to_contain_the_following_data_and_the_#_should_add_up_to_#.js
module.exports = function() {
  this.Then(/^I should see the "([^"]*)" mlayerpie\-chart follow the "([^"]*)" panel-heading to (contain|match) the following data and the (legends|percent) should add up to (\d+)%$/, 
    {timeout: process.env.StepTimeoutInMS*5},
    function (chartName, panelName, action, percentType , percentTotal, table) {
    // Write the automation code here
    // browser.pause(1000);
    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    //this.browser_session.waitForRender(browser);
    var expected_row_list = table.hashes();
    
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase());
    var myChart = content_xpath.namedPieChar.replace(/__NAME__/g, chartName);
    myChart = myPanel + myChart;
    // console.log(myChart);
    browser.getLocationInView(myChart);

    var myChart_title = myChart + content_xpath.chartTitle;
    var myChart_label = myChart + content_xpath.chartLabel;
    var myChart_legend = myChart + content_xpath.chartLegend;

    var displayed_title_text;
    var displayed_label;
    var displayed_label_is_array;
    var displayed_text;
    var displayed_legend;
    // first we check if what we want to see is displayed in the chart
    expected_row_list.forEach(function(row) {
      if (row['title']) {
        displayed_title_text = browser.getText(myChart_title).toString();
        switch(action) {
          case 'contain': expect(displayed_title_text).toContain(row['title']); break;
          case 'match' : expect(displayed_title_text).toMatch(row['title']); break;
        }
      }
      if (row['percent_label']) {
        displayed_label = browser.getText(myChart_label).toString();
        // displayed_label_is_array = Array.isArray(displayed_label);
        switch (action) {
          case 'contain': expect(displayed_label).toContain(row['percent_label']); break;
          case 'match': expect(displayed_label).toMatch(row['percent_label']); break;
        }
      }
      if (row['text']) {
        displayed_text = browser.getText(myChart);
        switch (action) {
          case 'contain': expect(displayed_text).toContain(row['text']); break;
          case 'match': expect(displayed_text).toMatch(row['text']); break;
        }
      }
      if (row['legend']) {
        displayed_legend = browser.getText(myChart_legend).toString();
        // console.log(displayed_legend);
        switch (action) {
          case 'contain': expect(displayed_legend.replace(/ /g,'')).toContain(row['legend'].replace(/ /g,'')); break;
          case 'match': expect(displayed_legend.replace(/ /g,'')).toMatch(row['legend'].replace(/ /g,'')); break;
        }
      }
    });
    // second we check if what we want to see adds up to 100 (%)
    if (displayed_label&&(percentType=='percent')) {
      var displayed_percent_nums
      if (displayed_label_is_array) {
        displayed_percent_nums = displayed_label.toString().split('\n');
      } else {
        displayed_percent_nums = displayed_label.split('\n');
      }
      var displayed_percent_total = 0;
      displayed_percent_nums.forEach(function(item , displayed_index){
        var item_name = item.split(':')[0].replace(/(^,)|(,$)/g, "");
        var item_num = parseFloat(item.split(':')[1]);
        expected_row_list.forEach(function(row, index) {
          var item_name = displayed_percent_nums[displayed_index].split(':')[0].replace(/(^,)|(,$)/g, "").replace(/,/g,"");
          var item_num = parseFloat(displayed_percent_nums[displayed_index].split(':')[1]);
          switch (action) {
            case 'contain':
              if (row['percent_label'] != '' && item_name == row['percent_label']) {
                displayed_percent_total = displayed_percent_total + item_num;
              }
              break;
            case 'match':
              if (row['percent_label'] != '' && item_name.match(row['percent_label']) != null) {
                displayed_percent_total = displayed_percent_total + item_num;
              }
              break;
          }
        // console.log(displayed_percent_total);
        });
      });
      expect(displayed_percent_total).toBeCloseTo(percentTotal, 0);
    }
    else if(displayed_legend&&(percentType=='legends'))
    {
      var displayed_percent_nums
      if (displayed_label_is_array) {
        displayed_percent_nums = displayed_legend.toString().split('\n');
      } else {
        displayed_percent_nums = displayed_legend.split('\n');
      }
      console.log('displayed:' + displayed_percent_nums);
      var displayed_percent_total = 0;
      displayed_percent_nums.forEach(function(item,displayed_index){
        // var item_name = item.split(':')[0].replace(/(^,)|(,$)/g, "");
        // var item_num = parseFloat(item.split(':')[1]);
        expected_row_list.forEach(function(row, index) {
          // console.log(displayed_percent_nums[index].split(':')[0]);
          var item_name = displayed_percent_nums[displayed_index].split(':')[0].replace(/(^,)|(,$)/g, "").replace(/,/g,"");
          var item_num = parseFloat(displayed_percent_nums[displayed_index].split(':')[1]);
          switch (action) {
            case 'contain':
              if (row['legend'] != '' && item_name == row['legend']) {
                console.log(item_name + ':' + item_num);
                displayed_percent_total = displayed_percent_total + item_num;
                // console.log('displayed_percent_total: '+displayed_percent_total);
              }
              break;
            case 'match':
              if (row['legend'] != '' && item_name.match(row['legend']) != null) {
                console.log(item_name + ':' + item_num);
                displayed_percent_total = displayed_percent_total + item_num;
              }
              break;
          }
        });
      });
      expect(displayed_percent_total).toBeCloseTo(percentTotal, 0);
    }
  });
}
