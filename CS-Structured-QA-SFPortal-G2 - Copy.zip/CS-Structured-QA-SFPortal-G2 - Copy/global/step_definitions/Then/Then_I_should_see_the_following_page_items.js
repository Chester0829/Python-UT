// Recommended filename: Then_I_should_see_the_following_page_items.js
module.exports = function() {
  this.Then(/^I should see the following page items$/,
    {timeout: process.env.StepTimeoutInMS*20}, function (table) {
    // whatever xpath object file listed in the feature scenario check table should have a line below
    const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const footer_xpath = this.xpath_lib.xpathRequire('footer_xpath');
    const loginPage_xpath = this.xpath_lib.xpathRequire('loginPage_xpath');
    const dashboardPage_xpath = this.xpath_lib.xpathRequire('dashboardPage_xpath');
    const portfolioPage_xpath = this.xpath_lib.xpathRequire('portfolioPage_xpath');
    const managerPage_xpath = this.xpath_lib.xpathRequire('managerPage_xpath');
    const dealPage_xpath = this.xpath_lib.xpathRequire('dealPage_xpath');
    const performancePage_xpath = this.xpath_lib.xpathRequire('performancePage_xpath');
    const iframe_xpath = this.xpath_lib.xpathRequire('iframe_xpath');
    const my_regex_lib = this.regex_lib;

    var expected_item_list = table.hashes();
    var myBrowserSession = this.browser_session; 
    var myWaitDefault = this.waitDefault;
    var self = this;
    expected_item_list.forEach(function(expected_item) {
      var myExpected_xpath = eval(expected_item['item']);
      var cmbsInfo = ['Wachovia Bank Commercial Mortgage Trust 2007-C32',
                      'Merrill Lynch Mortgage Trust 2008-C1',
                      'FRESB Multifamily Mortgage Pass-Through Certificates, Series 2016-SB11',
                      'Portfolio-CMBS_-for-automation',
                      'Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1', //RMBS Deal
                      'Portfolio-RMBS-for-automation',
                      'MADRID RMBS IV, FTA'
                    ];
      if((cmbsInfo.indexOf(self.deal) != -1  || cmbsInfo.indexOf(self.portfolio) != -1 ) && expected_item['item'] == 'header_xpath.exportPdf_button'){
        // console.log(expected_item);
        var flag = expected_item['isDisplay'] == 'true' ? true : false;
        console.log(expected_item['isDisplay']);
        // console.log(myExpected_xpath);
        // console.log(browser.isVisible(myExpected_xpath));
        expect(browser.isVisible(myExpected_xpath)).toBe(flag);
      }else{
        var myActual_displayedText;
        if (myExpected_xpath) {
          if (expected_item['replace_text']) {
            myExpected_xpath = myExpected_xpath.replace(/__.*__/, expected_item['replace_text']);
          }
          console.log('expected page item: ' + expected_item['item']);
          console.log('xpath: ' + myExpected_xpath);
          browser.waitForVisible(myExpected_xpath, myWaitDefault*2);
          var myElementId = browser.element(myExpected_xpath).ELEMENT;
          // expect(myBrowserSession.elementAllVisible(browser, myExpected_xpath)).toBe(true);
          expect(myBrowserSession.elementSomeVisible(browser,myExpected_xpath)).toBe(true); 
          if (expected_item['count']) {
            var displayed_items = browser.elements(myExpected_xpath).value;
            console.log('displayed count: ' + displayed_items.length);
            expect(displayed_items.length).toBe(parseInt(expected_item['count']));
          }
          expect(myBrowserSession.elementSomeVisible(browser, myExpected_xpath)).toBe(true);
          if (expected_item['displayed_text']) {
            if (expected_item['item'] == "dealPage_xpath.bannerInfo" ||expected_item['item'] == "dealPage_xpath.bannerInfo1" ||expected_item['item'] == "dealPage_xpath.bannerInfo2"||expected_item['item'] == "dealPage_xpath.bannerInfo3"){
              var valueXpath = myExpected_xpath + "/parent::*//span";
              if (expected_item['replace_text'] == "Country" ||expected_item['replace_text'] == "Currency" 
                ||expected_item['replace_text'] == "Closing"||expected_item['replace_text'] == "Termination"||expected_item['replace_text'] == "Issuer"
                ||expected_item['replace_text'] == "Co-Issuer"||expected_item['replace_text'] == "Currency"||expected_item['replace_text'] == "Liabilities + Equity Par"){
                valueXpath = myExpected_xpath + "/following-sibling::div";
              }
              if (expected_item['replace_text'] == "dealCtrl.maViewDealData.compliance_status"||expected_item['replace_text'] == "dealCtrl.bannerInfo.volcker_compliance"||expected_item['replace_text'] == "dealCtrl.bannerInfo.std_underwriter_name"||expected_item['replace_text'] == "dealCtrl.bannerInfo.std_trustee_name"
                ||expected_item['replace_text'] == "dealCtrl.bannerInfo.closing_date"||expected_item['replace_text'] == "dealCtrl.bannerInfo.end_reinvestment"||expected_item['replace_text'] == "dealCtrl.bannerInfo.first_pay_date"
                ||expected_item['replace_text'] == "dealCtrl.bannerInfo.stated_maturity_date"||expected_item['replace_text'] == "dealCtrl.refinance_date"||expected_item['replace_text'] == "dealCtrl.latest_reset_date"){
                valueXpath = myExpected_xpath + "/div/following-sibling::div";
              }
              if (expected_item['replace_text'] == "Manager"){
                valueXpath = myExpected_xpath + "/parent::*//a";
              }
              console.log(valueXpath);
              myActual_displayedText = browser.getText(valueXpath);
              // try{
              //   myActual_displayedText = browser.getText(valueXpath);
              // }catch(e){
              //   // CMBS Deal and RMBS Deal
              //   myActual_displayedText = browser.getText(myExpected_xpath);
              // }
              console.log("Value on Page:"+ myActual_displayedText);
              console.log("Value expected:"+ my_regex_lib.replaceRegex(expected_item['displayed_text']));
              expect(myActual_displayedText).toMatch(my_regex_lib.replaceRegex(expected_item['displayed_text']));
            }
            else{
              myActual_displayedText = browser.getText(myExpected_xpath);          
              expect(myActual_displayedText).toMatch(my_regex_lib.replaceRegex(expected_item['displayed_text']));
            }
          }
        } else {
          console.log('**NOTE**: ' + expected_item['item'] + ' yield null in ' + process.env.NODE_ENV + ' xpath file.');
        }
      }
      

    });
  });
}
