//Then_I_should__see_the_setting_of_charts_as_below.js
module.exports = function() {
  this.Then(/^I should see the setting of charts as below$/, function (table) {
         // Write code here that turns the phrase above into concrete actions 
         const content_xpath = this.xpath_lib.xpathRequire('content_xpath');    
         var setting_table = table.hashes()
         // const dateFormat = require('dateformat');
         var self = this
         setting_table.forEach(function(list_row){
           switch(list_row['settings']){
             case "ctrl.applyCohort":
             case "ctrl.combineY":
               var setting_field = '('+content_xpath.modeCheckbox.replace('__NAME__',list_row['settings'])+')['+list_row['charts']+']'
               console.log(setting_field)
               var flag = browser.getAttribute(setting_field,'aria-checked')
               if(list_row['value']=='unchecked'){
                  expect(flag).toBe('false')
               }else{
                 expect(flag).toBe('true')
               }
               // if(flag=='true'&&list_row['value']=='unchecked'){
               //   browser.click(setting_field)
               // }else if(flag=='false'&&list_row['value']=='checked'){
               //   browser.click(setting_field)
               // }
               break;
              case "ctrl.dateRange":
                var setting_field = '('+content_xpath.labelCheckbox.replace('__MODEL__',list_row['settings']).replace('__VALUE__',list_row['value'])+')['+list_row['charts']+']'
                var flag = browser.getAttribute(setting_field,'class')
                expect(flag.includes('active')).toBe(true)
                break;
              case "ctrl.startDate":
              case "ctrl.endDate":
                var setting_field = '('+ content_xpath.inputoption.replace('__NAME__',list_row['settings'])+')['+list_row['charts']+']'
                try{
                  expect(browser.getValue(setting_field)).toEqual(list_row['value'])
                }catch(e){
                  console.log("list_row['value']:"+list_row['value'])
                  var newDate=self.time_lib.getLocalDate(list_row['value'],"yyyy-mm-dd")
                  // var dateValue=new Date(list_row['value'])
                  // var newDate = dateFormat(dateValue.toLocaleDateString('en-US', {timeZone: 'America/Los_Angeles'}),"yyyy-mm-dd");
                  console.log(newDate)
                  expect(browser.getValue(setting_field)).toEqual(newDate)
                }
                break;
           }
            
         });
        
       })
};
