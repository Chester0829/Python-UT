// Recommended filename: Then_I_should_see_the_#_performance_chart_metric_drop-down_list_to_contain_the_following_unique_and_ordered_items.js
module.exports = function() {
  this.Then(/^I should see the ([^"]*) performance chart metric drop\-down list to contain the following unique and ordered items$/, {timeout: process.env.StepTimeoutInMS}, function(itemName, table) {
    // Write the automation code here
    var expected_list = table.hashes();
    const performancePage_xpath = this.xpath_lib.xpathRequire('performancePage_xpath');
    var metricInput_xpath = performancePage_xpath.metricInput;
    var metricInputChoice_xpath = performancePage_xpath.metricChoice;
    var displayed_metricInput_list = browser.elements(metricInput_xpath).value;
    var displayed_metricChoice_list = browser.elements(metricInputChoice_xpath).value;
    // check chart counts
    // console.log(chart_item)
    if(/\d{1,2}/.test(itemName)!=false){
      var chart_item=parseInt(itemName);
      console.log(chart_item)
      expect(displayed_metricInput_list.length).toBe(chart_item);
    }else{
      displayed_metricInput_list=browser.elements('('+metricInput_xpath+')[1]').value;
      console.log(displayed_metricInput_list)
      browser.setValue('('+metricInput_xpath+')[1]',itemName)
    }
    // for each chart, check expected item line-by-line
    displayed_metricInput_list.forEach(function(metricInputItem) {
      browser.elementIdClick(metricInputItem.ELEMENT);
      browser.pause(100);
      var displayed_metricChoice_listText = browser.elementIdText(displayed_metricChoice_list[metricInputItem.index].ELEMENT).value;
      var displayed_metricChoice_textArray = displayed_metricChoice_listText.split('\n');
      // console.log(displayed_metricChoice_textArray);
      // for(var i=0;i<displayed_metricChoice_textArray.length;i++){
      //   console.log(displayed_metricChoice_textArray[i]);
      // }
      expected_list.forEach(function(expected_item, index) {
        // console.log will display displayed items line-by-line
        // console.log(displayed_metricChoice_textArray[index]);
        expect(displayed_metricChoice_textArray[index]).toBe(expected_item['dropdown_item']);
      });
    });
  });
};
