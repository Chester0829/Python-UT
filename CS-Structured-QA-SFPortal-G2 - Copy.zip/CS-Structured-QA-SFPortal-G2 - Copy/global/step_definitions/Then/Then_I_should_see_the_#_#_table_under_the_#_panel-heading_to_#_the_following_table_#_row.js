// Recommended filename: Then_I_should_see_the_#_#_table_under_the_#_panel-heading_to_#_the_following_table_#_row.js
module.exports = function () {
  this.Then(/^I should see the (only|first|second|third|fourth|fifth|sixth|seventh|eighth|nineth|tenth) (data|cluster|iframe) table under the "([^"]*)" panel-heading to (contain|match|equal|not contain) the following table (header|data|regex|anormal|data\ any|backwards) row$/,
    { timeout: process.env.StepTimeoutInMS * 20 },
    function (tableIndex, tableType, panelName, action, content, table) {
      // Write the automation code here
      var self = this;
      this.browser_session.waitForResource(browser);
      console.log(self.page);
      console.log(self.pagetype);
      var isEmptyForCity = false;
      var expected_row_list = table.hashes();
      const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      const iframe_xpath = this.xpath_lib.xpathRequire('iframe_xpath');
      const createPortfolioPage_xpath = this.xpath_lib.xpathRequire('createPortfolioPage_xpath');
      const regulatory_xpath = this.xpath_lib.xpathRequire('regulatory_xpath');
      const bwic_xpath = this.xpath_lib.xpathRequire('bwic_xpath');
      const scenarioManager_xpath = this.xpath_lib.xpathRequire('scenarioManager_xpath');

      const my_regex_lib = this.regex_lib;
      var myPanel = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase());
      if (panelName == 'Asset Type' || panelName == 'Current Balance' || panelName == 'Geography' || panelName == 'Industry'
        || panelName == 'Obligor Concentration' || panelName == 'Original Term' || panelName == 'Remaining Term' || panelName == 'APR of Receivables'
        || panelName == 'Delinquency Experience' || panelName == 'FICO Score' || panelName == 'Loan To Value'
        || panelName == 'Vehicle Type' || panelName == 'Scheduled Termination Date' || panelName == 'Vehicle Model') {
        myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase());
      }
      var nth_index;
      var myTable;
      switch (tableType) {
        case 'data':
          if (panelName == 'BWIC Analyzer:') {
            myTable = '//sfp-data-table//table';
          }
          else if (panelName == 'Tranche Level Universe: CLO' || panelName == 'Tranche Level Universe: AUTO' || panelName == 'Key Stats: Portfolio-CLO-for-automation' || panelName == 'Key Stats: Portfolio-All-for-automation'
            || panelName == 'Key Stats: Portfolio-RMBS-for-automation' || panelName == 'Dealer Inventory: ALL' || panelName == 'BWIC List: CLO/ CBO'
            || panelName == 'BWIC List: User Input BWIC List' || panelName == 'BWIC List: User Input BWIC List for CMBS' || panelName == 'BWIC List: User Input BWIC List for Mix' || panelName == 'Comparables' || panelName == 'Dealer Inventory: BAML') {
            myPanel = content_xpath.titledSectionLowercaseBWIC.replace('__TITLE__', panelName.toLowerCase());
            myTable = myPanel + bwic_xpath.enhancedBWICTable;
          } else if (panelName == 'Customized Filter') {
            myTable = content_xpath.sfp_cardWidget.replace("__WIDGETNAME__", panelName) + bwic_xpath.customizedFilterTable;
          }
          else if (panelName == 'BWIC List: AAA') {
            myTable = '//table';
          }
          else if (panelName == 'Staging Threshold' || panelName == 'Scenario Weights' || panelName == 'Rating - as of Purchase - overwrite') {
            // in RegModule IFRS9 page
            myTable = '(' + myPanel + ')[2]' + content_xpath.descendantDataTable;
          }
          else if (panelName == 'Settings' && self.page == 'Cashflows') {
            myTable = cashflow_xpath.vectorTable1.replace('__NAME__', panelName);
          }
          else if (panelName == 'Add Scenario') {
            myTable = scenarioManager_xpath.scenarioManagerVectorTable;
          }
          else if (panelName == "Assumptions" && self.page == 'Cashflows') {
            myTable = '//*[@class="sfp-card-content"]//*[contains(@ng-include,"cashflows")]//table';
          } else if (panelName == "CDO Custom Rates") {
            myTable = '//div[@id="custom-rates"]//table';
          }
          /* else if(panelName == 'My Screens'){
            myTable = '//div[@id="widget-screener-myScreens"]//table';
          } */
          else {
            myTable = myPanel + content_xpath.descendantDataTable;
          }
          break;
        case 'cluster':
          myTable = myPanel + content_xpath.descendantClusterTable;
          break;
        case 'iframe':
          myPanel = iframe_xpath.titledDashboardLowercase.replace('__TITLE__', panelName.toLowerCase());
          // for city
          if (!browser.isVisible(myPanel)) {
            myPanel = iframe_xpath.titledDashboardLowercase.replace('__TITLE__', panelName.split(':')[0].toLowerCase());
          }
          myTable = myPanel + content_xpath.descendantDataTable;
          break;
      }
      switch (tableIndex) {
        case "only":
          nth_index = 1;
          break;
        case "first":
          nth_index = 1;
          break;
        case "second":
          nth_index = 2;
          break;
        case "third":
          nth_index = 3;
          break;
        case "fourth":
          nth_index = 4;
          break;
        case "fifth":
          nth_index = 5;
          break;
        case "sixth":
          nth_index = 6;
          break;
        case "seventh":
          nth_index = 7;
          break;
        case "eighth":
          nth_index = 8;
          break;
        case "nineth":
          nth_index = 9;
          break;
        case "tenth":
          nth_index = 10;
          break;
        default:
          nth_index = 1;
          break;
      };
      if (panelName.toLowerCase() == "overlap results" || panelName.includes("Alerts for")) {
        var titledSection = content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase());
        myTable = '(' + titledSection + '//table' + ')[' + nth_index + ']';
      }
      else if (panelName.toLowerCase() == "deals with largest exposure to this issuer" || panelName.toLowerCase() == "managers with largest exposure to this issuer") {
        var titledSection = content_xpath.titledSectionLowercase1.replace('__TITLE__', panelName.toLowerCase());
        myTable = '(' + titledSection + '//table' + ')[' + nth_index + ']';
      }
      else if (panelName == 'Settings' && self.page == 'Cashflows') {
        myTable = '(' + cashflow_xpath.vectorTable1.replace('__NAME__', panelName) + ')[' + nth_index + ']';
      }
      else if (panelName == 'Add Scenario') {
        myTable = '(' + scenarioManager_xpath.scenarioManagerVectorTable + ')[' + nth_index + ']';
      }
      else if (browser.isVisible('//iframe')) {
        browser.pause(10000);
        browser.frame(0);
        var titledSection = content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase());
        myTable = '(' + titledSection + '//table' + ')[' + nth_index + ']';
      }
      else if (panelName == 'All Positions' || panelName == 'By Asset Class' || panelName == 'By Vintage' || panelName == 'By Region') {
        const regulatory_xpath = this.xpath_lib.xpathRequire('regulatory_xpath');
        var titledSection = regulatory_xpath.unhiddenSummaryctrl_xpath + content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase());
        myTable = '(' + titledSection + '//table' + ')[' + nth_index + ']';
      }

      else if (panelName == 'Tests' && self.page == 'Dynamic CFs' || (panelName == 'Accounts' && self.page == 'Dynamic CFs')
        || (panelName == 'Fees' && self.page == 'Dynamic CFs') || (panelName == 'Triggers' && self.page == 'Dynamic CFs')
        || (panelName == 'Principal Paydown' && self.page == 'Dynamic CFs') || (panelName == 'PDL' && self.page == 'Dynamic CFs')
        || (panelName == 'Reinvestment' && self.page == 'Dynamic CFs') || (panelName == 'Hedges' && self.page == 'Dynamic CFs')) {
        var myTable = cashflow_xpath.dealCfresultTable;
        console.log('myTable:', myTable);
      }
      //compatible new cashflow page
      else if (panelName == 'Tests' && self.page == 'Dynamic CFs New' || (panelName == 'Accounts' && self.page == 'Dynamic CFs New')
        || (panelName == 'Fees' && self.page == 'Dynamic CFs New') || (panelName == 'Triggers' && self.page == 'Dynamic CFs New')
        || (panelName == 'Principal Paydown' && self.page == 'Dynamic CFs New') || (panelName == 'PDL' && self.page == 'Dynamic CFs New')
        || (panelName == 'Reinvestment' && self.page == 'Dynamic CFs New') || (panelName == 'Hedges' && self.page == 'Dynamic CFs New')) {
        var myTable = cashflow_xpath.dealCfresultTable;
        console.log('myTable:', myTable);
      } else if (panelName == 'Deal Flows') {
        var myTable = cashflow_xpath.dealFlowsresutTable;
        console.log('myTable new deal flows ', myTable);
      }
      else if (panelName == 'CDO Reinvestments') {
        var myTable = '(' + cashflow_xpath.cashflowReinTable + ')[' + nth_index + ']';
      }
      else if (panelName == 'Reinvestments') {
        var myTable = '(' + cashflow_xpath.cashflowReinTable + ')[' + nth_index + ']';
      }
      else if ((panelName == 'Accounts' && self.page == 'Cashflows') || (panelName == 'Fees' && self.page == 'Cashflows') || (panelName == 'Reinvestment' && self.page == 'Cashflows')
        || (panelName == 'Hedges' && self.page == 'Cashflows') || (panelName == 'Triggers' && self.page == 'Cashflows')
        || (panelName == 'Principal Paydown' && self.page == 'Cashflows') || (panelName == 'PDL' && self.page == 'Cashflows') || (panelName == 'Tests' && self.page == 'Cashflows')) {
        var myTable = cashflow_xpath.portfolioCfresultTable;
        if (this.portfolio && panelName == 'Accounts' && this.portfolio.indexOf('CMBS') != -1) {
          myTable = '//*[@ng-if="cash.showResults"]//*[contains(@ng-if,"cash.cashflow_type") or contains(@ng-include,"cash.cashflow_type")]//table//tbody//td';
        }
      } else if (panelName == 'Stratification' || panelName == 'Stratifications') {
        // for cashflows
        var myTable = '//*[@id="cmbsWatchlist" or @id="watchlist"]'
      } else if (panelName == 'Loan Level Assumptions') {
        var myTable = '//*[@ng-controller="cmbsLoanLevelAssumpController as loanLevelAssumpCtrl"]//*[@id="loanLevelScrollableHeaderTable"]';
      } else if (panelName == 'Custom Rates') {
        // for cashflows Forward Curve
        if (this.deal) {
          var myTable = cashflow_xpath.showForward + '//table';
          //*[@ng-if="assumpCtrl.showForward"]//table;
        } else if (this.portfolio) {
          var myTable = cashflow_xpath.cmbsCustomRate + '//table';
          //*[@ng-controller="analyticsRatesController as ratesCtrl"]//table';
        }
        // get all ui data
        var allUiData = browser.getText(myTable + '//tbody//tr');
        console.log(allUiData);
      } else if (panelName == "Results" && self.pagetype == "portfolio") {
        var myTable = '(' + cashflow_xpath.portfolioCfallresultTable + ')[' + nth_index + ']';
      } else if (panelName == 'Your Portfolio') {
        var myTable = createPortfolioPage_xpath.yourPortfolio_table;
      } else if (panelName == 'Basic Vectors' || panelName == 'Custom Forward Rates' || panelName == 'Macro Scenarios' || panelName == 'SEDF Overrides') {
        var myTable = regulatory_xpath.regCusScenBVTable_xpath.replace('__NAME__', panelName.toLowerCase());
      } else if (panelName == 'OTTI Calculator') {
        var myTable = regulatory_xpath.regOTTICalcTable_xpath
      }
      else {
        myTable = '(' + myTable + ')[' + nth_index + ']';
      }


      console.log(myTable);
      console.log(panelName + ':' + self.page);
      this.browser_session.waitForResource(browser, myTable);
      browser.waitForVisible(myTable, this.waitMax);
      if (!process.env.BROWSER.startsWith('IE') && panelName != 'Deal Flows') {
        try {
          browser.touchScroll(browser.element(myTable).value['ELEMENT'], 0, 200);
        } catch (e) { }
      }

      if (content == 'data any') {
        if (panelName == 'Deal Flows' || panelName == 'Tests' || (panelName == 'Accounts' && self.page == 'Dynamic CFs') || (panelName == 'Accounts' && self.page == 'Dynamic CFs New') || panelName == 'Fees' || panelName == 'Triggers') {
          var firstTable = myTable + "[1]";
          var table_len = this.browser_session.getAnormalTableRowCount(browser, firstTable, true);
          console.log(table_len);
          var display_content = "";
          for (var row_index = 0; row_index < table_len; row_index++) {
            var row_text = browser.getText(myTable + "//tbody//tr[" + (row_index + 1) + "]").toString().replace(/ ,/g, ',').replace(/ /g, ',');
            display_content += ',' + row_text;
            // all_display_content+= ' :: ' + this.browser_session.getAnormalTableRowText(browser,myTable,row_index+1);
          }
          all_display_content = display_content;
        } else if (panelName == "CDO Custom Rates") {
          all_display_content = browser.getValue(myTable + '//input').toString().replace(/,/g, ' :: ');
          // console.log('all_display_content Custom Rates: ' + all_display_content);
        } else {
          var all_display_content = this.browser_session.getAnormalTableAllText(browser, myTable);
        }
        // console.log(all_display_content);
      }

      var myBrowserSession = this.browser_session;
      var displayed_row_content;
      var expected_row_content;
      var expected_row_regex;
      var myIFrame_type = this.iFrame_type;
      if (panelName == 'Deal Flows') {
        browser.click(cashflow_xpath.dealCfsTableClick);
        self.robot_session.keyTap('home');
      }
      expected_row_list.forEach(function (expected_row, index) {
        switch (content) {
          case 'header':
            if (panelName == 'Trade Behavior'
              || panelName == 'Loss Mitigation' || panelName == 'Stratification' || panelName == 'Custom Forward Rates'
              || panelName == 'Assumptions' || panelName == 'Asset Characteristics' || panelName == 'Debt vs. Equity'
              || panelName == 'Loan Level Assumptions' || panelName == 'PDL' || panelName == 'Stratifications') {
              displayed_row_content = myBrowserSession.getTableHeaderText(browser, myTable);
            }
            else if (panelName == 'Tests' || (panelName == 'Accounts') || (panelName == 'Triggers') || (panelName == 'Principal Paydown')) {
              displayed_row_content = myBrowserSession.getAnormalTableRowHeader(browser, myTable, index + 1);
              // console.log('displayed_row_content :'+displayed_row_content)
            }
            else if (panelName == 'Deal Flows' && index == 0) {
              var element = cashflow_xpath.dealCashflowHeader1;
              console.log(element);
              // browser.getLocationInView(myTable);
              displayed_row_content = myBrowserSession.getAnormalTableRowHeader(browser, myTable, index + 1, ' :: ', element);
              console.log('11111 displayed_row_content :' + displayed_row_content);
            } else if (panelName == 'Deal Flows' && index == 1) {
              // browser.getLocationInView(myTable);
              var element = cashflow_xpath.dealCashflowHeader2;
              console.log(element);
              displayed_row_content = myBrowserSession.getAnormalTableRowHeader(browser, myTable, index + 2, ' :: ', element);
              // displayed_row_content = myBrowserSession.getAnormalTableRowHeader(browser, myTable, index);
              console.log('222 displayed_row_content :' + displayed_row_content);
            } else if (panelName == 'Customized Filter') {
              console.log('myTable---customized : ' + myTable);
              browser.click(myTable + '/tbody//tr');
              self.robot_session.keyTap('home');
              displayed_row_content = myBrowserSession.getTableHeaderTextIncludingDuplicateCheck(browser, myTable);
            }
            else {
              displayed_row_content = myBrowserSession.getTableHeaderTextIncludingDuplicateCheck(browser, myTable);
            }
            // console.log(displayed_row_content);
            expected_row_content = my_regex_lib.replaceRegex(expected_row['row_data']);
            self.ui_header = displayed_row_content;
            if (tableType == 'iframe') {
              displayed_row_content = myBrowserSession.getTableRowText(browser, myTable, index + 1);
            }
            if (panelName == 'Collateral Summary') {
              // for cmbs deal summary
              var tmp = browser.getText(myTable + '//tr[1]//th');
              //console.log(tmp);
              displayed_row_content = tmp.join(' :: ');
            }
            if (panelName == 'OTTI Calculator') {
              displayed_row_content = myBrowserSession.getOTTICalcHeader(browser, myTable).toString();
              console.log('-------------:', displayed_row_content);
            }
            break;
          case 'data':
            if (panelName == 'ALTICE NV') {
              displayed_row_content = myBrowserSession.getTableRowText(browser, myTable, index + 2);

            }
            else if (panelName == 'Tranche Level Universe: CLO' || panelName == 'Tranche Level Universe: AUTO' || panelName == 'Key Stats: Portfolio-CLO-for-automation' || panelName == 'Key Stats: Portfolio-All-for-automation'
              || panelName == 'Key Stats: Portfolio-RMBS-for-automation' || panelName == 'Dealer Inventory: ALL' || panelName == 'BWIC List: CLO/ CBO'
              || panelName == 'BWIC List: User Input BWIC List' || panelName == 'BWIC List: User Input BWIC List for CMBS' || panelName == 'BWIC List: User Input BWIC List for Mix' || panelName == 'Comparables' || panelName == 'Dealer Inventory: BAML'
              || panelName == 'BWIC List: AAA') {
              displayed_row_content = myBrowserSession.getTableRowText(browser, myTable, index + 2);
            }
            else {
              if (isEmptyForCity) {  // for city
                index = index - 1;
                isEmptyForCity = false;
              }
              displayed_row_content = myBrowserSession.getTableRowText(browser, myTable, index + 1);
            }

            if (panelName == 'Macro Scenarios' || panelName == 'Custom Forward Rates' || panelName == 'SEDF Overrides') {
              displayed_row_content = myBrowserSession.getCustomScenarioValueList(browser, myTable);
            }

            console.log('displayed_row_content:', displayed_row_content);
            expected_row_content = my_regex_lib.replaceRegex(expected_row['row_data']);

            if (tableType == 'iframe') {
              var offset = 2; //Deal iFrame start on row 2.  First row is hidden.
              if (myIFrame_type == 'citi-manager' || myIFrame_type == 'citi-py') {
                offset = 1;
              }
              displayed_row_content = myBrowserSession.getTableRowText(browser, myTable, index + offset).trim();
            }
            // console.log(displayed_row_content);          
            break;
          case 'regex':
            if (myBrowserSession.getTableRowCount(browser, myTable) == 1) {
              var displayed_row_count = myBrowserSession.getTableRowCount(browser, myTable);
            }
            else {
              var displayed_row_count = myBrowserSession.getTableRowCount(browser, myTable) - 1;
            }
            console.log('displayed_row_count');
            expected_row_regex = my_regex_lib.replaceRegex(expected_row['row_data']);
            if ((panelName == 'Settings' && self.page == 'Cashflows') || panelName == 'Add Scenario') {
              for (var i = 1; i < displayed_row_count; i++) {
                displayed_row_content = myBrowserSession.getTableRowText(browser, myTable, i + 1);
                // console.log('displayed_row_content' + displayed_row_content);
                console.log('displayed_row_content--------' + displayed_row_content);
                console.log('expected_row_regex---------' + expected_row_regex);
                expect(displayed_row_content).toMatch(expected_row_regex);
              }
            } else if (panelName == 'Comparables') {
              console.log(displayed_row_count);
              if (index == 0) {
                displayed_row_content = myBrowserSession.getTableRowText(browser, myTable, index + 2);
                console.log('displayed_row_content AAA' + displayed_row_content);
                console.log('expected_row_regex AAA' + expected_row_regex);
                expect(displayed_row_content).toMatch(expected_row_regex);
              } else {
                for (var i = 0; i < displayed_row_count - 2; i++) {
                  displayed_row_content = myBrowserSession.getTableRowText(browser, myTable, i + 3);
                  console.log('displayed_row_content BBB' + displayed_row_content);
                  console.log('expected_row_regex BBB' + expected_row_regex);
                  expect(displayed_row_content).toMatch(expected_row_regex);
                }
              }
            }
            else if (panelName == 'Tranche Level Universe: CLO' || panelName == 'Tranche Level Universe: AUTO' || panelName == 'Key Stats: Portfolio-CLO-for-automation' || panelName == 'Key Stats: Portfolio-All-for-automation'
              || panelName == 'Key Stats: Portfolio-RMBS-for-automation' || panelName == 'Dealer Inventory: ALL' || panelName == 'BWIC List: CLO/ CBO'
              || panelName == 'BWIC List: User Input BWIC List' || panelName == 'BWIC List: User Input BWIC List for CMBS' || panelName == 'BWIC List: User Input BWIC List for Mix' || panelName == 'Dealer Inventory: BAML') {
              for (var i = 0; i < displayed_row_count - 1; i++) {
                displayed_row_content = myBrowserSession.getTableRowText(browser, myTable, i + 2);
                console.log('displayed_row_content--------' + displayed_row_content);
                console.log('expected_row_regex---------' + expected_row_regex);
                expect(displayed_row_content).toMatch(expected_row_regex);
              }
            }
            else {
              for (var i = 0; i < displayed_row_count; i++) {
                displayed_row_content = myBrowserSession.getTableRowText(browser, myTable, i + 1);
                // console.log('displayed_row_content' + displayed_row_content);
                console.log('displayed_row_content--------' + displayed_row_content);
                console.log('expected_row_regex---------' + expected_row_regex);
                expect(displayed_row_content).toMatch(expected_row_regex);
              }
            }
            break;
          case 'anormal':
            browser.pause(5000);
            if (panelName == 'Tests' || (panelName == 'Accounts') || (panelName == 'Triggers') || (panelName == 'Hedges')
              || panelName == 'PDL' || panelName == 'Principal Paydown') {
              displayed_row_content = myBrowserSession.getAnormalTableRowText(browser, myTable, index + 1);
              expected_row_content = expected_row['row_data'];
              console.log('displayed_row_content :' + displayed_row_content)
            }
            if (panelName == 'Fees' || panelName == 'PDL') {
              displayed_row_content = myBrowserSession.getAnormalTableRowText(browser, myTable, index + 1);
              expected_row_content = expected_row['row_data'];
              // console.log('displayed_row_content :'+displayed_row_content)
            } if (panelName == 'Deal Flows') {
              // var myTable_location= browser.getLocation('(//div[contains(@ng-if,"analyticsCtrl.dealFlowsLoaded")]//div[@ref="eLeftContainer"]//div[@role="row"])[1]');
              // console.log(myTable_location);
              // browser.click('(//div[contains(@ng-if,"analyticsCtrl.dealFlowsLoaded")]//div[@ref="eLeftContainer"]//div[@role="row"])[1]');
              // browser.click(cashflow_xpath.dealCfsTableClick);
              // // browser.pause(1000);
              // self.robot_session.keyTap('home');
              // var table_element = cashflow_xpath.dealCfsTableData.replace('__INDEX__',index); 
              expected_row_content = expected_row['row_data'];
              displayed_row_content = myBrowserSession.getCashflowTableRowText(browser, myTable, index);
              // console.log('dealflows new table display row content : ' , displayed_row_content);
              // for (var i = 0; i < 10; i++) {
              //     var date_element = '//div[contains(@ng-if,"analyticsCtrl.dealFlowsLoaded")]//div[@ref="eLeftContainer"]//div[@role="row" and @row-index="'+i+'"]';
              //     console.log('---',browser.getText(date_element));   
              // }
              //  for(var i = 0 ; i < 10 ; i++){
              //     var data_element = '//div[contains(@ng-if,"analyticsCtrl.dealFlowsLoaded")]//div[@ref="eBodyContainer"]//div[@role="row" and @row-index="'+i+'"]';
              //     console.log('>>>>',browser.getText(data_element));
              //  }

              // displayed_row_content = myBrowserSession.getAnormalTableRowText(browser, myTable, index + 1);
            }
            else {
              browser.pause(5000);
              console.log("myTable:" + myTable);
              displayed_row_content = myBrowserSession.getAnormalTableRowText(browser, myTable, index + 1);
              expected_row_content = expected_row['row_data'];
              // console.log('displayed_row_content :'+displayed_row_content);
            }
            if (panelName == 'Custom Rates') {
              // for cashflows Forward Curve
              displayed_row_content = allUiData[index];
              expected_row_content = expected_row['row_data'];
            }
            // console.log(expected_row_content);
            break;
          //count backwards the table row
          case 'backwards':
            if (panelName == 'Shared Link Usage History') {
              var tableRowCount = browser.elements(myTable + '//tbody//tr').value.length - 1;
              var row_number = tableRowCount - index;
              console.log(row_number);
              displayed_row_content = myBrowserSession.getAnormalTableRowText(browser, myTable, row_number);
              expected_row_content = expected_row['row_data'];
              console.log('displayed_row_content :' + displayed_row_content)
            }
            break;
          // no need to row by row , any row contain will true
          case 'data any':
            // var contain_flag = false;
            expected_row_content = expected_row['row_data'];
            if (panelName == 'Deal Flows' || panelName == 'Tests' || (panelName == 'Accounts' && self.page == 'Dynamic CFs') || (panelName == 'Accounts' && self.page == 'Dynamic CFs New') || panelName == 'Fees' || panelName == 'Triggers') {
              // console.log(expected_row_content.replace(/ :: /g,','));
              expect(all_display_content.includes(expected_row_content.replace(/ :: /g, ','))).toBe(true, "expected_row_content :" + expected_row_content)
            } else {
              console.log(all_display_content);
              expect(all_display_content.includes(expected_row_content)).toBe(true, 'display:' + all_display_content, 'not include expect:' + expected_row_content);
            }
            // console.log(displayed_row_count);
            // for (var i = 0; i < displayed_row_count; i++) {
            //     displayed_row_content = myBrowserSession.getAnormalTableRowText(browser, myTable, i + 1);
            //     switch(action){
            //       case 'contain':
            //       if(displayed_row_content.includes(expected_row_content)){
            //         // console.log('expect:'+displayed_row_content);
            //         contain_flag = true;
            //         break;
            //       }
            //       break;
            //       case 'match':
            //       if(displayed_row_content.match(expected_row_regex)){
            //         // console.log('expect:'+displayed_row_content);
            //         contain_flag=true;
            //         break;
            //       }
            //       break;
            //     }
            // }
            // expect(contain_flag).toBe(true,expected_row_content,index);
            break;
        };
        if (content != 'regex' && content != 'data any') {
          switch (action) {
            case 'not contain':
              expect(displayed_row_content).not.toContain(expected_row_content);
              break;
            case 'contain':
              // console.log("Actual: " + displayed_row_content);
              // console.log("Expected: " + expected_row_content);
              expect(displayed_row_content).toContain(expected_row_content);
              break;
            case 'equal':
              if (panelName == 'OTTI Calculator') {
                expect(displayed_row_content.trim()).toEqual(expected_row_content.replace(/ :: /g, ','));
              } else {
                expect(displayed_row_content.trim()).toEqual(expected_row_content);
              }
              break;
            case 'match':
              // console.log('+++++++++++++++++++++++++++++');
              expected_row_regex = expected_row['row_data'];
              console.log("Actual: " + displayed_row_content);
              var expected_string = my_regex_lib.replaceRegex(expected_row_content);
              console.log("Expected: " + expected_string);
              if (panelName == 'Custom Rates') {
                expect(displayed_row_content).toMatch(my_regex_lib.replaceRegex(expected_row_content.replace(/ :: /g, ' ')));
                // reg cus scen
              } else if (panelName == 'Macro Scenarios' || panelName == 'Custom Forward Rates' || panelName == 'SEDF Overrides') {
                expect(displayed_row_content.toString()).toMatch(my_regex_lib.replaceRegex(expected_row_content.replace(/ :: /g, ',')));
              } else if (panelName == 'OTTI Calculator') {
                expect(displayed_row_content).toMatch(my_regex_lib.replaceRegex(expected_row_content.replace(/ :: /g, ',')));
              } else if (tableType == 'iframe' && panelName.indexOf('PRICE ANALYSIS') != -1) {
                // for City, need to be ignore '|  ::  ::  ::  ::  ::  |' as Prod and Staging is not the same style:WSAPORTAL-7807
                // when this part release, it will change those codes
                console.log('-----------', displayed_row_content.replace(/::/g, '').trim());
                if (expected_string.replace(/::/g, '').trim() == "" && displayed_row_content.replace(/::/g, '').trim() != "") {
                  // console.log('***************');
                  isEmptyForCity = true;
                  return;
                }
                console.log(index);
                expect(displayed_row_content).toMatch(my_regex_lib.replaceRegex(expected_row_content));
              } else if (panelName == 'Customized Filter') {
                expect(displayed_row_content.trim()).toMatch(my_regex_lib.replaceRegex(expected_row_content));
              }
              else {
                expect(displayed_row_content).toMatch(my_regex_lib.replaceRegex(expected_row_content));
              }
              break;
          };
        }
      });
    });
};