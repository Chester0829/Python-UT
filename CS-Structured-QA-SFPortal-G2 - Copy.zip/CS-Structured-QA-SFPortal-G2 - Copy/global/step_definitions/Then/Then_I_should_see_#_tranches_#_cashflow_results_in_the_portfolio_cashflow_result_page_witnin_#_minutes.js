// Recommended filename: Then_I_should_see_#_FLC_and_#_cashflow_results_in_the_portffolio_cashflow_result_page_witnin_#_minutes.js
module.exports = function() {
  this.Then(/^I should see (.*) tranches "([^"]*)" cashflow results in the portfolio cashflow result page within (.*) minutes$/, {timeout: 1000*1000}, function ( batchSize, output_type,waitMinutes) {
    // Write the automation code here
    var totalWaitTime = waitMinutes * 30 * 1000;
    var self = this;
    // var cf_initializing_status = '//*[contains(@*, "cash.showInitialize")]';
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
    var cf_progress_status = cashflow_xpath.cashflowProcess;
    var results_section = content_xpath.resultPanel;
    var tranche_summary_table = cashflow_xpath.trancheSummaryTable;
    var cashflow_summary_table = cashflow_xpath.cashflowResult;
    var cashflow_process_bar = content_xpath.tableWaitline;
    console.log(tranche_summary_table);
    this.browser_session.waitForResource(browser,tranche_summary_table);
    browser.getLocationInView(tranche_summary_table);
    expect(browser.isExisting(tranche_summary_table));
    expect(browser.isExisting(cashflow_summary_table));
    this.browser_session.waitVisible(browser,cashflow_process_bar);
    this.browser_session.waitForLoading(browser,cashflow_process_bar,1000,totalWaitTime);
    this.browser_session.waitVisible(browser,cf_progress_status,this.waitDefault);
    this.browser_session.waitForLoading(browser, cf_progress_status, 1000,totalWaitTime);
    console.log(cashflow_summary_table);
    browser.getLocationInView(cashflow_summary_table); 
    var table_html;
    table_html = browser.getHTML(tranche_summary_table);
    var tranche_summary_table_json = this.tabletojson.convert(table_html)[0];
    table_html = browser.getHTML(cashflow_summary_table);
    var cashflow_summary_table_json = this.tabletojson.convert(table_html)[0];
    expect(tranche_summary_table_json).not.toBe(null);
    expect(cashflow_summary_table_json).not.toBe(null);
    // console.log(tranche_summary_table_json);
    // console.log(cashflow_summary_table_json);
    if (batchSize == 'all') {
        console.log('this.set_size:'+this.set_size);
        batchSize = this.set_size;
    }
    expect(Object.keys(tranche_summary_table_json).length).toBe(parseInt(batchSize));
    expect(Object.keys(cashflow_summary_table_json).length).not.toBe(0);
    var reg = /^(\+|-)?[0-9]+([.]{1}[0-9]+){0,1}$/;
    var flc_reg = /^\d{1,2}\.\d{2} \((MOD)?(CDR)?(SMM)?(PTC)?\)$/;
    // TODO
    if(this.portfolio == 'Portfolio-CMBS-for-automation'){
      console.log(tranche_summary_table_json);
      // check if page display warning message
      // var warning = '//*[contains(@class,"alert-error alert-danger icon alert-dismissable")]';
      // if(browser.isVisible(warning)){
      //   // click
      //   browser.click(warning + '//button[@data-dismiss]');
      //   browser.pause(1000);
      // }
      return;
    }
    tranche_summary_table_json.forEach(function(row) {
      switch (output_type) {
          case "'First Loss":
                switch (self.selectedAssetClass) {
                    case "CDO":
                        expect(flc_reg.test(row['First Loss'])).toBe(true);
                        break;
                    case "ABS":
                        expect(row['First Loss']).toContain('(Default Rate)');
                        break;
                    case "CARDS":
                        expect(row['First Loss']).toContain('(Monthly Loss %)');
                        break;
                }
                break;
            // case "Price":
            //     expect(row['Price'] != null).toBe(true);
            //     expect(reg.test(row['Price'])).toBe(true);
            //     break;
            // case "DM / Yield":
            //     expect((row['DM (%)'] != null) && (row['Yield (%)'] != null)).toBe(true);
            //     expect(reg.test(row['DM (%)']) && reg.test(row['Yield (%)'])).toBe(true);
            //     break;
            // case "Spread":
            //     expect(row['Pricing Spread'] != null).toBe(true);
            //     expect(reg.test(row['Pricing Spread'])).toBe(true);
            //     break;
               case "IRR":
                   expect(row['IRR'] != null).toBe(true);
                   break;
            default:
                break;
            }
    });
  });
};