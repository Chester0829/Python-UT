// Recommended filename: Then_I_should_see_the_#_pie-chart_under_the_#_panel-heading_to_#_the_following_data.js
module.exports = function() {
  this.Then(/^I should see the "([^"]*)" pie\-chart under the "([^"]*)" panel\-heading to (contain|match) the following data$/, 
    {timeout: process.env.StepTimeoutInMS*5},
    function (chartName, panelName, action, table) {
      // Write the automation code here
      // browser.pause(1000);
      this.browser_session.waitForLoading(browser);
      var expected_row_list = table.hashes();
      this.pie_charts_value_length = expected_row_list.length;
      this.chartName = chartName;

      const my_regex_lib = this.regex_lib;
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase());
      // if (panelName == 'Rating') {
      //   myPanel = '(' + myPanel + ')[2]'
      // }
      var myChart = myPanel + content_xpath.namedPieChar.replace(/__NAME__/g, chartName);
      var myChart_title = myChart + content_xpath.chartTitle;
      var myChart_label = myChart + content_xpath.chartLabel; //'//*[contains(@class, "highcharts-data-labels")]';
      var myChart_legend = myChart + content_xpath.chartLegend; //'//*[contains(@class, "highcharts-legend")]';
      
      console.log(myChart);
      this.browser_session.waitForResource(browser, myChart);
      if (!process.env.BROWSER.startsWith('IE')) {
        browser.touchScroll(browser.element(myPanel).value['ELEMENT'],0,200);
    }
      
      var displayed_label;
      var displayed_label_is_array;
      var displayed_text;
      var displayed_legend;
      expected_row_list.forEach(function(row) {
        if (row['title']) {
          displayed_title_text = browser.getText(myChart_title).toString();
          switch(action) {
            case 'contain': expect(displayed_title_text).toContain(row['title']); break;
            case 'match' : expect(displayed_title_text).toMatch(row['title']); break;
          }
        }
        if (row['percent_label']) {
          displayed_label = browser.getText(myChart_label);
          displayed_label_is_array = Array.isArray(displayed_label);
          console.log(displayed_label);
          if (displayed_label_is_array) {
            displayed_label = displayed_label.toString();
          }
          console.log(displayed_label);

          switch (action) {
            case 'contain': expect(displayed_label).toContain(row['percent_label']); break;
            case 'match': expect(displayed_label).toMatch(my_regex_lib.replaceRegex(row['percent_label'])); break;
          }
        }
        if (row['text']) {
          displayed_text = browser.getText(myChart);
          switch (action) {
            case 'contain': expect(displayed_text).toContain(row['text']); break;
            case 'match': expect(displayed_text).toMatch(my_regex_lib.replaceRegex(row['text'])); break;
          }
        }
        if (row['legend']) {
          displayed_legend = browser.getText(myChart_legend).toString();
          switch (action) {
            case 'contain': expect(displayed_legend.replace(/ /g,'')).toContain(row['legend'].replace(/ /g,'')); break;
            case 'match': expect(displayed_legend.replace(/ /g,'')).toMatch(my_regex_lib.replaceRegex(row['legend'].replace(/ /g,''))); break;
          }
        }
      });

  });
}
