// Recommended filename: Then_I_should_see_the_#_table_data_under_the_#_panel-heading_to_#_the_following_table_data_row.js
// Then I should see the "ABS" table data under the "BWIC Analyzer" panel-heading to contain the following table data row
module.exports = function() {
 this.Then(/^I should see the "([^"]*)" table data under the "([^"]*)" panel-heading to (match|contain) the following table data row$/, 
 	{timeout: process.env.StepTimeoutInMS * 10},
 	function (tableName,widget,testAction,table) {
  // Write code here that turns the phrase above into concrete actions
  // return 'pending';
  this.browser_session.waitForResource(browser);
  this.browser_session.waitForLoading(browser);
  //this.browser_session.waitForRender(browser);

  const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
  var myPanel = content_xpath.titledPanelLowercase.replace('__TITLE__', widget.toLowerCase());
  var tableList = browser.getText(myPanel + '//table');
  // console.log(tableList);
  
  const my_regex_lib = this.regex_lib;

  var expectList =table.hashes();
  console.log(expectList);


  var targetTableList = undefined;
  if (tableName == 'Solve Advisors BWICs') {
  	var targetTableList = tableList;
	  console.log(targetTableList);
	  var start = 1;
  }
  else if(tableName == 'Your BWICs'){
    var targetTableList = browser.getText(myPanel + '//sfp-data-table//table');
    console.log(targetTableList);
    var start = 1;
  }
  else{
	  for(var i=0;i<tableList.length;i++){
	  	if(tableList[i].startsWith(tableName)){
	  		targetTableList = tableList[i].split('\n');
	  		break;
	  	}
	  }
	  console.log(targetTableList);
	 	var len  = targetTableList[targetTableList.length-1].indexOf('No data') == -1 ? targetTableList.length : targetTableList.length-1;
	  // for BWIC Analyzer on dashboard 
	  if(widget == 'BWIC Analyzer'){
	  	var item = targetTableList[0].split(' ');
      console.log(item);
	  	var itemLen = item.length;
      console.log(itemLen);
	  	expect(parseInt(item[itemLen-2]) ).toEqual(len-4);
	  	var total = 0;
	  	for(var i=2;i<len;i++){
		  	var tmp = targetTableList[i].split(' ');
        console.log(tmp);
		  	total += parseInt(tmp[tmp.length-1]);
		  }
		  // console.log(total + '---' + item[itemLen-1]);
		  //expect(total).toEqual(parseInt(item[itemLen-1]));
	  }
	  var start = 2;
  }

  switch(testAction){
  	case 'contain':
  	case 'contains':
  		for(var i=1;i<expectList.length;i++){
        console.log(expectList[i]['row_data']);
        console.log(targetTableList.indexOf(expectList[i]['row_data']));
  			expect(targetTableList.indexOf(expectList[i]['row_data'].replace(/ :: /g,' ')) != -1).toBe(true);
  		}
  		break;
  	case 'match':
  		// start index = 2
			for(var i=1;i<expectList.length;i++){
        console.log(targetTableList[i]);
        console.log(len);
        var expected_string = my_regex_lib.replaceRegex(expectList[i-1]['row_data']);
				expect(targetTableList[i]).toMatch(expected_string.replace(/ :: /g,' '));
			}			
  		break;
  }
 });
}