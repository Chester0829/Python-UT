//Then I should see Scen "1" "Tranche Flows" cashflow result is the same as a benchmark file "Benchmark-MADPK11.csv" for the "MADPK11.AR" tranche
//Then_I_should_see_Scen_#_#_cashflow_result_is_the_same_as_a_benchmark_file_#_for_the_#_tranche.js
module.exports = function() {
this.When(/^I should see the "([^"]*)" cashflow result is the same as a benchmark file "([^"]*)" for the "([^"]*)" tranche$/, function (cashflowType,benchmFile,assetType) {
         // Write code here that turns the phrase above into concrete actions
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
      const path = require('path');
      const fs = require('fs');
      var displayed_row_content;
      var xlsxpath = path.join(process.cwd(), '..', '..','testdata', 'cashflow', benchmFile);
      console.log(xlsxpath);
      var self = this;
      var tableAllcount = 0;
      this.browser_session.waitForResource(browser);
      this.browser_session.waitForLoading(browser);
      if(fs.existsSync(xlsxpath)==false)
      {
        xlsxpath = path.join(process.cwd(),'testdata', 'cashflow', benchmFile);
      }
      // var type_array = ['Tranche Flows', 'Deal Flows', 'Collateral Flows','Fees','Tests','Reinvestments','Accounts','Hedges','Principal Paydown'];
      var cfresultMode = browser.getText(cashflow_xpath.dealCfresultMode);
      expect(cfresultMode==cashflowType).toBe(true,cfresultMode,cashflowType);
      var xlsxsheetnames = this.file_session.readXlsxSheetNames(xlsxpath);
      var myTable = cashflow_xpath.dealCfresultTable;
      switch (cashflowType) {
        case 'Tranche Flows':
        case 'Collateral Flows':   
        case 'Reinvestments': 
              var benchMJson = self.file_session.readXlsxAsJsonStrBysheetName(xlsxpath, cashflowType);
              var displace_all_text = self.browser_session.getTableAllText(browser,myTable);
              var displace_length = displace_all_text.length - 1;
              expect(benchMJson.length == displace_length).toBe(true,"benchMJson length :"+ benchMJson.length , "displace length :" + displace_length);
              //JSON.stringify
              for(var row_index = 0 ; row_index < benchMJson.length ; row_index ++ ){
                var displace_row = JSON.stringify(displace_all_text[row_index]);
                var benm_row = JSON.stringify(benchMJson[row_index]);
                expect(displace_row == benm_row).toBe(true, "benchmark row :"+benm_row , "displace_row :" +　displace_row);
              }
              // var benchMAllString = benchMCsvString.substring(benchMCsvString.indexOf('\n')+1).replace(/\n/g,',').replace(/"/g,'').replace(/(^\s*)|(\s*$)/g, ""); 
              // var displayed_all_content = self.browser_session.getAnormalTableAllText(browser, myTable,',');
              // expect(benchMAllString == displayed_all_content).toBe(true,benchMAllString,displayed_all_content);
            break;
        case 'Deal Flows':
        case 'Tests':
        case 'Accounts':
          var benchMCsvString = self.file_session.readXlsxAsCsvStrBysheetName(xlsxpath, cashflowType);
          // var benchMAllString = benchMCsvString.replace(/\n/g, ',').replace(/"/g, ',').replace(/,,/g, ',').replace(/,,/g,',').replace(/,,/g,',').replace(/,/g,' ').replace(/ /g,' ').replace(/(^\s*)|(\s*$)/g,'');
          // var displayed_all_content = self.browser_session.getAnormalTableAllText(browser,myTable,"null",true).replace(/,/g,' ').replace(/(^\s*)|(\s*$)/g, '');
          // console.log(benchMAllString);
          // console.log('************************');
          // console.log(displayed_all_content);
          // expect(benchMAllString == displayed_all_content).toBe(true);
          // var benchMAllString = benchMCsvString.replace(/"/g, ',').replace(/,,/g, ',').replace(/,,/g, ',').replace(/,,/g, ',').replace(/,/g, ' ').replace(/ /g, ' ').replace(/ /g,' ').replace(/(^\s*)|(\s*$)/g, "");
            var benchMAllString = benchMCsvString.replace(/"/g, '').replace(/ /g,' ').replace(/(^\s*)|(\s*$)/g, "").replace(/^,+/, "").replace(/,+$/, "");
            var benchmark_array = benchMAllString.trim().split('\n');
            // first line is blank ,so need '-1'
            var displace_length = self.browser_session.getAnormalTableRowCount(browser,myTable,true) - 1;
          // console.log(benchmark_array);
          console.log(benchmark_array.length);
          console.log(displace_length);
          expect(benchmark_array.length == displace_length).toBe(true,"benchmark_array :" + benchmark_array.length, "displace_length :"+displace_length);
          for(var row_index = 0 ; row_index < benchmark_array.length ; row_index ++ ){
            var display_row_element = "("+myTable+"//tr)["+(row_index+2)+"]";
            // console.log(browser.getText(display_row_element));
            var display_row_text = browser.getText(display_row_element).replace(/ /g, ',');
            // console.log(benchmark_array[row_index]);
            var benchmark_row_text = benchmark_array[row_index].replace(/^,+/, "").replace(/,+$/, "").replace(/ /g, ',');
            expect(display_row_text == benchmark_row_text).toBe(true,"display_row_text:"+display_row_text ,"benchmark_row_text :"+benchmark_row_text);
            }
            break;
        case 'Principal Paydown':
            var benchMCsvString = self.file_session.readXlsxAsCsvStrBysheetName(xlsxpath, cashflowType);
            var benchMAllString = benchMCsvString.replace(/"/g, '').replace(/ /g,' ').replace(/(^\s*)|(\s*$)/g, "").replace(/^,+/, "").replace(/,+$/, "");
            var benchmark_array = benchMAllString.trim().split('\n');
            var displace_length = self.browser_session.getAnormalTableRowCount(browser,myTable,true);
            // console.log(benchmark_array);
            console.log(benchmark_array.length);
            console.log(displace_length);
            expect(benchmark_array.length == displace_length).toBe(true,"benchmark_array :" + benchmark_array.length, "displace_length :"+displace_length);
            for(var row_index = 0 ; row_index < benchmark_array.length ; row_index ++ ){
              var display_row_element = "("+myTable+"//tr)["+(row_index+1)+"]";
              // console.log(display_row_element);
              var display_row_text = browser.getText(display_row_element).replace(/ /g, ',');
              // console.log(benchmark_array[row_index]);
              var benchmark_row_text = benchmark_array[row_index].replace(/^,+/, "").replace(/,+$/, "").replace(/ /g, ',');
              expect(display_row_text == benchmark_row_text).toBe(true,"display_row_text:"+display_row_text ,"benchmark_row_text :"+benchmark_row_text);
            }
            break;
          //Hedges no data display
        case 'Hedges':
          break;
        case 'Fees': 
          if(assetType == 'CDO'){
              var benchMJson = self.file_session.readXlsxAsJsonStrBysheetName(xlsxpath, cashflowType);
              var displace_all_text = self.browser_session.getTableAllText(browser,myTable);
              var displace_length = displace_all_text.length - 1;
              expect(benchMJson.length == displace_length).toBe(true,"benchMJson length :"+ benchMJson.length , "displace length :" + displace_length);
              //JSON.stringify
              for(var row_index = 0 ; row_index < benchMJson.length ; row_index ++ ){
                var displace_row = JSON.stringify(displace_all_text[row_index]);
                var benm_row = JSON.stringify(benchMJson[row_index]);
                expect(displace_row == benm_row).toBe(true, "benchmark row :"+benm_row , "displace_row :" +　displace_row);
              }
          }else{
              var benchMCsvString = self.file_session.readXlsxAsCsvStrBysheetName(xlsxpath, cashflowType);
              var benchMAllString = benchMCsvString.replace(/"/g, '').replace(/ /g,' ').replace(/(^\s*)|(\s*$)/g, "").replace(/^,+/, "").replace(/,+$/, "");
              var benchmark_array = benchMAllString.trim().split('\n');
              // first line is not blank.
              var displace_length = self.browser_session.getAnormalTableRowCount(browser,myTable,true);
              // console.log(benchmark_array);
              console.log(benchmark_array.length);
              console.log(displace_length);
              expect(benchmark_array.length == displace_length).toBe(true,"benchmark_array :" + benchmark_array.length, "displace_length :"+displace_length);
              for(var row_index = 0 ; row_index < benchmark_array.length ; row_index ++ ){
              var display_row_element = "("+myTable+"//tr)["+(row_index+1)+"]";
             // console.log(browser.getText(display_row_element));
              var display_row_text = browser.getText(display_row_element).replace(/ /g, ',');
             // console.log(benchmark_array[row_index]);
             var benchmark_row_text = benchmark_array[row_index].replace(/^,+/, "").replace(/,+$/, "").replace(/ /g, ',');
             expect(display_row_text == benchmark_row_text).toBe(true,"display_row_text:"+display_row_text ,"benchmark_row_text :"+benchmark_row_text);
            }
          }
          break;
      }
  });
}
