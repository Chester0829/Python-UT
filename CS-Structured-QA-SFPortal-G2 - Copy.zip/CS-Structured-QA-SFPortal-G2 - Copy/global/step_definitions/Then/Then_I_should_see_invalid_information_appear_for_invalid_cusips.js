// Then_I_should_see_invalid_information_appear_for_invalid_cusips.js
// for cmbs bwic
module.exports = function() {
	this.Then(/^I should see invalid information appear for invalid cusips$/, function () {
		// Write code here that turns the phrase above into concrete actions
		this.browser_session.waitForResource(browser);
		var warning = '//*[@class="alert alert-warning"]';
		var invalidInfo = browser.getText(warning);
		console.log(invalidInfo);
		
		var expectInfo = ['The following identifiers are invalid: AUS3832LS, US812KFCBIZ0, XS83LBI381SD, ASLDIB832103, AKS338B83, 38394736C, 38D8DURKS, 3829DBE8S, 328192SKDIBB ',
			'The following identifiers are invalid: ABCDEFGHI, JKLMNOPQR, STUVWXYZ1, 234567890, A128VB3K3, 2129CLW3L2, ASD83L2DC, 8343VK3LS, AUS3832LS '
		]
		// expect(invalidInfo).toContain(expectInfo);
		expect(expectInfo.join('-')).toContain(invalidInfo);


	});
}