// filename : Then_I_close_edit_deal_frame.js
module.exports=function(){
  this.Then(/^I close edit deal frame$/, function () {
         // Write code here that turns the phrase above into concrete actions
         const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
         browser.click(cashflow_xpath.editDealClose);
         this.browser_session.waitForResource(browser);
       });
}