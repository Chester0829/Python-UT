// Recommended filename: Then_I_should_see_the_file_#_the_following_multi_#_#.js
module.exports = function() {
  this.Then(/^I should see the file (contains|contain|match) the following (only|first|second) (header|data|data regex) (row|row by row)$/, 
    {timeout: process.env.StepTimeoutInMS*5},
    function (testAction, tableNum, contentType, compareType ,table) {
      // return 'pending';
      this.browser_session.waitForResource(browser);
      var expected_item_list = table.hashes();
      var self = this;
      var tableIndex = 1;
      expected_item_list.forEach(function(expected_item, index){
        var row_data = expected_item['row_data'];
        var check_data;
        if(contentType.indexOf('regex') != -1){ 
          row_data = self.regex_lib.replaceRegex(row_data);
        }
        switch(tableNum){
          case "only":
          case "first":
            tableIndex = 0;
          break;
          case "second":
            tableIndex = 1;
          break;
          default:
          break;
        }
        switch(contentType){
          case 'header':
            check_data = self.file_target_data[tableIndex][0];
            break;
          case 'data':
          case 'data regex':
            check_data = self.file_target_data[tableIndex].slice(1);
            break;
        }
        console.log(check_data);
        switch(testAction){
          case 'contains':
          case 'contain':
            // indexOf
            var tmp = row_data.replace(/ :: /g,',').trim();
            if( tmp.endsWith(' ::') ){
              var data = tmp.replace(' ::',',');
            }else{
              var data = tmp;
            }
            // // console.log(data)
            // if( Array.isArray(check_data)  && check_data.length == 1 && check_data[0] == ''){
            //  // for rmbs Credit Support
            //  check_data = check_data.join('');
            //  expect(check_data).toEqual(data);
            //  break;
            // }
            expect(check_data.replace(/"/g,'')).toContain(data);
            break;
          case 'match':
            // reg
            if(check_data.length == 0){
              // no data
              console.log(row_data);
              for(var j=0;j<self.no_data_text_list.length;j++){
                // console.log(self.no_data_text_list);
                if(row_data.indexOf(self.no_data_text_list[j]) != -1){
                  return;
                }
              }
              expect(false).toBe(true);
            }
            if(typeof(check_data) === 'string') {
              expect(check_data.replace(/"/g, '').replace(/, /g,',')).toMatch(row_data.replace(/ :: /g,','));
              return;
            }
            if(compareType == 'row'){
              for(var i=0;i<check_data.length;i++){
                console.log('check_data:' + check_data[i]);
                if(check_data[i] == ''){continue}
                // var tmp = check_data[i].split('","').join(' :: ');
                var tmp = check_data[i].split('","').map(function(curValue){return curValue.trim()}).join(' :: ');
                console.log(tmp);
                expect(tmp).toMatch(row_data);
              }
            }else if(compareType == 'row by row'){
              console.log('expected_row index: ' + index + ' expected_row ' + row_data);
              console.log('displayed_row index ' + index + ' displayed_row ' + check_data[index]);
              if(check_data[index] != null && check_data[index] != '' ){
                console.log('before split-join: ' + check_data[index]);
                var tmp = check_data[index].split('","').map(function(curValue){return curValue.trim()}).join(' :: ');
                console.log('after split-join: ' + tmp);
                expect(tmp).toMatch(row_data);
              }
            }
            break;
        }
      });

    });
};