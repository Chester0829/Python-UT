// Recommended filename: Then_I_should_see_the_select_after_the_#_checkbox_under_the_panel-heading_contains_below_options.js
module.exports = function() {
	this.Then(/^I should see the select after the "([^"]*)" checkbox under the "([^"]*)" panel-heading contains below options$/, 
		{timeout: process.env.StepTimeoutInMS*5},
		function(checkboxValue,widgetName,table){
			// return 'pending';	
			this.browser_session.waitForResource(browser);
			var table_json = table.hashes();
			console.log(table_json);

			const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
			const download_xpath = this.xpath_lib.xpathRequire('managerModeDownload_xpath');
			const selectOption_xpath = this.xpath_lib.xpathRequire('selectOption_xpath');

			var widget_xpath = download_xpath.widget_xpath.replace('__WIDGETNAME__',widgetName);
			var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());

			var checkBox_xpath = this.xpath_lib.xpathRequire('checkBox_xpath');
			var checkBoxTitle_xpath = myPanel + checkBox_xpath.checkBoxTitle_xpath.replace('__CHECKBOXTITLE__',checkboxValue);
			var select_xpath = checkBoxTitle_xpath + '/parent::*/following-sibling::*';

			if(!browser.isVisible(checkBoxTitle_xpath)){
				checkBoxTitle_xpath = myPanel + checkBox_xpath.checkBoxTitle_xpath1.replace('__CHECKBOXTITLE__',checkboxValue)
				select_xpath = checkBoxTitle_xpath + '/parent::*/parent::*/parent::*/following-sibling::*';
			}

			// for Filter Settings
			console.log( select_xpath);
			browser.click(select_xpath);
			browser.pause(1000);

			var allOptions = browser.getText(selectOption_xpath.selectMenu1).split('\n');
			console.log(allOptions);
			console.log(selectOption_xpath.selectMenu1 + '//*[contains(text(),"' + allOptions[0] + '")]');
			browser.click(selectOption_xpath.selectMenu1 + '//*[contains(text(),"' + allOptions[0] + '")]');
			for(var i=0;i<table_json.length;i++){
				expect(table_json[i]['row_data']).toContain(allOptions[i],allOptions);
			}

			if(widgetName == 'Filter Settings'){
				// var label_xpath = widget_xpath + '/parent::*/parent::*/following-sibling::*' + checkBoxTitle_xpath;
				browser.click(checkBoxTitle_xpath);
				browser.pause(1000);
			}

			
		})
}