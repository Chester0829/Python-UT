//Then I_#_charts_to_#_charts_and_check_the_limit.js
module.exports = function() {
  this.Then(/^I "([^"]*)" charts to (least|most) charts and check the limit$/,
   function (type,number) {
    // Write the automation code here
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    var delete_button = content_xpath.delete_button
    var add_button = content_xpath.add_chart
    var charts_element = content_xpath.charts
    if (type == 'delete'){
      var charts_number = browser.elements(charts_element).value.length;
      for(var item = 1; item <= charts_number-3;item++ ){
        var count = browser.elements(charts_element).value.length;
        if(count==4){
          browser.click('('+delete_button+')[1]')
          console.log('least limit')
          browser.waitForVisible("//*[contains(text(),'Reached minimum number of charts')]",this.waitDefault)
        }else{
          browser.click('('+delete_button+')[1]')
        }
        browser.pause(500)
      }
      charts_number = browser.elements(charts_element).value.length;
      console.log('charts_number:'+charts_number)
      expect(charts_number==4).toBe(true)
    }else{
      var charts_number = browser.elements(charts_element).value.length;
      for(var item = 1; item<=9-charts_number;item++){
        var count = browser.elements(charts_element).value.length;
        if(count==8){
          browser.click(add_button)
          console.log('most limit')
          browser.waitForVisible("//*[contains(text(),'Reached maximum number of charts')]",this.waitDefault)
        }else{
          browser.click(add_button)
        }
      browser.pause(500)
      }
      charts_number = browser.elements(charts_element).value.length;
      console.log('charts_number:'+charts_number)
      expect(charts_number==8).toBe(true)
    }
   }
)};