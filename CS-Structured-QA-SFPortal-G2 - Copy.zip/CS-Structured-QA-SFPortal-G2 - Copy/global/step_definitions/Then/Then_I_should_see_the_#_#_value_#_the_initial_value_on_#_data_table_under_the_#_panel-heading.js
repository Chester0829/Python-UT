//Recommended filename : Then_I_should_see_the_#_#_value_#_the_initial_value_on_#_data_table_under_the_#_panel-heading.js     
module.exports = function() { 
       this.Then(/^I should see the (first|second|third) "([^"]*)" value "([^"]*)" the initial value on (only|first|second|third) data table under the "([^"]*)" panel\-heading$/, function (filedIndex,fieldname, action,tableIndex, panelName) {
         // Write code here that turns the phrase above into concrete actions
        const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
        var content_xpath = this.xpath_lib.xpathRequire('content_xpath');
        var myPanel = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase());
        var myTable = myPanel + content_xpath.descendantDataTable;
        var nth_index;
        var filed_index;
        switch (tableIndex) {
          case "only":
            nth_index = 1;
            break;
          case "first":
            nth_index = 1;
            break;
          case "second":
            nth_index = 2;
            break;
          case "third":
            nth_index = 3;
            break;
        };
        switch (filedIndex) {
          case "first":
            filed_index = 0;
            break;
          case "second":
            filed_index = 1;
            break;
          case "third":
            filed_index = 2;
            break;
        };
        myTable = '(' + myTable + ')[' + nth_index + ']';
        console.log(myTable);
        this.browser_session.waitForResource(browser,myTable);
        if (!process.env.BROWSER.startsWith('IE')) {
            try {
            browser.touchScroll(browser.element(myTable).value['ELEMENT'],0,200);
          } catch(e) {}
        }

        var table_html = browser.getHTML(myTable);
        var cashflow_table_json = this.tabletojson.convert(table_html)[0];
        var field_value = cashflow_table_json[filed_index][fieldname].replace(/,/g,'');
        var init_value;
        switch(fieldname){
          case "End Balance":
          init_value = this.bal_initValue;
          break;
          case "Coupon":
          init_value = this.cou_initValue;
          break;
          case "Interest":
          init_value = this.intere_initValue;
        }
        init_value = init_value.replace(/,/g,'');
        switch(action){
          case "less than":
            expect(parseFloat(field_value)<parseFloat(init_value)).toBe(true,field_value,"init_value :"+init_value);
            break;
          case "more than":
            expect(parseFloat(field_value)>parseFloat(init_value)).toBe(true,field_value,"init_value :"+init_value);
            break;
          case "different with":
            expect(parseFloat(field_value)==parseFloat(init_value)).toBe(false,field_value,"init_value :"+init_value);
            break;
          case "same as":
            expect(parseFloat(field_value)==parseFloat(init_value)).toBe(true,field_value,"init_value :"+init_value);
            break;
        }

    });
};