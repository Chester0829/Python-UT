//Then_I_run_deal cashflows_and_save_the_cashflow_run_deal_requests_for_#_asset_class.js
module.exports = function(){ 
      this.Then(/^I run (deal|portfolio) cashflows and save the cashflow run deal requests for "([^"]*)" asset class$/, 
        { timeout: process.env.StepTimeoutInMS * 10 },
        function (runtype,assettype) {
         // Write code here that turns the phrase above into concrete actions
        // const cashflow_xpath = this.xpath_lib.xpathRequire("cashflow_xpath");
        const content_xpath = this.xpath_lib.xpathRequire("content_xpath");
         var fs = require("fs"); 
         var path = require('path');
         // var timeOut = arg1*60*1000; 
         var self = this;
         var myWaitDefault = this.waitDefault;
         var panelName = "Results";
         var sfwdealID; 
         const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
         var scenario_list = this.scenario_list;
         // var scenario_list_length = scenario_list.length;
         var scenarios_used = this.scenarios_used;
         console.log('this.scenario_used:', scenarios_used);

            //  defined the write function
            var export_res = function (file_name, file_path, file_content, file_type) {
                var myDate = new Date();
                var month = myDate.getMonth() + 1;
                var day = myDate.getDate();
                var today = '0' + month + day;
                file_name = file_name + '_' + today + '.' + file_type;
                if (file_type == 'json') {
                    var data_json = JSON.stringify(file_content);
                } else {
                    var data_json = file_content;
                }
                //if (fs.existsSync(file_path)) {
                //    console.log(file_path + ' exist!') 
                //} else {
                //    fs.mkdir(file_path, function (err) {
                //        if (err) {
                //            console.log(err);
                //            throw err;
                //        }
                //        console.log('make dir success.');
                //    });
                //}
                self.utility_lib.mkdirsSync(file_path);
                // console.log("--------------------------cash flow---------------------------------",casgflow_json);
                fs.writeFile(file_path + '/' + file_name, data_json, { flag: "w" }, function (err) {
                    if (err) {
                        console.log(file_name + " saved failed!");
                        return console.log(err);
                    } else {
                        console.log(file_name + " saved successfully!");
                    }

                })
            }; 


         if(runtype == 'deal'){
           var scenario_list_length = scenario_list.length;
           this.browser_session.waitForResource(browser,cashflow_xpath.dealCfsAssumptions);
           browser.getLocationInView(cashflow_xpath.dealRunCashflow);
           browser.click(cashflow_xpath.dealRunCashflow);
           var tranche_select_box = content_xpath.titledSectionLowercase.replace("__TITLE__", panelName.toLowerCase()) + "// select";
           var tranche_select_xpath = tranche_select_box + "// option";
           console.log("tranche_select_xpath:", tranche_select_xpath);
           browser.waitForVisible(tranche_select_box,this.waitDefault)
           var tranche_name = browser.getValue(tranche_select_box);
           console.log('default tranche_name' + tranche_name);
           sfwdealID = tranche_name.split('.')[0];
           var toggle_output_button = '//span[contains(text(),"Toggle Debug Output")]';
           if(process.env.NODE_ENV.indexOf('SPS')!=-1){
             var run_deal_request_xpath = '//div[contains(@ng-repeat,"item in analyticsCtrl.debugOutput track by")]';
           }else{
             var run_deal_request_xpath = '//div[contains(@ng-repeat,"item in analyticsCtrl.debugOutput track by")][2]'
           }
           try {
             browser.waitForVisible(toggle_output_button,this.waitMax)
             browser.getLocationInView(toggle_output_button);
             if (browser.isVisible(toggle_output_button)&&!browser.isVisible(run_deal_request_xpath)) {
               browser.click(toggle_output_button);
               browser.waitForVisible(run_deal_request_xpath, myWaitDefault);
               self.browser_session.waitForResource(browser,run_deal_request_xpath)
             } else {
               console.log('click toggle output button failed');
             }
           } catch (e) {
             console.log('wait for run deal request');
             browser.waitForVisible(run_deal_request_xpath, myWaitDefault);
             self.browser_session.waitForResource(browser,run_deal_request_xpath)
           }
           for (var scen_index = 1; scen_index <= scenario_list_length; scen_index++) {
             var scenario_id = scenario_list[scen_index - 1]["scenario_id"];
             var settles_date = scenarios_used[scenario_id][4];
             var request_str = browser.getText(run_deal_request_xpath);
             var file_name = scenario_id + '_' + sfwdealID + '_' + settles_date+'_request';
             if(process.env.NODE_ENV.indexOf('SPS')!=-1){
               request_str = request_str.replace(/Cashflow Request for Scen \d/g,'').replace(/_FLC_Principal/g,'').replace(/_FLC_Interest/g,'')
               var run_deal_request = JSON.parse(request_str)
               var file_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res', 'run_deal_request');
               export_res(file_name, file_path, run_deal_request, 'json');
             }else{
               var run_deal_request = request_str.substring(request_str.indexOf("<runDealSettings"), request_str.indexOf("</RundealRequest>"));
               var file_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res', 'run_deal_request');
               export_res(file_name, file_path, run_deal_request, 'xml');
             }

           }

           if(self.stratifications_flag){
             console.log('delet all stratifications_flag')
             var apply_stra='//a[contains(text(),"Apply Stratification")]'
             browser.getLocationInView(apply_stra)
             browser.click(apply_stra);
             browser.waitForVisible('//table[contains(@id,"watchlist")]',self.waitDefault);
             if(browser.isExisting('//*[contains(@ng-click,"assumpCtrl.deleteRule")]')){
               var stra_length = browser.elements('//*[contains(@ng-click,"assumpCtrl.deleteRule")]').value.length;
               console.log('stra_length:',stra_length)
               for(var strItem = 1; strItem <= stra_length; strItem++){
                 console.log('strItem:',strItem)
                 browser.click('(//*[contains(@ng-click,"assumpCtrl.deleteRule")])[1]');
               }
               browser.click('//span[contains(text(),"Save Stratifications")]')
             }
           // close Stratifications
           browser.click('//*[contains(@ng-click,"assumpCtrl.colWatchList = false")]');
           self.stratifications_flag=false
         }

         }else{
            var run_cashflow_button = cashflow_xpath.cashflowButton;
            browser.getLocationInView(run_cashflow_button);
            browser.click(run_cashflow_button);
            var assumption_body = content_xpath.assumptionsPanel+'//tbody/tr';
            var deal_list_length = browser.elements(assumption_body).value.length;
            var run_deal_request_xpath = '//div[contains(@ng-show,"cash.showDebugOutput")]';
            var toggle_output_button = '//span[contains(text(),"Toggle Debug Output")]';
            console.log(browser.isVisible(run_deal_request_xpath))
            if(!browser.isVisible(run_deal_request_xpath)){
                browser.waitForVisible(toggle_output_button,this.waitMax)
                browser.getLocationInView(toggle_output_button);
              try {
                if (browser.isVisible(toggle_output_button)) {
                  browser.click(toggle_output_button);
                  browser.waitForVisible(run_deal_request_xpath, myWaitDefault);
                } else {
                  console.log('click toggle output button failed');
                }
              } catch (e) {
                console.log('wait for run deal request');
                browser.waitForVisible(run_deal_request_xpath, myWaitDefault);
              }
            }
           for (var deal_index = 1; deal_index <= deal_list_length; deal_index++) {
             var deal_element = '('+assumption_body+')['+deal_index+']//td[2]'
             var tranche_element = '('+assumption_body+')['+deal_index+']//td[4]'
             var tranche_name = browser.getText(deal_element)+'-'+browser.getText(tranche_element)
             var scenario_id = scenario_list[0]["scenario_id"];
             var settles_date = scenarios_used[scenario_id][4];
             var file_name = scenario_id + '_' + tranche_name.toUpperCase() + '_' + settles_date;
             var request_str = browser.getText(run_deal_request_xpath);
             file_name = 'portfolio_' + file_name + '_request';
             if(process.env.NODE_ENV.indexOf('SPS')!=-1){
               var tmp = request_str.split('\n')[0]
               console.log("tmp----------",tmp)
               request_str = request_str.replace(tmp,'')
               var run_deal_request = JSON.parse(request_str)
               var file_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res', 'run_deal_request');
               export_res(file_name, file_path, run_deal_request, 'json');
             }else{
               var run_deal_request = request_str.substring(request_str.indexOf("<runDealSettings"), request_str.indexOf("</RundealRequest>"));
               var file_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res', 'run_deal_request');
               export_res(file_name, file_path, run_deal_request, 'xml');
             }


           }
           if (self.stratifications_flag) {
             console.log('delet all stratifications_flag')
             var apply_stra = '//*[@ng-repeat="item in cash.tabs" and text()="Stratification"]'
             browser.getLocationInView(apply_stra)
             browser.click(apply_stra);
             browser.waitForVisible('//table[contains(@id,"watchlist")]', self.waitDefault);
             if (browser.isExisting('//*[contains(@ng-click,"assumpCtrl.deleteRule")]')) {
               var stra_length = browser.elements('//*[contains(@ng-click,"assumpCtrl.deleteRule")]').value.length;
               console.log('stra_length:', stra_length)
               for (var strItem = 1; strItem <= stra_length; strItem++) {
                 console.log('strItem:', strItem)
                 browser.click('(//*[contains(@ng-click,"assumpCtrl.deleteRule")])[1]');
               }
               browser.click('//span[contains(text(),"Save Stratifications")]')
             }
                // close Stratifications
                browser.click('//*[@ng-repeat="item in cash.tabs" and text()="Settings"]');
                self.stratifications_flag = false
              }

         }         
 
       }); 
};