//Then_I_should_see_the_portfolio_cashflow_assumptions_for_#_tranches_for_the_following_assumptions.js
module.exports=function(){
 this.Then(/^I should see the portfolio cashflow assumptions for "([^"]*)" tranches for the following assumptions$/, function (assetType, table) {
    // Write code here that turns the phrase above into concrete actions
    var assumption_list = table.hashes();
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
    var assumption_div = content_xpath.assumptionsPanel;

    // this.browser_session.waitForResource(browser,cashflow_xpath.dealCfsAssumptions);
    // browser.getLocationInView(cashflow_xpath.dealCfsAssumptions);
    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    var self = this;   

    var target_item = cashflow_xpath.cfnamedDescendantTab.replace('__TYPE__','cash.assetClassTypes').replace('__NAME__',assetType);
    console.log(target_item);
    browser.waitForVisible(target_item,self.waitDefault);
    browser.click(target_item); 

    assumption_list.forEach(function(list_row) {
      console.log("Validating " + list_row['name']  + " " + list_row['value']);
      switch(list_row['name']) {
        case "cash.output_type":        
          var selectPicker_select = content_xpath.selectPicker.replace('__SELECTNAME__','Output Type') + '/span/div';
          console.log(selectPicker_select);
          browser.waitForVisible(selectPicker_select,self.waitDefault);
          expect(browser.getText(selectPicker_select)).toEqual(list_row['value']);
          break;
        case "cash.cashflowOutputType":
          var selectPicker_select = content_xpath.selectPicker.replace('__SELECTNAME__','Cashflow Output') + '/span/div';
          console.log(selectPicker_select);
          browser.waitForVisible(selectPicker_select,self.waitDefault);
          expect(browser.getText(selectPicker_select)).toEqual(list_row['value']);
          break;
        case "cash.settles_date":
          var settleDateInput = cashflow_xpath.cashflowPortfolioInput.replace('__NAME__',list_row['name']);
          console.log(settleDateInput);
          expect(browser.getValue(settleDateInput)).toEqual(list_row['value']);
          break;
        case "cash.apply_watch":
        case "cash.isCustomRates":
          var check_box = cashflow_xpath.mdCheckbox.replace('__NAME__',list_row['name']);
          var target_attribute = browser.getAttribute(check_box, 'class');
          console.log(check_flag);
          if(list_row['value']=='checked')
          {
            expect(target_attribute.indexOf('ng-not-empty') > -1).toBe(true);
          }
          if(list_row['value']=='unchecked')
          {
            expect(target_attribute.indexOf('ng-empty')>-1).toBe(true);
          }
          if(list_row['value'] == "disabled")  {
            var disabled_attribute_value = browser.getAttribute(check_flag, 'disabled');
            console.log(list_row['name'] + " " + list_row['value'] + ". actual disabled field value: " + disabled_attribute_value);

            expect(browser.getAttribute(check_flag, 'disabled')).toEqual('true');
          }
          break;
        // case "tranche.run_flag":
        case "tranche.cal_first_loss":
        case "tranche.seed_default":
        case "tranche.ignore_input_nonpayment_term":
        case "tranche.calc_curve_off_static_bal":
        case "tranche.useACHVector":
        case "tranche.apply_watch":
        case "tranche.apply_loan_level_assumps":
        case 'tranche.term_triggers_activate_LTV_trigger':
        case 'tranche.term_triggers_activate_DSCR_trigger':
        case 'tranche.maturity_trigger_activate_LTV_trigger':
        case 'tranche.maturity_trigger_activate_DY_trigger':
        // case 'tranche.apply_loan_level_assumps':
          var check_box = '(' + assumption_div + content_xpath.inputoption.replace('__NAME__',list_row['name']) + ')[1]';
          var check_flag = '(' + assumption_div + content_xpath.inputoption.replace('__NAME__',list_row['name']) + ')[1]';
          var target_attribute = browser.getAttribute(check_flag, 'class');
          console.log(check_flag);
          if(list_row['value']=='checked')
          {
            expect(target_attribute.indexOf('ng-not-empty') > -1).toBe(true);
          }
          if(list_row['value']=='unchecked')
          {
            expect(target_attribute.indexOf('ng-empty')>-1).toBe(true);
          }
          if(list_row['value'] == "disabled")  {
            var disabled_attribute_value = browser.getAttribute(check_flag, 'disabled');
            console.log(list_row['name'] + " " + list_row['value'] + ". actual disabled field value: " + disabled_attribute_value);

            expect(browser.getAttribute(check_flag, 'disabled')).toEqual('true');
          }
          break;
        // case "tranche.scenType":
        //   var sentypeText = cashflow_xpath.mdSelect.replace('__NAME__',list_row['name'])+ '//md-select-value//*[contains(@class,"md-text")]';
        //   if(flag == false){
        //     expect(browser.getText(sentypeText)).not.toEqual(list_row['value']);
        //     break;
        //   }
        //   expect(browser.getText(sentypeText)).toEqual(list_row['value']);
        //   break;
        case "tranche.solve_for":
        case "tranche.loss_type":
        case "tranche.benchmark":
        case "tranche.delinquency_type":
        case "tranche.repay_type":
        case "tranche.purchase_type":
        case "tranche.portfolio_yield_type":
        case "tranche.portfolio_loss_type":
        case "tranche.deferment_type":
        case "tranche.grace_type":
        case "tranche.forbear_type":
        case "tranche.interest_cap_freq":
        case "tranche.BB_type":
        case "tranche.reinvest_price_type":
        case "tranche.reinvest_pool":
        case "tranche.reinvest_rules":
        case "tranche.call_option":
        case "tranche.force_call":
        case "tranche.call_price_type":
        case "tranche.prepay_type":
        case "tranche.forward_curve":
        case 'tranche.NOI_growth_rate_type':
        case 'tranche.cap_rate_growth_rate_type':
        case 'tranche.term_triggers_select_priority':
        case 'tranche.maturity_trigger_select_priority':
        case 'tranche.servicer_basis':
        case 'tranche.servicer_type':
          // var deal_CfSfpSelectInput = cashflow_xpath.dealCfSfpSelect.replace('__NAME__',list_row['name']) + '//input';
          // console.log(deal_CfSfpSelectInput);
          // // var deal_CfSfpSelect = cashflow_xpath.dealCfSfpSelect.replace('__NAME__',list_row['name']);
          var target_set = '(' + assumption_div + cashflow_xpath.selectButton.replace('__NAME__',list_row['name']) + ')[1]';
          // if(flag == false){
          //   expect(browser.getValue(deal_CfSfpSelectInput)).not.toEqual(list_row['value']);
          //   break;
          // }
          console.log(target_set);
          browser.waitForVisible(target_set,self.waitDefault);
          if(list_row['value'] == "disabled")  {
            var disabled_attribute_value = browser.getAttribute(target_set, 'disabled');
            console.log('disabled_attribute_value:'+ disabled_attribute_value);
            console.log(list_row['name'] + " " + list_row['value'] + ". actual disabled field value: " + disabled_attribute_value);

            expect(browser.getAttribute(target_set, 'disabled')).toEqual('true');
          }
          else {
            // var value = browser.getValue(target_set);
            // var value1 = browser.getText(target_set);
            // console.log(value);
            // console.log(value1);
            if(list_row['name'] == 'tranche.benchmark'){
              // for mix portfolio
              expect(list_row['value']).toContain(browser.getValue(target_set));
              break;
            }
            if(list_row['name'] == 'tranche.loss_type'){
              // for mix portfolio
              list_row['value'] = list_row['value'].replace('%','Percent').replace(/\s*/g,'');
            } 
            expect(browser.getValue(target_set)).toEqual(list_row['value']);            
          }
          break;
        case "tranche.settle_date":
        case "tranche.buy_price":
        case "tranche.buy_date":
        case "tranche.price":
        case "tranche.prepay_rate":
        case "tranche.loss_rate":
        case "tranche.delinquency_rate":
        case "tranche.adv_loss_rate":
        case "tranche.adv_lag_mon":
        case "tranche.repay_rate":
        case "tranche.purchase_rate":
        case "tranche.portfolio_yield_rate":
        case "tranche.portfolio_loss_rate":
        case "tranche.deferment_rate":
        case "tranche.grace_rate":
        case "tranche.forbear_rate":
        case "tranche.BB_utilization_rate":
        case "tranche.subsidy_payment_delay":
        case "tranche.SAP_payment_delay":
        case "tranche.prinLossSeverityPctNonPerf":
        case "tranche.rec_lag":
        case "tranche.alloc_mon":
        case "tranche.reinvest_price":
        case "tranche.reinvDefaultLockout":
        case "tranche.NOI_growth_rate":
        case "tranche.cap_rate_growth_rate":
        case "tranche.term_triggers_LTV_liquidate":
        case "tranche.term_triggers_LTV_months":
        case "tranche.term_triggers_LTV_loss":
        case "tranche.term_triggers_DSCR_liquidate":
        case "tranche.term_triggers_DSCR_months":
        case "tranche.term_triggers_DSCR_loss":
        case "tranche.maturity_trigger_LTV_payoff":
        case "tranche.maturity_trigger_LTV_liquidate":
        case "tranche.maturity_trigger_LTV_loss":
        case "tranche.maturity_trigger_LTV_extension":
        case "tranche.maturity_trigger_LTV_end_of_extension_liq_or_payoff":
        case "tranche.maturity_trigger_LTV_end_of_extension_loss":
        case "tranche.maturity_trigger_DY_payoff":
        case "tranche.maturity_trigger_DY_liquidate":
        case "tranche.maturity_trigger_DY_loss":
        case "tranche.maturity_trigger_DY_extension":
        case "tranche.maturity_trigger_DY_end_of_extension_liq_or_payoff":
        case "tranche.maturity_trigger_DY_end_of_extension_loss":
        case "tranche.servicer_rate":
        case "tranche.call_date":
        case "tranche.reinvest_spread":
        case "tranche.reinvest_term":
        case "tranche.call_price":
          // var assumptions_input = cashflow_xpath.dealCfsInput.replace('__NAME__',list_row['name']);
          var target_set = '(' + assumption_div + content_xpath.inputoption.replace('__NAME__',list_row['name']) + ')[1]';
          browser.waitForVisible(target_set,self.waitDefault);
          var disabled_attribute_value = browser.getAttribute(target_set, 'disabled');
          //console.log(list_row['name']  + " " + list_row['value'] + ". actual disabled field value: " + disabled_attribute_value);

          if(list_row['value'] == "disabled") {
            expect(browser.getAttribute(target_set, 'disabled')).toEqual('true');
          }
          else {
            expect(browser.getValue(target_set)).toEqual(list_row['value']);
          }
          break;
        case "tranche.yield_pct":
        case "tranche.dm":
          var target_set = '(' + assumption_div + content_xpath.inputoption.replace('__NAME__',list_row['name']) + ')[1]';
          browser.waitForVisible(target_set,self.waitDefault);
          var disabled_attribute_value = browser.getAttribute(target_set, 'disabled');
          //console.log(list_row['name']  + " " + list_row['value'] + ". actual disabled field value: " + disabled_attribute_value);
          if(list_row['value'] == "disabled") {
            expect(browser.getAttribute(target_set, 'disabled')).toEqual('true');
          }
          else if(disabled_attribute_value == null){
            expect(browser.getValue(target_set)).toEqual(list_row['value']);
          }
          break;
      }
    });  
  });
}
