// Recommended filename:Then_I_should_see_the_following_items_in_the_Deal_Overrides_section_under_the_#_panel-heading.js
module.exports = function() {
  this.Then(/^I should see the following items in the Deal Overrides section under the "([^"]*)" panel-heading$/, 
    {timeout: process.env.StepTimeoutInMS*5},
    function (panelName, table) {
    // Write the automation code here
    
    const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');

    var expected_row_list = table.hashes();

    switch (expected_row_list['item']) {
        case "EOD Override":
        case "OPT-REDEEM Override":
        case "PRO-RATA Override":
        case "EARLY-EVENT-A&E Override":
        case "EARLY-EVENT-B Override":
        case "EARLY-EVENT-C Override":
        case "EARLY-EVENT-D Override":
        case "RAPID-AMORT Override":
        case "REGULATED-AMORT Override":
            var cashflowDealOverridesLabel = cashflow_xpath.cashflowDealOverridesSubLabel.replace('__NAME__','Triggers').replace('__LABEL__',expected_row_list['item']);
            console.log(cashflowDealOverridesLabel);
            browser.waitForVisible(cashflowDealOverridesLabel,this.waitDefault);
            var cashflowDealOverridesDropdownItem = cashflow_xpath.cashflowDealOverridesDropdownItem.replace('__NAME__','Triggers');
            console.log(cashflowDealOverridesDropdownItem);
            browser.waitForVisible(v,this.waitDefault);
            break;
        case "Trustee Fees":
        case "Administration Fee":
        case "Senior Fees":
        case "JUNIOR-COST":
        case "SENIOR-COST":
        case "SERVICING-FEE":
        case "MSF":
        case "REVIEWER":
        case "TRUSTEE": 
        case "SERVICER": 
        case "SERVICING":
        case "ADMIN":
        case "DOE":
        case "EXCESS":
        case "EXTRAORDINARY FEE":
        case "OTHER":
            var cashflowDealOverridesLabel = cashflow_xpath.cashflowDealOverridesSubLabel.replace('__NAME__','Fee Overrides').replace('__LABEL__',expected_row_list['item']);
            console.log(cashflowDealOverridesLabel);
            browser.waitForVisible(cashflowDealOverridesLabel,this.waitDefault);
            var cashflowDealOverridesCheckboxItem = cashflow_xpath.cashflowDealOverridesCheckboxItem.replace('__NAME__','Fee Overrides');
            console.log(cashflowDealOverridesCheckboxItem);
            browser.waitForVisible(cashflowDealOverridesCheckboxItem,this.waitDefault);
            break;  
        case "SWAP1": 
        case "SWAP2": 
            var cashflowDealOverridesLabel = cashflow_xpath.cashflowDealOverridesSubLabel.replace('__NAME__','Swap Overrides').replace('__LABEL__',expected_row_list['item']);
            console.log(cashflowDealOverridesLabel);
            browser.waitForVisible(cashflowDealOverridesLabel,this.waitDefault);
            var cashflowDealOverridesCheckboxItem = cashflow_xpath.cashflowDealOverridesCheckboxItem.replace('__NAME__','Swap Overrides');
            console.log(cashflowDealOverridesCheckboxItem);
            browser.waitForVisible(cashflowDealOverridesCheckboxItem,this.waitDefault);
            break;         
    }    
  });
};
