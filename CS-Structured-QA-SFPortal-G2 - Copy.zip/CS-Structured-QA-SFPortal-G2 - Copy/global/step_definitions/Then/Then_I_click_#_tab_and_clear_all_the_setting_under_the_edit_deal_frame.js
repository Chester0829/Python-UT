//Recommended filename : Then_I_click_#_tab_and_clear_all_the_setting_under_the_edit_deal_frame.js
module.exports = function() {
       this.Then(/^I click "([^"]*)" tab and clear all the setting under the edit deal frame$/, function (arg1) {
         // Write code here that turns the phrase above into concrete actions
         const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
         var editTab = cashflow_xpath.editDealFrame + cashflow_xpath.editDealTab.replace('__TAB__',arg1);
         browser.getLocationInView(editTab);
         browser.click(editTab);
         this.browser_session.waitForResource(browser,cashflow_xpath.editDealFrame);
         browser.click(cashflow_xpath.editDealFrame+cashflow_xpath.editDealClearAll);
         this.browser_session.waitForResource(browser,cashflow_xpath.editDealFrame);
       });
}