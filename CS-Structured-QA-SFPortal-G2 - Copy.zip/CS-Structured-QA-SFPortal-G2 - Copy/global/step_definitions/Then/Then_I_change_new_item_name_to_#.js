// Recommended filename: Then_I_change_new_item_name_to_#.js
module.exports = function(){
       this.Then(/^I change new item name to "([^"]*)"$/, function (itemName) {
         // Write code here that turns the phrase above into concrete actions
         const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
         const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
         var create_new = content_xpath.namedButton.replace('__NAME__','Create New');
         browser.waitForVisible(create_new,this.waitDefault);
         var table_tr = content_xpath.nomarlTable.replace('__NAME__',"table cftable")+"//tr";
         var ItemDelete = content_xpath.nomarlTable.replace('__NAME__',"table cftable")+cashflow_xpath.cashflowReinDelete;
         var length = browser.elements(table_tr).value.length;
         var self = this;
         console.log(length);
         console.log(table_tr);
         for (var i = 0; i < length; i++) {
            var text = browser.getValue("("+table_tr+")["+(i+1)+"]//input");
            console.log("("+table_tr+")["+(i+1)+"]//input");
            console.log(text);
             if (browser.getValue("("+table_tr+")["+(i+1)+"]//input") == itemName) {
                console.log('delete');
                browser.click("("+ItemDelete+")["+(i+1)+"]");
                length--;
             }
         }
         this.browser_session.waitForResource(browser,table_tr);
         var newlength = browser.elements(table_tr).value.length;
         console.log(newlength);
         browser.setValue("("+table_tr+")["+newlength+"]//input",itemName);
         browser.click("("+table_tr+")["+newlength+"]//input");
         this.browser_session.waitForResource(browser,table_tr);

         var assetTr = browser.isVisible(cashflow_xpath.cashflowAssetDate);
         if (assetTr == false && self.tabName == 'Reinvestments') {
            browser.click('//*[text()="Add New Asset"]');
            this.browser_session.waitForResource(browser,table_tr);
         }
       });
};
