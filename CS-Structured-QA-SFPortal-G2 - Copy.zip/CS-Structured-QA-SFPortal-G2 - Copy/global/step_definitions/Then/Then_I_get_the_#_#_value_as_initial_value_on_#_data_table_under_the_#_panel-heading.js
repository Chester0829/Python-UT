//Recommended filename : Then_I_get_the_first_#_value_as_initial_value_on_#_data_table_under_the_#_panel-heading.js     
module.exports = function() { 
       this.Then(/^I get the (first|second|third) "([^"]*)" value as initial value on (only|first|second|third) data table under the "([^"]*)" panel\-heading$/, function (fieldIndex,fieldname, tableIndex, panelName) {
         // Write code here that turns the phrase above into concrete actions
        const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
        var content_xpath = this.xpath_lib.xpathRequire('content_xpath');
        var myPanel = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase());
        var myTable = myPanel + content_xpath.descendantDataTable;
        var nth_index;
        var filed_index;
        switch (tableIndex) {
          case "only":
            nth_index = 1;
            break;
          case "first":
            nth_index = 1;
            break;
          case "second":
            nth_index = 2;
            break;
          case "third":
            nth_index = 3;
            break;
        };
        switch (fieldIndex) {
          case "first":
            filed_index = 0;
            break;
          case "second":
            filed_index = 1;
            break;
          case "third":
            filed_index = 2;
            break;
        };
        myTable = '(' + myTable + ')[' + nth_index + ']';
        console.log(myTable);
        this.browser_session.waitForResource(browser,myTable);
        if (!process.env.BROWSER.startsWith('IE')) {
            try {
            browser.touchScroll(browser.element(myTable).value['ELEMENT'],0,200);
          } catch(e) {}
        }

        var table_html = browser.getHTML(myTable);
        var cashflow_table_json = this.tabletojson.convert(table_html)[0];
        switch(fieldname){
          case "End Balance":
            this.bal_initValue = cashflow_table_json[filed_index][fieldname];
            console.log(this.bal_initValue);
          break;
          case "Coupon":
           this.cou_initValue = cashflow_table_json[filed_index][fieldname];
           console.log(this.cou_initValue);
          break;
          case "Interest":
           this.intere_initValue = cashflow_table_json[filed_index][fieldname];
           console.log(this.intere_initValue);
          break;
        }
    });
};