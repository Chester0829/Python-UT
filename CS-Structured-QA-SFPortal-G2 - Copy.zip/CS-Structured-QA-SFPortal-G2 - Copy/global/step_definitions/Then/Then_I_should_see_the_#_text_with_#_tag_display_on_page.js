// Then_I_should_see_the_#_text_with_#_tag_display_on_page.js
module.exports = function() {
	this.Then(/^I should see the "([^"]*)" text with "([^"]*)" tag display under the "([^"]*)" panel\-heading$/, function (text, tag,widgetName) {
    // Write code here that turns the phrase above into concrete actions
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
	  var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());
    switch(widgetName){
    	case 'Journal':
      // <strong>This is a test B for auto</strong>
    		var expectText = '<'+tag+'>'+ '(<!--block-->&nbsp;)*' + text+'</'+tag+'>';
        var pattern = new RegExp(expectText,'g');
        // <pre>This is a test Code,Bullets for auto</pre>
        // <pre><!--block-->&nbsp;This is a test Code,Bullets for auto</pre>
        var editArea = myPanel + content_xpath.editArea;
    		var editText = browser.getHTML(editArea);
        console.log(editText);
        console.log(expectText);
        console.log(pattern.test(editText));
        // console.log(editText.indexOf(expectText));
    		console.log('**************');
    		break;
    }

    





    
  });
}
