// Recommended filename: Then_I_should_see_the_#_text_#_in_the_search_result_under_#_category.js
module.exports = function() {
 this.Then(/^I should see the "([^"]*)" text (displayed|not displayed) in the search result under "([^"]*)" category$/, 
  function(result, displayornot, category){

    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    
    var searchResultPannel = content_xpath.searchResultPannel;
    browser.waitForVisible(searchResultPannel,this.waitDefault);

    var searchResult = content_xpath.searchResult.replace('__CATEGORY__',category).replace('__RESULTTEXT__', result);
    console.log(searchResult);
    var flag = browser.isVisible(searchResult,this.waitDefault);
    console.log(flag);

    if(displayornot == "displayed"){
      expect(flag).toBe(true);
    }
    else{
      browser.pause(3000);
      expect(flag).toBe(false);
    }
 });
}