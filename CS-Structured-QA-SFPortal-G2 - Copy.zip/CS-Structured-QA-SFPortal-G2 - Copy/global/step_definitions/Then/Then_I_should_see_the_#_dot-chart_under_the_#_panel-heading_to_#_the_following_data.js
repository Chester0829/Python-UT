// Recommended filename: Then_I_should_see_the_#_dot-chart_under_the_#_panel-heading_to_contain_the_following_data.js
module.exports = function() {
  this.Then(/^I should see the "([^"]*)" dot\-chart under the "([^"]*)" panel-heading to (contain|match) the following data$/,
  { timeout: process.env.StepTimeoutInMS*5}, 
  function (chartTitle, panelName, action, table) {
    // Write the automation code here
    //browser.pause(1000);
    const portfolioPage_xpath = this.xpath_lib.xpathRequire('portfolioPage_xpath');
    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    //this.browser_session.waitForRender(browser);
    var expected_row_list = table.hashes();
    
    const my_regex_lib = this.regex_lib;
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');

    var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase());
    if(panelName == 'Scenario Cashflows') { myPanel = ''; }
    var myChart = myPanel + content_xpath.namedPieChar.replace(/__NAME__/g, chartTitle);

    console.log(myChart);
    browser.getLocationInView(myChart);
    var myChart_title = myChart + content_xpath.chartTitle;
    var myChart_x_label = myChart + content_xpath.chartXLabel;
    var myChart_y_label = myChart + content_xpath.chartYLabel;
    var myChart_y_title = myChart + content_xpath.chartYTitle;
    var myChart_point = myChart + portfolioPage_xpath.chartPoint;

    var displayed_chart_text = browser.getText(myChart);
    var displayed_title_text;
    var displayed_x_label;
    var displayed_y_label;
    var displayed_y_title;
    var displayed_text;

    expect(displayed_chart_text.replace(/ /g,'')).toContain(chartTitle.replace(/ /g,''));
    expected_row_list.forEach(function(row) {
      switch(action) {
        case "contain":
          if (row['title']) {
            displayed_title_text = browser.getText(myChart_title).toString();
            expect(displayed_title_text).toContain(row['title']);
          };
          if (row['y_title']) {
            displayed_y_title = browser.getText(myChart_y_title).toString();
            expect(displayed_y_title).toContain(row['y_title']);
          };
          if (row['x_label']) {
            displayed_x_label = browser.getText(myChart_x_label).toString();
            expect(displayed_x_label.replace(/ /g,'')).toContain(row['x_label'].replace(/ /g,''));
          };
          if (row['y_label']) {
            displayed_y_label = browser.getText(myChart_y_label).toString();
            expect(displayed_y_label.replace(/ /g,'')).toContain(row['y_label'].replace(/ /g,''));
          };
          if (row['text'])
          {
            displayed_text = browser.getText(myChart).toString();
            expect(displayed_text).toContain(row['text']);
          };
          break;
        case "match":
          if (row['title']) {
              displayed_title_text = browser.getText(myChart_title).toString();
              expect(displayed_title_text).toMatch(my_regex_lib.replaceRegex(row['title']));
            };
            if (row['y_title']) {
              displayed_y_title = browser.getText(myChart_y_title).toString();
              expect(displayed_y_title).toMatch(my_regex_lib.replaceRegex(row['y_title']));
            };
            if (row['x_label']) {
              displayed_x_label = browser.getText(myChart_x_label).toString();
              expect(displayed_x_label.replace(/ /g,'')).toMatch(my_regex_lib.replaceRegex(row['x_label'].replace(/ /g,'')));
            };
            if (row['y_label']) {
              displayed_y_label = browser.getText(myChart_y_label).toString();
              expect(displayed_y_label.replace(/ /g,'')).toMatch(my_regex_lib.replaceRegex(row['y_label'].replace(/ /g,'')));
            };
            if (row['text'])
            {
              displayed_text = browser.getText(myChart).toString();
              expect(displayed_text).toMatch(row['text']);
            };
            break;
      }
    });
  });
}
