// Then_I_should_see_the_content_of_filename_#_should_be_match_the_#.js
// only for Export XLSX in CLO Deal Cashflow 
module.exports = function() {
  this.Then(/^I should see the content of (filename|upload file) "([^"]*)" should be match the "([^"]*)"$/, 
  {timeout: process.env.StepTimeoutInMS*5},  
  function (fileType,filename,matchType) {   
    this.browser_session.waitForResource(browser);
    // const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
    if(matchType != 'Mixed Portfolio UI'){
      if(fileType=='upload file'){
        console.log("------------For import file comparison-------------");
        console.log('this.uploadFilePath : '+this.uploadFilePath);
        var content = this.file_session.readXlsxAsCsvString(this.uploadFilePath,1);
      }else{
        console.log("------------For export file comparison-------------");
        var my_download_file = this.file_session.waitForDownload(browser,filename);
        console.log("--------my_download_file---------: "+my_download_file);
        // simple compare, according to the before setting step
        switch(matchType){
          case 'CLO UI':
            var content = this.file_session.readXlsxAsCsvString(my_download_file);
            break;
          case 'CMBS UI':
            var content = this.file_session.readXlsxAsCsvString(my_download_file,2);
            break;
          default: 
            var content = this.file_session.readXlsxAsCsvString(my_download_file,1);
            break;
        }
        expect(content).not.toContain('undefined');
        console.log(content);
      }
      // console.log(content);
      var tmp = content.split('\n');
      switch(matchType){
        case 'CLO Portfolio UI':
          var title = ',Run,Ticker,Deal,Class,cusip,isin,Vintage,Ratings,Legal Maturity,Tranche Type,DM (bps),Yield (%),Price,Benchmark,Buy Price,Buy Date,First Loss Threshold,Basic Assumptions,Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate (%),Loss Type,Loss Rate (non-performing) (%),RecLag (months),Reinvestment Assumptions,Reinvest Price,Reinvest Price Type,Reinvest Spread (%),Reinvest Term,Reinvest Pool,Reinvest Default Lockout (months),Intra/Post Reinvest Rules,Call Assumptions,Forced Call,Call Option,Call Date,(+/-) Months,Call Price Type,Call Price';
          break;
        case 'RMBS Portfolio UI':
          var title = ',Run,Ticker,Deal,Class,Cusip/Isin,Vintage,Ratings,Tranche Type,DM (bps),Yield (%),Price,Benchmark,Buy Price,Buy Date,First Loss Threshold,Solve For,Basic Assumptions,Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate (%),Loss Type,Rec Lag (months),Allocation (months),Advanced Assumptions,Delinquency Rate,Delinquency Type,Servicer Advance Basis,Servicer Advance Rate,Servicer Advance Type,Seeded Defaults,Loss Rate,Lag (months),Call Assumptions,Forced Call,Call Option,Call Date';
          break;
        case 'CLO UI':
          var title = ',Run,Deal,Vintage,Legal Maturity,Scenario,Settles Date,Calculate First Loss,Apply Stratification,Custom Rates,Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate,Loss Type,Loss Rate (non-performing),RecLag (Months),Reinvest Price,Reinvest Price Type,Reinvest Spread (%),Reinvest Term,Reinvest Pool,Reinvest Default Lockout (months),Intra/Post Reinvest Rules,Forced call,Call Option,Call Date,(+/-) Months,Call Price Type,Call Price';
          break;
        case 'ABS UI':
          var title = ',Run,Deal,Scenario,Settles Date,Calculate First Loss,Solve For,Forward Curve,Basic Assumptions,Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate (%),Loss Type,RecLag (months),Allocation (months),Call Assumptions,Forced Call,Call Option,Call Date';
          break;
        case 'AUTO UI':
          var title = ',Run,Deal,Scenario,Settles Date,Calculate First Loss,Solve For,Forward Curve,Basic Assumptions,Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate (%),Loss Type,RecLag (months),Allocation (months),Advanced Assumptions,Delinquency Rate,Delinquency Type,Seeded Defaults,Loss Rate,Lag (months),Call Assumptions,Forced Call,Call Option,Call Date';
          break;
        case 'CARDS UI':
          var title = ',Run,Deal,Scenario,Settles Date,Calculate First Loss,Solve For,Forward Curve,Basic Assumptions,Repayment Rate,Repayment Type,Purchase Rate,Purchase Type,Portfolio Yield Rate,Portfolio Yield Type,Charge-off,Charge-off Type,Call Assumptions,Forced Call,Call Option,Call Date';
          break;
        case 'SLABS UI':
          var title = ',Run,Deal,Scenario,Settles Date,Calculate First Loss,Solve For,Forward Curve,Basic Assumptions,Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate (%),Loss Type,RecLag (months),Allocation (months),Advanced Assumptions,Deferment Rate,Deferment Type,Grace Rate,Grace Type,Forbearance Rate,Forbearance Type,Ignore Input Non-Payment Term,Calculate Curve off of Static Starting Balance,Interest Capitalization Frequency,Subsidy Payment Delay,SAP Payment Delay,Use ACH Vector,ACH (0.25%),ACH Vector,Borrower Benefit Name,Call Assumptions,Forced Call,Call Option,Call Date';
          break;
        case 'RMBS UI':
          var title = ',Run,Deal,Scenario,Settles Date,Calculate First Loss,Solve For,Forward Curve,Basic Assumptions,Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate (%),Loss Type,Rec Lag (months),Allocation (months),Advanced Assumptions,Delinquency Rate,Delinquency Type,Servicer Advance Basis,Servicer Advance Rate,Servicer Advance Type,Seeded Defaults,Loss Rate,Lag (months),Call Assumptions,Forced Call,Call Option,Call Date';
          break;
        case 'CMBS UI':
          var title = ',Run,Deal,Scenario,Settles Date,Calculate First Loss,Solve For,Forward Curve,Basic Assumptions,Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate (%),Loss Type,RecLag (months),Allocation (months),Advanced Assumptions,NOI Growth Rate,NOI Growth Rate Type,Cap Rate Growth Rate,Cap Rate Growth Rate Type,Term Triggers,LTV Trigger,Activate LTV Term Trigger,LTV Trigger Liquidate (if greater than trigger input),LTV Trigger: Rec. Lag (months),LTV Trigger: Loss (%),DSCR Trigger,Activate DSCR Term Trigger,DSCR Trigger: Liquidate (if less than trigger input),DSCR Trigger: Rec. Lag (months),DSCR Trigger: Loss (%),Term Trigger to Prioritize if Simultaneous Breach,Maturity Trigger,LTV Trigger,Activate LTV Trigger at Maturity,LTV Trigger: Payoff (if less than trigger input),LTV Trigger: Liquidate (if greater than trigger input),LTV Trigger: Liquidation Loss (%),LTV Trigger: Extension (months) applicable if LTV falls between Liq. and Payoff trigger inputs,LTV Trigger: End of Ext. Liq. (if greater than or equal to trigger input) or Payoff (if less than trigger input),LTV Trigger: End of Extension Liquidation Loss (%),Debt Yield Trigger,Activate Debt Yield Trigger at Maturity,Debt Yield Trigger: Payoff (if greater than trigger input),Debt Yield Trigger: Liquidate (if less than trigger input),Debt Yield Trigger: Liquidation Loss (%),Debt Yield Trigger: Extension (months) applicable if Debt Yield falls between Liq. and Payoff trigger inputs,Debt Yield Trigger: End of Ext. Liq. (if less than or equal to trigger input) or Payoff (if greater than trigger input),Debt Yield Trigger: End of Extension Liquidation Loss (%),Maturity Trigger to Prioritize if Simultaneous Breach,Servicer Advance Basis,Servicer Advance Rate,Servicer Advance Type,Call Assumptions,Forced Call,Call Option,Call Date';
          break;
      }
      var titleIndex = tmp.indexOf(title);
      console.log(titleIndex);
      var data = tmp.slice(titleIndex);
      console.log('------data--------: '+data);
      var filejson = this.file_session.parseCSVStrtoJSON(data);
      console.log(filejson);
      var settingsDate = tmp.slice(0,titleIndex - 1).join();
      if(matchType == "ABS UI" ||matchType == "AUTO UI"||matchType == "CARDS UI"||matchType == "SLABS UI"||matchType == "RMBS UI"
        ||matchType == "CMBS UI"||(matchType == "CLO Portfolio UI" && fileType=='filename')||(matchType == "RMBS Portfolio UI" && fileType=='filename')){
        var content1 = this.file_session.readXlsxAsCsvString(my_download_file,0).split('\n');
        settingsDate = content1.slice(0,9).join();
      }
      // get from UI 
      if(fileType=='filename'){
        switch(matchType){
          case 'CLO Portfolio UI':
            var UItitle = 'Run,Deal,Cusip,Class,Vintage,Ratings,Legal Maturity,DM (bps),Yield (%),First Loss Threshold,Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate,Loss Type,Loss Rate (non-performing),RecLag (Months),Reinvest Price,Reinvest Price Type,Reinvest Spread (%),Reinvest Term,Reinvest Pool,Reinvest Default Lockout (months),Intra/Post Reinvest Rules,Forced Cal,Call Option,Call Date,(+/-) Months,Call Price Type,Call Price';
            var settingXpath = [
              {'type':'mdSelect','value':'cash.output_type'},
              {'type':'input','value':'cash.settles_date'},
              {'type':'mdSelect','value':'cash.cashflowOutputType'},
              {'type':'mdCheckbox','value':'cash.apply_watch'},
              {'type':'mdCheckbox','value':'cash.isCustomRates'},
             ];
            var settingTitle = ['Output Type','Settles Date','Cashflow Output','Apply Stratification','Custom Rates'];
            var uiSettingDisplay = this.browser_session.getCashflowUiValueList(browser,settingXpath,1,matchType)[0];
            break;
          case 'RMBS Portfolio UI':
            var UItitle = 'Run,Deal,Cusip,Class,Vintage,Ratings,Legal Maturity,Buy Price,Buy Date,Price,Benchmark,DM (bps),Yield (%),Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate,Loss Type,Loss Rate (non-performing),RecLag (Months),Reinvest Price,Reinvest Price Type,Reinvest Spread (%),Reinvest Term,Reinvest Pool,Reinvest Default Lockout (months),Intra/Post Reinvest Rules,Call Option,Call Date,Call Price Type,Call Price';
            var settingXpath = [
              {'type':'input','value':'cash.settles_date'},
              {'type':'mdSelect','value':'cash.output_type'},        
              {'type':'mdCheckbox','value':'cash.apply_watch'},
              {'type':'mdCheckbox','value':'cash.isCustomRates'},
             ];
            var settingTitle = ['Settles Date','Output Type','Apply Stratification','Custom Rates'];
            var uiSettingDisplay = this.browser_session.getCashflowUiValueList(browser,settingXpath,1,matchType)[0];
            break;
          case 'CLO UI':
            var settingXpath = [
              {'type':'fpSelect','value':'analyticsCtrl.outputType'},
              {'type':'fpSelect','value':'analyticsCtrl.scenarioMethod'},
              {'type':'fpSelect','value':'analyticsCtrl.scenarioInput'},
              {'type':'input','value':'analyticsCtrl.scenarioMidPoint'},
              {'type':'input','value':'analyticsCtrl.scenarioStepSize'},
             ];
            var settingTitle = ['Cashflow Output','Method','Input','Mid Point','Step Size (bps)'];
            var uiSettingDisplay = this.browser_session.getCashflowUiValueList(browser,settingXpath,1,matchType)[0];
            break;
          case 'ABS UI':
          case 'AUTO UI':
          case 'CARDS UI':
          case 'SLABS UI':
          case 'RMBS UI':
          case 'CMBS UI':
            var settingXpath = [
              {'type':'fpSelect','value':'analyticsCtrl.scenarioMethod'},
              {'type':'fpSelect','value':'analyticsCtrl.scenarioInput'},
              {'type':'input','value':'analyticsCtrl.scenarioMidPoint'},
              {'type':'input','value':'analyticsCtrl.scenarioStepSize'},
             ];
            var settingTitle = ['Method','Input','Mid Point','Step Size (bps)'];
            var uiSettingDisplay = this.browser_session.getCashflowUiValueList(browser,settingXpath,1,matchType)[0];
            break;
        }   
        console.log("-------uiSettingDisplay----------: "+uiSettingDisplay);
        // console.log('------------------');
        for(var j=0;j<uiSettingDisplay.length;j++){    
          if(settingTitle[j]=='Settles Date'){
              var forwardFormat=uiSettingDisplay[j];
              var formatMonth=('0'+(forwardFormat.split('/')[0])).slice(-2);
              var formatDate=('0'+(forwardFormat.split('/')[1])).slice(-2);
              uiSettingDisplay[j]='20'+forwardFormat.split('/')[2]+'-'+formatMonth+'-'+formatDate;
              console.log("-------uiSettingDisplay----------: "+uiSettingDisplay);
          }  
          if(settingTitle[j] == "Mid Point"){
            try{
              expect(settingsDate).toContain('Mid Point' + ',' + uiSettingDisplay[j]);
            }
            catch(error){
              expect(settingsDate).toContain('Mid point' + ',' + uiSettingDisplay[j]);
            }
          }
          else{
            expect(settingsDate).toContain(settingTitle[j] + ',' + uiSettingDisplay[j]);
          } 
        }
      }

      // get value from UI
      switch(matchType){
        case 'CLO Portfolio UI':
          var table_text = '//table/tbody//tr[@md-virtual-repeat]';
          var table_UI_All_Text = [];
          var xpathInfo = [
            {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
            {'title':'Deal','type':'deal','value':'2'},
            {'title':'Cusip','type':'cusip','value':'3'},
            {'title':'Class','type':'class','value':'4'},
            {'title':'Vintage','type':'vintage','value':'5'},
            {'title':'Ratings','type':'ratings','value':'6'},
            {'title':'Legal Maturity','type':'legal maturity','value':'7'},
            {'title':'DM (bps)','type':'input','value':'tranche.dm'},
            {'title':'Yield (%)','type':'input','value':'tranche.yield_pct'},
            {'title':'First Loss Threshold','type':'select','value':'tranche.first_loss_threshold'},
            {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
            {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
            // Need to add the following assumption back after the bug is fixed.
            // {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
            {'title':'Default Type','type':'select','value':'tranche.default_type'},
            {'title':'Loss Rate','type':'input','value':'tranche.loss_rate'},
            {'title':'Loss Type','type':'select','value':'tranche.loss_type'},
            {'title':'Loss Rate (non-performing)','type':'input','value':'tranche.prinLossSeverityPctNonPerf'},
            {'title':'RecLag (Months)','type':'input','value':'tranche.rec_lag'},
            {'title':'Reinvest Price','type':'input','value':'tranche.reinvest_price'},
            {'title':'Reinvest Price Type','type':'select','value':'tranche.reinvest_price_type'},
            {'title':'Reinvest Spread (%)','type':'input','value':'tranche.reinvest_spread'},
            {'title':'Reinvest Term','type':'input','value':'tranche.reinvest_term'},
            {'title':'Reinvest Pool','type':'select','value':'tranche.reinvest_pool'},
            {'title':'Reinvest Default Lockout (months)','type':'input','value':'tranche.reinvDefaultLockout'},
            {'title':'Intra/Post Reinvest Rules','type':'select','value':'tranche.reinvest_rules'},
            {'title':'Call Option','type':'select','value':'tranche.call_option'},
            {'title':'Call Date','type':'input','value':'tranche.call_date'},
            {'title':'Call Price Type','type':'select','value':'tranche.call_price_type'},
            {'title':'Call Price','type':'input','value':'tranche.call_price'}
          ];
          var xpathInfo1 = [
            {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
            {'title':'Deal','type':'deal','value':'2'},
            {'title':'Buy Price','type':'input','value':'tranche.buy_price'},
            {'title':'Buy Date','type':'input','value':'tranche.buy_date'},
            {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
            {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
            {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
            {'title':'Default Type','type':'select','value':'tranche.default_type'},
            {'title':'Loss Rate','type':'input','value':'tranche.loss_rate'},
            {'title':'Loss Type','type':'select','value':'tranche.loss_type'},
            {'title':'Loss Rate (non-performing)','type':'input','value':'tranche.prinLossSeverityPctNonPerf'},
            {'title':'RecLag (Months)','type':'input','value':'tranche.rec_lag'},
            {'title':'Reinvest Price','type':'input','value':'tranche.reinvest_price'},
            {'title':'Reinvest Price Type','type':'select','value':'tranche.reinvest_price_type'},
            {'title':'Reinvest Spread (%)','type':'input','value':'tranche.reinvest_spread'},
            {'title':'Reinvest Term','type':'input','value':'tranche.reinvest_term'},
            {'title':'Reinvest Pool','type':'select','value':'tranche.reinvest_pool'},
            {'title':'Reinvest Default Lockout (months)','type':'input','value':'tranche.reinvDefaultLockout'},
            {'title':'Intra/Post Reinvest Rules','type':'select','value':'tranche.reinvest_rules'},
            {'title':'Call Option','type':'select','value':'tranche.call_option'},
            {'title':'Call Date','type':'input','value':'tranche.call_date'},
            {'title':'Call Price Type','type':'select','value':'tranche.call_price_type'},
            {'title':'Call Price','type':'input','value':'tranche.call_price'}
          ];
          // var table_length = browser.elements(table_text).value.length;
          // console.log(table_length);
            ////////API to get dealist////////////////
          var searchInput = '//input[@ng-model="cash.trancheQueryString"]';
          var license = this.api_session.getLicense(this.test_user);
          var fxRates = this.api_session.getFxRates(license);
          var portfolio_id = this.api_session.getPortfolioInfo(this.portfolio, license).portfolioId;
          var dealList = this.api_session.getDealList(portfolio_id,license,fxRates);
          // console.log('dealList.deals:'+dealList.deals);
          if(fileType=='upload file'){
            var uiTextJson = this.browser_session.getCashflowPortfolioUiValueJson(browser,xpathInfo1,dealList);
          }
          else{
            var uiTextJson = this.browser_session.getCashflowPortfolioUiValueJson(browser,xpathInfo,dealList);
          }        
          //console.log(uiTextJson);
          console.log(uiTextJson.length);
          console.log('-----------------');
           if(fileType =='upload file'){
            for (var i = 0; i < uiTextJson.length; i++) {
              var findDeal = false ;
              for (var j = 0; j < filejson.length; j++) {
                if(uiTextJson[i]['Deal']==filejson[j]['Deal']){
                  findDeal = true;
                  for(var key in uiTextJson[i]){
                    console.log(uiTextJson[i][key]);
                    console.log(filejson[j][key]);
                  if (key == 'Call Option' && uiTextJson[i][key] == 'Clean-up Call' || filejson[i][key] == 'Clean Up'){
                    continue;
                  }
                  if (key == 'Call Price Type' && uiTextJson[i][key] == 'Mrkt Price' || filejson[i][key] == 'Market Value'){
                    continue;
                  }
                  if (key == 'Call Price Type' && uiTextJson[i][key] == 'Input' || filejson[i][key] == 'User Defined'){
                    continue;
                  }
                  if (key == 'Loss Rate'){
                    filejson[i][key] = filejson[i]['Loss Rate (%)'];
                  }
                  // Loss Rate (non-performing) vs. Loss Rate (non-performing) (%) 
                  if (key.indexOf("performing") > -1){              
                    filejson[i][key] = filejson[i]['Loss Rate (non-performing) (%)'];
                  } 
                  //Month vs. month
                  if (key.indexOf("RecLag") > -1){   
                    filejson[i][key] = filejson[i]['RecLag (months)'];
                  }       
                  if (uiTextJson[i][key]!='disabled') {
                    expect(uiTextJson[i][key]).toEqual(filejson[j][key]);
                 }
                }
               }
              }
              expect(findDeal).toBe(true);
            }
           }else{
            for (var i = 0; i < uiTextJson.length; i++) {
              for(var key in uiTextJson[i]){
                console.log(key);
                console.log(uiTextJson[i][key]);
                console.log("filejson");
                console.log(filejson[i][key]); 
                if (key == 'Cusip'){
                  continue;  
                  }
                if (key == 'Legal Maturity'){
                  var forwardFormat=uiTextJson[i][key];
                  var formatMonth=('0'+(forwardFormat.split('/')[0])).slice(-2);
                  var formatDate=('0'+(forwardFormat.split('/')[1])).slice(-2);
                  uiTextJson[i][key]='20'+forwardFormat.split('/')[2]+'-'+formatMonth+'-'+formatDate;
                } 
                // Loss Rate vs. Loss Rate (%)
                if (key == 'Loss Rate'){
                  filejson[i][key] = filejson[i]['Loss Rate (%)'];
                }
                // Loss Rate (non-performing) vs. Loss Rate (non-performing) (%) 
                if (key.indexOf("performing") > -1){              
                  filejson[i][key] = filejson[i]['Loss Rate (non-performing) (%)'];
                } 
                //Month vs. month
                if (key.indexOf("RecLag") > -1){   
                  filejson[i][key] = filejson[i]['RecLag (months)'];
                }         
                if (uiTextJson[i][key]!='disabled') {
                  expect(uiTextJson[i][key]).toEqual(filejson[i][key]);
                }
              }
            }
          }
          break;
        case 'RMBS Portfolio UI':
          var table_text = '//table/tbody//tr[@md-virtual-repeat]';
          var table_UI_All_Text = [];
          var xpathInfo = [
            {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
            {'title':'Deal','type':'deal','value':'2'},
            {'title':'Cusip','type':'cusip','value':'4'},
            {'title':'Class','type':'class','value':'3'},
            {'title':'Vintage','type':'vintage','value':'5'},
            {'title':'Ratings','type':'ratings','value':'6'},
            {'title':'Price','type':'input','value':'tranche.price'},
            {'title':'Benchmark','type':'select','value':'tranche.benchmark'},
            {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
            {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
            {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
            {'title':'Default Type','type':'select','value':'tranche.default_type'},
            {'title':'Loss Rate','type':'input','value':'tranche.loss_rate'},
            {'title':'Loss Type','type':'select','value':'tranche.loss_type'},          
            {'title':'Rec Lag (Months)','type':'input','value':'tranche.rec_lag'},
            {'title':'Allocation (Months)','type':'input','value':'tranche.alloc_mon'},
            {'title':'Delinquency Rate','type':'input','value':'tranche.delinquency_rate'},
            {'title':'Delinquency Type','type':'select','value':'tranche.delinquency_type'},
            {'title':'Servicer Advance Basis','type':'select','value':'tranche.servicer_basis'},
            {'title':'Servicer Advance Rate','type':'input','value':'tranche.servicer_rate'},
            {'title':'Servicer Advance Type','type':'select','value':'tranche.servicer_type'},
            {'title':'Seeded defaults','type':'checkbox','value':'tranche.seed_default'},
            {'title':'Loss Rate','type':'input','value':'tranche.adv_loss_rate'},
            {'title':'Lag (months)','type':'input','value':'tranche.adv_lag_mon'},
            {'title':'Forced Call','type':'select','value':'tranche.force_call'},          
            {'title':'Call Option','type':'select','value':'tranche.call_option'},
            {'title':'Call Date','type':'input','value':'tranche.call_date'}
          ];
          var xpathInfo1 = [
            {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
            {'title':'Deal','type':'deal','value':'2'},
            {'title':'Price','type':'input','value':'tranche.price'},
            {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
            {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
            {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
            {'title':'Default Type','type':'select','value':'tranche.default_type'},
            {'title':'Loss Rate','type':'input','value':'tranche.loss_rate'},
            {'title':'Loss Type','type':'select','value':'tranche.loss_type'},          
            {'title':'Rec Lag (Months)','type':'input','value':'tranche.rec_lag'},
            {'title':'Allocation (Months)','type':'input','value':'tranche.alloc_mon'},
            {'title':'Delinquency Rate','type':'input','value':'tranche.delinquency_rate'},
            {'title':'Delinquency Type','type':'select','value':'tranche.delinquency_type'},
            {'title':'Servicer Advance Basis','type':'select','value':'tranche.servicer_basis'},
            {'title':'Servicer Advance Rate','type':'input','value':'tranche.servicer_rate'},
            {'title':'Servicer Advance Type','type':'select','value':'tranche.servicer_type'},
            {'title':'Seeded defaults','type':'checkbox','value':'tranche.seed_default'},
            {'title':'Loss Rate','type':'input','value':'tranche.adv_loss_rate'},
            {'title':'Lag (months)','type':'input','value':'tranche.adv_lag_mon'},
            {'title':'Forced Call','type':'select','value':'tranche.force_call'},          
            {'title':'Call Option','type':'select','value':'tranche.call_option'},
            {'title':'Call Date','type':'input','value':'tranche.call_date'}
          ];
          // var table_length = browser.elements(table_text).value.length;
          // console.log(table_length);
            ////////API to get dealist////////////////
          var searchInput = '//input[@ng-model="cash.trancheQueryString"]';
          var license = this.api_session.getLicense(this.test_user);
          var fxRates = this.api_session.getFxRates(license);
          var portfolio_id = this.api_session.getPortfolioInfo(this.portfolio, license).portfolioId;
          var dealList = this.api_session.getDealList(portfolio_id,license,fxRates);
          console.log('dealList.deals:'+dealList.deals);
          if(fileType=='upload file'){
            var uiTextJson = this.browser_session.getCashflowPortfolioUiValueJson(browser,xpathInfo1,dealList);
          }
          else{
            var uiTextJson = this.browser_session.getCashflowPortfolioUiValueJson(browser,xpathInfo,dealList);
          }    
          console.log(uiTextJson);
          console.log(uiTextJson.length);
          console.log('-----------------');
           if(fileType =='upload file'){
            for (var i = 0; i < uiTextJson.length; i++) {
              var findDeal = false ;
              for (var j = 0; j < filejson.length; j++) {
                 if(uiTextJson[i]['Deal']==filejson[j]['Deal']){
                   findDeal = true;
                   for(var key in uiTextJson[i]){
                      console.log(uiTextJson[i][key]);
                      console.log(filejson[j][key]);
                      if (key == 'Call Option' && uiTextJson[i][key] == 'Clean-up Call' || filejson[i][key] == 'Clean Up'){
                        continue;
                      }
                      if (key == 'Loss Rate'){
                        filejson[i][key] = filejson[i]['Loss Rate (%)'];
                      }
                      if (uiTextJson[i][key]!='disabled') {
                        expect(uiTextJson[i][key]).toEqual(filejson[j][key]);
                     }
                 }
               }
              }
              expect(findDeal).toBe(true);
            }
           }else{
            for (var i = 0; i < uiTextJson.length; i++) {
              for(var key in uiTextJson[i]){
                console.log(key);
                console.log(uiTextJson[i][key]);
                console.log("filejson");
                console.log(filejson[i][key]); 
                if (key == 'Cusip'){
                  continue;  
                }
                if (key == 'Benchmark' && uiTextJson[i][key] == '3M' || filejson[i][key] == 'LIBOR 3M'){
                  continue;
                }
                // Loss Rate vs. Loss Rate (%)
                if (key == 'Loss Rate'){
                  filejson[i][key] = filejson[i]['Loss Rate (%)'];
                }
                // //Month vs. month
                // if (key.indexOf("RecLag") > -1){   
                //   filejson[i][key] = filejson[i]['RecLag (months)'];
                // }         
                if (uiTextJson[i][key]!='disabled') {
                  expect(uiTextJson[i][key]).toEqual(filejson[i][key]);
                }
              }
            }
          }
          break;
        case 'CLO UI':
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            {'type':'deal','value':'"Madison Park Funding XI,Ltd."'}, // Deal
            {'type':'Vintage','value':'2013'}, // Vintage
            {'type':'Legal Maturity','value':'7/23/29'}, // Legal Maturity
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'checkbox','value':'scen.apply_watch'}, // Apply Stratification
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.prepay_rate'}, // Prepay Rate
            {'type':'fpSelect','value':'scen.prepay_type'}, // Prepay Type
            {'type':'input','value':'scen.default_rate'}, // Default Rate 
            {'type':'fpSelect','value':'scen.default_type'}, // Default Type
            {'type':'input','value':'scen.loss_rate'}, // Loss Rate
            {'type':'fpSelect','value':'scen.loss_type'}, // Loss Type
            {'type':'input','value':'scen.prinLossSeverityPctNonPerf'}, // Loss Rate (non-performing)
            {'type':'input','value':'scen.rec_lag'}, // RecLag (Months)
            {'type':'input','value':'scen.reinvest_price'}, // Reinvest Price
            {'type':'fpSelect','value':'scen.reinvest_price_type'}, // Reinvest Price Type
            {'type':'input','value':'scen.reinvest_spread'}, // Reinvest Spread (%)
            {'type':'input','value':'scen.reinvest_term'}, // Reinvest Term
            {'type':'fpSelect','value':'scen.reinvest_pool'}, // Reinvest Pool
            {'type':'input','value':'scen.reinvDefaultLockout'}, // Reinvest Default Lockout (months)
            {'type':'fpSelect','value':'scen.reinvest_rules'}, // Intra/Post Reinvest Rules
            {'type':'fpSelect','value':'scen.force_call'},
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'}, // Call Date
            {'type':'input','value':'scen.plus_minus_months'},
            {'type':'fpSelect','value':'scen.call_price_type'}, // Call Price Type
            {'type':'input','value':'scen.call_price'}  // Call Price
          ];
          var uiDisplay = this.browser_session.getCashflowUiValueList(browser,xpathInfo,5,matchType);
          console.log('-----uiDisplay---------: '+uiDisplay);
          for(var i=0;i<uiDisplay.length;i++){
            var flag = false;
            var scenarioValue = uiDisplay[i];
            // can not get the background color in xlsx file.
            if(scenarioValue[4].indexOf('MA') != -1){
              flag = true;
              var uiScenarioData = (i+1) + ',' + scenarioValue.slice(0,6).join(',');
              var fileScenarioData = data[i+1];
            }else{
              scenarioValue.splice(0, 0, (i+1));
              console.log(scenarioValue);
              // find disabled in UI
              var disabledList = [];
              for(var j=0;j<scenarioValue.length;j++){
                if(scenarioValue[j] == 'disabled'){
                  disabledList.push(j);
                }
              }
              console.log(disabledList);
              // modify fileScenarioData in disabledList
              var fileList = data[i+1].split(',');
              for(var n=0;n < disabledList.length;n++){
                if(disabledList[n] >= 3){
                  fileList[disabledList[n] + 1 ] = '';
                }else{
                  fileList[disabledList[n] ] = '';
                }
              }
              // var uiScenarioData = (i+1) + ',' + scenarioValue.join(',');
              var uiScenarioData = scenarioValue.join(',');
              for(var i=0;i < fileList.length;i++){
                fileList[i]=fileList[i].trim();
              }
              var fileScenarioData = fileList.join(',');
            }
            if(flag){
              expect(fileScenarioData).toContain(uiScenarioData);
            }else{
              expect(fileScenarioData).toEqual(uiScenarioData.replace(/disabled/g,''));
            }
           
          }
          break;
        case 'ABS UI':
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            //{'type':'deal','value':'Dell Equipment Finance Trust 2016-1'}, // Deal
            {'type':'deal','value':this.deal},
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'fpSelect','value':'scen.solve_for'}, // 
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.prepay_rate'}, // Prepay Rate
            {'type':'fpSelect','value':'scen.prepay_type'}, // Prepay Type
            {'type':'input','value':'scen.default_rate'}, // Default Rate 
            {'type':'fpSelect','value':'scen.default_type'}, // Default Type
            {'type':'input','value':'scen.loss_rate'}, // Loss Rate
            {'type':'fpSelect','value':'scen.loss_type'}, // Loss Type
            {'type':'input','value':'scen.rec_lag'}, // RecLag (Months)
            {'type':'input','value':'scen.alloc_mon'}, // Allocation (months)
            {'type':'fpSelect','value':'scen.force_call'},  // Force Call
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'} // Call Date
          ];
          var uiDisplay = this.browser_session.getCashflowUiValueList(browser,xpathInfo);
          console.log('-----uiDisplay---------: '+uiDisplay);
          for(var i=0;i<uiDisplay.length;i++){
            var flag = false;
            var scenarioValue = uiDisplay[i];
            console.log(scenarioValue);
            // can not get the background color in xlsx file.
            if(scenarioValue[2].indexOf('MA') != -1){
              flag = true;
              var uiScenarioData = (i+1) + ',' + scenarioValue.slice(0,3).join(',');
              var fileScenarioData = data[i+1];
            }else{
              scenarioValue.splice(0, 0, (i+1));
              // find disabled in UI
              var disabledList = [];
              for(var j=0;j<scenarioValue.length;j++){
                if(scenarioValue[j] == 'disabled'){
                  disabledList.push(j);
                }
              }
              console.log(disabledList);
              var fileList = data[i+1].split(',');
              console.log(fileList);
              // modify fileScenarioData in disabledList 
              for(var n=0;n < disabledList.length;n++){
                if(disabledList[n] <= 6 || disabledList[n] >= 18){
                //   fileList[disabledList[n] + 1 ] = '';
                // }else{
                  fileList[disabledList[n]] = '';
                 } 
              }
              console.log(fileList);
              // var uiScenarioData = (i+1) + ',' + scenarioValue.join(',');
              var uiScenarioData = scenarioValue.join(',');
              var fileScenarioData1 = fileList.slice(0,8).join(',');
              var fileScenarioData2 = fileList.slice(9,17).join(',');
              var fileScenarioData3 = fileList.slice(18,21).join(',');
              var fileScenarioData = fileScenarioData1 + ',' + fileScenarioData2 + ',' + fileScenarioData3;
              console.log(fileScenarioData1);
              console.log(fileScenarioData2);
              console.log(fileScenarioData3);
              console.log(fileScenarioData);
              //var fileScenarioData = fileList.join(',');          
            }
            if(flag){
              expect(fileScenarioData).toContain(uiScenarioData);
            }else{
              expect(fileScenarioData).toEqual(uiScenarioData.replace(/disabled/g,''));
            }         
          }
          break;
        case 'AUTO UI':
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            //{'type':'deal','value':'Dell Equipment Finance Trust 2016-1'}, // Deal
            {'type':'deal','value':this.deal},
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'fpSelect','value':'scen.solve_for'}, // 
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.prepay_rate'}, // Prepay Rate
            {'type':'fpSelect','value':'scen.prepay_type'}, // Prepay Type
            {'type':'input','value':'scen.default_rate'}, // Default Rate 
            {'type':'fpSelect','value':'scen.default_type'}, // Default Type
            {'type':'input','value':'scen.loss_rate'}, // Loss Rate
            {'type':'fpSelect','value':'scen.loss_type'}, // Loss Type
            {'type':'input','value':'scen.rec_lag'}, // RecLag (Months)
            {'type':'input','value':'scen.alloc_mon'}, // Allocation (months)
            {'type':'input','value':'scen.delinquency_rate'},
            {'type':'fpSelect','value':'scen.delinquency_type'},
            {'type':'checkbox','value':'scen.seed_default'},
            {'type':'input','value':'scen.adv_loss_rate'},
            {'type':'input','value':'scen.adv_lag_mon'},
            {'type':'fpSelect','value':'scen.force_call'},  // Force Call
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'} // Call Date
          ];
          var uiDisplay = this.browser_session.getCashflowUiValueList(browser,xpathInfo);
          console.log('-----uiDisplay---------: '+uiDisplay);
          for(var i=0;i<uiDisplay.length;i++){
            var flag = false;
            var scenarioValue = uiDisplay[i];
            console.log(scenarioValue);
            // can not get the background color in xlsx file.
            if(scenarioValue[2].indexOf('MA') != -1){
              flag = true;
              var uiScenarioData = (i+1) + ',' + scenarioValue.slice(0,3).join(',');
              var fileScenarioData = data[i+1];
            }else{
              scenarioValue.splice(0, 0, (i+1));
              // find disabled in UI
              var disabledList = [];
              for(var j=0;j<scenarioValue.length;j++){
                if(scenarioValue[j] == 'disabled'){
                  disabledList.push(j);
                }
              }
              console.log(disabledList);
              var fileList = data[i+1].split(',');
              console.log(fileList);
              // modify fileScenarioData in disabledList 
              for(var n=0;n < disabledList.length;n++){
                if(disabledList[n] <= 6){
                  fileList[disabledList[n]] = '';
                }else if(disabledList[n] >= 16 && disabledList[n] <= 17){
                  fileList[disabledList[n]+2] = '';
                }else if(disabledList[n] >= 18 && disabledList[n] <= 20){
                  fileList[disabledList[n]+2] = '';
                }else{
                  fileList[disabledList[n]+3] = '';
                }
              }
              console.log(fileList);
              // var uiScenarioData = (i+1) + ',' + scenarioValue.join(',');
              var uiScenarioData = scenarioValue.join(',');
              var fileScenarioData1 = fileList.slice(0,8).join(',');
              var fileScenarioData2 = fileList.slice(9,17).join(',');
              var fileScenarioData3 = fileList.slice(18,23).join(',');
              var fileScenarioData4 = fileList.slice(24,27).join(',');
              var fileScenarioData = fileScenarioData1 + ',' + fileScenarioData2 + ',' + fileScenarioData3 + ',' + fileScenarioData4;
              console.log(fileScenarioData1);
              console.log(fileScenarioData2);
              console.log(fileScenarioData3);
              console.log(fileScenarioData4);
              console.log(fileScenarioData);
              //var fileScenarioData = fileList.join(',');          
            }
            if(flag){
              expect(fileScenarioData).toContain(uiScenarioData);
            }else{
              expect(fileScenarioData).toEqual(uiScenarioData.replace(/disabled/g,''));
            }         
          }
          break;
        case 'CARDS UI':
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            //{'type':'deal','value':'Dell Equipment Finance Trust 2016-1'}, // Deal
            {'type':'deal','value':'"American Express Credit Account Master Trust, Series 2017-2"'},
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'fpSelect','value':'scen.solve_for'}, // 
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.repay_rate'}, // Repayrepay Rate
            {'type':'fpSelect','value':'scen.repay_type'}, // Repayrepay Type
            {'type':'input','value':'scen.purchase_rate'}, // Purchase Rate Rate 
            {'type':'fpSelect','value':'scen.purchase_type'}, // Purchase Type
            {'type':'input','value':'scen.portfolio_yield_rate'}, // Portfolio Yield Rate Rate
            {'type':'fpSelect','value':'scen.portfolio_yield_type'}, // Portfolio Yield Type
            {'type':'input','value':'scen.portfolio_loss_rate'}, // Charge-off Rate
            {'type':'fpSelect','value':'scen.portfolio_loss_type'}, //Charge-off Type
            {'type':'fpSelect','value':'scen.force_call'},  // Force Call
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'}
          ];
          var uiDisplay = this.browser_session.getCashflowUiValueList(browser,xpathInfo);
          console.log('-----uiDisplay---------: '+uiDisplay);
          for(var i=0;i<uiDisplay.length;i++){
            var flag = false;
            var scenarioValue = uiDisplay[i];
            console.log(scenarioValue);
            // can not get the background color in xlsx file.
            if(scenarioValue[2].indexOf('MA') != -1){
              flag = true;
              var uiScenarioData = (i+1) + ',' + scenarioValue.slice(0,3).join(',');
              var fileScenarioData = data[i+1];
            }else{
              scenarioValue.splice(0, 0, (i+1));
              // find disabled in UI
              var disabledList = [];
              for(var j=0;j<scenarioValue.length;j++){
                if(scenarioValue[j] == 'disabled'){
                  disabledList.push(j);
                }
              }
              console.log(disabledList);
              var fileList = data[i+1].split(',');
              console.log(fileList);
              // modify fileScenarioData in disabledList 
              for(var n=0;n < disabledList.length;n++){
                if(disabledList[n] <= 6){
                  fileList[disabledList[n]+1] = '';
                }else if(disabledList[n] >= 16 && disabledList[n] <= 18){
                  fileList[disabledList[n]+3] = '';
                }
              }
              console.log(fileList);
              // var uiScenarioData = (i+1) + ',' + scenarioValue.join(',');
              var uiScenarioData = scenarioValue.join(',');
              var fileScenarioData1 = fileList.slice(0,9).join(',');
              var fileScenarioData2 = fileList.slice(10,18).join(',');
              var fileScenarioData3 = fileList.slice(19,22).join(',');
              var fileScenarioData = fileScenarioData1 + ',' + fileScenarioData2 + ',' + fileScenarioData3;
              console.log(fileScenarioData1);
              console.log(fileScenarioData2);
              console.log(fileScenarioData3);
              console.log(fileScenarioData);
              //var fileScenarioData = fileList.join(',');          
            }
            if(flag){
              expect(fileScenarioData).toContain(uiScenarioData);
            }else{
              expect(fileScenarioData).toEqual(uiScenarioData.replace(/disabled/g,''));
            }         
          }
          break;
        case 'SLABS UI':
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            //{'type':'deal','value':'Dell Equipment Finance Trust 2016-1'}, // Deal
            {'type':'deal','value':this.deal},
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'fpSelect','value':'scen.solve_for'}, // 
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.prepay_rate'}, // Prepay Rate
            {'type':'fpSelect','value':'scen.prepay_type'}, // Prepay Type
            {'type':'input','value':'scen.default_rate'}, // Default Rate 
            {'type':'fpSelect','value':'scen.default_type'}, // Default Type
            {'type':'input','value':'scen.loss_rate'}, // Loss Rate
            {'type':'fpSelect','value':'scen.loss_type'}, // Loss Type
            {'type':'input','value':'scen.rec_lag'}, // RecLag (Months)
            {'type':'input','value':'scen.alloc_mon'}, // Allocation (months)
            {'type':'input','value':'scen.deferment_rate'},
            {'type':'fpSelect','value':'scen.deferment_type'},
            {'type':'input','value':'scen.grace_rate'},
            {'type':'fpSelect','value':'scen.grace_type'},
            {'type':'input','value':'scen.forbear_rate'},
            {'type':'fpSelect','value':'scen.forbear_type'},
            {'type':'checkbox','value':'scen.ignore_input_nonpayment_term'},
            {'type':'checkbox','value':'scen.calc_curve_off_static_bal'},
            {'type':'fpSelect','value':'scen.interest_cap_freq'},
            {'type':'input','value':'scen.subsidy_payment_delay'},
            {'type':'input','value':'scen.SAP_payment_delay'},
            {'type':'checkbox','value':'scen.useACHVector'},
            //{'type':'fpSelect','value':'scen.scen.BB_type'},
            {'type':'input','value':'scen.BB_utilization_rate'},
            {'type':'fpSelect','value':'scen.force_call'},  // Force Call
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'} // Call Date
          ];
          var uiDisplay = this.browser_session.getCashflowUiValueList(browser,xpathInfo);
          console.log('-----uiDisplay---------: '+uiDisplay);
          for(var i=0;i<uiDisplay.length;i++){
            var flag = false;
            var scenarioValue = uiDisplay[i];
            console.log(scenarioValue);
            // can not get the background color in xlsx file.
            if(scenarioValue[2].indexOf('MA') != -1){
              flag = true;
              var uiScenarioData = (i+1) + ',' + scenarioValue.slice(0,3).join(',');
              var fileScenarioData = data[i+1];
            }else{
              scenarioValue.splice(0, 0, (i+1));
              // find disabled in UI
              var disabledList = [];
              for(var j=0;j<scenarioValue.length;j++){
                if(scenarioValue[j] == 'disabled'){
                  disabledList.push(j);
                }
              }
              console.log(disabledList);
              var fileList = data[i+1].split(',');
              console.log(fileList);
              // modify fileScenarioData in disabledList 
              for(var n=0;n < disabledList.length;n++){
                if(disabledList[n] <= 6){
                  fileList[disabledList[n]] = '';
                }
                else if(disabledList[n] == 23){
                  fileList[disabledList[n]+2] = '';
                }
                else if(disabledList[n] >= 24){
                  fileList[disabledList[n]+3] = '';
                }
                // else{
                //   fileList[disabledList[n]+3] = '';
                // }
              }
              console.log(fileList);
              // var uiScenarioData = (i+1) + ',' + scenarioValue.join(',');
              var uiScenarioData = scenarioValue.join(',');
              var fileScenarioData1 = fileList.slice(0,8).join(',');
              var fileScenarioData2 = fileList.slice(9,17).join(',');
              var fileScenarioData3 = fileList.slice(18,31).join(',');
              var fileScenarioData4 = fileList.slice(34,37).join(',');
              var fileScenarioData = fileScenarioData1 + ',' + fileScenarioData2 + ',' + fileScenarioData3 + ',' + fileScenarioData4;
              console.log(fileScenarioData1);
              console.log(fileScenarioData2);
              console.log(fileScenarioData3);
              console.log(fileScenarioData4);
              console.log(fileScenarioData);
              //var fileScenarioData = fileList.join(',');          
            }
            if(flag){
              expect(fileScenarioData).toContain(uiScenarioData);
            }else{
              expect(fileScenarioData).toEqual(uiScenarioData.replace(/disabled/g,''));
            }         
          }
          break;
        case 'RMBS UI':
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            //{'type':'deal','value':'Dell Equipment Finance Trust 2016-1'}, // Deal
            {'type':'deal','value':'"Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1"'},
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'fpSelect','value':'scen.solve_for'}, // 
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.prepay_rate'}, // Prepay Rate
            {'type':'fpSelect','value':'scen.prepay_type'}, // Prepay Type
            {'type':'input','value':'scen.default_rate'}, // Default Rate 
            {'type':'fpSelect','value':'scen.default_type'}, // Default Type
            {'type':'input','value':'scen.loss_rate'}, // Loss Rate
            {'type':'fpSelect','value':'scen.loss_type'}, // Loss Type
            {'type':'input','value':'scen.rec_lag'}, // RecLag (Months)
            {'type':'input','value':'scen.alloc_mon'}, // Allocation (months)
            {'type':'input','value':'scen.delinquency_rate'},
            {'type':'fpSelect','value':'scen.delinquency_type'},
            {'type':'fpSelect','value':'scen.servicer_basis'},
            {'type':'input','value':'scen.servicer_rate'},
            {'type':'fpSelect','value':'scen.servicer_type'},
            {'type':'checkbox','value':'scen.seed_default'},
            {'type':'input','value':'scen.adv_loss_rate'},
            {'type':'input','value':'scen.adv_lag_mon'},
            {'type':'fpSelect','value':'scen.force_call'},  // Force Call
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'} // Call Date
          ];
          var uiDisplay = this.browser_session.getCashflowUiValueList(browser,xpathInfo);
          console.log('-----uiDisplay---------: '+uiDisplay);
          for(var i=0;i<uiDisplay.length;i++){
            var flag = false;
            var scenarioValue = uiDisplay[i];
            console.log(scenarioValue);
            // can not get the background color in xlsx file.
            if(scenarioValue[2].indexOf('MA') != -1){
              flag = true;
              var uiScenarioData = (i+1) + ',' + scenarioValue.slice(0,3).join(',');
              var fileScenarioData = data[i+1];
            }else{
              scenarioValue.splice(0, 0, (i+1));
              // find disabled in UI
              var disabledList = [];
              for(var j=0;j<scenarioValue.length;j++){
                if(scenarioValue[j] == 'disabled'){
                  disabledList.push(j);
                }
              }
              console.log(disabledList);
              var fileList = data[i+1].split(',');
              console.log(fileList);
              // modify fileScenarioData in disabledList 
              for(var n=0;n < disabledList.length;n++){
                if(disabledList[n] <= 6){
                  fileList[disabledList[n]+1] = '';
                }else if(disabledList[n] >= 19 && disabledList[n] <= 23){
                  fileList[disabledList[n]+3] = '';
                }
                else if(disabledList[n] >= 24){
                  fileList[disabledList[n]+4] = '';
                }
                //else{
                //   fileList[disabledList[n]+3] = '';
                // }
              }
              console.log(fileList);
              // var uiScenarioData = (i+1) + ',' + scenarioValue.join(',');
              var uiScenarioData = scenarioValue.join(',');
              var fileScenarioData1 = fileList.slice(0,9).join(',');
              var fileScenarioData2 = fileList.slice(10,18).join(',');
              var fileScenarioData3 = fileList.slice(19,27).join(',');
              var fileScenarioData4 = fileList.slice(28,31).join(',');
              var fileScenarioData = fileScenarioData1 + ',' + fileScenarioData2 + ',' + fileScenarioData3 + ',' + fileScenarioData4;
              console.log(fileScenarioData1);
              console.log(fileScenarioData2);
              console.log(fileScenarioData3);
              console.log(fileScenarioData4);
              console.log(fileScenarioData);
              //var fileScenarioData = fileList.join(',');          
            }
            if(flag){
              expect(fileScenarioData).toContain(uiScenarioData);
            }else{
              expect(fileScenarioData).toEqual(uiScenarioData.replace(/disabled/g,''));
            }         
          }
          break;
        case 'CMBS UI':
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            //{'type':'deal','value':'Dell Equipment Finance Trust 2016-1'}, // Deal
            {'type':'deal','value':this.deal},
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'fpSelect','value':'scen.solve_for'}, // 
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.prepay_rate'}, // Prepay Rate
            {'type':'fpSelect','value':'scen.prepay_type'}, // Prepay Type
            {'type':'input','value':'scen.default_rate'}, // Default Rate 
            {'type':'fpSelect','value':'scen.default_type'}, // Default Type
            {'type':'input','value':'scen.loss_rate'}, // Loss Rate
            {'type':'fpSelect','value':'scen.loss_type'}, // Loss Type
            {'type':'input','value':'scen.rec_lag'}, // RecLag (Months)
            {'type':'input','value':'scen.alloc_mon'}, // Allocation (months)
            {'type':'input','value':'scen.NOI_growth_rate'},
            {'type':'fpSelect','value':'scen.NOI_growth_rate_type'},
            {'type':'input','value':'scen.cap_rate_growth_rate'},
            {'type':'fpSelect','value':'scen.cap_rate_growth_rate_type'},
            {'type':'checkbox','value':'scen.term_triggers_activate_LTV_trigger'},
            {'type':'input','value':'scen.term_triggers_LTV_liquidate'},
            {'type':'input','value':'scen.term_triggers_LTV_months'},
            {'type':'input','value':'scen.term_triggers_LTV_loss'},
            {'type':'checkbox','value':'scen.term_triggers_activate_DSCR_trigger'},
            {'type':'input','value':'scen.term_triggers_DSCR_liquidate'},
            {'type':'input','value':'scen.term_triggers_DSCR_months'},
            {'type':'input','value':'scen.term_triggers_DSCR_loss'},
            {'type':'fpSelect','value':'scen.term_triggers_select_priority'},
            {'type':'checkbox','value':'scen.maturity_trigger_activate_LTV_trigger'},
            {'type':'input','value':'scen.maturity_trigger_LTV_payoff'},
            {'type':'input','value':'scen.maturity_trigger_LTV_liquidate'},
            {'type':'input','value':'scen.maturity_trigger_LTV_loss'},
            {'type':'input','value':'scen.maturity_trigger_LTV_extension'},
            {'type':'input','value':'scen.maturity_trigger_LTV_end_of_extension_liq_or_payoff'},
            {'type':'input','value':'scen.maturity_trigger_LTV_end_of_extension_loss'},
            {'type':'checkbox','value':'scen.maturity_trigger_activate_DY_trigger'},
            {'type':'input','value':'scen.maturity_trigger_DY_payoff'},
            {'type':'input','value':'scen.maturity_trigger_DY_liquidate'},
            {'type':'input','value':'scen.maturity_trigger_DY_loss'},
            {'type':'input','value':'scen.maturity_trigger_DY_extension'},
            {'type':'input','value':'scen.maturity_trigger_DY_end_of_extension_liq_or_payoff'},
            {'type':'input','value':'scen.maturity_trigger_DY_end_of_extension_loss'},
            {'type':'fpSelect','value':'scen.maturity_trigger_select_priority'},
            {'type':'fpSelect','value':'scen.servicer_basis'},
            {'type':'input','value':'scen.servicer_rate'},
            {'type':'fpSelect','value':'scen.servicer_type'},
            {'type':'checkbox','value':'scen.apply_loan_level_assumps'},
            {'type':'fpSelect','value':'scen.force_call'},  // Force Call
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'} // Call Date          
          ];
          var uiDisplay = this.browser_session.getCashflowUiValueList(browser,xpathInfo);
          console.log('-----uiDisplay---------: '+uiDisplay);
          for(var i=0;i<uiDisplay.length;i++){
            var flag = false;
            var scenarioValue = uiDisplay[i];
            console.log(scenarioValue);
            // can not get the background color in xlsx file.
            if(scenarioValue[2].indexOf('MA') != -1){
              flag = true;
              var uiScenarioData = (i+1) + ',' + scenarioValue.slice(0,3).join(',');
              var fileScenarioData = data[i+1];
            }else{
              scenarioValue.splice(0, 0, (i+1));
              // find disabled in UI
              var disabledList = [];
              for(var j=0;j<scenarioValue.length;j++){
                if(scenarioValue[j] == 'disabled'){
                  disabledList.push(j);
                }
              }
              console.log(disabledList);
              var fileList = data[i+1].split(',');
              console.log(fileList);
              // modify fileScenarioData in disabledList 
              for(var n=0;n < disabledList.length;n++){
                if(disabledList[n] >= 45){
                  fileList[disabledList[n]+8] = '';
                }else{
                  fileList[disabledList[n]] = '';
                }
              }
              
              console.log(fileList);
              fileList[55] = scenarioValue[47];
              // var uiScenarioData = (i+1) + ',' + scenarioValue.join(',');
              var uiScenarioData = scenarioValue.join(',');
              var fileScenarioData1 = fileList.slice(0,8).join(',');
              var fileScenarioData2 = fileList.slice(9,17).join(',');
              var fileScenarioData3 = fileList.slice(18,22).join(',');
              var fileScenarioData4 = fileList.slice(24,28).join(',');
              var fileScenarioData5 = fileList.slice(29,34).join(',');
              var fileScenarioData6 = fileList.slice(36,43).join(',');
              var fileScenarioData7 = fileList.slice(44,59).join(',');
              var fileScenarioData = fileScenarioData1 + ',' + fileScenarioData2 + ',' + fileScenarioData3 + ',' + fileScenarioData4 + ',' + fileScenarioData5 + ',' + fileScenarioData6 + ',' + fileScenarioData7;
              console.log(fileScenarioData1);
              console.log(fileScenarioData2);
              console.log(fileScenarioData3);
              console.log(fileScenarioData4);
              console.log(fileScenarioData5);
              console.log(fileScenarioData6);
              console.log(fileScenarioData7);
              console.log(fileScenarioData);
              //var fileScenarioData = fileList.join(',');          
            }
            if(flag){
              expect(fileScenarioData).toContain(uiScenarioData);
            }else{
              expect(fileScenarioData).toEqual(uiScenarioData.replace(/disabled/g,''));
            }         
          }
          break;
      }
    }else{
      console.log("------------For Mixed Portfolio-------------");
      var content = [];
      var tmp = [];
      var title = [];
      //CMBS
      title[7] = ',Run,Ticker,Deal,Class,Cusip/Isin,Vintage,Ratings,Tranche Type,DM (bps),Yield (%),Price,Benchmark,Buy Price,Buy Date,First Loss Threshold,Solve For,Basic Assumptions,Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate (%),Loss Type,RecLag (months),Allocation (months),Advanced Assumptions,NOI Growth Rate,NOI Growth Rate Type,Cap Rate Growth Rate,Cap Rate Growth Rate Type,Term Triggers,LTV Trigger,Activate LTV Term Trigger,LTV Term Trigger: If LTV Exceeds Percentage then Liquidate,LTV Trigger: Recovery Lag (months),LTV Term Trigger: Loss (%),DSCR Trigger,Activate DSCR Term Trigger,Trigger: If DSCR falls below (x.xx),Trigger: Recovery Lag (months),DSCR Trigger: Loss (%),Trigger to Prioritize if Simultaneous Breach,Maturity Trigger,LTV Trigger,Activate LTV Trigger at Maturity,LTV Trigger: Payoff if less than trigger input (%),LTV Trigger: Liquidate if greater than trigger input (%),LTV at Maturity Trigger: Loss (%) If Loan is Liquidated,LTV at Maturity Trigger: Extension period if LTV is between payoff and liquidation trigger levels,"LTV at Maturity Trigger: End of Extension Liquidate if LTV is greater than or equal to (%), or payoff if less than",LTV at Maturity Trigger: End of Extension Loss (%) if Loan is Liquidated,Debt Yield Trigger,Activate Debt Yield at Maturity Trigger,Debt Yield at Maturity Trigger: Payoff if DY greater than (%),Debt Yield at Maturity Trigger: Liquidation if DY is less than (%),Debt Yield Maturity Trigger: Loss (%) if Loan is liquidated,Debt Yield at Maturity Trigger: Extension (Recovery Lag in Months) if DY is between payoff and liquidation trigger levels,"Debt Yield at Maturity Trigger: End of Extension Liquidate if DY is less then or equal to (%), or payoff if greater than",Debt Yield at Maturity Trigger: End of Extension Loss (%) if Loan is Liquidated,Maturity Trigger to Prioritize if Simultaneous Breach,Servicer Advance Basis,Servicer Advance Rate,Servicer Advance Type,Call Assumptions,Forced Call,Call Option,Call Date';
      //SLABS
      title[1] = ',Run,Ticker,Deal,Class,Cusip/Isin,Vintage,Ratings,Tranche Type,DM (bps),Yield (%),Price,Benchmark,Buy Price,Buy Date,First Loss Threshold,Solve For,Basic Assumptions,Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate (%),Loss Type,RecLag (months),Allocation (months),Advanced Assumptions,Deferment Rate,Deferment Type,Grace Rate,Grace Type,Forbearance Rate,Forbearance Type,Ignore Input Non-Payment Term,Calculate Curve off of Static Starting Balance,Interest Capitalization Frequency,Subsidy Payment Delay,SAP Payment Delay,Use ACH Vector,ACH (0.25%),ACH Vector,Borrower Benefit Name,Call Assumptions,Forced Call,Call Option,Call Date';
      //RMBS
      title[4] = ',Run,Ticker,Deal,Class,Cusip/Isin,Vintage,Ratings,Tranche Type,DM (bps),Yield (%),Price,Benchmark,Buy Price,Buy Date,First Loss Threshold,Solve For,Basic Assumptions,Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate (%),Loss Type,Rec Lag (months),Allocation (months),Advanced Assumptions,Delinquency Rate,Delinquency Type,Servicer Advance Basis,Servicer Advance Rate,Servicer Advance Type,Seeded Defaults,Loss Rate,Lag (months),Call Assumptions,Forced Call,Call Option,Call Date';
      //ABS
      title[5] = ',Run,Ticker,Deal,Class,Cusip/Isin,Vintage,Ratings,Tranche Type,DM (bps),Yield (%),Price,Benchmark,Buy Price,Buy Date,First Loss Threshold,Solve For,Basic Assumptions,Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate (%),Loss Type,RecLag (months),Allocation (months),Call Assumptions,Forced Call,Call Option,Call Date';        
      //CARDS
      title[6] = ',Run,Ticker,Deal,Class,Cusip/Isin,Vintage,Ratings,Tranche Type,DM (bps),Yield (%),Price,Benchmark,Buy Price,Buy Date,First Loss Threshold,Solve For,Basic Assumptions,Repayment Rate,Repayment Type,Purchase Rate,Purchase Type,Portfolio Yield Rate,Portfolio Yield Type,Charge-off,Charge-off Type,Call Assumptions,Forced Call,Call Option,Call Date';
      //CDO
      title[3] = ',Run,Ticker,Deal,Class,cusip,isin,Vintage,Ratings,Legal Maturity,Tranche Type,DM (bps),Yield (%),Price,Benchmark,Buy Price,Buy Date,First Loss Threshold,Basic Assumptions,Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate (%),Loss Type,Loss Rate (non-performing) (%),RecLag (months),Reinvestment Assumptions,Reinvest Price,Reinvest Price Type,Reinvest Spread (%),Reinvest Term,Reinvest Pool,Reinvest Default Lockout (months),Intra/Post Reinvest Rules,Call Assumptions,Forced Call,Call Option,Call Date,(+/-) Months,Call Price Type,Call Price';
      //AUTO
      title[2] = ',Run,Ticker,Deal,Class,Cusip/Isin,Vintage,Ratings,Tranche Type,DM (bps),Yield (%),Price,Benchmark,Buy Price,Buy Date,First Loss Threshold,Solve For,Basic Assumptions,Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate (%),Loss Type,RecLag (months),Allocation (months),Advanced Assumptions,Delinquency Rate,Delinquency Type,Seeded Defaults,Loss Rate,Lag (months),Call Assumptions,Forced Call,Call Option,Call Date';       
      var titleIndex = [];
      var data = [];
      var filejson = [];
      var deal
      if(fileType=='upload file'){
        console.log("------------For import file comparison-------------");
        console.log('this.uploadFilePath : '+this.uploadFilePath);
        //var content = this.file_session.readXlsxAsCsvString(this.uploadFilePath,1);
        for(var i=1; i<8; i++){
          content[i] = this.file_session.readXlsxAsCsvString(this.uploadFilePath,i);
          expect(content[i]).not.toContain('undefined');
          console.log(content[i]);
          tmp[i] = content[i].split('\n');
          titleIndex[i] = tmp[i].indexOf(title[i]);
          data[i] = tmp[i].slice(titleIndex[i]);
          console.log(data[i]);
          filejson[i] = this.file_session.parseCSVStrtoJSON(data[i]);
          console.log(filejson[i]);
        }
      }else{
        console.log("------------For export file comparison-------------");          
        var my_download_file = this.file_session.waitForDownload(browser,filename);
        console.log("--------my_download_file---------: "+my_download_file);          
        for(var i=1; i<8; i++){
          content[i] = this.file_session.readXlsxAsCsvString(my_download_file,i);
          expect(content[i]).not.toContain('undefined');
          console.log(content[i]);
          tmp[i] = content[i].split('\n');
          titleIndex[i] = tmp[i].indexOf(title[i]);
          data[i] = tmp[i].slice(titleIndex[i]);
          console.log(data[i]);
          filejson[i] = this.file_session.parseCSVStrtoJSON(data[i]);
          console.log(filejson[i]);
        }
        var settingsDate = tmp.slice(0,titleIndex - 1).join();

        var content1 = this.file_session.readXlsxAsCsvString(my_download_file,0).split('\n');
        settingsDate = content1.slice(0,7).join();

        var UItitle = 'Run,Deal,Cusip,Class,Vintage,Ratings,Legal Maturity,Buy Price,Buy Date,Price,Benchmark,DM (bps),Yield (%),Prepay Rate,Prepay Type,Default Rate,Default Type,Loss Rate,Loss Type,Loss Rate (non-performing),RecLag (Months),Reinvest Price,Reinvest Price Type,Reinvest Spread (%),Reinvest Term,Reinvest Pool,Reinvest Default Lockout (months),Intra/Post Reinvest Rules,Call Option,Call Date,Call Price Type,Call Price';
        var settingXpath = [
          {'type':'input','value':'cash.settles_date'},
          {'type':'mdSelect','value':'cash.output_type'},        
          {'type':'mdCheckbox','value':'cash.apply_watch'},
          {'type':'mdCheckbox','value':'cash.isCustomRates'},
         ];
        var settingTitle = ['Settles Date','Output Type','Apply Stratification','Custom Rates'];
        var uiSettingDisplay = this.browser_session.getCashflowUiValueList(browser,settingXpath,1,matchType)[0];
        console.log("-------uiSettingDisplay----------: "+uiSettingDisplay);
        // console.log('------------------');
        for(var j=0;j<uiSettingDisplay.length;j++){    
          if(settingTitle[j]=='Settles Date'){
              var forwardFormat=uiSettingDisplay[j];
              var formatMonth=('0'+(forwardFormat.split('/')[0])).slice(-2);
              var formatDate=('0'+(forwardFormat.split('/')[1])).slice(-2);
              uiSettingDisplay[j]='20'+forwardFormat.split('/')[2]+'-'+formatMonth+'-'+formatDate;
              console.log("-------uiSettingDisplay----------: "+uiSettingDisplay);
          }  
          expect(settingsDate).toContain(settingTitle[j] + ',' + uiSettingDisplay[j]);
        }
      }       
      console.log("----------------------------CompareUI--------------------------------")
      var table_text = '//table/tbody//tr[@md-virtual-repeat]';
      var table_UI_All_Text = [];
      var xpathInfo = [];
      xpathInfo[7] = [//CMBS
        {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
        {'title':'Deal','type':'deal','value':'2'},
        {'title':'Cusip','type':'cusip','value':'4'},
        {'title':'Class','type':'class','value':'3'},
        {'title':'Vintage','type':'vintage','value':'5'},
        {'title':'Ratings','type':'ratings','value':'6'},
        {'title':'DM (bps)','type':'input','value':'tranche.dm'},
        {'title':'Yield (%)','type':'input','value':'tranche.yield_pct'},
        {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
        {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
        {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
        {'title':'Default Type','type':'select','value':'tranche.default_type'},
        {'title':'Loss Rate','type':'input','value':'tranche.loss_rate'},
        {'title':'Loss Type','type':'select','value':'tranche.loss_type'},
        {'title':'Rec Lag (Months)','type':'input','value':'tranche.rec_lag'},
        {'title':'Allocation (Months)','type':'input','value':'tranche.alloc_mon'},
        {'title':'NOI Growth Rate Type','type':'select','value':'tranche.NOI_growth_rate_type'},
        {'title':'Annual NOI Growth Rate','type':'input','value':'tranche.NOI_growth_rate'},
        {'title':'Cap Rate Growth Rate Type','type':'select','value':'tranche.cap_rate_growth_rate_type'},
        {'title':'Annual Cap Rate Growth Rate','type':'input','value':'tranche.cap_rate_growth_rate'},
        {'title':'Activate LTV Term Trigger','type':'checkbox','value':'tranche.term_triggers_activate_LTV_trigger'},
        {'title':'LTV Term Trigger: If LTV Exceeds Percentage then Liquidate','type':'input','value':'tranche.term_triggers_LTV_liquidate'},
        {'title':'LTV Term Trigger: Recovery Lag (months)','type':'input','value':'tranche.term_triggers_LTV_months'},
        {'title':'LTV Term Trigger: Loss (%)','type':'input','value':'tranche.term_triggers_LTV_loss'},
        {'title':'Activate DSCR Term Trigger','type':'checkbox','value':'tranche.term_triggers_activate_DSCR_trigger'},
        {'title':'DSCR Term Trigger: If DSCR falls below (x.xx)','type':'input','value':'tranche.term_triggers_DSCR_liquidate'},
        {'title':'DSCR Term Trigger: Recovery Lag (months)','type':'input','value':'tranche.term_triggers_DSCR_months'},
        {'title':'DSCR Term Trigger Loss (%)','type':'input','value':'tranche.term_triggers_DSCR_loss'},
        {'title':'Term Trigger to Prioritize if Simultaneous Breach','type':'select','value':'tranche.term_triggers_select_priority'},
        {'title':'Activate LTV at Maturity Trigger','type':'checkbox','value':'tranche.maturity_trigger_activate_LTV_trigger'},
        {'title':'LTV at Maturity Trigger: Payoff if LTV is less than (%)','type':'input','value':'tranche.maturity_trigger_LTV_payoff'},
        {'title':'LTV at Maturity Trigger: Liquidate if LTV is greater than (%)','type':'input','value':'tranche.maturity_trigger_LTV_liquidate'},
        {'title':'LTV at Maturity Trigger: Loss (%) If Loan is Liquidated','type':'input','value':'tranche.maturity_trigger_LTV_loss'},
        {'title':'LTV at Maturity Trigger: Extension period if LTV is between payoff and liquidation trigger levels','type':'input','value':'tranche.maturity_trigger_LTV_extension'},
        {'title':'LTV at Maturity Trigger: End of Extension Liquidate if LTV is greater than or equal to (%), or payoff if less than','type':'input','value':'tranche.maturity_trigger_LTV_end_of_extension_liq_or_payoff'},
        {'title':'LTV at Maturity Trigger: End of Extension Loss (%) if loan is liquidated','type':'input','value':'tranche.maturity_trigger_LTV_end_of_extension_loss'},
        {'title':'Activate Debt Yield at Maturity Trigger','type':'checkbox','value':'tranche.maturity_trigger_activate_DY_trigger'},
        {'title':'Debt Yield at Maturity Trigger: Payoff if DY greater than (%)','type':'input','value':'tranche.maturity_trigger_DY_payoff'},
        {'title':'Debt Yield at Maturity Trigger: Liquidation if DY is less than (%)','type':'input','value':'tranche.maturity_trigger_DY_liquidate'},
        {'title':'Debt Yield Maturity Trigger: Loss (%) if Loan is liquidated','type':'input','value':'tranche.maturity_trigger_DY_loss'},
        {'title':'Debt Yield at Maturity Trigger: Extension (Recovery Lag in Months) if DY is between payoff and liquidation trigger levels','type':'input','value':'tranche.maturity_trigger_DY_extension'},
        {'title':'Debt Yield at Maturity Trigger: End of Extension Liquidate if DY is less then or equal to (%), or payoff if greater than','type':'input','value':'tranche.maturity_trigger_DY_end_of_extension_liq_or_payoff'},
        {'title':'Debt Yield at Maturity Trigger: End of Extension Loss (%) if loan is liquidated','type':'input','value':'tranche.maturity_trigger_DY_end_of_extension_loss'},
        {'title':'Maturity Trigger to Prioritize if Simultaneous Breach','type':'select','value':'tranche.maturity_trigger_select_priority'},
        {'title':'Servicer Advance Basis','type':'select','value':'tranche.servicer_basis'},
        {'title':'Servicer Advance Rate','type':'input','value':'tranche.servicer_rate'},
        {'title':'Servicer Advance Type','type':'select','value':'tranche.servicer_type'},
        {'title':'Forced Call','type':'select','value':'tranche.force_call'},          
        {'title':'Call Option','type':'select','value':'tranche.call_option'},
        {'title':'Call Date','type':'input','value':'tranche.call_date'}
      ];
      xpathInfo[1] = [//SLABS
        {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
        {'title':'Deal','type':'deal','value':'2'},
        {'title':'Cusip','type':'cusip','value':'4'},
        {'title':'Class','type':'class','value':'3'},
        {'title':'Vintage','type':'vintage','value':'5'},
        {'title':'Ratings','type':'ratings','value':'6'},
        {'title':'DM (bps)','type':'input','value':'tranche.dm'},
        {'title':'Yield (%)','type':'input','value':'tranche.yield_pct'},
        {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
        {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
        {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
        {'title':'Default Type','type':'select','value':'tranche.default_type'},
        {'title':'Loss Rate','type':'input','value':'tranche.loss_rate'},
        {'title':'Loss Type','type':'select','value':'tranche.loss_type'},
        {'title':'Rec Lag (Months)','type':'input','value':'tranche.rec_lag'},
        {'title':'Allocation (Months)','type':'input','value':'tranche.alloc_mon'},
        {'title':'Deferment Rate','type':'input','value':'tranche.deferment_rate'},
        {'title':'Deferment Type','type':'select','value':'tranche.deferment_type'},
        {'title':'Grace Rate','type':'input','value':'tranche.grace_rate'},
        {'title':'Grace Type','type':'select','value':'tranche.grace_type'},
        {'title':'Forbearance Rate','type':'input','value':'tranche.forbear_rate'},
        {'title':'Forbearance Type','type':'select','value':'tranche.forbear_type'},
        {'title':'Ignore Input Non-Payment Term','type':'checkbox','value':'tranche.ignore_input_nonpayment_term'},
        {'title':'Calculate Curve off of Static Starting Balance','type':'checkbox','value':'tranche.calc_curve_off_static_bal'},
        {'title':'Interest Capitalization Frequency','type':'select','value':'tranche.interest_cap_freq'},
        {'title':'Subsidy Payment Delay','type':'input','value':'tranche.subsidy_payment_delay'},
        {'title':'SAP Payment Delay','type':'input','value':'tranche.SAP_payment_delay'},
        {'title':'Use ACH Vector','type':'checkbox','value':'tranche.useACHVector'},
        {'title':'ACH (0.25%)','type':'input','value':'tranche.BB_utilization_rate'}, 
        {'title':'Forced Call','type':'select','value':'tranche.force_call'},          
        {'title':'Call Option','type':'select','value':'tranche.call_option'},
        {'title':'Call Date','type':'input','value':'tranche.call_date'}
      ];
      xpathInfo[4] = [//RMBS
        {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
        {'title':'Deal','type':'deal','value':'2'},
        {'title':'Cusip','type':'cusip','value':'4'},
        {'title':'Class','type':'class','value':'3'},
        {'title':'Vintage','type':'vintage','value':'5'},
        {'title':'Ratings','type':'ratings','value':'6'},
        {'title':'DM (bps)','type':'input','value':'tranche.dm'},
        {'title':'Yield (%)','type':'input','value':'tranche.yield_pct'},
        {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
        {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
        {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
        {'title':'Default Type','type':'select','value':'tranche.default_type'},
        {'title':'Loss Rate1','type':'input','value':'tranche.loss_rate'},
        {'title':'Loss Type','type':'select','value':'tranche.loss_type'},          
        {'title':'Rec Lag (Months)','type':'input','value':'tranche.rec_lag'},
        {'title':'Allocation (Months)','type':'input','value':'tranche.alloc_mon'},
        {'title':'Delinquency Rate','type':'input','value':'tranche.delinquency_rate'},
        {'title':'Delinquency Type','type':'select','value':'tranche.delinquency_type'},
        {'title':'Servicer Advance Basis','type':'select','value':'tranche.servicer_basis'},
        {'title':'Servicer Advance Rate','type':'input','value':'tranche.servicer_rate'},
        {'title':'Servicer Advance Type','type':'select','value':'tranche.servicer_type'},
        {'title':'Seeded defaults','type':'checkbox','value':'tranche.seed_default'},
        {'title':'Loss Rate','type':'input','value':'tranche.adv_loss_rate'},
        {'title':'Lag (months)','type':'input','value':'tranche.adv_lag_mon'},
        {'title':'Forced Call','type':'select','value':'tranche.force_call'},          
        {'title':'Call Option','type':'select','value':'tranche.call_option'},
        {'title':'Call Date','type':'input','value':'tranche.call_date'}
      ];
      xpathInfo[5] = [//ABS
        {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
        {'title':'Deal','type':'deal','value':'2'},
        {'title':'Cusip','type':'cusip','value':'4'},
        {'title':'Class','type':'class','value':'3'},
        {'title':'Vintage','type':'vintage','value':'5'},
        {'title':'Ratings','type':'ratings','value':'6'},
        {'title':'DM (bps)','type':'input','value':'tranche.dm'},
        {'title':'Yield (%)','type':'input','value':'tranche.yield_pct'},
        {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
        {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
        {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
        {'title':'Default Type','type':'select','value':'tranche.default_type'},
        {'title':'Loss Rate','type':'input','value':'tranche.loss_rate'},
        {'title':'Loss Type','type':'select','value':'tranche.loss_type'},          
        {'title':'Rec Lag (Months)','type':'input','value':'tranche.rec_lag'},
        {'title':'Allocation (Months)','type':'input','value':'tranche.alloc_mon'},
        {'title':'Forced Call','type':'select','value':'tranche.force_call'},          
        {'title':'Call Option','type':'select','value':'tranche.call_option'},
        {'title':'Call Date','type':'input','value':'tranche.call_date'}
      ];
      xpathInfo[6] = [//CARDS
        {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
        {'title':'Deal','type':'deal','value':'2'},
        {'title':'Cusip','type':'cusip','value':'4'},
        {'title':'Class','type':'class','value':'3'},
        {'title':'Vintage','type':'vintage','value':'5'},
        {'title':'Ratings','type':'ratings','value':'6'},
        {'title':'DM (bps)','type':'input','value':'tranche.dm'},
        {'title':'Yield (%)','type':'input','value':'tranche.yield_pct'},
        {'title':'Repayment Rate','type':'input','value':'tranche.repay_rate'},
        {'title':'Repayment Type','type':'select','value':'tranche.repay_type'},
        {'title':'Purchase Rate','type':'input','value':'tranche.purchase_rate'},
        {'title':'Purchase Type','type':'select','value':'tranche.purchase_type'},          
        {'title':'Portfolio Yield Rate','type':'input','value':'tranche.portfolio_yield_rate'},
        {'title':'Portfolio Yield Type','type':'select','value':'tranche.portfolio_yield_type'},
        {'title':'Charge-off','type':'input','value':'tranche.portfolio_loss_rate'},
        {'title':'Charge-off Type','type':'select','value':'tranche.portfolio_loss_type'},
        {'title':'Forced Call','type':'select','value':'tranche.force_call'},          
        {'title':'Call Option','type':'select','value':'tranche.call_option'},
        {'title':'Call Date','type':'input','value':'tranche.call_date'}
      ];
      xpathInfo[3] = [//CDO
        {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
        {'title':'Deal','type':'deal','value':'2'},
        {'title':'Cusip','type':'cusip','value':'4'},
        {'title':'Class','type':'class','value':'3'},
        {'title':'Vintage','type':'vintage','value':'5'},
        {'title':'Ratings','type':'ratings','value':'6'},
        {'title':'Legal Maturity','type':'legal maturity','value':'7'},
        {'title':'DM (bps)','type':'input','value':'tranche.dm'},
        {'title':'Yield (%)','type':'input','value':'tranche.yield_pct'},
        {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
        {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
        {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
        {'title':'Default Type','type':'select','value':'tranche.default_type'},
        {'title':'Loss Rate','type':'input','value':'tranche.loss_rate'},
        {'title':'Loss Type','type':'select','value':'tranche.loss_type'},
        {'title':'Loss Rate (non-performing)','type':'input','value':'tranche.prinLossSeverityPctNonPerf'},
        {'title':'Rec Lag(Months)','type':'input','value':'tranche.rec_lag'},
        {'title':'Reinvest Price','type':'input','value':'tranche.reinvest_price'},
        {'title':'Reinvest Price Type','type':'select','value':'tranche.reinvest_price_type'},
        {'title':'Reinvest Spread (%)','type':'input','value':'tranche.reinvest_spread'},
        {'title':'Reinvest Term','type':'input','value':'tranche.reinvest_term'},
        {'title':'Reinvest Pool','type':'select','value':'tranche.reinvest_pool'},
        {'title':'Reinvest Default Lockout (months)','type':'input','value':'tranche.reinvDefaultLockout'},
        {'title':'Intra/Post Reinvest Rules','type':'select','value':'tranche.reinvest_rules'},
        {'title':'Forced Call','type':'select','value':'tranche.force_call'},
        {'title':'Call Option','type':'select','value':'tranche.call_option'},
        {'title':'Call Date','type':'input','value':'tranche.call_date'},
        {'title':'(+/-) Months','type':'input','value':'tranche.plus_minus_months'},
        {'title':'Call Price Type','type':'select','value':'tranche.call_price_type'},
        {'title':'Call Price','type':'input','value':'tranche.call_price'}
      ];
      xpathInfo[2] = [//AUTO
        {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
        {'title':'Deal','type':'deal','value':'2'},
        {'title':'Cusip','type':'cusip','value':'4'},
        {'title':'Class','type':'class','value':'3'},
        {'title':'Vintage','type':'vintage','value':'5'},
        {'title':'Ratings','type':'ratings','value':'6'},
        {'title':'DM (bps)','type':'input','value':'tranche.dm'},
        {'title':'Yield (%)','type':'input','value':'tranche.yield_pct'},
        {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
        {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
        {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
        {'title':'Default Type','type':'select','value':'tranche.default_type'},
        {'title':'Loss Rate','type':'input','value':'tranche.loss_rate'},
        {'title':'Loss Type','type':'select','value':'tranche.loss_type'},          
        {'title':'Rec Lag (Months)','type':'input','value':'tranche.rec_lag'},
        {'title':'Allocation (Months)','type':'input','value':'tranche.alloc_mon'},
        {'title':'Delinquency Rate','type':'input','value':'tranche.delinquency_rate'},
        {'title':'Delinquency Type','type':'select','value':'tranche.delinquency_type'},
        {'title':'Seeded defaults','type':'checkbox','value':'tranche.seed_default'},
        {'title':'Loss Rate','type':'input','value':'tranche.adv_loss_rate'},
        {'title':'Lag (months)','type':'input','value':'tranche.adv_lag_mon'},
        {'title':'Forced Call','type':'select','value':'tranche.force_call'},          
        {'title':'Call Option','type':'select','value':'tranche.call_option'},
        {'title':'Call Date','type':'input','value':'tranche.call_date'}
      ];
      var xpathInfo1 = [];
      xpathInfo1[7] = [//CMBS
        {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
        {'title':'Deal','type':'deal','value':'2'},
        {'title':'Buy Price','type':'input','value':'tranche.buy_price'},
        {'title':'Buy Date','type':'input','value':'tranche.buy_date'},
        {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
        {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
        {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
        {'title':'Default Type','type':'select','value':'tranche.default_type'},
        {'title':'Loss Rate','type':'input','value':'tranche.loss_rate'},
        {'title':'Loss Type','type':'select','value':'tranche.loss_type'},
        {'title':'Rec Lag (Months)','type':'input','value':'tranche.rec_lag'},
        {'title':'Allocation (Months)','type':'input','value':'tranche.alloc_mon'},
        {'title':'NOI Growth Rate Type','type':'select','value':'tranche.NOI_growth_rate_type'},
        {'title':'Annual NOI Growth Rate','type':'input','value':'tranche.NOI_growth_rate'},
        {'title':'Cap Rate Growth Rate Type','type':'select','value':'tranche.cap_rate_growth_rate_type'},
        {'title':'Annual Cap Rate Growth Rate','type':'input','value':'tranche.cap_rate_growth_rate'},
        {'title':'Activate LTV Term Trigger','type':'checkbox','value':'tranche.term_triggers_activate_LTV_trigger'},
        {'title':'LTV Term Trigger: If LTV Exceeds Percentage then Liquidate','type':'input','value':'tranche.term_triggers_LTV_liquidate'},
        {'title':'LTV Term Trigger: Recovery Lag (months)','type':'input','value':'tranche.term_triggers_LTV_months'},
        {'title':'LTV Term Trigger: Loss (%)','type':'input','value':'tranche.term_triggers_LTV_loss'},
        {'title':'Activate DSCR Term Trigger','type':'checkbox','value':'tranche.term_triggers_activate_DSCR_trigger'},
        {'title':'DSCR Term Trigger: If DSCR falls below (x.xx)','type':'input','value':'tranche.term_triggers_DSCR_liquidate'},
        {'title':'DSCR Term Trigger: Recovery Lag (months)','type':'input','value':'tranche.term_triggers_DSCR_months'},
        {'title':'DSCR Term Trigger Loss (%)','type':'input','value':'tranche.term_triggers_DSCR_loss'},
        {'title':'Term Trigger to Prioritize if Simultaneous Breach','type':'select','value':'tranche.term_triggers_select_priority'},
        {'title':'Activate LTV at Maturity Trigger','type':'checkbox','value':'tranche.maturity_trigger_activate_LTV_trigger'},
        {'title':'LTV at Maturity Trigger: Payoff if LTV is less than (%)','type':'input','value':'tranche.maturity_trigger_LTV_payoff'},
        {'title':'LTV at Maturity Trigger: Liquidate if LTV is greater than (%)','type':'input','value':'tranche.maturity_trigger_LTV_liquidate'},
        {'title':'LTV at Maturity Trigger: Loss (%) If Loan is Liquidated','type':'input','value':'tranche.maturity_trigger_LTV_loss'},
        {'title':'LTV at Maturity Trigger: Extension period if LTV is between payoff and liquidation trigger levels','type':'input','value':'tranche.maturity_trigger_LTV_extension'},
        {'title':'LTV at Maturity Trigger: End of Extension Liquidate if LTV is greater than or equal to (%), or payoff if less than','type':'input','value':'tranche.maturity_trigger_LTV_end_of_extension_liq_or_payoff'},
        {'title':'LTV at Maturity Trigger: End of Extension Loss (%) if loan is liquidated','type':'input','value':'tranche.maturity_trigger_LTV_end_of_extension_loss'},
        {'title':'Activate Debt Yield at Maturity Trigger','type':'checkbox','value':'tranche.maturity_trigger_activate_DY_trigger'},
        {'title':'Debt Yield at Maturity Trigger: Payoff if DY greater than (%)','type':'input','value':'tranche.maturity_trigger_DY_payoff'},
        {'title':'Debt Yield at Maturity Trigger: Liquidation if DY is less than (%)','type':'input','value':'tranche.maturity_trigger_DY_liquidate'},
        {'title':'Debt Yield Maturity Trigger: Loss (%) if Loan is liquidated','type':'input','value':'tranche.maturity_trigger_DY_loss'},
        {'title':'Debt Yield at Maturity Trigger: Extension (Recovery Lag in Months) if DY is between payoff and liquidation trigger levels','type':'input','value':'tranche.maturity_trigger_DY_extension'},
        {'title':'Debt Yield at Maturity Trigger: End of Extension Liquidate if DY is less then or equal to (%), or payoff if greater than','type':'input','value':'tranche.maturity_trigger_DY_end_of_extension_liq_or_payoff'},
        {'title':'Debt Yield at Maturity Trigger: End of Extension Loss (%) if loan is liquidated','type':'input','value':'tranche.maturity_trigger_DY_end_of_extension_loss'},
        {'title':'Maturity Trigger to Prioritize if Simultaneous Breach','type':'select','value':'tranche.maturity_trigger_select_priority'},
        {'title':'Servicer Advance Basis','type':'select','value':'tranche.servicer_basis'},
        {'title':'Servicer Advance Rate','type':'input','value':'tranche.servicer_rate'},
        {'title':'Servicer Advance Type','type':'select','value':'tranche.servicer_type'},
        {'title':'Forced Call','type':'select','value':'tranche.force_call'},          
        {'title':'Call Option','type':'select','value':'tranche.call_option'},
        {'title':'Call Date','type':'input','value':'tranche.call_date'}
      ];
      xpathInfo1[1] = [//SLABS
        {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
        {'title':'Deal','type':'deal','value':'2'},
        {'title':'Buy Price','type':'input','value':'tranche.buy_price'},
        {'title':'Buy Date','type':'input','value':'tranche.buy_date'},
        {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
        {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
        {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
        {'title':'Default Type','type':'select','value':'tranche.default_type'},
        {'title':'Loss Rate','type':'input','value':'tranche.loss_rate'},
        {'title':'Loss Type','type':'select','value':'tranche.loss_type'},
        {'title':'Rec Lag (Months)','type':'input','value':'tranche.rec_lag'},
        {'title':'Allocation (Months)','type':'input','value':'tranche.alloc_mon'},
        {'title':'Deferment Rate','type':'input','value':'tranche.deferment_rate'},
        {'title':'Deferment Type','type':'select','value':'tranche.deferment_type'},
        {'title':'Grace Rate','type':'input','value':'tranche.grace_rate'},
        {'title':'Grace Type','type':'select','value':'tranche.grace_type'},
        {'title':'Forbearance Rate','type':'input','value':'tranche.forbear_rate'},
        {'title':'Forbearance Type','type':'select','value':'tranche.forbear_type'},
        {'title':'Ignore Input Non-Payment Term','type':'checkbox','value':'tranche.ignore_input_nonpayment_term'},
        {'title':'Calculate Curve off of Static Starting Balance','type':'checkbox','value':'tranche.calc_curve_off_static_bal'},
        {'title':'Interest Capitalization Frequency','type':'select','value':'tranche.interest_cap_freq'},
        {'title':'Subsidy Payment Delay','type':'input','value':'tranche.subsidy_payment_delay'},
        {'title':'SAP Payment Delay','type':'input','value':'tranche.SAP_payment_delay'},
        {'title':'Use ACH Vector','type':'checkbox','value':'tranche.useACHVector'},
        {'title':'ACH (0.25%)','type':'input','value':'tranche.BB_utilization_rate'}, 
        {'title':'Forced Call','type':'select','value':'tranche.force_call'},          
        {'title':'Call Option','type':'select','value':'tranche.call_option'},
        {'title':'Call Date','type':'input','value':'tranche.call_date'}
      ];
      xpathInfo1[4] = [//RMBS
        {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
        {'title':'Deal','type':'deal','value':'2'},
        {'title':'Buy Price','type':'input','value':'tranche.buy_price'},
        {'title':'Buy Date','type':'input','value':'tranche.buy_date'},
        {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
        {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
        {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
        {'title':'Default Type','type':'select','value':'tranche.default_type'},
        {'title':'Loss Rate','type':'input','value':'tranche.loss_rate'},
        {'title':'Loss Type','type':'select','value':'tranche.loss_type'},          
        {'title':'Rec Lag (Months)','type':'input','value':'tranche.rec_lag'},
        {'title':'Allocation (Months)','type':'input','value':'tranche.alloc_mon'},
        {'title':'Delinquency Rate','type':'input','value':'tranche.delinquency_rate'},
        {'title':'Delinquency Type','type':'select','value':'tranche.delinquency_type'},
        {'title':'Servicer Advance Basis','type':'select','value':'tranche.servicer_basis'},
        {'title':'Servicer Advance Rate','type':'input','value':'tranche.servicer_rate'},
        {'title':'Servicer Advance Type','type':'select','value':'tranche.servicer_type'},
        {'title':'Seeded defaults','type':'checkbox','value':'tranche.seed_default'},
        {'title':'Loss Rate','type':'input','value':'tranche.adv_loss_rate'},
        {'title':'Lag (months)','type':'input','value':'tranche.adv_lag_mon'},
        {'title':'Forced Call','type':'select','value':'tranche.force_call'},          
        {'title':'Call Option','type':'select','value':'tranche.call_option'},
        {'title':'Call Date','type':'input','value':'tranche.call_date'}
      ];
      xpathInfo1[5] = [//ABS
        {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
        {'title':'Deal','type':'deal','value':'2'},
        {'title':'Buy Price','type':'input','value':'tranche.buy_price'},
        {'title':'Buy Date','type':'input','value':'tranche.buy_date'},
        {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
        {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
        {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
        {'title':'Default Type','type':'select','value':'tranche.default_type'},
        {'title':'Loss Rate','type':'input','value':'tranche.loss_rate'},
        {'title':'Loss Type','type':'select','value':'tranche.loss_type'},          
        {'title':'Rec Lag (Months)','type':'input','value':'tranche.rec_lag'},
        {'title':'Allocation (Months)','type':'input','value':'tranche.alloc_mon'},
        {'title':'Forced Call','type':'select','value':'tranche.force_call'},          
        {'title':'Call Option','type':'select','value':'tranche.call_option'},
        {'title':'Call Date','type':'input','value':'tranche.call_date'}
      ];
      xpathInfo1[6] = [//CARDS
        {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
        {'title':'Deal','type':'deal','value':'2'},
        {'title':'Buy Price','type':'input','value':'tranche.buy_price'},
        {'title':'Buy Date','type':'input','value':'tranche.buy_date'},
        {'title':'Repayment Rate','type':'input','value':'tranche.repay_rate'},
        {'title':'Repayment Type','type':'select','value':'tranche.repay_type'},
        {'title':'Purchase Rate','type':'input','value':'tranche.purchase_rate'},
        {'title':'Purchase Type','type':'select','value':'tranche.purchase_type'},          
        {'title':'Portfolio Yield Rate','type':'input','value':'tranche.portfolio_yield_rate'},
        {'title':'Portfolio Yield Type','type':'select','value':'tranche.portfolio_yield_type'},
        {'title':'Charge-off','type':'input','value':'tranche.portfolio_loss_rate'},
        {'title':'Charge-off Type','type':'select','value':'tranche.portfolio_loss_type'},
        {'title':'Forced Call','type':'select','value':'tranche.force_call'},          
        {'title':'Call Option','type':'select','value':'tranche.call_option'},
        {'title':'Call Date','type':'input','value':'tranche.call_date'}
      ];
      xpathInfo1[3] = [//CDO
        {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
        {'title':'Deal','type':'deal','value':'2'},
        {'title':'Buy Price','type':'input','value':'tranche.buy_price'},
        {'title':'Buy Date','type':'input','value':'tranche.buy_date'},
        {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
        {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
        {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
        {'title':'Default Type','type':'select','value':'tranche.default_type'},
        {'title':'Loss Rate','type':'input','value':'tranche.loss_rate'},
        {'title':'Loss Type','type':'select','value':'tranche.loss_type'},
        {'title':'Loss Rate (non-performing)','type':'input','value':'tranche.prinLossSeverityPctNonPerf'},
        {'title':'Rec Lag(Months)','type':'input','value':'tranche.rec_lag'},
        {'title':'Reinvest Price','type':'input','value':'tranche.reinvest_price'},
        {'title':'Reinvest Price Type','type':'select','value':'tranche.reinvest_price_type'},
        {'title':'Reinvest Spread (%)','type':'input','value':'tranche.reinvest_spread'},
        {'title':'Reinvest Term','type':'input','value':'tranche.reinvest_term'},
        {'title':'Reinvest Pool','type':'select','value':'tranche.reinvest_pool'},
        {'title':'Reinvest Default Lockout (months)','type':'input','value':'tranche.reinvDefaultLockout'},
        {'title':'Intra/Post Reinvest Rules','type':'select','value':'tranche.reinvest_rules'},
        {'title':'Forced Call','type':'select','value':'tranche.force_call'},
        {'title':'Call Option','type':'select','value':'tranche.call_option'},
        {'title':'Call Date','type':'input','value':'tranche.call_date'},
        {'title':'(+/-) Months','type':'input','value':'tranche.plus_minus_months'},
        {'title':'Call Price Type','type':'select','value':'tranche.call_price_type'},
        {'title':'Call Price','type':'input','value':'tranche.call_price'}
      ];
      xpathInfo1[2] = [//AUTO
        {'title':'Run','type':'checkbox','value':'tranche.run_flag'},
        {'title':'Deal','type':'deal','value':'2'},
        {'title':'Buy Price','type':'input','value':'tranche.buy_price'},
        {'title':'Buy Date','type':'input','value':'tranche.buy_date'},
        {'title':'Prepay Rate','type':'input','value':'tranche.prepay_rate'},
        {'title':'Prepay Type','type':'select','value':'tranche.prepay_type'},
        {'title':'Default Rate','type':'input','value':'tranche.default_rate'},
        {'title':'Default Type','type':'select','value':'tranche.default_type'},
        {'title':'Loss Rate1','type':'input','value':'tranche.loss_rate'},
        {'title':'Loss Type','type':'select','value':'tranche.loss_type'},          
        {'title':'Rec Lag (Months)','type':'input','value':'tranche.rec_lag'},
        {'title':'Allocation (Months)','type':'input','value':'tranche.alloc_mon'},
        {'title':'Delinquency Rate','type':'input','value':'tranche.delinquency_rate'},
        {'title':'Delinquency Type','type':'select','value':'tranche.delinquency_type'},
        {'title':'Seeded defaults','type':'checkbox','value':'tranche.seed_default'},
        {'title':'Loss Rate','type':'input','value':'tranche.adv_loss_rate'},
        {'title':'Lag (months)','type':'input','value':'tranche.adv_lag_mon'},
        {'title':'Forced Call','type':'select','value':'tranche.force_call'},          
        {'title':'Call Option','type':'select','value':'tranche.call_option'},
        {'title':'Call Date','type':'input','value':'tranche.call_date'}
      ];
      // var table_length = browser.elements(table_text).value.length;
      // console.log(table_length);
        ////////API to get dealist////////////////
      var searchInput = '//input[@ng-model="cash.trancheQueryString"]';
      // var license = this.api_session.getLicense(this.test_user);
      // var fxRates = this.api_session.getFxRates(license);
      // var portfolio_id = this.api_session.getPortfolioInfo(this.portfolio, license).portfolioId;
      // var dealList = this.api_session.getDealList(portfolio_id,license,fxRates);
      var dealList = [];
      dealList[7] = {//CMBS
        "deals": [
          {
            "dealName": "WACHOVIA BANK COMMERCIAL MORTGAGE TRUST SERIES 2007-C32"
          },
          {
            "dealName": "BANK 2017-BNK4"
          }
        ]
      };
      dealList[1] = {//SLABS
        "deals": [
          {
            "dealName": "SLM STUDENT LOAN TRUST 2013-3"
          },
          {
            "dealName": "Navient Student Loan Trust 2019-3"
          }
        ]
      };
      dealList[4] = {//RMBS
        "deals": [
          {
            "dealName": "Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1"
          },
          {
            "dealName": "MADRID RMBS IV, FTA"
          }
        ]
      };
      dealList[5] = {//ABS
        "deals": [
          {
            "dealName": "DELL EQUIPMENT FINANCE TRUST 2019-1"
          },
          {
            "dealName": "Flexi ABS Trust 2018-1"
          }
        ]
      };
      dealList[6] = {//CRADS
        "deals": [
          {
            "dealName": "AMERICAN EXPRESS CREDIT ACCOUNT MASTER TRUST"
          },
          {
            "dealName": "Gracechurch Card Programme Funding PLC"
          }
        ]
      };
      dealList[3] = {//CDO
        "deals": [
          {
            "dealName": "Flatiron CLO 17 Ltd."
          },
          {
            "dealName": "Dryden 48 Euro CLO 2016 BV"
          }
        ]
      };
      dealList[2] = {//AUTO
        "deals": [
          {
            "dealName": "MERCEDES-BENZ AUTO LEASE TRUST 2019-A"
          },
          {
            "dealName": "SC Germany Auto 2018-1 UG (haftungsbeschraenkt)"
          }
        ]
      };
      // console.log('dealList.deals:'+dealList);
      var uiTextJson = [];       
      //console.log(uiTextJson);
      
      if(fileType =='upload file'){
        for(var k=1; k<8; k++){
          uiTextJson[k] = this.browser_session.getCashflowPortfolioUiValueJson(browser,xpathInfo1[k],dealList[k]);
          console.log('---------uiTextJson[k]--------');
          console.log(uiTextJson[k]);
          console.log(uiTextJson.length);
          console.log('-----------------');
        }
        for (var x = 1; x < 8; x++){
          for (var i = 0; i < uiTextJson[x].length; i++) {
            var findDeal = false ;
            for (var j = 0; j < filejson[x].length; j++) {
              if(uiTextJson[x][i]['Deal']==filejson[x][j]['Deal']){
                findDeal = true;
                for(var key in uiTextJson[x][i]){
                  console.log(uiTextJson[x][i][key]);
                  console.log(filejson[x][j][key]);
                if (key == 'Call Option' && uiTextJson[x][i][key] == 'Clean-up Call' || filejson[x][i][key] == 'Clean Up'){
                  continue;
                }
                if (key == 'Call Price Type' && uiTextJson[x][i][key] == 'Mrkt Price' || filejson[x][i][key] == 'Market Value'){
                  continue;
                }
                if (key == 'Call Price Type' && uiTextJson[x][i][key] == 'Input' || filejson[x][i][key] == 'User Defined'){
                  continue;
                }
                if((x == 3 || x == 7) && key== 'Loss Rate1'){
                  filejson[x][i][key] = filejson[x][i]['Loss Rate (%)'];
                }else if((x == 3 || x == 7) && key== 'Loss Rate'){
                    filejson[x][i][key] = filejson[x][i]['Loss Rate'];
                }else if(key == 'Loss Rate' && key.indexOf("performing") <= -1){
                  filejson[x][i][key] = filejson[x][i]['Loss Rate (%)'];
                }
                // Loss Rate (non-performing) vs. Loss Rate (non-performing) (%) 
                if (key.indexOf("performing") > -1){              
                  filejson[x][i][key] = filejson[x][i]['Loss Rate (non-performing) (%)'];
                } 
                //Month vs. month
                if ((x == 1 || x == 2 || x == 4 || x == 7) && key.indexOf("Rec Lag ") > -1){
                    filejson[x][i][key] = filejson[x][i]['RecLag (months)'];
                }else if (x == 6 && key.indexOf("Rec Lag") > -1){ 
                    filejson[x][i][key] = filejson[x][i]['RecLag (months)']; 
                }else{
                  if (key.indexOf("RecLag") > -1){   
                    filejson[x][i][key] = filejson[x][i]['RecLag (months)'];
                  }
                  if (key.indexOf("Rec Lag ") > -1){   
                    filejson[x][i][key] = filejson[x][i]['Rec Lag (months)'];
                  }
                }                                  
                if (key.indexOf("Allocation") > -1){   
                  filejson[x][i][key] = filejson[x][i]['Allocation (months)'];
                }  
                if (key.indexOf("Annual NOI Growth Rate") > -1){   
                  filejson[x][i][key] = filejson[x][i]['NOI Growth Rate'];
                }
                if (key.indexOf("Annual Cap Rate Growth Rate") > -1){   
                  filejson[x][i][key] = filejson[x][i]['Cap Rate Growth Rate'];
                }
                if (key.indexOf("LTV Term Trigger: Recovery Lag (months)") > -1){   
                  filejson[x][i][key] = filejson[x][i]['LTV Trigger: Recovery Lag (months)'];
                } 
                if (key.indexOf("LTV Term Trigger: Loss (%)") > -1){   
                  filejson[x][i][key] = filejson[x][i]['LTV Term Trigger: Loss (%)'];
                } 
                if (key.indexOf("DSCR Term Trigger: Recovery Lag (months)") > -1){   
                  filejson[x][i][key] = filejson[x][i]['Trigger: Recovery Lag (months)'];
                }  
                if (key.indexOf("DSCR Term Trigger: If DSCR falls below (x.xx)") > -1){   
                  filejson[x][i][key] = filejson[x][i]['Trigger: If DSCR falls below (x.xx)'];
                }
                if (key.indexOf("DSCR Term Trigger: Recovery Lag (months)") > -1){   
                  filejson[x][i][key] = filejson[x][i]['Trigger: Recovery Lag (months)'];
                }
                if (key.indexOf("DSCR Term Trigger Loss (%)") > -1){   
                  filejson[x][i][key] = filejson[x][i]['DSCR Trigger: Loss (%)'];
                }
                if (key.indexOf("Term Trigger to Prioritize if Simultaneous Breach") > -1){   
                  filejson[x][i][key] = filejson[x][i]['Trigger to Prioritize if Simultaneous Breach'];
                }
                if (key.indexOf("LTV at Maturity Trigger: Payoff if LTV is less than (%)") > -1){   
                  filejson[x][i][key] = filejson[x][i]['LTV Trigger: Payoff if less than trigger input (%)'];
                }  
                if (key.indexOf("LTV at Maturity Trigger: Liquidate if LTV is greater than (%)") > -1){   
                  filejson[x][i][key] = filejson[x][i]['LTV Trigger: Liquidate if greater than trigger input (%)'];
                } 
                if (key.indexOf("LTV at Maturity Trigger: End of Extension Loss (%) if loan is liquidated") > -1){   
                  filejson[x][i][key] = filejson[x][i]['LTV at Maturity Trigger: End of Extension Loss (%) if Loan is Liquidated'];
                } 
                if (key.indexOf("Debt Yield at Maturity Trigger: End of Extension Loss (%) if loan is liquidated") > -1){   
                  filejson[x][i][key] = filejson[x][i]['Debt Yield at Maturity Trigger: End of Extension Loss (%) if Loan is Liquidated'];
                }
                if (key == 'Call Option' && uiTextJson[x][i][key] == 'Clean-up Call' || filejson[x][i][key] == 'Clean Up'){
                  continue;
                }
                if (key == 'Call Option' && uiTextJson[x][i][key] == 'Input' || filejson[x][i][key] == 'User Defined'){
                  continue;
                }
                if (key == 'Call Price Type' && uiTextJson[x][i][key] == 'Mrkt Price' || filejson[x][i][key] == 'Market Value'){
                  continue;
                }
                if (key == 'Call Price Type' && uiTextJson[x][i][key] == 'Input' || filejson[x][i][key] == 'User Defined'){
                  continue;
                }
                if (uiTextJson[x][i][key]!='disabled') {
                  expect(uiTextJson[x][i][key]).toEqual(filejson[x][j][key]);
               }
              }
             }
            }
            expect(findDeal).toBe(true);
          }
        }
      }else{
        for(var j=1; j<8; j++){
          uiTextJson[j] = this.browser_session.getCashflowPortfolioUiValueJson(browser,xpathInfo[j],dealList[j]);
          console.log(uiTextJson.length);
          console.log('-----------------');
        } 
        for (var x = 1; x < 8; x++){
          for (var i = 0; i < uiTextJson[x].length; i++) {
            for(var key in uiTextJson[x][i]){
              console.log(key);
              console.log(uiTextJson[x][i][key]);
              console.log("filejson");
              console.log(filejson[x][i][key]); 
              if (key == 'Cusip'){
                continue;  
                }
              if (key == 'Legal Maturity'){
                var forwardFormat=uiTextJson[x][i][key];
                var formatMonth=('0'+(forwardFormat.split('/')[0])).slice(-2);
                var formatDate=('0'+(forwardFormat.split('/')[1])).slice(-2);
                uiTextJson[x][i][key]='20'+forwardFormat.split('/')[2]+'-'+formatMonth+'-'+formatDate;
              } 
              // Loss Rate vs. Loss Rate (%)
              if((x == 3 || x == 7) && key== 'Loss Rate1'){
                  filejson[x][i][key] = filejson[x][i]['Loss Rate (%)'];
              }else if((x == 3 || x == 7) && key== 'Loss Rate'){
                  filejson[x][i][key] = filejson[x][i]['Loss Rate'];
              }else if(key == 'Loss Rate' && key.indexOf("performing") <= -1){
                filejson[x][i][key] = filejson[x][i]['Loss Rate (%)'];
              }
              // Loss Rate (non-performing) vs. Loss Rate (non-performing) (%) 
              if (key.indexOf("performing") > -1){              
                filejson[x][i][key] = filejson[x][i]['Loss Rate (non-performing) (%)'];
              }
              //Month vs. month
              if ((x == 1 || x == 2 || x == 4 || x == 7) && key.indexOf("Rec Lag ") > -1){
                  filejson[x][i][key] = filejson[x][i]['RecLag (months)'];
              }else if (x == 6 && key.indexOf("Rec Lag") > -1){ 
                  filejson[x][i][key] = filejson[x][i]['RecLag (months)']; 
              }else{
                if (key.indexOf("RecLag") > -1){   
                  filejson[x][i][key] = filejson[x][i]['RecLag (months)'];
                }
                if (key.indexOf("Rec Lag ") > -1){   
                  filejson[x][i][key] = filejson[x][i]['Rec Lag (months)'];
                }
              }                                  
              if (key.indexOf("Allocation") > -1){   
                filejson[x][i][key] = filejson[x][i]['Allocation (months)'];
              }  
              if (key.indexOf("Annual NOI Growth Rate") > -1){   
                filejson[x][i][key] = filejson[x][i]['NOI Growth Rate'];
              }
              if (key.indexOf("Annual Cap Rate Growth Rate") > -1){   
                filejson[x][i][key] = filejson[x][i]['Cap Rate Growth Rate'];
              }
              if (key.indexOf("LTV Term Trigger: Recovery Lag (months)") > -1){   
                filejson[x][i][key] = filejson[x][i]['LTV Trigger: Recovery Lag (months)'];
              } 
              if (key.indexOf("LTV Term Trigger: Loss (%)") > -1){   
                filejson[x][i][key] = filejson[x][i]['LTV Term Trigger: Loss (%)'];
              } 
              if (key.indexOf("DSCR Term Trigger: Recovery Lag (months)") > -1){   
                filejson[x][i][key] = filejson[x][i]['Trigger: Recovery Lag (months)'];
              }  
              if (key.indexOf("DSCR Term Trigger: If DSCR falls below (x.xx)") > -1){   
                filejson[x][i][key] = filejson[x][i]['Trigger: If DSCR falls below (x.xx)'];
              }
              if (key.indexOf("DSCR Term Trigger: Recovery Lag (months)") > -1){   
                filejson[x][i][key] = filejson[x][i]['Trigger: Recovery Lag (months)'];
              }
              if (key.indexOf("DSCR Term Trigger Loss (%)") > -1){   
                filejson[x][i][key] = filejson[x][i]['DSCR Trigger: Loss (%)'];
              }
              if (key.indexOf("Term Trigger to Prioritize if Simultaneous Breach") > -1){   
                filejson[x][i][key] = filejson[x][i]['Trigger to Prioritize if Simultaneous Breach'];
              }
              if (key.indexOf("LTV at Maturity Trigger: Payoff if LTV is less than (%)") > -1){   
                filejson[x][i][key] = filejson[x][i]['LTV Trigger: Payoff if less than trigger input (%)'];
              }  
              if (key.indexOf("LTV at Maturity Trigger: Liquidate if LTV is greater than (%)") > -1){   
                filejson[x][i][key] = filejson[x][i]['LTV Trigger: Liquidate if greater than trigger input (%)'];
              } 
              if (key.indexOf("LTV at Maturity Trigger: End of Extension Loss (%) if loan is liquidated") > -1){   
                filejson[x][i][key] = filejson[x][i]['LTV at Maturity Trigger: End of Extension Loss (%) if Loan is Liquidated'];
              } 
              if (key.indexOf("Debt Yield at Maturity Trigger: End of Extension Loss (%) if loan is liquidated") > -1){   
                filejson[x][i][key] = filejson[x][i]['Debt Yield at Maturity Trigger: End of Extension Loss (%) if Loan is Liquidated'];
              }
              if (key == 'Call Option' && uiTextJson[x][i][key] == 'Clean-up Call' || filejson[x][i][key] == 'Clean Up'){
                continue;
              }
              if (key == 'Call Option' && uiTextJson[x][i][key] == 'Auction Call' || filejson[x][i][key] == 'Auction'){
                continue;
              }
              if (key == 'Call Option' && uiTextJson[x][i][key] == 'Input' || filejson[x][i][key] == 'User Defined'){
                continue;
              }
              if (key == 'Call Price Type' && uiTextJson[x][i][key] == 'Mrkt Price' || filejson[x][i][key] == 'Market Value'){
                continue;
              }
              if (key == 'Call Price Type' && uiTextJson[x][i][key] == 'Input' || filejson[x][i][key] == 'User Defined'){
                continue;
              }
              if (uiTextJson[x][i][key]!='disabled') {
                expect(uiTextJson[x][i][key]).toEqual(filejson[x][i][key]);
              }
            }
          }
        }
      }
    }    
  });
}