// Recommended filename: Then_I_need_to_see_my_screen_infomation_match_the_following_data.js
module.exports = function () {
    this.Then(/^I need to see my screen infomation match the following data$/, function (table) {
        // Write code here that turns the phrase above into concrete actions
        var expect_row_list = table.hashes();
        browser.pause(2000);
        for (var i = 0; i < expect_row_list.length; i++) {
            console.log(expect_row_list[i].select_type);
            if (expect_row_list[i].select_type == 'vm.screenerName') {

                var select_type = '//input[@ng-model="' + expect_row_list[i].select_type + '"]';
                // console.log(browser.getValue(select_type));
                // console.log(expect_row_list[i].select_fields);
                expect(browser.getValue(select_type).includes(expect_row_list[i].select_fields)).toBe(true, browser.getValue(select_type), expect_row_list[i].select_fields);
            }
            else if (expect_row_list[i].select_type == 'Asset Characteristic:Currency') {
                var select_type = '(//*[@ng-model="char.selectedItems"])[1]//span[@uis-transclude-append]/span';
                console.log(browser.getText(select_type));
                console.log(expect_row_list[i].select_fields);
                expect(browser.getText(select_type).includes(expect_row_list[i].select_fields)).toBe(true, browser.getText(select_type), expect_row_list[i].select_fields);

            }
            else if (expect_row_list[i].select_type == 'Deal Characteristic:Asset Class') {
                var select_type = '(//*[@ng-model="char.selectedItems"])[2]//span[@uis-transclude-append]/span';
                // console.log(browser.getValue(select_type));
                // console.log(expect_row_list[i].select_fields);
                expect(browser.getText(select_type).includes(expect_row_list[i].select_fields)).toBe(true, browser.getText(select_type), expect_row_list[i].select_fields);

            }
            else {
                // var select_type = '//*[@ng-model="'+expect_row_list[i].select_type+'"]//span[@class="ng-binding ng-scope"]';
                var select_type = '//*[@ng-model="' + expect_row_list[i].select_type + '"]//span[@ng-transclude or @uis-transclude-append]//span';
                // '//*[@ng-model="'+expect_row_list[i].select_type+'"]//span[@ng-transclude or @uis-transclude-append]//span';
                console.log(select_type);
                if (!browser.isVisible(select_type)) {
                    // for cmbs screen
                    var select_type = '//*[@ng-model="' + expect_row_list[i].select_type + '"]';
                    expect(browser.getValue(select_type).includes(expect_row_list[i].select_fields)).toBe(true, browser.getValue(select_type), expect_row_list[i].select_fields);
                } else {
                    expect(browser.getText(select_type).includes(expect_row_list[i].select_fields)).toBe(true, browser.getText(select_type), expect_row_list[i].select_fields);
                }
                // console.log(select_type);
                //    console.log(browser.getText(select_type));
                // console.log(expect_row_list[i].select_fields);
                // expect(browser.getText(select_type).includes(expect_row_list[i].select_fields)).toBe(true,browser.getText(select_type),expect_row_list[i].select_fields);
            }
        }
    });
};