// Recommended filename: Then_I_should_see_the_chart_with_#_#_under_the_#_section_to_#_the_following_chart_data.js
module.exports = function() {
  this.Then(/^I should see the chart with (title|name) "([^"]*)" under the "([^"]*)" section to (contain|match|regex) the following chart data$/, 
    {timeout: process.env.StepTimeoutInMS*5},
    function (nameType, chartName, panelName, action, table) {
    // Write the automation code here
    // browser.pause(3000);
    this.browser_session.waitForLoading(browser);
    var expected_row_list = table.hashes();
    this.pie_charts_value_length = expected_row_list.length;
    this.chartName = chartName;

    const my_regex_lib = this.regex_lib;
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase());
    var myChart;
    switch (nameType) {
      case 'title':
          myChart = content_xpath.titledChart.replace('__TITLE__', chartName);
        break;
      case 'name':
          myChart = content_xpath.namedChart.replace('__NAME__', chartName);
        break;
      default:
          myChart = '';
    }
    var myChart = myPanel + myChart;
    if(panelName=='Concentration Report Chart Builder'){
      myChart = content_xpath.titledChart.replace('__TITLE__', chartName);
    }
    if (chartName == 'ratesCtrl.us_libor_curve'|| chartName == 'ratesCtrl.custom_us_libor_curve'){
        myChart = content_xpath.libor_chart.replace('__CHART__',chartName);
    }
    myChart = myChart.trim();
    this.browser_session.waitForResource(browser,myChart);
    browser.waitForVisible(myChart,this.waitDefault);
    browser.getLocationInView(myChart);
    if (!process.env.BROWSER.startsWith('IE')) {
      browser.touchScroll(browser.element(myChart).value['ELEMENT'], 0, 100);
    }
    browser.pause(2000);
    //const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    var myChart_x_title = myChart + content_xpath.chartXTitle;
    var myChart_y_title = myChart + content_xpath.chartYTitle;
    var myChart_x_label = myChart + content_xpath.chartXLabel;
    var myChart_y_label = myChart + content_xpath.chartYLabel;
    var my_Chart_y_wholeLabel = myChart + content_xpath.chartYwholeLabel;
    var myChart_legend = myChart + content_xpath.chartLegend;
    var myChart_label = myChart + content_xpath.chartLabel;

    var myChart_drilldown;
    var myChart_tooltip;
    var displayed_chartText;
    var displayed_x_title;
    var displayed_y_title;
    var displayed_x_label;
    var displayed_y_label;
    var displayed_tooltip;
    var displayed_drilldown;
    var displayed_legend;
    var displayed_text;
    var robot_session = this.robot_session;
    var xpath_lib = this.xpath_lib;
    var my_waitDefault = this.waitDefault;
    var displayed_label;
    var concentrationReportList = []; // only for Concentration Report Chart Builder
    expected_row_list.forEach(function(row, index) {
      var x_labelItem_selector = '(' + myChart_x_label + ')[' + (index + 1) + ']';
      var drilldownItem_selector = '(' + myChart_x_label + ')[' + (index + 1) + ']';
      // if (row['text']) {
      //   displayed_chartText = browser.getText(myChart);
      //   expect(displayed_chartText).toContain(row['text']);
      // }
      if (row['x_title']) {
        displayed_x_title = browser.getText(myChart_x_title);
        switch (action) {
          case 'contain':
            expect(displayed_x_title).toContain(row['x_title']);
            break;
          case 'match':
            expect(displayed_x_title).toMatch(my_regex_lib.replaceRegex(row['x_title']));
            break;
        }
      }
      if (row['y_title']) {
        displayed_y_title = browser.getText(myChart_y_title);
        switch (action) {
          case 'contain':
            expect(displayed_y_title).toContain(row['y_title']);
            break;
          case 'match':
            expect(displayed_y_title).toMatch(my_regex_lib.replaceRegex(row['y_title']));
            break;
        }
      }
      if (row['y_title_1']) {
        displayed_y_title = browser.getText('(' + myChart_y_title + ')[1]');
        switch (action) {
          case 'contain':
            expect(displayed_y_title).toContain(row['y_title_1']);
            break;
          case 'match':
            expect(displayed_y_title).toMatch(my_regex_lib.replaceRegex(row['y_title_1']));
            break;
        }
      }
      if (row['y_title_2']) {
        displayed_y_title = browser.getText('(' + myChart_y_title + ')[2]');
        switch (action) {
          case 'contain':
            expect(displayed_y_title).toContain(row['y_title_2']);
            break;
          case 'match':
            expect(displayed_y_title).toMatch(my_regex_lib.replaceRegex(row['y_title_2']));
            break;
        }
        expect(displayed_y_title).toContain(row['y_title_2']);
      }
      if (row['x_label']) {
        displayed_x_label = browser.getText(x_labelItem_selector).replace(/ /g,' :: ');
        switch (action) {
          case 'contain':
            expect(displayed_x_label).toContain(row['x_label']);
            break;
          case 'match':
            expect(displayed_x_label).toMatch(my_regex_lib.replaceRegex(row['x_label']));
            break;
        }
      }
      if (row['y_label_row']) {
        console.log(myChart_y_label);
        console.log(browser.isVisible(myChart_y_label));
        var y_labelItem_selector = '(' + myChart_y_label + ')[' + (index + 1) + ']';
        console.log(browser.getText(y_labelItem_selector));
        displayed_y_label = browser.getText(y_labelItem_selector).replace(/ /g,' :: ');
        console.log('y_labelItem_selector: ' + displayed_y_label);
        switch (action) {
          case 'contain':
            expect(displayed_y_label).toContain(row['y_label_row']);
            break;
          case 'match':
            expect(displayed_y_label).toMatch(my_regex_lib.replaceRegex(row['y_label_row']));
            break;
        }
      }
      if (row['y_label']) {
        console.log(myChart_y_label);
        console.log(browser.isVisible(myChart_y_label));
        console.log(browser.getText(myChart_y_label));
        var mychart_y_text = browser.getText(myChart_y_label);
        displayed_y_label = Array.isArray(mychart_y_text) ? mychart_y_text.join(' :: ') : mychart_y_text;
        // displayed_y_label = browser.getText(myChart_y_label).join(' :: ');
        console.log('displayed_y_label: ' + displayed_y_label);
        switch (action) {
          case 'contain':
            expect(displayed_y_label).toContain(row['y_label']);
            break;
          case 'match':
            expect(displayed_y_label).toMatch(my_regex_lib.replaceRegex(row['y_label']));
            break;
        }
      }
      if (row['y_label_1']) {
        console.log(my_Chart_y_wholeLabel);
        console.log(browser.isVisible(my_Chart_y_wholeLabel));
        console.log(browser.getText('(' + my_Chart_y_wholeLabel + ')[1]//*[text()]'));
        displayed_y_label = browser.getText('(' + my_Chart_y_wholeLabel + ')[1]//*[text()]').join(' :: ');
        switch (action) {
          case 'contain':
            expect(displayed_y_label).toContain(row['y_label_1']);
            break;
          case 'match':
            expect(displayed_y_label).toMatch(my_regex_lib.replaceRegex(row['y_label_1']));
            break;
        }
      }
      if (row['y_label_2']) {
        displayed_y_label = browser.getText('(' + my_Chart_y_wholeLabel + ')[2]//*[text()]').join(' :: ');
        switch (action) {
          case 'contain':
            expect(displayed_y_label).toContain(row['y_label_2']);
            break;
          case 'match':
            expect(displayed_y_label).toMatch(my_regex_lib.replaceRegex(row['y_label_2']));
            break;
        }
      }
      if (row['drilldown']) {
        myChart_drilldown = myChart + '//a[text()]';
        displayed_drilldown = browser.getText(myChart_drilldown);
        switch (action) {
          case 'contain':
            expect(displayed_drilldown).toContain(row['drilldown']);
            break;
          case 'match':
            expect(displayed_drilldown).toMatch(my_regex_lib.replaceRegex(row['drilldown']));
            break;
        }
      }
      if (row['percent_label']) {
        displayed_label = browser.getText(myChart_label).toString();
        switch (action) {
          case 'contain':
          expect(displayed_label).toContain(row['percent_label']);
          break;
          case 'match':
          expect(displayed_label).toMatch(my_regex_lib.replaceRegex(row['percent_label']));
          break;
          case 'regex': // for CLO DEAL Concentration
            // console.log(displayed_label);
            var displayValue = displayed_label.split('\n');
            console.log(displayValue);
            if(expected_row_list.length != 1){
              var data = displayValue[index].split('%')[0] + '%';
              concentrationReportList.push(data);
              expect(data.replace(/ /g,'')).toMatch(my_regex_lib.replaceRegex(row['percent_label'].replace(/ /g,'')));
              break;
            }
            for(var i=0;i<displayValue.length;i++){
              // console.log('**************');
              var data = displayValue[i].split('%')[0] + '%';
              concentrationReportList.push(data);
              expect(data.replace(/ /g,'')).toMatch(my_regex_lib.replaceRegex(row['percent_label'].replace(/ /g,'')));
            }
            break;
        }
      }
      // if (row['tooltip']) {
      //   var token_list = row['tooltip'].split(' :: ');
      //   token_list.forEach(function(token) {
      //     token=token.trim();
      //     myChart_tooltip = myChart + content_xpath.chartTooltip;
      //     displayed_tooltip = browser.getText(myChart_tooltip).toString();
      //     console.log(myChart_tooltip);
      //     console.log(displayed_tooltip);
      //     // here we move the mouse to the label and above by 5 to display the tooltip
      //     // we try 4 positions here
      //     for (var i=1; i<=4; i++) {
      //       try {
      //         robot_session.moveMouse(browser, x_labelItem_selector, false, null, false, 'center', 0, -10*i);
      //         browser.waitForVisible(myChart_tooltip, my_waitDefault/2);
      //         browser.pause(100);
      //         break;
      //       } catch(e) {
      //         continue;
      //       }
      //     };
      //     console.log('tooltip_xpath: ' + myChart_tooltip);
      //     console.log('tooltip_text: ' + displayed_tooltip);
      //     console.log('expected_text: ' + token);
      //     switch (action) {
      //       case 'contain':
      //         expect(displayed_tooltip).toContain(token);
      //         break;
      //       case 'match':
      //         expect(displayed_tooltip).toMatch(my_regex_lib.replaceRegex(token));
      //         break;
      //     }
      //   });
      // }
      if (row['legend']) {
        console.log(myChart_legend);
        displayed_legend = browser.getText(myChart_legend).toString();
        switch (action) {
          case 'contain':
            expect(displayed_legend.replace(/ /g,'')).toContain(row['legend'].replace(/ /g,''));
            break;
          case 'match':
            expect(displayed_legend.replace(/ /g,'')).toMatch(my_regex_lib.replaceRegex(row['legend'].replace(/ /g,'')));
            break;
          case 'regex': // for CLO DEAL Concentration
            var displayed_legend_list = displayed_legend.split('\n');
            for(var i=0;i<displayed_legend_list.length;i++){
              expect(displayed_legend_list[i].replace(/ /g,'')).toMatch(my_regex_lib.replaceRegex(row['legend'].replace(/ /g,'')));
            }
            break;
        }
      }
      if (row['text']) {
        displayed_text = browser.getText(myChart).toString();
        switch (action) {
          case 'contain':
            expect(displayed_text).toContain(row['text']);
            break;
          case 'match':
            expect(displayed_text).toMatch(my_regex_lib.replaceRegex(row['text']));
            break;
        }
      }
    });

    this.concentrationReportList = concentrationReportList;
    console.log('concentrationReportList: ' + this.concentrationReportList);
  });
}