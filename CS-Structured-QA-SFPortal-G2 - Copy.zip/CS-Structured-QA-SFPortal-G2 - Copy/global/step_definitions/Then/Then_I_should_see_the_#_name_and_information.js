// Recommended filename: Then_I_should_see_my_portfolio_name_and_tranche_information.js
module.exports = function() {
  this.Then(/^I should see the "([^"]*)" name and information$/, function (pageType) {
    // Write the automation code here
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const portfolioPage_xpath = this.xpath_lib.xpathRequire('portfolioPage_xpath');
    const managerPage_xpath = this.xpath_lib.xpathRequire('managerPage_xpath');
    const dealPage_xpath = this.xpath_lib.xpathRequire('dealPage_xpath');

    // browser.pause(1000);
    this.browser_session.waitForLoading(browser);
    switch(pageType){
        case 'portfolio':
            console.log('found this.portfolio = ' + this.portfolio);
            var my_portfolio_section_selector = portfolioPage_xpath.portfolioMainContent;
            var my_portfolio_name_selector = portfolioPage_xpath.namedPortfolioName.replace('__NAME__', this.portfolio);
            browser.waitForVisible(my_portfolio_name_selector, this.waitDefault);
            var my_portfolio_header_selector = portfolioPage_xpath.portfolioInfoHeader;
            var my_portfolio_name_text = browser.getText(my_portfolio_name_selector);
            var my_ListOfTranches_Section = content_xpath.titledSection.replace('__TITLE__', 'List of Tranches')
            console.log(my_ListOfTranches_Section);
            console.log(my_portfolio_header_selector);
            var my_portfolio_header_text = browser.getText(my_portfolio_header_selector);
            console.log(my_portfolio_header_text);
            expect(my_portfolio_name_text).toContain(this.portfolio);
            // expect(my_portfolio_header_text).toContain(this.portfolio_tranche_count);
            expect(my_portfolio_header_text).not.toContain("undefined");
            break;
        case 'manager':
            console.log('found this.manager = ' + this.manager);
            var manager_section_selector = managerPage_xpath.managerMainContent;
            var manager_name_selector = managerPage_xpath.namedManagerName.replace('__NAME__', this.manager);
            browser.waitForVisible(manager_name_selector, this.waitDefault);
            var manager_header_selector = managerPage_xpath.managerInfoHeader;
            var manager_name_text = browser.getText(manager_name_selector);
            var LossMitigation_Section = content_xpath.titledSection.replace('__TITLE__', 'Loss Mitigation')
            var manager_header_text = browser.getText(manager_header_selector);
            expect(manager_name_text).toContain(this.manager);
            expect(manager_header_text).not.toContain("undefined");
            break;
        case 'deal':
            console.log('found this.deal = ' + this.deal);
            var deal_section_selector = dealPage_xpath.dealMainContent;
            var deal_name_selector = dealPage_xpath.namedDealName.replace('__NAME__', this.deal);
            browser.waitForVisible(deal_name_selector, this.waitDefault);
            var deal_header_selector = dealPage_xpath.dealInfoHeader;
            var deal_name_text = browser.getText(deal_name_selector);
            var deal_header_text = browser.getText(deal_header_selector);
            expect(deal_name_text).toContain(this.deal);
            expect(deal_header_text).not.toContain("undefined");
            break;
    }
  });
};