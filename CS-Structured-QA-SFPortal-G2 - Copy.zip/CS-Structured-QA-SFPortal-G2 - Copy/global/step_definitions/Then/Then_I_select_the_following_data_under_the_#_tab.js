// Recommended filename : Then_I_select_the_following_data_under_the_#_tab.js
module.exports = function() {
       this.Then(/^I select the following data under the "([^"]*)" tab$/, function (arg1, table) {
         // Write code here that turns the phrase above into concrete actions
         const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
         var expected_item_list = table.hashes();
         var self = this;
          console.log('setting');
         expected_item_list.forEach(function(list_row){
          switch(list_row.name){
            case  "Base":
              browser.click(content_xpath.mdyRatesBase);
              browser.waitForVisible(content_xpath.selectBox3,self.waitDefault);
              browser.click(content_xpath.selectOption.replace('__OPTION__',list_row.setting));
            break;
            case "Index":
              browser.click(content_xpath.mdyRatesIndex);
              browser.waitForVisible(content_xpath.selectBox3,self.waitDefault);
              browser.click(content_xpath.selectOption.replace('__OPTION__',list_row.setting));
            break;
            case "Relevant rates":
              var relevant_value = browser.getAttribute(content_xpath.relevant_rates,'aria-checked');
              console.log('relevant_value:' + relevant_value);
              console.log('list_row.setting:'+list_row.setting);
              if(list_row.setting!=relevant_value){
                console.log('click');
                browser.click(content_xpath.relevant_rates);
              }
            break;
            default:
              console.log('no setting');
            break;
          }
         });
       });
};

