// Then_I_should_see_the_settings_for_the_#_business_rule_as_below.js
module.exports = function() {
  this.Then(/^I should see the settings for the (first|second|third|fourth|fifth) business rule as below$/, function (arg1,table) {
    // Write code here that turns the phrase above into concrete actions
    const settingsPage_xpath = this.xpath_lib.xpathRequire('settingsPage_xpath');

    var tableList = table.hashes();
    var nth_index;

    switch (arg1) {
        case "first":
            nth_index = 1;
            break;
        case "second":
            nth_index = 2;
            break;
        case "third":
            nth_index = 3;
            break;
         case "fourth":
            nth_index = 4;
            break;
        case "fifth":
            nth_index = 5;
            break;
    };
    this.browser_session.waitForResource(browser);
    
    for(var i=0;i<tableList.length;i++){
      var rule = tableList[i]['rule'];
      var value = tableList[i]['value'];
      switch(rule){
        case 'selectedType':
        case 'rule.asset_type':
        case 'rule.asset_scope':
        case 'rule.loan_status':
        case 'rule.action':
        case 'rule.filter':
        case 'rule.filter_val':
          var businessRuleSelect = "(" + settingsPage_xpath.businessRuleSelect.replace('__NAME__', rule) + ")[" +nth_index+ "]";
          console.log(businessRuleSelect);
          expect(browser.getText(businessRuleSelect)).toEqual(value); 
          break;
        case 'rule.price':
        case 'rule.id':
          var businessRuleInput = "(" + settingsPage_xpath.businessRuleInput.replace('__NAME__', rule) + ")[" +nth_index+ "]";
          console.log(businessRuleInput);
          expect(browser.getValue(businessRuleInput)).toEqual(value); 
          break;
      }
      this.browser_session.waitForResource(browser);
    }
  });
}