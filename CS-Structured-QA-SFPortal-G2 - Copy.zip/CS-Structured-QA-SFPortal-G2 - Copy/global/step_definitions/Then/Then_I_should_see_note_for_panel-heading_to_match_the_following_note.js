module.exports = function(){
 this.Then(/^I should see note for panel-heading to match the following note$/, function (table) {
         // Write code here that turns the phrase above into concrete actions
  const content_xpath = this.xpath_lib.xpathRequire('content_xpath');

  var row_list = table.hashes();
  for(var i = 0; i<row_list.length; i++){
    if(row_list[i].method == 'under'){
      var textForNote = browser.getText(content_xpath.notesUnderWidget);
      expect(textForNote).toMatch(row_list[i].note);
    }
    else{
      switch(row_list[i].widgetName){
        case 'Notable Metrics':
        case 'Capital Structure':
          var note = content_xpath.notesInWidget1.replace('__WIDGETNAME__', row_list[i].widgetName);
          console.log(note);
          var textForNote = browser.getText(note);
          expect(textForNote).toMatch(row_list[i].note);
          break;
        case 'Apply Stratification':
          var cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
          var note = browser.getText('('+ cashflow_xpath.StratificationTable +'/parent::div/following-sibling::div)[1]').replace(/\n/g,'');
          expect(note).toEqual(row_list[i].note);
          break;
        case 'CDO Stratification' :
          var cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
          console.log(browser.getText(cashflow_xpath.StratificationTable+'/parent::div/following-sibling::span'));
          var note = browser.getText(cashflow_xpath.StratificationTable+'/parent::div/following-sibling::span').toString().replace(/\n/g,'');
          expect(note).toEqual(row_list[i].note);
          break;
        case 'Loan Level Assumptions':
          var note = browser.getText('//*[@ng-controller="cmbsLoanLevelAssumpController as loanLevelAssumpCtrl"]/div[2]/div[1]').replace(/\n/g,'');
          console.log(note);
          expect(note).toEqual(row_list[i].note);
          break;
        case 'Results':
          var note = content_xpath.titledSectionLowercaseDiv.replace('__TITLE__', row_list[i].widgetName.toLowerCase()) + '//*[contains(text(),"'+row_list[i].note+'")]';
          console.log(note);
          browser.waitForVisible(note,this.waitDefault);
          break;
        case 'Solely for payments of Principal and Interest (SPPI) Metrics':
          var note = browser.getText('//*[@class="reg-agg-disclaimer"]')
          note = Array.isArray(note) ? note.join() : note;
          console.log(note);
          expect(note).toContain(row_list[i].note)
          break;
        default:
          var note = content_xpath.notesInWidget.replace('__TITLE__', row_list[i].widgetName.toLowerCase()).replace('__NOTES__', row_list[i].note);
          console.log(note);
          browser.waitForVisible(note,this.waitDefault);
          break;
      }
      //To be implemented
     } 
    }   
   });
};