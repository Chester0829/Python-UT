// Recommended filename: Then_I_should_see_below_information_under_the_#_panel-heading.js
module.exports = function() {
 this.Then(/^I should see below information under the "([^"]*)" panel\-heading$/, 
 	{timeout: process.env.StepTimeoutInMS * 10},
 	function (widget, table) {
  // Write code here that turns the phrase above into concrete actions
  // return 'pending';
  this.browser_session.waitForResource(browser);
  this.browser_session.waitForLoading(browser);
  // this.browser_session.waitForRender(browser);

  const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
  var myPanel = content_xpath.titledPanelLowercase.replace('__TITLE__', widget.toLowerCase());

  var tableList = browser.getText(myPanel + '//table');
  console.log(tableList);

  var expectList =table.hashes();
  console.log(expectList);

  expect(tableList.length).toEqual(expectList.length);
  for(var i=0;i<expectList.length;i++){
  	var item = expectList[i]['row_data'].replace(/ :: /g, ' ');
  	console.log(item);
  	expect(tableList.indexOf(item) != -1).toBe(true);
  }


 });
}