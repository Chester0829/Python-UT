// Then_I_can_get_below_value_under_the_#_panel-heading_in_deal_mode.js
//	| row_data |
module.exports = function() {
	this.Then(/^I can get below value under the "([^"]*)" panel-heading in deal mode$/, 
		{timeout:process.env.StepTimeoutInMS*5},
		function (panelName, table) {
			var table_list = table.hashes();
			var item_list = [];
			for(var i=0;i<table_list.length;i++){
				item_list.push(table_list[i]['row_data']);
			}
			console.log(item_list);

			this.browser_session.waitForResource(browser);
			const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
			const selectOption_xpath = this.xpath_lib.xpathRequire('selectOption_xpath');
			if(panelName == 'main'){
			var myPanel = '//div[@class="container" or @id="content"]';
			}else{
				var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase());
			}
	    if (!process.env.BROWSER.startsWith('IE')) {
	      browser.touchScroll(browser.element(myPanel).value['ELEMENT'], 0, 200 );
	    }
	    // set max vaule
	    var selectIcon= selectOption_xpath.selectIcon;
			var selectMenu = selectOption_xpath.selectMenu;
			var selectOption = selectOption_xpath.selectOption.replace('__OPTIONTEXT__',200);
			browser.waitForVisible(myPanel + selectIcon, this.waitDefault);

			// this browser.click step is replaced by the below steps
			// browser.click(myPanel + selectIcon);
			var mySelectCaret_xpath = myPanel + selectIcon;
			// try to click the select caret, if not clickable (md-select) click the main md-select
	    this.browser_session.waitForLoading(browser);
	    try {
	        console.log('click try: ' + mySelectCaret_xpath);
	        browser.click(mySelectCaret_xpath);
	    } catch (e) {
	        if (mySelectCaret_xpath.includes('md-select')) {
	            console.log('click: md-select');
	            browser.click(mySelectCaret_xpath + '/ancestor::*[contains(@class, "ui-select-container") or name()="md-select"][1]')
	        } else {
	          console.log(e);
	        }
	    }

			browser.waitForVisible(selectMenu,this.waitDefault);
			browser.click(selectMenu + selectOption);
			this.browser_session.waitForResource(browser);
			// get table json
			var table_xpath = myPanel + content_xpath.descendantDataTable;
			var htmls = browser.getHTML(table_xpath);
			var table_json = this.tabletojson.convert(htmls)[0];
			var result = [];
			for(var i=0;i<table_json.length;i++){
				var entry = table_json[i];
				var tmp = [];
				for(var j=0;j<item_list.length;j++){
					tmp.push(entry[item_list[j]].replace('N/A',' '));
				}
				result.push(tmp);
			}
			this.deal_result = result;
			console.log(result);



	})
}