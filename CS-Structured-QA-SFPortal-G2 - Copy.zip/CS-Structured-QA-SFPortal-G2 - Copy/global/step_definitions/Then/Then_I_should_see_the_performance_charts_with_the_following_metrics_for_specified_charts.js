// Recommended filename: Then_I_should_see_the_performance_charts_with_the_following_metrics_for_specified_charts.js
module.exports = function() {
  this.Then(/^I should see the performance charts with the following metrics for specified charts$/, {timeout: process.env.StepTimeoutInMS}, function(table) {
    var expected_list = table.hashes();
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    var metricInput_xpath = content_xpath.charts_fields;
    var self = this;
      expected_list.forEach(function(expected_item){
        var chartMetricInput = '(' + metricInput_xpath + ')[' + expected_item['charts'] + ']';
        // browser.waitForExist(chartMetricInput,self.waitMax)
        // browser.waitForVisible(chartMetricInput,self.waitDefault)
        var metricsText=browser.getText(chartMetricInput)
        console.log(metricsText)
        expect(metricsText).toContain(expected_item['dropdown_item'])
      })
  });
};
