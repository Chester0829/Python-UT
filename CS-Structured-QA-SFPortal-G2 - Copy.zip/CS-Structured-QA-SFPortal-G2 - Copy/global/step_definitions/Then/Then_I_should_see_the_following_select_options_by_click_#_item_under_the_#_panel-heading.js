// Then_I_should_see_the_following_select_options_by_click_#_item_under_the_#_panel-heading.js
// CMBS Deal Analytics Dynamic CFS Page - Forward Curve
module.exports = function() {
  this.Then(/^I should see the following select options by click "([^"]*)" item under the "([^"]*)" panel\-heading$/, function (targetXpath, widgetName,table) {
    var cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
    var content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    if(this.deal){
      var root_xpath = cashflow_xpath.showForward;  
    }else if(this.portfolio){
      var root_xpath = cashflow_xpath.cmbsCustomRate;
    }
    var activeSelectMenu = cashflow_xpath.activeSelectMenu;

    var tableList = table.hashes();
    // ratesCtrl.customRatesBase
    if(targetXpath == 'ratesCtrl.customRatesBase'){
      // uncheck relevantRates
      var checkbox = root_xpath + '//*[@ng-model="ratesCtrl.relevantOpt"]';
      var isChecked = browser.getAttribute(checkbox,'aria-checked');
      if(isChecked == 'true'){
        browser.click(checkbox);
        //browser.pause(1000);
        this.browser_session.waitForResource(browser);
      }
    }

    // if(['benchCtrl.selectedMetric','benchCtrl.benchChartType','benchCtrl.selectedOption'].indexOf(targetXpath) != -1){
    if(targetXpath.startsWith('benchCtrl') || targetXpath.startsWith('dtCtrl')){
      // CMBS Benchmarking setting
      var root_xpath = content_xpath.titledSection.replace('__TITLE__',widgetName);
      switch(targetXpath){
        case 'benchCtrl.selectedOption':
        case 'benchCtrl.benchChartType':
        case 'benchCtrl.selectedMetric':
        case 'benchCtrl.selectedMetricX':
        case 'benchCtrl.selectedMetricY':
        case 'dtCtrl.selectedOption':
        case 'dtCtrl.benchChartType':
        case 'dtCtrl.selectedMetric':
        case 'dtCtrl.selectedMetricX':
        case 'dtCtrl.selectedMetricY':
          // click
          this.browser_session.waitForResource(browser);
          browser.waitForVisible(root_xpath,this.waitDefault);
          var mdSelect = root_xpath + '//*[@ng-model="'+ targetXpath +'"]';
          var mdSelectMenu = activeSelectMenu;
          console.log(mdSelect);
          console.log(mdSelectMenu);
          this.browser_session.waitForLoading(browser);
          browser.waitForValue(mdSelect,this.waitDefault);
          browser.click(mdSelect);
          browser.pause(500);
          browser.waitForVisible(mdSelectMenu,this.waitDefault);
          var tmp = browser.getText(mdSelectMenu).split('\n');
          // delete ""
          var optionsList = tmp.filter(function(currentValue){return currentValue.length != 0});
          console.log(optionsList);
          var itemXpath = activeSelectMenu + '//*[text()="'+ optionsList[0] +'"]';
          console.log(itemXpath)
          browser.waitForVisible(itemXpath,this.waitDefault);
          browser.click(itemXpath);
          browser.pause(500);
          for(var i=0;i<tableList.length;i++){
            expect(tableList[i]['Base_item']).toEqual(optionsList[i]);
          }
          break;
      } 
      return;
    }

    for(var i=0;i<tableList.length;i++){
      var Base_item = tableList[i]['Base_item'];
      var IndexList = tableList[i]['IndexList'];
      var indexType = tableList[i]['IndexXpath'];
      switch(targetXpath){
        case 'ratesCtrl.mdyRatesBase':
        case 'ratesCtrl.customRatesBase':
          var mdSelect = root_xpath + cashflow_xpath.mdSelect.replace('__NAME__',targetXpath); 
          var mdSelectMenu = activeSelectMenu + '//*[text()="'+ Base_item +'"]';
          var indexXpath = root_xpath + cashflow_xpath.mdSelect.replace('__NAME__',indexType);
          // console.log(mdSelect);
          browser.waitForValue(mdSelect,this.waitDefault);
          browser.click(mdSelect);
          browser.waitForVisible(mdSelectMenu,this.waitDefault);
          console.log(mdSelectMenu);
          browser.click(mdSelectMenu);
          browser.pause(1000); // use pause instead of waitForResource
          // this.browser_session.waitForResource(browser);
          console.log(indexXpath);
          browser.click(indexXpath);
          browser.pause(1000); // use pause instead of waitForResource
          // this.browser_session.waitForResource(browser);
          var textList = browser.getText(activeSelectMenu).split('\n');
          // console.log(textList);
          // console.log(IndexList);
          expect(textList.join('')).toEqual(IndexList.replace(/_/g,''));
          // console.log('*************');
          // for Forward Curve
          for(var j=0;j<textList.length;j++){
            // console.log(textList[j]);
            var indexSubValue = activeSelectMenu + '//*[text()="'+ textList[j] + '"]';
            // console.log(indexSubValue);
            browser.click(indexSubValue);
            browser.pause(1000); // use pause instead of waitForResource
            // this.browser_session.waitForResource(browser);

            // if(browser.isVisible(root_xpath + '//table//thead')){
            if(indexType == 'ratesCtrl.customRatesIndex'){
              // for Custom Rates tab
              var curvetTble = root_xpath + '//table//thead//th';
              var thead = browser.getText(curvetTble);
              console.log('thead: ' + thead);
            }else if(indexType == 'ratesCtrl.mdyRatesIndex'){
              // Moody's Rates
              var curvetTble = '(' + root_xpath + '//table//tbody)[2]';
              var thead = browser.getText(curvetTble + '//tr[1]//td');
              console.log('thead: ' + thead);
            }
            if(j == textList.length - 1) {continue;}
            browser.click(indexXpath);
            browser.pause(1000); // use pause instead of waitForResource
            // this.browser_session.waitForResource(browser);
          }
          break;
        
      }

    }



  })


}