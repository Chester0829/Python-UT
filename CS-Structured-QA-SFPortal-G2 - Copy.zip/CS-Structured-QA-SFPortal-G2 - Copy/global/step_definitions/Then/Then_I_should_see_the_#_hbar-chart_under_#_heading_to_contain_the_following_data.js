// Recommended filename: Then_I_should_see_the_#_hbar-chart_under_#_heading_to_contain_the_following_data.js
module.exports = function() {
    this.Then(/^I should see the "([^"]*)" hbar\-chart under "([^"]*)" heading to (contain|match) the following data$/, 
    function (chartTitle, panelName, action, table) {
      // Write the automation code here
      //browser.pause(1000);
      this.browser_session.waitForResource(browser);
      this.browser_session.waitForLoading(browser);
      //this.browser_session.waitForRender(browser);
      var expected_row_list = table.hashes();

      const my_regex_lib = this.regex_lib;
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase());
      var myChart = myPanel + content_xpath.namedPieChar.replace(/__NAME__/g, chartTitle);

      console.log(myChart);
      browser.getLocationInView(myChart);
      var myChart_title = myChart + content_xpath.chartTitle;
      var myChart_x_label = myChart + content_xpath.chartXLabel;
      var myChart_y_label = myChart + content_xpath.chartYLabel;
      var myChart_legend = myChart + content_xpath.chartLegend;

      var displayed_title_text;
      var displayed_x_label;
      var displayed_y_label;
      var displayed_legend;

      expected_row_list.forEach(function(row) {
        if (row['title']) {
          displayed_title_text = browser.getText(myChart_title).toString();
          switch(action) {
            case 'contain': expect(displayed_title_text).toContain(row['title']); break;
            case 'match' : expect(displayed_title_text).toMatch(my_regex_lib.replaceRegex(row['title'])); break;
          }
        }
        if (row['x_label']) {
          displayed_x_label = browser.getText(myChart_x_label).toString().replace(/ /g,'');
          switch(action) {
            case 'contain': expect(displayed_x_label).toContain(row['x_label'].replace(/ /g,'')); break;
            case 'match' : expect(displayed_x_label).toMatch(my_regex_lib.replaceRegex(row['x_label']).replace(/ /g,'')); break;
          }
        }
        if (row['y_label']) {
          displayed_y_label = browser.getText(myChart_y_label).toString().replace(/ /g,'');
          switch(action) {
            case 'contain': expect(displayed_y_label).toContain(row['y_label'].replace(/ /g,'')); break;
            case 'match' : expect(displayed_y_label).toMatch(my_regex_lib.replaceRegex(row['y_label']).replace(/ /g,'')); break;
          }
        }
        if (row['legend']) {
          displayed_legend = browser.getText(myChart_legend).toString().replace(/ /g,'');
          switch(action) {
            case 'contain': expect(displayed_legend).toContain(row['legend'].replace(/ /g,'')); break;
            case 'match' : expect(displayed_legend).toMatch(my_regex_lib.replaceRegex(row['legend']).replace(/ /g,'')); break;
          }
        }
      });

    });
  };
  