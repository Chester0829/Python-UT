// Then_I_should_see_the_rule_that_before_created_should_be_match_the_following_information_under_the_#_panel-heading.js
// only for Stratification
module.exports = function(){
  this.Then(/^I should see the rule that before created should be match the following information under the "([^"]*)" panel\-heading$/, function (arg1, table) {
      // Write code here that turns the phrase above into concrete actions
      var cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');

      var rule_item_list = table.hashes();
      for(var i=0;i<rule_item_list.length;i++){
        var column = rule_item_list[i]['row_item'];
        var value = rule_item_list[i]['value'];
        // console.log('column: ' + column + ', value: ' + value);
        switch(column){
          case 'watch.type1':
          case 'watch.type2':
          case 'watch.type3':
          case 'watch.prepaytype':
          case 'watch.defaulttype':
            // var mdSelect = '//md-select[@ng-model="'+ column +'"]';
            var mdSelect = cashflow_xpath.mdSelect.replace('__NAME__',column);
            var tmp = browser.isVisible(mdSelect);
            var mdSelectLen = Array.isArray(tmp) ? tmp.length : 1; 
            // console.log('(' + mdSelect +')[' + mdSelectLen + ']');
            expect(browser.getText('(' + mdSelect +')[' + mdSelectLen + ']')).toEqual(value);
            break;
          case 'watch.min1':
            var uiSelectMatch = '//div[@ng-model="'+ column +'"]';
            var tmp = browser.isVisible(uiSelectMatch);
            var uiSelectMatchLen = Array.isArray(tmp) ? tmp.length : 1;
            // console.log('(' + uiSelectMatch + ')[' + uiSelectMatchLen +']');
            expect(browser.getText('(' + uiSelectMatch + ')[' + uiSelectMatchLen +']')).toEqual(value);
            break;
          case 'watch.max1':
          case 'watch.min2':
          case 'watch.max2':
          case 'watch.min3':
          case 'watch.max3':
          case 'watch.NOI_growth_rate':
          case 'watch.cap_rate_growth_rate':
          case 'watch.term_triggers_LTV_liquidate':
          case 'watch.term_triggers_LTV_months':
          case 'watch.term_triggers_LTV_loss':
          case 'watch.term_triggers_DSCR_liquidate':
          case 'watch.term_triggers_DSCR_months':
          case 'watch.term_triggers_DSCR_loss':
          case 'watch.maturity_trigger_LTV_payoff':
          case 'watch.maturity_trigger_LTV_liquidate':
          case 'watch.maturity_trigger_LTV_loss':
          case 'watch.maturity_trigger_LTV_extension':
          case 'watch.maturity_trigger_LTV_end_of_extension_liq_or_payoff':
          case 'watch.maturity_trigger_LTV_end_of_extension_loss':
          case 'watch.maturity_trigger_DY_payoff':
          case 'watch.maturity_trigger_DY_liquidate':
          case 'watch.maturity_trigger_DY_loss':
          case 'watch.maturity_trigger_DY_extension':
          case 'watch.maturity_trigger_DY_end_of_extension_liq_or_payoff':
          case 'watch.maturity_trigger_DY_end_of_extension_loss':
          case 'watch.prepayrate':
          case 'watch.defaultrate':
          case 'watch.lossrate':
          case 'watch.lagmonths':
            // var sfpTextInput = '//sfp-text-input[@ng-model="'+ column +'"]//input';
            var sfpTextInput = cashflow_xpath.sfpTextInput.replace('__NAME__',column) + '//input';
            var tmp = browser.isVisible(sfpTextInput);
            if(!tmp){
              sfpTextInput = '//input[@ng-model="'+ column +'"]';
              tmp = browser.isVisible(sfpTextInput); 
            }
            var sfpTextInputLen = Array.isArray(tmp) ? tmp.length : 1;
            // console.log('(' + sfpTextInput + ')[' + sfpTextInputLen + ']');
            if(value == 'disabled'){
              var isDisable = browser.getAttribute('(' + sfpTextInput + ')[' + sfpTextInputLen + ']','disabled');
              expect(isDisable).toEqual('true');
            }else{
              expect(browser.getValue('(' + sfpTextInput + ')[' + sfpTextInputLen + ']')).toEqual(value);
            }
            break;
          case 'watch.NOI_growth_rate_type':
          case 'watch.cap_rate_growth_rate_type':
          case 'watch.term_triggers_select_priority':
          case 'watch.lossType':
          case 'watch.maturity_trigger_select_priority':
            // var mdSelect = '//md-select[@ng-model="'+ column +'"]';
            var mdSelect = cashflow_xpath.mdSelect.replace('__NAME__',column);
            var tmp = browser.isVisible(mdSelect);
            var mdSelectLen = Array.isArray(tmp) ? tmp.length : 1;
            // console.log('(' + mdSelect + ')[' + mdSelectLen + ']');
            expect(browser.getText('(' + mdSelect + ')[' + mdSelectLen + ']')).toEqual(value);
            break;
          case 'watch.term_triggers_activate_LTV_trigger':
          case 'watch.term_triggers_activate_DSCR_trigger':
          case 'watch.maturity_trigger_activate_LTV_trigger':
          case 'watch.maturity_trigger_activate_DY_trigger':
            // var sfpCheckbox = '//sfp-checkbox[@ng-model="'+ column +'"]';
            var sfpCheckbox = cashflow_xpath.sfpCheckbox.replace('__NAME__',column);
            var tmp = browser.isVisible(sfpCheckbox);
            var sfpCheckboxLen = Array.isArray(tmp) ? tmp.length : 1;
            // console.log('(' + sfpCheckbox + ')[' + sfpCheckboxLen + ']');
            var checkedStatus = browser.getAttribute('(' + sfpCheckbox + ')[' + sfpCheckboxLen + ']','class');
            // console.log(checkedStatus);
            if(value == 'checked'){
              // ng-valid ng-dirty ng-valid-parse ng-touched ng-not-empty
              expect(checkedStatus).toContain('ng-not-empty');
            }else if(value == 'unchecked'){
              // ng-valid ng-dirty ng-valid-parse ng-touched ng-empty
              expect(checkedStatus).toContain('ng-empty');
            }
            break;
          
        }
  
      }


    });

}
