// Recommended filename:
module.exports = function() {
  this.Then(/^I should see all the above metrics and legends in (deal|other) (mode|mode for specified charts)$/, 
    {timeout: process.env.StepTimeoutInMS}, 
    function(arg1,type) {
    // Write the automation code here
    var expected_list = this.expected_list;
    var cohort_list = this.cohort_table
    const performancePage_xpath = this.xpath_lib.xpathRequire('performancePage_xpath');
    var waitDefault = this.waitDefault;
    var waitMax = this.waitMax
    var self = this;
    var refresh= false
    if(this.refresh!=undefined){refresh=this.refresh}
    if(type == 'mode for specified charts'){
      expected_list.forEach(function(expected_item){
        var myLegend_xpath = '('+performancePage_xpath.historicalChart+')['+expected_item['charts']+']'+performancePage_xpath.labeledLegend.replace('__LABEL__',expected_item['dropdown_item']);
         if (arg1 == 'deal'){
            myLegend_xpath = '('+performancePage_xpath.historicalChart+')['+expected_item['charts']+']'+performancePage_xpath.labeledLegend.replace('__LABEL__',expected_item['dropdown_item'] + "_" + self.pool);
         }
        browser.waitForVisible(myLegend_xpath,waitMax)
        //Cannot save Cohort Selection, pending in WSAPORTAL-6659    
        if(expected_item['cohort']=='Y' && refresh!=true){
          cohort_list.forEach(function(cohort_item){
            var cohort_myLegend_xpath = '('+performancePage_xpath.historicalChart+')['+expected_item['charts']+']'+performancePage_xpath.labeledLegend.replace('__LABEL__',expected_item['dropdown_item']+' ('+cohort_item['cohort_item']+')');
            console.log(cohort_myLegend_xpath)
            browser.waitForVisible(cohort_myLegend_xpath,waitMax)
            browser.pause(100)
          })
        }
        browser.pause(100)
        // var expected_item['dropdown_item']
      })
    }else{
      expected_list.forEach(function(expected_item, index) {
        var myLegend_xpath = performancePage_xpath.labeledLegend.replace('__LABEL__', expected_item['dropdown_item']);
        if (arg1 == 'deal'){
          myLegend_xpath = performancePage_xpath.labeledLegend.replace('__LABEL__', expected_item['dropdown_item'] + "_" + self.pool);
          console.log(myLegend_xpath);
        }
        if (expected_item['should_show']) {
          switch (expected_item['should_show']) {
            case 'N':
            browser.waitForVisible(myLegend_xpath, 1000, true);
            break;
            default:
            browser.waitForVisible(myLegend_xpath, waitDefault);
          }
        } else {
          browser.waitForVisible(myLegend_xpath, waitDefault);
        }
      });
    }
  });
};
