// Recommended filename: Then_I_should_see_#_areaspline-chart_under_the_#_panel-heading_to_#_the_following_data.js
module.exports = function() {
  this.Then(/^I should see (\d+) areaspline\-chart under the "([^"]*)" panel-heading to (contain|match) the following data$/, 
    {timeout: process.env.StepTimeoutInMS},
    function (numberOfChart, panelName, action, table) {
    // Write the automation code here
    // browser.pause(1000);
    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    //this.browser_session.waitForRender(browser);

    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase());
    var myCharts = myPanel + content_xpath.areaspline_chart_root;
    var svgPaths = myCharts + content_xpath.areaspline_chart_svg_path;

    browser.getLocationInView(myPanel);    

    var chart_count = browser.elements(myCharts).value.length;
    var svg_count = browser.elements(svgPaths).value.length;
    var myBrowserSession = this.browser_session;

    expect(chart_count).toMatch(numberOfChart);

    expect(svg_count).toBeGreaterThan(0);

    // TODO: Need to implement the data / svg graph  verification   
    // var expected_row_list = table.hashes();

  });
}
