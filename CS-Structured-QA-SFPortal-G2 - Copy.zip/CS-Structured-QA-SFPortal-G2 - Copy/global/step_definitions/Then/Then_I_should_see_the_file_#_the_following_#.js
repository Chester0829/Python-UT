// Recommended filename: Then_I_should_see_the_file_#_the_following_#.js
// Duplicate the file: Then_I_should_see_the_file_#_the_following_#_#.js and will delete
module.exports = function() {
	this.Then(/^I should see the file (contains|contain|match|equal) the following (header|data|data regex)$/, 
		{timeout: process.env.StepTimeoutInMS*5},
		function (testAction, contentType, table) {
			// return 'pending';
			this.browser_session.waitForResource(browser);
			const my_regex_lib = this.regex_lib;
			var expected_item_list = table.hashes();
			var self = this;
			expected_item_list.forEach(function(expected_item){
				var row_data = expected_item['row_data'];
				if(contentType.indexOf('regex') != -1){
					row_data = self.regex_lib.replaceRegex(row_data);
				}
				switch(contentType){
					case 'header':
						console.log('self.file_target_data[0]--------------:')
						console.log(self.file_target_data[0]);
						var check_data = self.file_target_data[0][0];
						break;
					case 'data':
					case 'data regex':
						var check_data = self.file_target_data[0].slice(1);
						break;
				}
				console.log('check_data:' + check_data);
				// console.log(check_data.length);
				switch(testAction){
					case 'contains':
					case 'contain':
						// indexOf
						var tmp = row_data.replace(/ :: /g,',').trim();
						if( tmp.endsWith(' ::') ){
							var data = tmp.replace(' ::',',');
						}else{
							var data = tmp;
						}
						expect(check_data.replace(/"/g,'')).toContain(data);
						break;
					case 'match':
						// reg
						if(check_data.length == 0){
							// no data
							console.log('row_data:',row_data);
							console.log('no_data_text_list:',self.no_data_text_list);
							for(var j=0;j<self.no_data_text_list.length;j++){
								console.log('no_data_text_list:',self.no_data_text_list);
								if(row_data.indexOf(self.no_data_text_list[j]) != -1){
									return;
								}
							}
							expect(false).toBe(true);
						}
						if(typeof(check_data) === 'string') {
							//expect(check_data.replace(/"/g, '')).toMatch(row_data.replace(/ :: /g,','));
							expect(check_data.replace(/"/g, '')).toMatch(my_regex_lib.replaceRegex(row_data).replace(/ :: /g,','));
							//expect(check_data.replace(/,/g, ' :: ').replace(/"/g, '')).toMatch(my_regex_lib.replaceRegex(row_data));
							return;
						}
						for(var i=0;i<check_data.length;i++){
							if(check_data[i] == ''){continue;}
							var tmp = check_data[i].split('","').map(function(curValue){return curValue.trim()}).join(' :: ');
							console.log(tmp);
							expect(tmp).toMatch(my_regex_lib.replaceRegex(row_data));
						}
						break;

					case 'equal':
						var tmp = row_data.replace(/ :: /g,',').trim();
						if(tmp.endsWith(' ::')){
							var data = tmp.replace(' ::',',');
						}else{
							var data = tmp;
						}
						check_data = check_data.substr(0,check_data.length - 1);
						expect(check_data.replace(/"/g,'').replace(/'/g,'')).toEqual(data);
						break;
				}


			});

		});
};