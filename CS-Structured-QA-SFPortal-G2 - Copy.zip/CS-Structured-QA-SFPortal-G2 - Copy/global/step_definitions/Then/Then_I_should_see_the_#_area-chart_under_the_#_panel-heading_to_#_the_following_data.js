// Recommended filename: Then_I_should_see_the_#_area-chart_under_the_#_panel-heading_to_#_the_following_data.js
module.exports = function() {
  this.Then(/^I should see the "([^"]*)" area\-chart under the "([^"]*)" panel-heading to (contain|match) the following data$/, function (chartName, panelName,action, table) {
    // Write the automation code here
    //browser.pause(1000);
    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    //this.browser_session.waitForRender(browser);
    var expected_row_list = table.hashes();
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const portfolioPage_xpath = this.xpath_lib.xpathRequire('portfolioPage_xpath');
    const my_regex_lib = this.regex_lib; 
    var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase());
    if(panelName == 'Market Color and Estimated Valuation'){
      if(browser.isExisting(myPanel)==false){
        myPanel = content_xpath.sfpCardPanel.replace('__WIDGETNAME__',panelName);
      }
    }
    browser.getLocationInView(myPanel);
    var myChart = myPanel + content_xpath.namedPieChar.replace(/__NAME__/g, chartName);
    // var myChart = this.browser_session.findChartUnderPanel(browser, null, panelName, chartName);
    // console.log(myChart);
    var myChart_title = myChart + '//*[@class="highcharts-title"]';
    var myChart_x_label = myChart + portfolioPage_xpath.chartXlabel;
    var myChart_y_label = myChart + portfolioPage_xpath.chartYlabel;
    if(panelName == 'Market Color and Estimated Valuation'||panelName == 'Simplified Supervisory Formula Approach (SSFA)'){
      var myChart_y_title = myChart + portfolioPage_xpath.chartYtitle1;
      console.log(myChart_y_title);
    }
    else{
      var myChart_y_title = myChart + portfolioPage_xpath.chartYtitle;
      console.log(myChart_y_title);
    }
    var myChart_point = myChart + portfolioPage_xpath.chartPoint;
    var displayed_chart_text = browser.getText(myChart);
    var displayed_title_text;
    var displayed_point_count;
    var displayed_x_label;
    var displayed_y_label;
    var displayed_y_title;
    var expected_x_label_count = 0;
    displayed_point_count = browser.elements(myChart_point).value.length
    expected_row_list.forEach(function(row) {
      // if (row['title']) {
      //   displayed_title_text = browser.getText(myChart_title)
      //   expect(displayed_title_text).toContain(row['title']);
      // };
      // if (row['y_title']) {
      //   displayed_y_title = browser.getText(myChart_y_title);
      //   expect(displayed_y_title).toContain(row['y_title']);
      // };
      // if (row['x_label']) {
      //   expected_x_label_count = expected_x_label_count + 1;
      //   displayed_x_label = browser.getText(myChart_x_label);
      //   expect(displayed_x_label.replace(/ /g,'')).toContain(row['x_label'].replace(/ /g,''));
      // };
      // if (row['y_label']) {
      //   displayed_y_label = browser.getText(myChart_y_label);
      //   expect(displayed_y_label.replace(/ /g,'')).toContain(row['y_label'].replace(/ /g,''));
      // };
      // if (row['text']){
      //   displayed_text = browser.getText(myChart);
      //   expect(displayed_text).toContain(row['text']);
      // };
      switch(action) {
        case "contain":
          if (row['title']) {
            displayed_title_text = browser.getText(myChart_title)
            expect(displayed_title_text).toContain(row['title']);
          };
          if (row['y_title']) {
            displayed_y_title = browser.getText(myChart_y_title);
            expect(displayed_y_title).toContain(row['y_title']);
          };
          if (row['x_label']) {
            expected_x_label_count = expected_x_label_count + 1;
            displayed_x_label = browser.getText(myChart_x_label);
            expect(displayed_x_label.replace(/ /g,'')).toContain(row['x_label'].replace(/ /g,''));
          };
          if (row['y_label']) {
            displayed_y_label = browser.getText(myChart_y_label);
            expect(displayed_y_label.replace(/ /g,'')).toContain(row['y_label'].replace(/ /g,''));
          };
          if (row['text'])
          {
            displayed_text = browser.getText(myChart);
            expect(displayed_text).toContain(row['text']);
          };
          break;
        case "match":
          if (row['title']) {
              displayed_title_text = browser.getText(myChart_title)
              expect(displayed_title_text).toMatch(my_regex_lib.replaceRegex(row['title']));
            };
            if (row['y_title']) {
              displayed_y_title = browser.getText(myChart_y_title);
              expect(displayed_y_title).toMatch(my_regex_lib.replaceRegex(row['y_title']));
            };
            if (row['x_label']) {
              expected_x_label_count = expected_x_label_count + 1;
              displayed_x_label = browser.getText(myChart_x_label);
              expect(displayed_x_label.replace(/ /g,'')).toMatch(my_regex_lib.replaceRegex(row['x_label']).replace(/ /g,''));
            };
            if (row['y_label']) {
              displayed_y_label = browser.getText(myChart_y_label);
              expect(displayed_y_label.replace(/ /g,'')).toMatch(my_regex_lib.replaceRegex(row['y_label']).replace(/ /g,''));
            };
            if (row['text'])
            {
              displayed_text = browser.getText(myChart);
              expect(displayed_text).toMatch(my_regex_lib.replaceRegex(row['text']));
            };
            break;
      }
    });
  });
}
