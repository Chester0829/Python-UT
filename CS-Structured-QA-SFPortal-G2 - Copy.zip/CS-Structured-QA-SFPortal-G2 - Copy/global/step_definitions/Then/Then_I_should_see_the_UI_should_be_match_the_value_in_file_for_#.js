// Then_I_should_see_the_UI_should_be_match_the_value_in_file_for_#.js
// only for Import XLSX in CLO Deal Cashflow 
module.exports = function() {
  this.Then(/^I should see the UI should be match the value in file for "([^"]*)"$/,
    {timeout: process.env.StepTimeoutInMS*5},
    function (matchType) { 
      // const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
      switch(matchType){
        case 'CLO':
          // the value come from CLOAssumptions.xlsx
          var expectInfo = [
            {'scenario1': 'TRUE,"Madison Park Funding XI, Ltd.",2013,7/23/29,User Defined,2/1/18,TRUE,TRUE,Custom,25,CPR,5,CDR,36,Loss %,0,3,50,User Defined,3.25,72,Basic,0,Basic,Yes,Clean Up,disabled,disabled,User Defined,15' },
            {'scenario2': 'TRUE,"Madison Park Funding XI, Ltd.",2013,7/23/29,MA Baseline,3/1/18,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled'},
            {'scenario3': 'TRUE,"Madison Park Funding XI, Ltd.",2013,7/23/29,User Defined,5/6/18,FALSE,FALSE,Custom,30,SMM,10,CDR,40,Loss %,0,6,200,User Defined,5.25,50,Basic,5,Basic,No,Clean Up,disabled,disabled,Market Value,disabled' },
            {'scenario4': 'TRUE,"Madison Park Funding XI, Ltd.",2013,7/23/29,User Defined,7/16/18,FALSE,FALSE,Moody\'s,30,CPR,2,CDR,30,Loss %,0,6,100,User Defined,3.25,72,Basic,0,Basic,disabled,Maturity,disabled,disabled,Par,disabled'},
            {'scenario5': 'TRUE,"Madison Park Funding XI, Ltd.",2013,7/23/29,User Defined,1/1/18,FALSE,TRUE,Custom,24,PCT,8,CDR,35,Loss %,0,9,disabled,Market Value,3.25,77,Basic,3,Basic,No,Next Callable Date,disabled,8,Market Value,disabled'}
          ];
          var expectSettingInfo = [
            // 'Cashflow and Price/Yield Settings',
            'Cashflow Output,Payment Dates',
            'Method,Step Size',
            'Input,Price',
            'Mid Point,100',
            'Step Size (bps),100'
          ];
          // verify setting
          var settingXpath = [
            {'type':'fpSelect','value':'analyticsCtrl.outputType'},
            {'type':'fpSelect','value':'analyticsCtrl.scenarioMethod'},
            {'type':'fpSelect','value':'analyticsCtrl.scenarioInput'},
            {'type':'input','value':'analyticsCtrl.scenarioMidPoint'},
            {'type':'input','value':'analyticsCtrl.scenarioStepSize'},
          ];
          var settingTitle = ['Cashflow Output','Method','Input','Mid Point','Step Size (bps)'];
          var uiSettingDisplay = this.browser_session.getCashflowUiValueList(browser,settingXpath,1,matchType)[0];
          console.log(uiSettingDisplay);
          // console.log('------------------');
          for(var i=0;i<expectSettingInfo.length;i++){
            expect(expectSettingInfo[i]).toEqual(settingTitle[i] + ',' +uiSettingDisplay[i]);
          }

          // according to the xlsx sort
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            {'type':'deal','value':'"Madison Park Funding XI, Ltd."'}, // Deal
            {'type':'Vintage','value':'2013'}, // Vintage
            {'type':'Legal Maturity','value':'7/23/29'}, // Legal Maturity
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'checkbox','value':'scen.apply_watch'}, // Apply Stratification
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.prepay_rate'}, // Prepay Rate
            {'type':'fpSelect','value':'scen.prepay_type'}, // Prepay Type
            {'type':'input','value':'scen.default_rate'}, // Default Rate
            {'type':'fpSelect','value':'scen.default_type'}, // Default Type
            {'type':'input','value':'scen.loss_rate'}, // Loss Rate
            {'type':'fpSelect','value':'scen.loss_type'}, // Loss Type
            {'type':'input','value':'scen.prinLossSeverityPctNonPerf'}, // Loss Rate (non-performing)
            {'type':'input','value':'scen.rec_lag'}, // RecLag (Months)
            {'type':'input','value':'scen.reinvest_price'}, // Reinvest Price
            {'type':'fpSelect','value':'scen.reinvest_price_type'}, // Reinvest Price Type
            {'type':'input','value':'scen.reinvest_spread'}, // Reinvest Spread (%)
            {'type':'input','value':'scen.reinvest_term'}, // Reinvest Term
            {'type':'fpSelect','value':'scen.reinvest_pool'}, // Reinvest Pool
            {'type':'input','value':'scen.reinvDefaultLockout'}, // Reinvest Default Lockout (months)
            {'type':'fpSelect','value':'scen.reinvest_rules'}, // Intra/Post Reinvest Rules
            {'type':'fpSelect','value':'scen.force_call'},
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'}, // Call Date
            {'type':'input','value':'scen.plus_minus_months'},
            {'type':'fpSelect','value':'scen.call_price_type'}, // Call Price Type
            {'type':'input','value':'scen.call_price'}  // Call Price
          ];
          break;
        case 'CLOClickwrap':
          // the value come from CLOAssumptions.xlsx
          var expectInfo = [
            {'scenario1': 'TRUE,'+this.deal+',2013,7/23/29,User Defined,2018-02-01,TRUE,TRUE,Custom,25,CPR,5,CDR,36,Loss %,0,3,50,User Defined,3.25,72,Basic,0,Basic,Yes,Clean Up,disabled,disabled,User Defined,15' },
            {'scenario2': 'TRUE,'+this.deal+',2013,7/23/29,MA Baseline,2018-03-01,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled'},
            {'scenario3': 'TRUE,'+this.deal+',2013,7/23/29,User Defined,2018-05-06,FALSE,FALSE,Custom,30,SMM,10,CDR,40,Loss %,0,6,200,User Defined,5.25,50,Basic,5,Basic,No,Clean Up,disabled,disabled,Market Value,disabled' },
            {'scenario4': 'TRUE,'+this.deal+',2013,7/23/29,User Defined,2018-07-16,FALSE,FALSE,Moody\'s,30,CPR,2,CDR,30,Loss %,0,6,100,User Defined,3.25,72,Basic,0,Basic,disabled,Maturity,disabled,disabled,Par,disabled'},
            {'scenario5': 'TRUE,'+this.deal+',2013,7/23/29,User Defined,2018-01-01,FALSE,TRUE,Custom,24,PCT,8,CDR,35,Loss %,0,9,disabled,Market Value,3.25,77,Basic,3,Basic,No,Next Callable Date,disabled,8,Market Value,disabled'}
          ];
          var expectSettingInfo = [
            // 'Cashflow and Price/Yield Settings',
            'Cashflow Output,Payment Dates',
            'Method,Step Size',
            'Input,Price',
            'Mid Point,100',
            'Step Size (bps),100'
          ];
          // verify setting
          var settingXpath = [
            {'type':'fpSelect','value':'analyticsCtrl.outputType'},
            {'type':'fpSelect','value':'analyticsCtrl.scenarioMethod'},
            {'type':'fpSelect','value':'analyticsCtrl.scenarioInput'},
            {'type':'input','value':'analyticsCtrl.scenarioMidPoint'},
            {'type':'input','value':'analyticsCtrl.scenarioStepSize'},
          ];
          var settingTitle = ['Cashflow Output','Method','Input','Mid Point','Step Size (bps)'];
          var uiSettingDisplay = this.browser_session.getCashflowUiValueList(browser,settingXpath,1,matchType)[0];
          console.log(uiSettingDisplay);
          // console.log('------------------');
          for(var i=0;i<expectSettingInfo.length;i++){
            expect(expectSettingInfo[i]).toEqual(settingTitle[i] + ',' +uiSettingDisplay[i]);
          }

          // according to the xlsx sort
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            // {'type':'deal','value':'"Madison Park Funding XI, Ltd."'}, // Deal
            {'type':'deal','value':this.deal}, // Deal            
            {'type':'Vintage','value':'2013'}, // Vintage
            {'type':'Legal Maturity','value':'7/23/29'}, // Legal Maturity
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'checkbox','value':'scen.apply_watch'}, // Apply Stratification
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.prepay_rate'}, // Prepay Rate
            {'type':'fpSelect','value':'scen.prepay_type'}, // Prepay Type
            {'type':'input','value':'scen.default_rate'}, // Default Rate
            {'type':'fpSelect','value':'scen.default_type'}, // Default Type
            {'type':'input','value':'scen.loss_rate'}, // Loss Rate
            {'type':'fpSelect','value':'scen.loss_type'}, // Loss Type
            {'type':'input','value':'scen.prinLossSeverityPctNonPerf'}, // Loss Rate (non-performing)
            {'type':'input','value':'scen.rec_lag'}, // RecLag (Months)
            {'type':'input','value':'scen.reinvest_price'}, // Reinvest Price
            {'type':'fpSelect','value':'scen.reinvest_price_type'}, // Reinvest Price Type
            {'type':'input','value':'scen.reinvest_spread'}, // Reinvest Spread (%)
            {'type':'input','value':'scen.reinvest_term'}, // Reinvest Term
            {'type':'fpSelect','value':'scen.reinvest_pool'}, // Reinvest Pool
            {'type':'input','value':'scen.reinvDefaultLockout'}, // Reinvest Default Lockout (months)
            {'type':'fpSelect','value':'scen.reinvest_rules'}, // Intra/Post Reinvest Rules
            {'type':'fpSelect','value':'scen.force_call'},
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'}, // Call Date
            {'type':'input','value':'scen.plus_minus_months'},
            {'type':'fpSelect','value':'scen.call_price_type'}, // Call Price Type
            {'type':'input','value':'scen.call_price'}  // Call Price
          ];
          break;
        case 'ABS':
          var expectInfo = [
            {'scenario1': 'TRUE,Dell Equipment Finance Trust 2019-1,User Defined,2019-08-12,TRUE,Prepay (CPR),Custom,15,ppy_automation01,15,def_automation01,15,loss_automation01,15,15,No,Earliest Call,disabled'},
            {'scenario2': 'TRUE,Dell Equipment Finance Trust 2019-1,MA S4,2019-08-12,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled'},
            {'scenario3': 'TRUE,Dell Equipment Finance Trust 2019-1,User Defined,2019-08-12,FALSE,disabled,Moody\'s,5,CPR,5,CDR,10,loss_automation01,6,12,disabled,Maturity,disabled'},
            {'scenario4': 'TRUE,Dell Equipment Finance Trust 2019-1,User Defined,2019-08-25,FALSE,disabled,Moody\'s,5,SMM,5,SMM,5,Loss %,5,10,No,User Defined,2020-08-08'},
            {'scenario5': 'TRUE,Dell Equipment Finance Trust 2019-1,User Defined,2019-07-12,FALSE,disabled,Moody\'s,0,CPR,0,CDR,0,Loss %,0,,disabled,Maturity,disabled'}
          ];
          var expectSettingInfo = [
            // 'Cashflow and Price/Yield Settings',
            'Method,Step Size',
            'Input,Price',
            'Mid Point,100',
            'Step Size (bps),100'
          ];
          // verify setting
          var settingXpath = [
            {'type':'fpSelect','value':'analyticsCtrl.scenarioMethod'},
            {'type':'fpSelect','value':'analyticsCtrl.scenarioInput'},
            {'type':'input','value':'analyticsCtrl.scenarioMidPoint'},
            {'type':'input','value':'analyticsCtrl.scenarioStepSize'},
          ];
          var settingTitle = ['Method','Input','Mid Point','Step Size (bps)'];
          var uiSettingDisplay = this.browser_session.getCashflowUiValueList(browser,settingXpath,1)[0];
          console.log(uiSettingDisplay);
          // console.log('------------------');
          for(var i=0;i<expectSettingInfo.length;i++){
            expect(expectSettingInfo[i]).toEqual(settingTitle[i] + ',' +uiSettingDisplay[i]);
          }

          // according to the xlsx sort
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            //{'type':'deal','value':'Dell Equipment Finance Trust 2016-1'}, // Deal
            {'type':'deal','value':this.deal},
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'fpSelect','value':'scen.solve_for'}, // 
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.prepay_rate'}, // Prepay Rate
            {'type':'fpSelect','value':'scen.prepay_type'}, // Prepay Type
            {'type':'input','value':'scen.default_rate'}, // Default Rate 
            {'type':'fpSelect','value':'scen.default_type'}, // Default Type
            {'type':'input','value':'scen.loss_rate'}, // Loss Rate
            {'type':'fpSelect','value':'scen.loss_type'}, // Loss Type
            {'type':'input','value':'scen.rec_lag'}, // RecLag (Months)
            {'type':'input','value':'scen.alloc_mon'}, // Allocation (months)
            {'type':'fpSelect','value':'scen.force_call'},  // Force Call
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'} // Call Da
          ];
          break;
        case 'ABSClickwrap':
          var expectInfo = [
            {'scenario1': 'TRUE,'+this.deal+',User Defined,2019-10-25,TRUE,Severity (SEV),Custom,30,CPR,2,CDR,30,Loss %,6,,disabled,Maturity,disabled'},
            {'scenario2': 'TRUE,'+this.deal+',User Defined,2019-10-25,TRUE,Severity (SEV),Moody\'s,30,CPR,4,CDR,30,Loss %,6,,disabled,Maturity,disabled'},
            {'scenario3': 'TRUE,'+this.deal+',User Defined,2019-10-25,FALSE,disabled,Moody\'s,30,CPR,6,CDR,35,Loss %,6,,Yes,User Defined,'},
            {'scenario4': 'TRUE,'+this.deal+',User Defined,2019-10-25,FALSE,disabled,Moody\'s,30,CPR,8,CDR,40,Loss %,6,,disabled,Maturity,disabled'},
            {'scenario5': 'TRUE,'+this.deal+',User Defined,2019-10-25,FALSE,disabled,Moody\'s,30,CPR,10,CDR,50,Loss %,6,,disabled,Maturity,disabled'}
          ];
          var expectSettingInfo = [
            // 'Cashflow and Price/Yield Settings',
            'Method,Step Size',
            'Input,Price',
            'Mid Point,100',
            'Step Size (bps),100'
          ];
          // verify setting
          var settingXpath = [
            {'type':'fpSelect','value':'analyticsCtrl.scenarioMethod'},
            {'type':'fpSelect','value':'analyticsCtrl.scenarioInput'},
            {'type':'input','value':'analyticsCtrl.scenarioMidPoint'},
            {'type':'input','value':'analyticsCtrl.scenarioStepSize'},
          ];
          var settingTitle = ['Method','Input','Mid Point','Step Size (bps)'];
          var uiSettingDisplay = this.browser_session.getCashflowUiValueList(browser,settingXpath,1)[0];
          console.log(uiSettingDisplay);
          // console.log('------------------');
          for(var i=0;i<expectSettingInfo.length;i++){
            expect(expectSettingInfo[i]).toEqual(settingTitle[i] + ',' +uiSettingDisplay[i]);
          }

          // according to the xlsx sort
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            //{'type':'deal','value':'Dell Equipment Finance Trust 2016-1'}, // Deal
            {'type':'deal','value':this.deal},
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'fpSelect','value':'scen.solve_for'}, // 
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.prepay_rate'}, // Prepay Rate
            {'type':'fpSelect','value':'scen.prepay_type'}, // Prepay Type
            {'type':'input','value':'scen.default_rate'}, // Default Rate 
            {'type':'fpSelect','value':'scen.default_type'}, // Default Type
            {'type':'input','value':'scen.loss_rate'}, // Loss Rate
            {'type':'fpSelect','value':'scen.loss_type'}, // Loss Type
            {'type':'input','value':'scen.rec_lag'}, // RecLag (Months)
            {'type':'input','value':'scen.alloc_mon'}, // Allocation (months)
            {'type':'fpSelect','value':'scen.force_call'},  // Force Call
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'} // Call Da
          ];
          break;
        case 'AUTO':
          var expectInfo = [
            {'scenario1': 'TRUE,Mercedes-Benz Auto Lease Trust 2019-A,User Defined,2018-07-16,TRUE,Prepay (CPR),Custom,15,ppy_automation01,15,def_automation01,15,loss_automation01,15,15,15,%,TRUE,15,15,Yes,Clean Up,disabled'},
            {'scenario2': 'TRUE,Mercedes-Benz Auto Lease Trust 2019-A,MA S2,2019-07-16,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled'},
            {'scenario3': 'TRUE,Mercedes-Benz Auto Lease Trust 2019-A,User Defined,2019-07-26,FALSE,disabled,Moody\'s,5,CPR,5,CDR,3,loss_automation01,3,3,10,%,FALSE,disabled,disabled,disabled,Maturity,disabled'},
            {'scenario4': 'TRUE,Mercedes-Benz Auto Lease Trust 2019-A,User Defined,2019-01-16,FALSE,disabled,Custom,5,SMM,5,SMM,5,Loss %,5,10,disabled,Current 60d+,TRUE,10,18,No,User Defined,2020-08-08'},
            {'scenario5': 'TRUE,Mercedes-Benz Auto Lease Trust 2019-A,User Defined,2018-07-18,FALSE,disabled,Moody\'s,5,PCT,5,PCT,5,Loss %,5,10,disabled,Current 90d+,FALSE,disabled,disabled,disabled,Maturity,disabled'}
          ];
          var expectSettingInfo = [
            // 'Cashflow and Price/Yield Settings',
            'Method,Step Size',
            'Input,Price',
            'Mid Point,100',
            'Step Size (bps),100'
          ];
          // verify setting
          var settingXpath = [
            {'type':'fpSelect','value':'analyticsCtrl.scenarioMethod'},
            {'type':'fpSelect','value':'analyticsCtrl.scenarioInput'},
            {'type':'input','value':'analyticsCtrl.scenarioMidPoint'},
            {'type':'input','value':'analyticsCtrl.scenarioStepSize'},
          ];
          var settingTitle = ['Method','Input','Mid Point','Step Size (bps)'];
          var uiSettingDisplay = this.browser_session.getCashflowUiValueList(browser,settingXpath,1)[0];
          console.log(uiSettingDisplay);
          // console.log('------------------');
          for(var i=0;i<expectSettingInfo.length;i++){
            expect(expectSettingInfo[i]).toEqual(settingTitle[i] + ',' +uiSettingDisplay[i]);
          }

          // according to the xlsx sort
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            //{'type':'deal','value':'Dell Equipment Finance Trust 2016-1'}, // Deal
            {'type':'deal','value':this.deal},
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'fpSelect','value':'scen.solve_for'}, // 
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.prepay_rate'}, // Prepay Rate
            {'type':'fpSelect','value':'scen.prepay_type'}, // Prepay Type
            {'type':'input','value':'scen.default_rate'}, // Default Rate 
            {'type':'fpSelect','value':'scen.default_type'}, // Default Type
            {'type':'input','value':'scen.loss_rate'}, // Loss Rate
            {'type':'fpSelect','value':'scen.loss_type'}, // Loss Type
            {'type':'input','value':'scen.rec_lag'}, // RecLag (Months)
            {'type':'input','value':'scen.alloc_mon'}, // Allocation (months)
            {'type':'input','value':'scen.delinquency_rate'},
            {'type':'fpSelect','value':'scen.delinquency_type'},
            {'type':'checkbox','value':'scen.seed_default'},
            {'type':'input','value':'scen.adv_loss_rate'},
            {'type':'input','value':'scen.adv_lag_mon'},
            {'type':'fpSelect','value':'scen.force_call'},  // Force Call
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'} // Call Da
          ];
          break;
        case 'CARDS':
          var expectInfo = [
            {'scenario1': 'TRUE,American Express Credit Account Master Trust, Series 2017-2,User Defined,2019-07-16,TRUE,Monthly Purchase Rate (%),Moody\'s,15,%,15,%,15,%,15,%,disabled,Maturity,disabled'},
            {'scenario2': 'TRUE,American Express Credit Account Master Trust, Series 2017-2,User Defined,2019-05-16,FALSE,disabled,Custom,2,repay_0824,2,pur_0824,5,%,5,%,No,Optional Date,disabled'},
            {'scenario3': 'TRUE,American Express Credit Account Master Trust, Series 2017-2,MA S3,2019-07-06,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled'},
            {'scenario4': 'TRUE,American Express Credit Account Master Trust, Series 2017-2,User Defined,2019-08-16,FALSE,disabled,Moody\'s,10,repay_0824,10,pur_0223,10,asset_card_0824,10,charoff_0824,No,User Defined,2020-08-08'},
            {'scenario5': 'TRUE,American Express Credit Account Master Trust, Series 2017-2,User Defined,2019-02-18,FALSE,disabled,Custom,5,%,5,%,5,%,5,%,Yes,Earliest Call,disabled'}
          ];
          var expectSettingInfo = [
            // 'Cashflow and Price/Yield Settings',
            'Method,Step Size',
            'Input,Price',
            'Mid Point,100',
            'Step Size (bps),100'
          ];
          // verify setting
          var settingXpath = [
            {'type':'fpSelect','value':'analyticsCtrl.scenarioMethod'},
            {'type':'fpSelect','value':'analyticsCtrl.scenarioInput'},
            {'type':'input','value':'analyticsCtrl.scenarioMidPoint'},
            {'type':'input','value':'analyticsCtrl.scenarioStepSize'},
          ];
          var settingTitle = ['Method','Input','Mid Point','Step Size (bps)'];
          var uiSettingDisplay = this.browser_session.getCashflowUiValueList(browser,settingXpath,1)[0];
          console.log(uiSettingDisplay);
          // console.log('------------------');
          for(var i=0;i<expectSettingInfo.length;i++){
            expect(expectSettingInfo[i]).toEqual(settingTitle[i] + ',' +uiSettingDisplay[i]);
          }

          // according to the xlsx sort
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            //{'type':'deal','value':'Dell Equipment Finance Trust 2016-1'}, // Deal
            {'type':'deal','value':this.deal},
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'fpSelect','value':'scen.solve_for'}, // 
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.repay_rate'}, // Repayrepay Rate
            {'type':'fpSelect','value':'scen.repay_type'}, // Repayrepay Type
            {'type':'input','value':'scen.purchase_rate'}, // Purchase Rate Rate 
            {'type':'fpSelect','value':'scen.purchase_type'}, // Purchase Type
            {'type':'input','value':'scen.portfolio_yield_rate'}, // Portfolio Yield Rate Rate
            {'type':'fpSelect','value':'scen.portfolio_yield_type'}, // Portfolio Yield Type
            {'type':'input','value':'scen.portfolio_loss_rate'}, // Charge-off Rate
            {'type':'fpSelect','value':'scen.portfolio_loss_type'}, //Charge-off Type
            {'type':'fpSelect','value':'scen.force_call'},  // Force Call
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'}
          ];
          break;
        case 'SLABS':
          var expectInfo = [
            {'scenario1': 'TRUE,Navient Student Loan Trust 2014-1,User Defined,2019-06-10,TRUE,Prepay (CPR),Moody\'s,15,ppy_automation01,15,def_automation01,15,loss_automation01,15,15,15,deferment_auto01,15,grace_auto01,15,forbearance_auto01,FALSE,TRUE,Semi-Annually,15,15,FALSE,15,No,Earliest Call,disabled'},
            {'scenario2': 'TRUE,Navient Student Loan Trust 2014-1,MA Baseline,2019-08-10,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,FALSE,FALSE,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled'},
            {'scenario3': 'TRUE,Navient Student Loan Trust 2014-1,User Defined,2019-07-10,FALSE,disabled,Moody\'s,10,SMM,10,SMM,10,Loss %,10,10,10,slab_0223,10,grace_0223,10,forbearance,TRUE,disabled,Quarterly,10,10,FALSE,10,disabled,Maturity,disabled'},
            {'scenario4': 'TRUE,Navient Student Loan Trust 2014-1,User Defined,2019-07-20,FALSE,disabled,Custom,3,CPR,3,CDR,3,Loss %,3,3,3,deferment_auto01,3,grace_auto01,3,forbearance_auto01,TRUE,disabled,Monthly,3,3,FALSE,3,No,User Defined,2020-08-08'},
            {'scenario5': 'TRUE,Navient Student Loan Trust 2014-1,User Defined,2019-05-23,FALSE,disabled,Moody\'s,5,CPR,5,CDR,5,Loss %,5,10,5,slab_0223,5,grace_0223,5,forbearance,FALSE,FALSE,Repayment,5,5,FALSE,60,Yes,Optional Date,disabled'}
          ];
          var expectSettingInfo = [
            // 'Cashflow and Price/Yield Settings',
            'Method,Step Size',
            'Input,Price',
            'Mid Point,100',
            'Step Size (bps),100'
          ];
          // verify setting
          var settingXpath = [
            {'type':'fpSelect','value':'analyticsCtrl.scenarioMethod'},
            {'type':'fpSelect','value':'analyticsCtrl.scenarioInput'},
            {'type':'input','value':'analyticsCtrl.scenarioMidPoint'},
            {'type':'input','value':'analyticsCtrl.scenarioStepSize'},
          ];
          var settingTitle = ['Method','Input','Mid Point','Step Size (bps)'];
          var uiSettingDisplay = this.browser_session.getCashflowUiValueList(browser,settingXpath,1)[0];
          console.log(uiSettingDisplay);
          // console.log('------------------');
          for(var i=0;i<expectSettingInfo.length;i++){
            expect(expectSettingInfo[i]).toEqual(settingTitle[i] + ',' +uiSettingDisplay[i]);
          }

          // according to the xlsx sort
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            //{'type':'deal','value':'Dell Equipment Finance Trust 2016-1'}, // Deal
            {'type':'deal','value':this.deal},
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'fpSelect','value':'scen.solve_for'}, // 
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.prepay_rate'}, // Prepay Rate
            {'type':'fpSelect','value':'scen.prepay_type'}, // Prepay Type
            {'type':'input','value':'scen.default_rate'}, // Default Rate 
            {'type':'fpSelect','value':'scen.default_type'}, // Default Type
            {'type':'input','value':'scen.loss_rate'}, // Loss Rate
            {'type':'fpSelect','value':'scen.loss_type'}, // Loss Type
            {'type':'input','value':'scen.rec_lag'}, // RecLag (Months)
            {'type':'input','value':'scen.alloc_mon'}, // Allocation (months)
            {'type':'input','value':'scen.deferment_rate'},
            {'type':'fpSelect','value':'scen.deferment_type'},
            {'type':'input','value':'scen.grace_rate'},
            {'type':'fpSelect','value':'scen.grace_type'},
            {'type':'input','value':'scen.forbear_rate'},
            {'type':'fpSelect','value':'scen.forbear_type'},
            {'type':'checkbox','value':'scen.ignore_input_nonpayment_term'},
            {'type':'checkbox','value':'scen.calc_curve_off_static_bal'},
            {'type':'fpSelect','value':'scen.interest_cap_freq'},
            {'type':'input','value':'scen.subsidy_payment_delay'},
            {'type':'input','value':'scen.SAP_payment_delay'},
            {'type':'checkbox','value':'scen.useACHVector'},
            //{'type':'fpSelect','value':'scen.scen.BB_type'},
            {'type':'input','value':'scen.BB_utilization_rate'},
            {'type':'fpSelect','value':'scen.force_call'},  // Force Call
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'} // Call Date
          ];
          break;
        case 'RMBS':
          var expectInfo = [
            {'scenario1': 'TRUE,Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1,User Defined,2018-07-16,TRUE,Default (CDR),Moody\'s,15,ppy_automation01,15,def_automation01,15,loss_automation01,15,15,disabled,Current 60d+,Based on Delinquencies,15,serAdv0223,TRUE,15,15,No,Clean Up,disabled'},
            {'scenario2': 'TRUE,Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1,MA S3,2019-07-16,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled'},
            {'scenario3': 'TRUE,Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1,User Defined,2019-07-26,FALSE,disabled,Custom,10,SMM,10,SMM,10,Loss %,10,10,disabled,Current 90d+,Off,disabled,disabled,FALSE,disabled,disabled,disabled,Maturity,disabled'},
            {'scenario4': 'TRUE,Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1,User Defined,2019-01-16,FALSE,disabled,Moody\'s,5,PCT,5,PCT,5,Loss %,5,5,5,del_0223,Based on Defaults,5,%,TRUE,10,18,No,User Defined,2020-08-08'},
            {'scenario5': 'TRUE,Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1,User Defined,2018-07-18,FALSE,disabled,Custom,3,CPR,3,CDR,3,Loss %,3,3,3,%,Off,disabled,disabled,FALSE,disabled,disabled,Yes,Optional Date,disabled'}
          ];
          var expectSettingInfo = [
            // 'Cashflow and Price/Yield Settings',
            'Method,Step Size',
            'Input,Price',
            'Mid Point,100',
            'Step Size (bps),100'
          ];
          // verify setting
          var settingXpath = [
            {'type':'fpSelect','value':'analyticsCtrl.scenarioMethod'},
            {'type':'fpSelect','value':'analyticsCtrl.scenarioInput'},
            {'type':'input','value':'analyticsCtrl.scenarioMidPoint'},
            {'type':'input','value':'analyticsCtrl.scenarioStepSize'},
          ];
          var settingTitle = ['Method','Input','Mid Point','Step Size (bps)'];
          var uiSettingDisplay = this.browser_session.getCashflowUiValueList(browser,settingXpath,1)[0];
          console.log(uiSettingDisplay);
          // console.log('------------------');
          for(var i=0;i<expectSettingInfo.length;i++){
            expect(expectSettingInfo[i]).toEqual(settingTitle[i] + ',' +uiSettingDisplay[i]);
          }

          // according to the xlsx sort
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            //{'type':'deal','value':'Dell Equipment Finance Trust 2016-1'}, // Deal
            {'type':'deal','value':this.deal},
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'fpSelect','value':'scen.solve_for'}, // 
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.prepay_rate'}, // Prepay Rate
            {'type':'fpSelect','value':'scen.prepay_type'}, // Prepay Type
            {'type':'input','value':'scen.default_rate'}, // Default Rate 
            {'type':'fpSelect','value':'scen.default_type'}, // Default Type
            {'type':'input','value':'scen.loss_rate'}, // Loss Rate
            {'type':'fpSelect','value':'scen.loss_type'}, // Loss Type
            {'type':'input','value':'scen.rec_lag'}, // RecLag (Months)
            {'type':'input','value':'scen.alloc_mon'}, // Allocation (months)
            {'type':'input','value':'scen.delinquency_rate'},
            {'type':'fpSelect','value':'scen.delinquency_type'},
            {'type':'fpSelect','value':'scen.servicer_basis'},
            {'type':'input','value':'scen.servicer_rate'},
            {'type':'fpSelect','value':'scen.servicer_type'},
            {'type':'checkbox','value':'scen.seed_default'},
            {'type':'input','value':'scen.adv_loss_rate'},
            {'type':'input','value':'scen.adv_lag_mon'},
            {'type':'fpSelect','value':'scen.force_call'},  // Force Call
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'} // Call Date
          ];
          break;
        case 'CMBS':
          var expectInfo = [
            {'scenario1': 'TRUE,Merrill Lynch Mortgage Trust 2008-C1,User Defined,2019-02-01,TRUE,Severity (SEV),Custom,15,CPR,15,CDR,15,Loss %,15,15,disabled,NOI,disabled,Cap,FALSE,160,10,38,TRUE,0.9,15,36,DSCR,TRUE,99,137,32,21,110,39,FALSE,11,8.5,31,45,13,32,DY,Based on Delinquencies,69,serAdv0223,Yes,Clean Up,disabled'},
            {'scenario2': 'TRUE,Merrill Lynch Mortgage Trust 2008-C1,MA Baseline,2019-03-01,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled,disabled'},
            {'scenario3': 'TRUE,Merrill Lynch Mortgage Trust 2008-C1,User Defined,2019-04-01,FALSE,disabled,Moody\'s,5,CPR,5,CDR,5,Loss %,5,5,-5,%,disabled,Cap,TRUE,130,12,30,TRUE,0.8,12,30,LTV,TRUE,90,130,30,12,100,35,TRUE,10,8,32,25,14,36,LTV,Off,disabled,disabled,disabled,Maturity,disabled'},
            {'scenario4': 'TRUE,Merrill Lynch Mortgage Trust 2008-C1,User Defined,2019-05-01,FALSE,disabled,Moody\'s,5,ppy_automation01,5,def_automation01,5,loss_automation01,5,10,-2,%,-0.0025,%,TRUE,130,16,30,FALSE,0.8,18,30,LTV,FALSE,90,130,30,12,100,35,TRUE,16,8.6,33,26,15,39,DY,Based on Defaults,63,%,No,User Defined,2020-08-08'},
            {'scenario5': 'TRUE,Merrill Lynch Mortgage Trust 2008-C1,User Defined,2019-06-01,FALSE,disabled,Moody\'s,3,CPR,3,CDR,3,Loss %,3,3,disabled,NOI,-0.63,%,FALSE,133,18,30,FALSE,0.86,16,30,DSCR,FALSE,90,130,30,12,100,35,FALSE,18,8.7,34,27,16,38,LTV,Off,disabled,disabled,disabled,Maturity,disabled'}
          ];
          var expectSettingInfo = [
            // 'Cashflow and Price/Yield Settings',
            'Method,Step Size',
            'Input,Price',
            'Mid Point,100',
            'Step Size (bps),100'
          ];
          // verify setting
          var settingXpath = [
            {'type':'fpSelect','value':'analyticsCtrl.scenarioMethod'},
            {'type':'fpSelect','value':'analyticsCtrl.scenarioInput'},
            {'type':'input','value':'analyticsCtrl.scenarioMidPoint'},
            {'type':'input','value':'analyticsCtrl.scenarioStepSize'},
          ];
          var settingTitle = ['Method','Input','Mid Point','Step Size (bps)'];
          var uiSettingDisplay = this.browser_session.getCashflowUiValueList(browser,settingXpath,1)[0];
          console.log(uiSettingDisplay);
          // console.log('------------------');
          for(var i=0;i<expectSettingInfo.length;i++){
            expect(expectSettingInfo[i]).toEqual(settingTitle[i] + ',' +uiSettingDisplay[i]);
          }
          // according to the xlsx sort
          var xpathInfo = [
            {'type':'checkbox','value':'scen.run_flag'}, // run
            //{'type':'deal','value':'Dell Equipment Finance Trust 2016-1'}, // Deal
            {'type':'deal','value':this.deal},
            {'type':'mdSelect','value':'scen.scenType'}, // Scenario
            {'type':'input','value':'scen.settle_date'}, // Settles Date
            {'type':'checkbox','value':'scen.cal_first_loss'}, // Calculate First Loss
            {'type':'fpSelect','value':'scen.solve_for'}, // 
            {'type':'fpSelect','value':'scen.forward_curve'}, // Custom Rates
            {'type':'input','value':'scen.prepay_rate'}, // Prepay Rate
            {'type':'fpSelect','value':'scen.prepay_type'}, // Prepay Type
            {'type':'input','value':'scen.default_rate'}, // Default Rate 
            {'type':'fpSelect','value':'scen.default_type'}, // Default Type
            {'type':'input','value':'scen.loss_rate'}, // Loss Rate
            {'type':'fpSelect','value':'scen.loss_type'}, // Loss Type
            {'type':'input','value':'scen.rec_lag'}, // RecLag (Months)
            {'type':'input','value':'scen.alloc_mon'}, // Allocation (months)
            {'type':'input','value':'scen.NOI_growth_rate'},
            {'type':'fpSelect','value':'scen.NOI_growth_rate_type'},
            {'type':'input','value':'scen.cap_rate_growth_rate'},
            {'type':'fpSelect','value':'scen.cap_rate_growth_rate_type'},
            {'type':'checkbox','value':'scen.term_triggers_activate_LTV_trigger'},
            {'type':'input','value':'scen.term_triggers_LTV_liquidate'},
            {'type':'input','value':'scen.term_triggers_LTV_months'},
            {'type':'input','value':'scen.term_triggers_LTV_loss'},
            {'type':'checkbox','value':'scen.term_triggers_activate_DSCR_trigger'},
            {'type':'input','value':'scen.term_triggers_DSCR_liquidate'},
            {'type':'input','value':'scen.term_triggers_DSCR_months'},
            {'type':'input','value':'scen.term_triggers_DSCR_loss'},
            {'type':'fpSelect','value':'scen.term_triggers_select_priority'},
            {'type':'checkbox','value':'scen.maturity_trigger_activate_LTV_trigger'},
            {'type':'input','value':'scen.maturity_trigger_LTV_payoff'},
            {'type':'input','value':'scen.maturity_trigger_LTV_liquidate'},
            {'type':'input','value':'scen.maturity_trigger_LTV_loss'},
            {'type':'input','value':'scen.maturity_trigger_LTV_extension'},
            {'type':'input','value':'scen.maturity_trigger_LTV_end_of_extension_liq_or_payoff'},
            {'type':'input','value':'scen.maturity_trigger_LTV_end_of_extension_loss'},
            {'type':'checkbox','value':'scen.maturity_trigger_activate_DY_trigger'},
            {'type':'input','value':'scen.maturity_trigger_DY_payoff'},
            {'type':'input','value':'scen.maturity_trigger_DY_liquidate'},
            {'type':'input','value':'scen.maturity_trigger_DY_loss'},
            {'type':'input','value':'scen.maturity_trigger_DY_extension'},
            {'type':'input','value':'scen.maturity_trigger_DY_end_of_extension_liq_or_payoff'},
            {'type':'input','value':'scen.maturity_trigger_DY_end_of_extension_loss'},
            {'type':'fpSelect','value':'scen.maturity_trigger_select_priority'},
            {'type':'fpSelect','value':'scen.servicer_basis'},
            {'type':'input','value':'scen.servicer_rate'},
            {'type':'fpSelect','value':'scen.servicer_type'},
            //{'type':'checkbox','value':'scen.apply_loan_level_assumps'},
            {'type':'fpSelect','value':'scen.force_call'},  // Force Call
            {'type':'fpSelect','value':'scen.call_option'}, // Call Option
            {'type':'input','value':'scen.call_date'} // Call Date          
          ];
          break;
      }
      var uiDisplay = this.browser_session.getCashflowUiValueList(browser,xpathInfo,5,matchType);
      console.log(uiDisplay);
      for(var i=0;i<expectInfo.length;i++){
        // console.log(expectInfo[i]['scenario' + (i+1)]);
        // console.log(uiDisplay[i].join(','))
        expect(expectInfo[i]['scenario' + (i+1)]).toEqual(uiDisplay[i].join(','));
      }
  });

}