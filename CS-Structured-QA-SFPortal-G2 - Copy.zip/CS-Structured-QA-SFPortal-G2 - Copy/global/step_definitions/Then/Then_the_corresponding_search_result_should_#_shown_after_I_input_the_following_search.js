// Recommended filename: Then_the_corresponding_search_result_should_#_shown_after_I_input_the_following_search.js
module.exports = function() {
  // this.setDefaultTimeout(360*1000);
  this.Then(/^the corresponding search result should (be|not be) shown after I input the following search$/, {timeout: process.env.StepTimeoutInMS*10}, function (displayornot, table) {
    // Write the automation code here   
    // console.log(action);
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');

    var items = table.hashes();

    // this.browser_session.waitForLoading(browser);
    browser.pause(5000);

    for(var i = 0; i<items.length; i++){
      console.log("Search for:"+ items[i].search_type + " " + items[i].search_text);
      
      this.browser_session.globalSearchItem(browser, items[i].search_type, items[i].search_text, 0, 300*1000, items[i].search_result);
      
      // var searchResultPannel = content_xpath.searchResultPannel;
      // browser.waitForVisible(searchResultPannel,this.waitDefault);

      
      var searchResult = content_xpath.searchResult.replace('__CATEGORY__', items[i].result_category).replace('__RESULTTEXT__', items[i].search_result);
      if(items[i].search_type == 'documents'){
        searchResult = '(' + content_xpath.searchResultforDocuments.replace('__CATEGORY__', items[i].result_category).replace('__DEALNAME__', items[i].search_text).replace('__RESULTTEXT__', items[i].search_result) + ')[1]';
      }
      console.log(searchResult);

      browser.pause(10000);
      var flag = browser.isVisible(searchResult,this.waitDefault);
      console.log(flag);

      if(displayornot == "be"){
        expect(flag).toBe(true);
      }
      else{
        browser.pause(3000);
        expect(flag).toBe(false);
      }
    };
  });
};