//Then_I_should_see_the_following_#_display_under_the_#_panel-heading.js
// CMBS Deal Analytics Dynamic CFS Page - Forward Curve
module.exports = function() {
  this.Then(/^I should see the following (price|button|information|deals) display under the "([^"]*)" panel\-heading$/, function (checkType, widgetName,table) {
    var cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
    this.browser_session.waitForResource(browser);
    if(this.deal){
      var root_xpath = cashflow_xpath.showForward;  
    }else if(widgetName == 'Settings'||widgetName == 'Add Scenario'){
      // portfolio cashflow
      var root_xpath = cashflow_xpath.vectors + '//*[@class="md-tabs-vertical"]';
      if(!browser.isVisible(root_xpath)){
        root_xpath = cashflow_xpath.vectors + '//*[@class="sfp-tabs-vertical"]';
      }
    }
    else if(this.portfolio){
      var root_xpath = cashflow_xpath.cmbsCustomRate;
    }
    var tableList = table.hashes();
    console.log(tableList);

    if(checkType == 'button'){
      var buttonList = browser.getText(root_xpath + '//button');
      var tmp = [];
      for(var i=0;i<tableList.length;i++){
        tmp.push(tableList[i]['row_item']);
      }
      expect(tmp.join().toLowerCase()).toEqual(buttonList.join().toLowerCase());
    }else if(checkType == 'information'){
      for(var i=0;i<tableList.length;i++){
        var row_item = tableList[i]['row_item'];
        var value = tableList[i]['value'];
        if(value.startsWith('rx')){
          value = this.regex_lib.replaceRegex(tableList[i]['value']);
          // root_xpath + '//*[@ng-model="'+ row_item +'"]';
          expect(browser.getValue(root_xpath + '//*[@ng-model="'+ row_item +'"]')).toMatch(value);
        }
      }
    }else if(checkType == 'deals'){
      // cmbs compare
      const portfolioPage_xpath = this.xpath_lib.xpathRequire('portfolioPage_xpath');
      if(tableList[0]['row_item'] == ''){
        var textarea = portfolioPage_xpath.sfpSearch.replace('__NAME__','compareCtrl.searchFactory') + '//div[@class="pillGroup"]';
      }else{
        var textarea = portfolioPage_xpath.sfpSearch.replace('__NAME__','compareCtrl.searchFactory') + '//div[@class="pillGroup"]//span';
      }
      var allDeals = browser.getText(textarea);
      console.log(allDeals);
      allDeals = Array.isArray(allDeals) ? allDeals : [allDeals];
      for(var i=0;i<allDeals.length;i++){
        expect(allDeals[i]).toEqual(tableList[i]['row_item']);
      }

    }else if(checkType == 'price'){
      var root_xpath = '//*[@id="cashflows"]//table';
      var trLength = browser.getValue(root_xpath + '//tr').length;
      var expectList = [];
      for(var i=0;i<tableList.length;i++){
        var cusipIsinExp = tableList[i]['Cusip/Isin'];
        var PriceExp = tableList[i]['Price'];
        expectList.push(cusipIsinExp + '_' + PriceExp);
      }
      var flag = false;
      console.log(expectList);
      // expect(expectList.join('_')).not.toContain('undefined');
      expect(expectList.length).toEqual(tableList.length);
      for(var i=0;i<trLength-1;i++){
        if(flag){
          var index = i-1;
        }else{
          var index = i;
        }

        var cusipIsinIndex = tableList[index]['cusipIndex'];
        var priceIndex = tableList[index]['priceIndex'];
        
        var cusipIsin = '(' + root_xpath + '//tr)['+ (i+2) +']' + '//td['+cusipIsinIndex+']';
        var price = '(' + root_xpath + '//tr)['+ (i+2) +']' + '//td['+priceIndex+']';
        console.log(cusipIsin);
        console.log(price);
        try{
          var cusipIsinUI = browser.getText(cusipIsin);  
        }catch(e){
          // console.log(e);
          flag = true;
          continue;
        }
        console.log(cusipIsinUI);
        var expectValue = undefined;
        for(var j=0;j<expectList.length;j++){
          var item = expectList[j].split('_');
          if(cusipIsinUI.indexOf(item[0]) != -1){
            expectValue = item[1];
            break;
          }
          if(expectValue){break;}
        }
        console.log(expectValue);
        expect(expectValue).toEqual((browser.getValue(price + '//input').trim()));
      }
      // console.log('***********************');
    } 
  })
}

