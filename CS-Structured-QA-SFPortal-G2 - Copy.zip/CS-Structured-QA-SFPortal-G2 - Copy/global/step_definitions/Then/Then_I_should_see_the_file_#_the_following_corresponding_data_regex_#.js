// Recommended filename: Then_I_should_see_the_file_#_the_following_corresponding_data_regex_#.js
// only for performance charts page
module.exports = function() {
	this.Then(/^I should see the file (match|contain) the following corresponding data regex (row|row by row)$/, 
	{timeout: process.env.StepTimeoutInMS*3},
	function (testAction,compareAction,table) {
    // Write code here that turns the phrase above into concrete actions
    // return 'pending';
  	var expectList = table.hashes();
  	console.log(expectList);
  	const my_regex_lib = this.regex_lib;

  	for(var i=0;i<expectList.length;i++){
      var index =  parseInt(expectList[i]['index'])-1
  		var item = expectList[i]['row_data'];
  		console.log(index)
  		var csvData = this.fileContentList[index]['data'];
  		// console.log('expect data: ' + item);
  		// console.log('csv data: ' + csvData);

  		for(var j=0;j<csvData.length;j++){
        // console.log(csvData[j]);
  			var tmp = csvData[j].replace(/"/g,'');
        if(tmp.replace(/["\s]/g,'').length == 0){break;}
  			if(compareAction == 'row'){
  				item = my_regex_lib.replaceRegex(item).replace(/ :: /g,',')
  				switch(testAction){
		  			case 'match':
              expect(tmp).toMatch(item);
		  				break;
		  			case 'contain':
		  				// TODO
		  				break;
		  		}
  			}else if(compareAction == 'row by row'){
  				// TODO
  			}

  		}

  		


  	}



  });
}