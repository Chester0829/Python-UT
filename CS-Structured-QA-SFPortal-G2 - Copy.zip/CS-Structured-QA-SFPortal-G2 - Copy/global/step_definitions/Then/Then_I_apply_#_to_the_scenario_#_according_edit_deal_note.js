// Recommended filename : Then_I_apply_#_to_the_scenario_#_according_edit_deal_note.js
module.exports = function() {
       this.Then(/^I apply "([^"]*)" to the scenario "([^"]*)" according edit deal note$/, function (arg1, arg2) {
         // Write code here that turns the phrase above into concrete actions
            const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
            var assumptions_input = '(' + cashflow_xpath.dealCfsInput.replace('__NAME__',arg1) + ')[' + arg2 + ']';
            browser.setValue(assumptions_input,this.settleDate);
            console.log(this.settleDate);
            console.log(assumptions_input);
            console.log(browser.getValue(assumptions_input));
       });
};
