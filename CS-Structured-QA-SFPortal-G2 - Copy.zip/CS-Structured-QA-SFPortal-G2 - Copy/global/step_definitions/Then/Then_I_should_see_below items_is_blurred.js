module.exports = function() {
  this.Then(/^I should see below items is blurred$/,
    function (table) {

      var expectList = table.hashes();

      const header_xpath = this.xpath_lib.xpathRequire('header_xpath');     
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      var self = this;

      expectList.forEach(function(list_row){
        var targetSection_xpath;
        var targetSection_xpath1;

        switch(list_row['type']){
          case 'button':
              targetSection_xpath = content_xpath.blurredButton;
              break;
          case 'header-button':
              targetSection_xpath = header_xpath.blurredHeaderBtn;
              targetSection_xpath1 = header_xpath.blurredHeaderBtn1;
              break;
          case 'widget':
              targetSection_xpath = content_xpath.blurredWidget;
              break;
          case 'section':
              targetSection_xpath = content_xpath.blurredSection;
              targetSection_xpath1 = content_xpath.blurredSection1;
              break;
         }
         var blurred_xpath;
         if(list_row['name']=="Home" || list_row['name']=="Research" || list_row['name']=="Scenario 2" || list_row['name']=="Scenario 3" || list_row['name']=="Scenario 4" || list_row['name']=="Scenario 5"){
           blurred_xpath = targetSection_xpath1.replace("__TEXT__",list_row['name']);
         }else if(list_row['name'] == "export results"){
           blurred_xpath='//span[contains(@class,"download")]/ancestor::button[contains(@class,"antiFeature")]';
         }else{
           blurred_xpath = targetSection_xpath.replace("__TEXT__",list_row['name']);
         }
         console.log(blurred_xpath);
         browser.waitForVisible(blurred_xpath,self.waitDefault);
         browser.pause(100);   
       });    
   }
)};