// Recommended filename: Then_I_should_see_the_below_widget-chart_to_contain_its_chart_text.js
module.exports = function() {
  this.Then(/^I should see the below widget-chart to contain its chart text$/, {timeout: process.env.StepTimeoutInMS*5}, function(table) {
    const performancePage_xpath = this.xpath_lib.xpathRequire('performancePage_xpath');
    var expected_rows = table.hashes();
    var waitTime = this.waitDefault*5 
    expected_rows.forEach(function(row) {
      var widgetChart_xpath = performancePage_xpath.titledwidgetChart.replace('__TITLE__', row['chart_name']);
      try {
        browser.waitForVisible(widgetChart_xpath, waitTime);
      } catch(e) {}
      browser.getLocationInView(widgetChart_xpath);
      browser.moveToObject(widgetChart_xpath);
      browser.pause(300);
      var displayedChartText = browser.getText(widgetChart_xpath);
      console.log(widgetChart_xpath);
      expect(displayedChartText).toContain(row['chart_text']);
    });
  });
};
