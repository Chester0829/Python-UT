// Then_I_should_see_the_order_of_#_column_for_#_under_the_#_panel-heading.js
module.exports = function(){
	this.Then(/^I should see the order of "([^"]*)" column for (number|text) under the "([^"]*)" panel\-heading$/, 
		function (column,type,panelName) {
		this.browser_session.waitForResource(browser);

        const bwic_xpath = this.xpath_lib.xpathRequire('bwic_xpath');
        const content_xpath = this.xpath_lib.xpathRequire('content_xpath');

		if(panelName == 'Tranche Level Universe: CLO' ||panelName == 'Tranche Level Universe: AUTO'|| panelName == 'Key Stats: Portfolio-CLO-for-automation'
            ||panelName == 'Key Stats: Portfolio-All-for-automation'||panelName == 'Key Stats: Portfolio-RMBS-for-automation'
            ||panelName == 'Dealer Inventory: ALL'||panelName == 'BWIC List: CLO/ CBO'
            ||panelName == 'BWIC List: User Input BWIC List' ||panelName == 'BWIC List: User Input BWIC List for CMBS' ||panelName == 'BWIC List: User Input BWIC List for Mix'){
          var myPanel = content_xpath.titledSectionLowercaseBWIC.replace('__TITLE__', panelName.toLowerCase());
        }
        
        var result = [];
        var htmls = browser.getHTML(myPanel + bwic_xpath.enhancedBWICTable);
        var table_json = this.tabletojson.convert(htmls)[0];
        // console.log(table_json);
        for(var i=1;i<table_json.length-1;i++){
        	result.push(table_json[i][column]);
        }
        // check sort
        // console.log(result);

        // difine the rules of sort
        var compare = function (str1,str2) {      
        return str1 - str2;
        }

        var pre = result;
        //console.log('pre:',pre);
        var result1 = [];
        var pre1 = [];
        if(type == 'number'){
            var k=1;
            for(var j=0;j<table_json.length-2;j++){
                if(result[j]=='-') k++;
                }
            console.log(k);
            result.length = table_json.length-1-k;

            var sorted_result = result.sort(compare);
            console.log('sorted_result:',sorted_result);
            var tmp = sorted_result.join(' :: ');
            //expect(pre.toLowerCase().toString()).toEqual(tmp.toLowerCase().toString().replace(/nan/g,"-"));
            pre.length = table_json.length-1-k;
            var pre1 = pre.join(' :: ');
            expect(pre1).toEqual(tmp);
        }       
        else{
        var pre1 = result.join(' :: ');
        console.log('pre1:',pre1);
        var sorted_result = result.map(function(item){return item.toLowerCase()}).sort();
        // var sorted_result = result.sort();
        }
        console.log('sorted_result:',sorted_result);
        var tmp = sorted_result.join(' :: ');
        //expect(pre.toLowerCase().toString()).toEqual(tmp.toLowerCase().toString().replace(/nan/g,"-"));
        expect(pre1.toLowerCase()).toEqual(tmp.toLowerCase());     
	})

 }
