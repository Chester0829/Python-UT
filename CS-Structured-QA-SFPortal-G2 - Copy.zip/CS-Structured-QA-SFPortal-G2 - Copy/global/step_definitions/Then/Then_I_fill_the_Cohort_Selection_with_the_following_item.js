//Then_I_fill_the_Cohort_Selection_with_the_following_item.js
module.exports = function() {
  this.Then(/^I fill the Cohort Selection with the following item$/, function (table) {
         // Write code here that turns the phrase above into concrete actions 
         const content_xpath = this.xpath_lib.xpathRequire('content_xpath');    
         var cohort_table = table.hashes()
         this.cohort_table = cohort_table
         var pill_element='//*[@class="pillGroup"]//span';
         cohort_table.forEach(function(list_row){
            browser.setValue(content_xpath.inputoption.replace('__NAME__','customSearchCtrl.searchStr'),list_row['cohort_item'])
            browser.pause(500);
            browser.keys('Enter') 
            browser.pause(500);
            var pill_text=browser.getText('//*[@class="pillGroup"]//span');
            console.log(pill_text)
            if(list_row['show']=='N'){
                expect(pill_text).not.toContain(list_row['cohort_item'])
            }else{
                expect(pill_text).toContain(list_row['cohort_item'])
            }

         });
         this.browser_session.waitForLoading(browser,'//md-progress-linear')
        
       })
};
