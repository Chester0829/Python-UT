// Recommended filename: Then_I_should_see_the_textarea_under_the_#_panel-heading_to_#_the_following_text.js
module.exports = function() {
  this.Then(/^I should see the textarea under the "([^"]*)" panel-heading to (contain|match) the following text$/, function (panelName, action, table) {
    // Write the automation code here
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const portfolioPage_xpath = this.xpath_lib.xpathRequire('portfolioPage_xpath');

    // browser.pause(1000);
    this.browser_session.waitForLoading(browser);
    var myPanel_xpath = content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase());
    var myBrowserSession = this.browser_session;
    var expected_row_list = table.hashes();
    var textarea_xpath = myPanel_xpath + portfolioPage_xpath.textEditor;
    var displayed_textarea_content = browser.getText(textarea_xpath);
    expected_row_list.forEach(function(expected_row, index) {
      switch (action) {
        case 'contain':
          expect(displayed_textarea_content).toContain(expected_row['row_data']);
          break;
        case 'match':
          expect(displayed_textarea_content).toMatch(expected_row['row_data']);
          break;
      };
    });
  });
};
