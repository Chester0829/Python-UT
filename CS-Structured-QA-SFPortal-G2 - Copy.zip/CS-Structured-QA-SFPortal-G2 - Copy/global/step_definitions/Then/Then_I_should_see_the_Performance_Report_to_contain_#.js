// Recommended filename: Then_I_should_see_the_Performance_Report_to_contain_#.js
module.exports = function() {
  this.Then(/^I should see the Performance Report to contain "([^"]*)"$/, {timeout: process.env.StepTimeoutInMS}, function(expectedReportText) {
    const performancePage_xpath = this.xpath_lib.xpathRequire('performancePage_xpath');
    var reportChart_xpath = performancePage_xpath.performanceReportChart;
    var reportText_xpath = performancePage_xpath.performanceReportText;
    var report_loading_bar = performancePage_xpath.reportLoadingBar;
    this.browser_session.waitForLoading(browser,report_loading_bar);
    try {
      browser.waitForVisible(reportChart_xpath, this.waitDefault);
    } catch(e) {}
    var displayedReportText = browser.getText(reportText_xpath);
    browser.getLocationInView(reportText_xpath);
    expect(displayedReportText.toString()).toContain(expectedReportText);

  });
};
