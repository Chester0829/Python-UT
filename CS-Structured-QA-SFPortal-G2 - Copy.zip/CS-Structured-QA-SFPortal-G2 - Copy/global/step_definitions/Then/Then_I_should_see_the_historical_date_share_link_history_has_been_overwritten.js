module.exports = function() {
  this.Then(/^I should see the historical date share link history has been overwritten$/,
   function () {
     const clickwrap_xpath = this.xpath_lib.xpathRequire('clickwrap_xpath');
     var wrapperHistoryTable = clickwrap_xpath.wrapperHistoryTable;
     var currentRow = this.currentRow;
     var dateLocation = wrapperHistoryTable + '//tr['+ currentRow+']//td[5]//span[@ng-bind-html]';
     console.log(dateLocation);
     browser.waitForVisible(dateLocation,this.waitDefault);
     var dateDisplay = browser.getText(dateLocation);
     console.log(dateDisplay);
     var myDate = new Date(); 
     var currentDate = myDate.getFullYear()+'-'+('0'+(myDate.getMonth()+1)).slice(-2)+'-'+ ('0'+myDate.getDate()).slice(-2);
     console.log(currentDate);
     expect(dateDisplay).toBe(currentDate);
    
  }
)}