// Then_I_should_see_#_entry_contain_#_item_display_under_the_#_panel-heading.js
module.exports = function(){
	this.Then(/^I should see (only one|any) entry contain "([^"]*)" item display under the "([^"]*)" panel-heading$/, 
		{timeout: process.env.StepTimeoutInMS*5},
		function (expectNum, value, panelName) {
			this.browser_session.waitForResource(browser);
			const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
			if(panelName == 'BWIC Analyzer:'){
				// cmbs bwic
				var myPanel = '//*[contains(@ng-init,"vm.initializeBwic")]';
			}else{
				var myPanel = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase());
			}
			// var myPanel = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase());
			var table_xpath = myPanel + content_xpath.descendantDataTable;
			// get table text
			var table_text = browser.getText(table_xpath + '//tbody//tr');
			table_text = Array.isArray(table_text) ? table_text.join(' :: ') : table_text;
			console.log(table_text);
			// get show entries
			var entries_info = browser.getText(myPanel + content_xpath.show_entries);
			console.log(entries_info);
			// var total_num = parseInt(entries_info.split(' ')[5]);
			var total_num = parseInt(entries_info.split('entries')[0].trim().split('of')[1]);
			switch(expectNum){
				case 'only one':
					expect(total_num).toEqual(1);
					// console.log(table_text.split(value))
					expect(table_text.split(value).length).toEqual(2);
					break;
				case 'any':
					expect(table_text).toContain(value);
					break;
				default:
					expect(false).toBe(true,'other option');
					break;
			}

		})
}