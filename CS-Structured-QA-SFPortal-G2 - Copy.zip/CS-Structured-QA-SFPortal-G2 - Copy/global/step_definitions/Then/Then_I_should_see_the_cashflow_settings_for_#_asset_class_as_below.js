// Recommended filename: Then_I_should_see_the_cashflow_settings_for_#_asset_class_as_below.js
module.exports = function() {
  this.Then(/^I should see the cashflow settings for "([^"]*)" asset class as below$/, 
    {timeout:process.env.StepTimeoutInMS*5},
    function (assetType, table) {
    // Write code here that turns the phrase above into concrete actions
    const settingsPage_xpath = this.xpath_lib.xpathRequire('settingsPage_xpath');
    var setting_list = table.hashes();

    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    
    var assetTab = settingsPage_xpath.cashflowSettingsAssetTypeTab.replace('__TABNAME__',assetType);
    console.log(assetTab);
    try{
      browser.waitForEnabled(assetTab,this.wait5);
      browser.click(assetTab);
    }catch(e){
      console.log('try again...');
      assetTab = settingsPage_xpath.cashflowSettingsAssetTypeTab1.replace('__TABNAME__',assetType);
      browser.click(assetTab);
    }

    if(assetType == 'CDO'){
        setting_list.forEach(function(list_row)
        {
        switch(list_row['name']){
            //checkbox items
            case "Default Until End":
            case "Default Before Amort":
            case "Non Performing Bonds Default":
            case "Recover Defaults at Maturity/Call":
            case "Liq NonPerf @ Market":
            case "Use Asset-Level Recovery Rate":
            case "Use Asset-Level Recovery Rate for NonPerf":
            case "Use Recovery Schedule (Periods)":
                var check_box = settingsPage_xpath.cashflowSettingsCheckBoxItems.replace('__CHECKBOXLABEL__',list_row['name']);
                console.log(check_box);
                var target_attribute = browser.getAttribute(check_box, 'aria-checked');
                console.log(target_attribute);
                if(list_row['value']=='unchecked'){
                    expect(target_attribute).toBe('false');
                    browser.pause(100); 
                }
                else{
                    expect(target_attribute).toBe('true');
                    browser.pause(100);
                }
                break;
            //select items
            case "Default Bond Rating Moody's":
            case "Default Bond Rating S&P":
            case "Default Bond Rating Fitch":
                var selectIcon = settingsPage_xpath.cashflowSettingsSelectIcon.replace('__SELECTLABEL__',list_row['name']);
                console.log(selectIcon);
                expect(browser.getText(selectIcon)).toEqual(list_row['value']); 
                break;
            //input items
            case "Default Bond below Market Price":
            case "Custom Flags Default Rate":
            case "Custom Flags Loss Rate":
            case "Interest Loss Severity":
                var inputItem = settingsPage_xpath.cashflowSettingsInputItems.replace('__INPUTLABEL__',list_row['name']);
                if(!browser.isVisible(inputItem)){
                  inputItem = settingsPage_xpath.cashflowSettingsInputItems1.replace('__INPUTLABEL__',list_row['name']);
                }
                console.log(inputItem);
                expect(browser.getValue(inputItem)).toEqual(list_row['value']);
                console.log(browser.getValue(inputItem));
                break;
            }
        })
    }
    else{
        setting_list.forEach(function(list_row)
        {
        switch(list_row['name']){
            //checkbox items
            case "Default Until End":
            case "REO":
            case "Foreclosed":
            case "Delinquent":
            case "Bankrupt":
            case "Interest Calculated Before Defaults":
            case "Reimburse Advance P&I":
            case "Prepays Only On Pay Dates":
                var check_box = settingsPage_xpath.cashflowSettingsCheckBoxItemsforABS.replace('__CHECKBOXLABEL__',list_row['name']);
                console.log(check_box);
                var target_attribute = browser.getAttribute(check_box, 'aria-checked');
                console.log(target_attribute);
                if(list_row['value']=='unchecked'){
                    expect(target_attribute).toBe('false');
                    browser.pause(100); 
                }
                else{
                    expect(target_attribute).toBe('true');
                    browser.pause(100);
                }
                break;
            //select items
            case "Calculation Method":
            case "Servicer Advances P&I":
                var selectIcon = settingsPage_xpath.cashflowSettingsSelectIconforABS.replace('__SELECTLABEL__',list_row['name']);
                console.log(selectIcon);
                browser.pause(200);
                //var selectValue = settingsPage_xpath.cashflowSettingsSelectOption.replace('__OPTIONTEXT__',list_row['value']); 
                expect(browser.getText(selectIcon)).toEqual(list_row['value']);    
                break;
            //input items
            case "Interest Loss Severity":
                var inputItem = settingsPage_xpath.cashflowSettingsInputItemsforABS.replace('__INPUTLABEL__',list_row['name']);
                if(!browser.isVisible(inputItem)){
                  inputItem = settingsPage_xpath.cashflowSettingsInputItemsforABS2.replace('__INPUTLABEL__',list_row['name']);
                }
                console.log(inputItem);
                expect(browser.getValue(inputItem)).toEqual(list_row['value']);
                console.log(browser.getValue(inputItem));
                break;
            case "Max Prepay":
                var inputItem = settingsPage_xpath.cashflowSettingsInputItemsforABS1.replace('__INPUTLABEL__',list_row['name']);
                if(!browser.isVisible(inputItem)){
                  inputItem = settingsPage_xpath.cashflowSettingsInputItemsforABS3.replace('__INPUTLABEL__',list_row['name']);
                }
                console.log(inputItem);
                expect(browser.getValue(inputItem)).toEqual(list_row['value']);
                console.log(browser.getValue(inputItem));
                break;
            }
        })
    };
  });
}