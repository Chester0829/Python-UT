//Then_I_should_see_the_following_content_in_#_panel-heading.js
module.exports = function(){
 this.Then(/^I should see the following content in "([^"]*)" panel-heading$/, function (widgetName, table) {
         // Write code here that turns the phrase above into concrete actions
  const content_xpath = this.xpath_lib.xpathRequire('content_xpath');

  var row_list = table.hashes();
  var myPanel = content_xpath.titledPanelLowercase.replace('__TITLE__', widgetName.toLowerCase());

  this.browser_session.waitForResource(browser);
  this.browser_session.waitForLoading(browser);

  for(var i = 0; i<row_list.length; i++){
    switch(widgetName){
          case 'Features':
            var text = myPanel + "//*[contains(text(),\"" + row_list[i].note + "\")]";
            if(row_list[i].note=='Workflow Improvements'||row_list[i].note=='New Features'||row_list[i].note=='Release Notes'){
              var text = myPanel + "//a[contains(text(),\"" + row_list[i].note + "\")]";
            }
            console.log(text);
            expect(browser.waitForVisible(text,this.waitDefault)).toBe(true);
            break;
          case 'More Information':
            var text = myPanel + "//a[contains(text(),\"" + row_list[i].note + "\")]";
            if(row_list[i].note=='Webinars on Demand'||row_list[i].note=='Additional Product Offerings'||row_list[i].note=='Areas of Focus'){
              var text = myPanel + "//strong[contains(text(),\"" + row_list[i].note + "\")]";
            }
            console.log(text);
            expect(browser.waitForVisible(text,this.waitDefault)).toBe(true);
            break;
          case 'Journal':
            var text = myPanel + "//*[contains(text(),\"" + row_list[i].note + "\")]";
            console.log(text);
            expect(browser.waitForVisible(text,this.waitDefault*5)).toBe(true);
            break;
          case 'Documents':
            var text = myPanel + "//a[contains(text(),\"" + row_list[i].note + "\")]";
            if(row_list[i].note=='Release Notes'||row_list[i].note=='Credit Model Brochures'||row_list[i].note=='Macro Scenarios Descriptions'
              ||row_list[i].note=='OTTI Methodology'||row_list[i].note=='Other Methodology Documents'||row_list[i].note=='Product Offerings'
              ||row_list[i].note=='Areas of Focus'||row_list[i].note=='Glossary'||row_list[i].note=='Custom Scenarios'){
              var text = myPanel + "//b[contains(text(),\"" + row_list[i].note + "\")]";
            }
            console.log(text);
            expect(browser.waitForVisible(text,this.waitDefault)).toBe(true);
            break;
    }
  }
 });
};