// Recommended filename: Then_I_should_be_able_to_search_the_assets_from_following_#_item.js
module.exports = function() {
  this.setDefaultTimeout(360*1000);
  this.Then(/^I should be able to search the assets from following (industry|issuer) item$/, {timeout: process.env.StepTimeoutInMS*30}, function (searchType, table) {
    var search_items = table.hashes();
    const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
    var searchInput_xpath = header_xpath.searchInput;
    var searchResult_xpath = header_xpath.searchResult;
    var browser_session = this.browser_session;
    var eachItem_searchWaittime = process.env.StepTimeoutInMS / search_items.length;
    browser_session.waitForResource(browser);
    browser_session.waitForLoading(browser);
    //browser_session.waitForRender(browser);
    search_items.forEach(function(item) {
      console.log(item['search_text']);
      browser.setValue(searchInput_xpath, item['search_text']);
      //browser.pause(1000);
      browser_session.waitForResource(browser);
      browser_session.waitForLoading(browser);
      browser.waitForText(searchResult_xpath, );
      //browser.pause(1000);
      var searchResultText = browser.getText(searchResult_xpath, eachItem_searchWaittime);
      console.log(searchResultText);
      expect(searchResultText).toContain(searchType.toUpperCase());
      expect(searchResultText).toContain(item['search_text']);
      if (item['expected_result']) {
        expect(searchResultText).toContain(item['expected_result']);
      }
      if (item['expected_not']) {
        expect(searchResultText).not.toContain(item['expected_not']);
      }
    });
  });
};
