module.exports = function() {
    this.Then(/^I should see the "([^"]*)" selected chart count is the same as FieldsPlus selected$/, function(widgetName) {
        // Write code here that turns the phrase above into concrete actions
        const content_xpath = this.xpath_lib.xpathRequire('content_xpath');

        browser.pause(5000);
        var keydiff_items_element = content_xpath.titledPanelLowercase.replace('__TITLE__', widgetName.toLowerCase()) + '//sfp-key-diff-re';
        this.browser_session.waitForResource(browser, keydiff_items_element);
        var keydiff_items_count = browser.elements(keydiff_items_element).value.length;
        expect(keydiff_items_count == this.selected_count).toBe(true, keydiff_items_count, this.selected_count);
    });
}