// Recommended filename: Then_I_should_see_the_#_settings_for_#_panel-heading_as_below.js
module.exports = function() {
  this.Then(/^I should see the "([^"]*)" settings for "([^"]*)" panel-heading as below$/, 
    {timeout:process.env.StepTimeoutInMS*5},
    function (type, widgetName, table) {
    // Write code here that turns the phrase above into concrete actions
    const settingsPage_xpath = this.xpath_lib.xpathRequire('settingsPage_xpath');
    var setting_list = table.hashes();
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');

    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    
    var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());

    if(type == 'OTTI'){
        setting_list.forEach(function(list_row)
        {
        switch(list_row['name']){
            //checkbox items
            case "Use Book Price Average":
                var check_box = myPanel + settingsPage_xpath.settingsCheckBoxItems.replace('__CHECKBOXLABEL__',list_row['name']);
                console.log(check_box);
                var target_attribute = browser.getAttribute(check_box, 'aria-checked');
                console.log(target_attribute);
                if(list_row['value']=='unchecked'){
                    expect(target_attribute).toBe('false');
                    browser.pause(100); 
                }
                else{
                    expect(target_attribute).toBe('true');
                    browser.pause(100);
                }
                break;
            //select items
            case "OTTI Calculation":
            case "Notional Loss Type":
            case "OCI Calculation":
            case "Book Price Average":
            case "Fair Value Calculation Approach:":
            case "Implied Yield Calculation:":
            case "Fair Value Credit Calculation:":
                var selectIcon = myPanel + settingsPage_xpath.settingsSelectIcon.replace('__SELECTLABEL__',list_row['name']);
                console.log(selectIcon);
                expect(browser.getText(selectIcon)).toEqual(list_row['value']); 
                break;
            //input items
            case "Notional Loss Threshold":
                var inputItem = myPanel + settingsPage_xpath.settingsInputItems.replace('__INPUTLABEL__',list_row['name']);
                if(!browser.isVisible(inputItem)){
                  inputItem = settingsPage_xpath.settingsInputItems1.replace('__INPUTLABEL__',list_row['name']);
                }
                console.log(inputItem);
                expect(browser.getValue(inputItem)).toEqual(list_row['value']);
                console.log(browser.getValue(inputItem));
                break;
            }
        })
    }
  });
}