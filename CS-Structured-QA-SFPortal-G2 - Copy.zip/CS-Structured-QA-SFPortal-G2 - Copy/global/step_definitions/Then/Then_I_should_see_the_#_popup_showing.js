module.exports = function() {
  this.Then(/^I should see the "([^"]*)" popup showing$/, function (popupName) {
    // Write code here that turns the phrase above into concrete actions
    // return 'pending';
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    var popup_panel = content_xpath.titledSection.replace('__TITLE__', popupName);
    if(popupName == 'Layout successfully copied'){
      popup_panel = content_xpath.titledSection1.replace('__TITLE__', popupName);
      browser.waitForVisible(popup_panel, this.waitDefault);
    }else{
      try {
        this.browser_session.waitForResource(browser);
        browser.waitForVisible(popup_panel, this.waitDefault); 
      } catch (e) {
        console.log(e);
        browser.pause(500);
        this.robot_session.keyTap();
      } 
    }   
    this.browser_session.waitForResource(browser);
  });
}