// Then_I_should_see_the_download_file_should_be_same_as_the_upload_file.js
//  for Deal Documents - My Company's Private Files
module.exports = function() {
	this.Then(/^I should see the download file should be same as the upload file$/,
    {timeout: process.env.StepTimeoutInMS*5},  
    function(){
    	var fs = require('fs');
    	// I click a drilldown link in row "([^"]*)" and column "([^"]*)" in "([^"]*)" panel-heading table
    	// console.log(this.downloadFileName);
    	var my_download_file = this.file_session.waitForDownload(browser,this.downloadFileName);
    	// console.log(my_download_file)
    	var download_file_content = fs.readFileSync(my_download_file,{encoding:'utf-8'});
    	// console.log(download_file_content);
    	// I upload file "([^"]*)" by click "([^"]*)" button
    	var upload_file_content = fs.readFileSync(this.uploadFilePath,{encoding:'utf-8'});
    	// console.log(upload_file_content);
    	expect(download_file_content).toEqual(upload_file_content);

    })

}