// Recommended filename: Then_I_should_see_the_following_settings_under_the_#_panel-heading.js
module.exports = function() {
  this.Then(/^I should see the following settings under the "([^"]*)" panel-heading$/, 
    {timeout:process.env.StepTimeoutInMS*5},
    function (widgetName, table) {
    // Write code here that turns the phrase above into concrete actions
    const settingsPage_xpath = this.xpath_lib.xpathRequire('settingsPage_xpath');
    var expected_row_list = table.hashes();

    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    
    console.log(expected_row_list.length);
    expected_row_list.forEach(function(setting_list, rowIndex){
        if(setting_list['Watchlist (Custom)']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[2]//span//input";
            console.log(xpath);
            var attribute = browser.getAttribute(xpath,'class');
            console.log(attribute);
            if(setting_list['Watchlist (Custom)']=='unchecked'){
                expect(attribute).toContain('ng-empty');
                browser.pause(100); 
                }
            else{
                expect(attribute).toContain('ng-not-empty');
                browser.pause(100);
            }
        }
        if(setting_list['Watchlist Status (Custom)']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[3]//span/select";
            console.log(xpath);
            console.log(browser.getValue(xpath));
            expect(browser.getValue(xpath)).toBe(setting_list['Watchlist Status (Custom)']);
        }
        if(setting_list['Defaulted (Custom)']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[4]//span//input";
            console.log(xpath);
            var attribute = browser.getAttribute(xpath,'class');
            if(setting_list['Defaulted (Custom)']=='unchecked'){
                expect(attribute).toContain('ng-empty');
                browser.pause(100); 
                }
            else{
                expect(attribute).toContain('ng-not-empty');
                browser.pause(100);
            }
        }
        if(setting_list['Rating (Custom)']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[5]//span//input";
            console.log(xpath);
            console.log(browser.getValue(xpath));
            expect(browser.getValue(xpath)).toBe(setting_list['Rating (Custom)']);
        }
        if(setting_list['Custom 1']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[6]//span//input";
            console.log(xpath);
            console.log(browser.getValue(xpath));
            expect(browser.getValue(xpath)).toBe(setting_list['Custom 1']);
        }
        if(setting_list['Custom 2']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[7]//span//input";
            console.log(xpath);
            console.log(browser.getValue(xpath));
            expect(browser.getValue(xpath)).toBe(setting_list['Custom 2']);
        }
        if(setting_list['Custom 3']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[8]//span//input";
            console.log(xpath);
            console.log(browser.getValue(xpath));
            expect(browser.getValue(xpath)).toBe(setting_list['Custom 3']);
        }
        if(setting_list['Custom 4']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[9]//span//input";
            console.log(xpath);
            console.log(browser.getValue(xpath));
            expect(browser.getValue(xpath)).toBe(setting_list['Custom 4']);
        }
        if(setting_list['Custom 5']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[10]//span//input";
            console.log(xpath);
            console.log(browser.getValue(xpath));
            expect(browser.getValue(xpath)).toBe(setting_list['Custom 5']);
        }
    })
  });
}