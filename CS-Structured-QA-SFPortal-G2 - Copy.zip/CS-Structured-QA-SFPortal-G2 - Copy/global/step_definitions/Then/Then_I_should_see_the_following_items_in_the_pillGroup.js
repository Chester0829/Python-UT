module.exports = function() {
    this.Then(/^I should see the following items in the pillGroup$/, function(table) {
        // Write the automation code here
        var items = table.hashes();
        const pillGroup_xpath = this.xpath_lib.xpathRequire('pillGroup_xpath');

        browser.waitForVisible(pillGroup_xpath.pillGroup,this.waitDefault);
        for(var i = 0; i<items.length; i++){
            console.log(items[i].item);
            var item = pillGroup_xpath.pillGroup_item.replace('__ITEMNAME__', items[i].item);
            console.log(item);
            browser.waitForVisible(item, this.waitDefault);
        };
    });
};