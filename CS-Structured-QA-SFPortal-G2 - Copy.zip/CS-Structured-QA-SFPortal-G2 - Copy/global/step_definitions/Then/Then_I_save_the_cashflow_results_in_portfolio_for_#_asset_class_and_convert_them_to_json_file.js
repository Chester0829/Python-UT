//  Then_I_save_the_cashflow_results_in_portfolio_for_#_asset_class_and_convert_them_to_json_file.js
module.exports = function () {
    this.Then(/^I save the cashflow results in (portfolio|FLC portfolio|DM portfolio|Spread portfolio|Price portfolio) for "([^"]*)" asset class and convert them to json file$/,
        { timeout: process.env.StepTimeoutInMS * 10 },
        function (portfolioMode, assettype, table) {
            this.browser_session.waitForResource(browser);
            var fs = require("fs");
            var path = require('path');
            const cashflow_xpath = this.xpath_lib.xpathRequire("cashflow_xpath");
            const content_xpath = this.xpath_lib.xpathRequire("content_xpath");
            var cashflow_res = {};
            var run_deal_request_flag = table.hashes()[0]["run_deal_request"];
            var myTable = cashflow_xpath.portfolioCfresultTable;
            var mySelectCaret_xpath;
            var panelName = "Results";
            var self = this; 
            var myWaitDefault = this.waitDefault;
            //var myPanel = content_xpath.titledSectionLowercase.replace("__TITLE__", panelName.toLowerCase());
            this.assettype=assettype;
            var restlen; 
            // var restlenfortranche = {};
            console.log(this.name);
            // this.pagetype=pagetype;
            switch (assettype) {  
                case "CLO":
                    var cashflow_type_list = ["Tranche Flows", "Collateral Flows", "Fees", "Tests", "Reinvestment", "Accounts", "Hedges", "Principal Paydown"];
                    // var cashflow_type_list = ["Principal Paydown"];
                    // if(this.name == "ALLCFS CDO Portfolio"){
                    //     var cashflow_tranche_list = ["Dryden 48 Euro CLO 2016 BV-A1", "Citius I Funding Ltd.-A1"];
                    // }
                    // if(this.name == "ALLCFS CDO Portfolio Spread 1"){
                    //     var cashflow_tranche_list = ["Ares XXXVIII CLO Ltd.-CR", "BlueMountain CLO 2016-2 Ltd.-C"];
                    // }
                    // if(this.name == "ALLCFS CDO Portfolio Spread 2"){
                    //     var cashflow_tranche_list = ["Carlyle US CLO 2018-1 Ltd.-A1", "CBAM 2017-1 Ltd.-B"];
                    // }
                    // if(this.name == "ALLCFS CDO Portfolio Spread 3"){
                    //     var cashflow_tranche_list = ["HPS Loan Management 7-2015 Ltd. (FKA Highbridge Loan Management 7-2015 Ltd.)-ER", "Greenwood Park CLO Ltd.-E"];
                    // }
                    // if(this.name == "ALLCFS CDO Portfolio Spread 4"){
                    //     var cashflow_tranche_list = ["LCM 27 Ltd.-D", "KKR CLO 21 Ltd.-PS"];
                    // }
                    // if(this.name == "ALLCFS CDO Portfolio Spread 5"){
                    //     var cashflow_tranche_list = ["Neuberger Berman Loan Advisers CLO 26 Ltd.-E", "Octagon Investment Partners 29 Ltd.-PS"];
                    // }
                    // if(this.name == "ALLCFS CDO Portfolio Spread 6"){
                    //     var cashflow_tranche_list = ["CIFC Funding 2017-III Ltd.-D", "GSC ABS CDO 2006-4u Ltd.-C"];
                    // }
                    // if(this.name == "ALLCFS CDO Portfolio Spread 7"){
                    //     var cashflow_tranche_list = ["Neuberger Berman CLO XVIII Ltd.-CR2", "NewStar Commercial Loan Funding 2017-1 LLC (FKA NewStar Commercial Loan Funding 2013-1 LLC)-EN"];
                    // }
                    // if(this.name == "ALLCFS CDO Portfolio Spread 8"){
                    //     var cashflow_tranche_list = ["OCP CLO 2016-11 Ltd.-PS1", "Octagon Investment Partners 28 Ltd.-DR"];
                    // }
                    // if(this.name == "ALLCFS CDO Portfolio Spread 9"){
                    //     var cashflow_tranche_list = ["Race Point X CLO Ltd.-ER", "Park Avenue Institutional Advisers CLO Ltd. 2016-1-CR"];
                    // }
                    // if(this.name == "ALLCFS CDO Portfolio Spread 10"){
                    //     var cashflow_tranche_list = ["THL Credit Wind River 2016-2 CLO Ltd.-C2R", "Regatta VII Funding Ltd.-ER"];
                    // }
                    // if(this.name == "ALLCFS Portfolio"){
                    //     var cashflow_tranche_list = ["Alinea CLO Ltd.-B", "Dryden 63 GBP CLO 2018 BV-C1"];  
                    // }
                    break;
                case "ABS":
                    //var cashflow_type_list = ["Tranche Flows", "Collateral Flows", "Fees", "Accounts"];
                    var cashflow_type_list = ["Tranche Flows", "Collateral Flows", "Fees", "Accounts", "Hedges", "Triggers", "Principal Paydown"];
                    //var cashflow_type_list = ["Tranche Flows", "Collateral Flows", "Fees", "Accounts", "Hedges", "Triggers", "Principal Paydown"];
                    // var cashflow_tranche_list = ["DELL EQUIPMENT FINANCE TRUST 2019-1-A1", "FLEXI ABS TRUST 2018-1-A2"];
                    break;
                case "AUTO":
                    var cashflow_type_list = ["Tranche Flows", "Collateral Flows", "Fees", "Accounts", "Hedges", "Triggers", "Principal Paydown"];
                    //var cashflow_type_list = ["Tranche Flows", "Collateral Flows", "Fees", "Accounts", "Hedges", "Triggers", "Principal Paydown"];
                    // var cashflow_tranche_list = ["SC Germany Auto 2018-1 UG (haftungsbeschraenkt)-A", "MERCEDES-BENZ AUTO LEASE TRUST 2019-A-A2"];
                    break;
                case "CARDS":
                    var cashflow_type_list = ["Tranche Flows", "Collateral Flows", "Fees", "Accounts", "Hedges", "Triggers", "Principal Paydown"];
                    //var cashflow_type_list = ["Tranche Flows", "Collateral Flows", "Fees", "Accounts", "Hedges", "Triggers", "Principal Paydown"];
                    // var cashflow_tranche_list = ["AMERICAN EXPRESS CREDIT ACCOUNT MASTER TRUST-20172A", "Barclays Dryrock Issuance Trust-20161A"];
                    break;
                case "SLABS":
                    var cashflow_type_list = ["Tranche Flows", "Collateral Flows", "Fees", "Accounts", "Hedges", "Triggers", "Principal Paydown"];
                    //var cashflow_type_list = ["Tranche Flows", "Collateral Flows", "Fees", "Accounts", "Hedges", "Triggers", "Principal Paydown"];
                    // var cashflow_tranche_list = ["SLM STUDENT LOAN TRUST 2004-8-A6", "Navient Student Loan Trust 2014-1-A3"];
                    break;
                case "CMBS":
                    var cashflow_type_list = ["Tranche Flows", "Collateral Flows", "Fees", "Accounts", "Hedges", "Triggers", "Principal Paydown"];
                    //var cashflow_type_list = ["Tranche Flows", "Collateral Flows", "Fees", "Accounts", "Hedges", "Triggers", "Principal Paydown"];
                    // var cashflow_tranche_list = ["TAURUS CMBS (PAN EUROPE) 2007-1 LIMITED-A1", "WACHOVIA BANK COMMERCIAL MORTGAGE TRUST SERIES 2007-C32-B"];
                    break;
                case "RMBS":
                    //var cashflow_type_list = ["Tranche Flows", "Collateral Flows", "Accounts",];
                    var cashflow_type_list = ["Tranche Flows", "Collateral Flows", "Fees", "Accounts", "Hedges", "Triggers", "PDL", "Principal Paydown"];
                    // if(this.name == "ALLCFS RMBS Portfolio"){
                    //     var cashflow_tranche_list = ["ALBA 2006-2 PLC-B", "MASTR ADJUSTABLE RATE MORTGAGES TRUST 2004-11-B1"];
                    // }
                    // else{
                    //     var cashflow_tranche_list = ["MADRID RMBS IV, FTA-A2", "Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1-B"];  
                    // }
                    break;
            }
             
            var tranche_summary_div = cashflow_xpath.portfolioCfsAllresultwidget;
            var tranche_table_elem = "("+tranche_summary_div+'//table)[1]//tbody';
            var cashflow_tranche_list = []
            var portfolio_length = browser.elements(tranche_table_elem).value.length
            for(var i=1;i<=portfolio_length;i++){
                var isin_name=''
                var tranche_name = ''
                var tranch_info = []

                var isin_name_xpath = tranche_table_elem + '/tr['+i+']/td[4]';
                isin_name = browser.getText(isin_name_xpath);
                var tranche_name_xpath = tranche_table_elem + '/tr['+i+']/td[1]';
                var tranche_class_xpath = tranche_table_elem + '/tr['+i+']/td[2]';
                tranche_name = browser.getText(tranche_name_xpath) + "-" + browser.getText(tranche_class_xpath);
                console.log(isin_name)
                console.log(tranche_name)
                tranch_info.push(isin_name)
                tranch_info.push(tranche_name)
                cashflow_tranche_list.push(tranch_info)
            }

            // var cashflow_type_list = ["Tranche Flows","Collateral Flows"];
            //var scenario_list_xpath = myPanel + content_xpath.named_mdSelectIcon2.replace("__NAME__", "analyticsCtrl.selectedScen");
            var scenario_list_xpath = cashflow_xpath.portfolioCfTrancheSelect;
            var scenario_list = this.scenario_list;
            //var scenario_list_length = scenario_list.length;
            var scenarios_used = this.scenarios_used;
            console.log('this.scenario_used:', scenarios_used);

            //  defined the write function
            var export_res = function (file_name, file_path, file_content, file_type) {
                var myDate = new Date();
                var month = myDate.getMonth() + 1;
                var day = myDate.getDate();
                var today = '0' + month + day;
                file_name = file_name + '_' + today + '.' + file_type;
                if (file_type == 'json') {
                    var data_json = JSON.stringify(file_content);
                } else {
                    var data_json = file_content;
                }
                //if (fs.existsSync(file_path)) {
                //    console.log(file_path + ' exist!') 
                //} else {
                //    fs.mkdir(file_path, function (err) {
                //        if (err) {
                //            console.log(err);
                //            throw err;
                //        }
                //        console.log('make dir success.');
                //    });
                //}
                self.utility_lib.mkdirsSync(file_path);
                // console.log("--------------------------cash flow---------------------------------",casgflow_json);
                fs.writeFile(file_path + '/' + file_name, data_json, { flag: "w" }, function (err) {
                    if (err) {
                        console.log(file_name + " saved failed!");
                        return console.log(err);
                    } else {
                        console.log(file_name + " saved successfully!");
                    }

                })
            }; 

            for (var tranche_index =0; tranche_index <= cashflow_tranche_list.length-1; tranche_index++) {
                var tranche_name = cashflow_tranche_list[tranche_index][1]
                var isin_name = cashflow_tranche_list[tranche_index][0]
                console.log('isin name:'+isin_name)
                console.log("Tranche Name:" + tranche_name);
                //  traverse the cash flow type list which we defined before
                for (var index in cashflow_type_list) {
                    //  console.log(cashflow_type_list[index]);
                    cashflow_res[cashflow_type_list[index]] = [];
                    //mySelectCaret_xpath = myPanel + content_xpath.named_mdSelectIcon2.replace("__NAME__", "analyticsCtrl.cashflow_type");
                    var select_tranche = cashflow_xpath.portfolioCfTrancheSelect;
                    console.log("click try: select_tranche" + select_tranche);
                    browser.click(select_tranche);
                    var select_tranche_item = select_tranche + cashflow_xpath.portfolioCfTypeTrancheOption.replace("__NAME__", tranche_name);
                    console.log("click try: select_tranche_item" + select_tranche_item);
                    browser.click(select_tranche_item);
                    mySelectCaret_xpath = cashflow_xpath.portfolioCfTypeSelect;
                    console.log("click try: mySelectCaret_xpath" + mySelectCaret_xpath);
                    browser.click(mySelectCaret_xpath);
                    var select_item = mySelectCaret_xpath + cashflow_xpath.portfolioCfTypeTrancheOption.replace("__NAME__", cashflow_type_list[index]);
                    console.log("select_item:", select_item);
                    this.browser_session.waitForResource(browser, select_item);
                    console.log('--------------------------selected cashflow type:' + browser.getText(select_item));
                    browser.click(select_item);

                    //var scenario_id = scenario_list[tranche_index]["scenario_id"];
                    var scenario_id = scenario_list[0]["scenario_id"];
                    console.log("scenario_id:", scenario_id);
                    if (assettype == 'CLO'){
                        var settles_date = scenarios_used[scenario_id][4];
                    }else{
                        var settles_date = scenarios_used[scenario_id][5];
                    }
                    
                    //TODO... what if data row >500
                    //  make sure could catch all rows once,change show items number to 500 directly
                    var next_page_xpath = '//a[contains(@ng-click,"selectPage(page + 1,")]';
                    console.log("next_page:", next_page_xpath);
                    browser.pause(3000);
                    if (browser.isVisible(next_page_xpath)) {
                        var display_item_number_xpath = '//md-select[contains(@ng-model,"ctrl.model.numPerPage")]';
                        console.log("display_item_number_xpath:", display_item_number_xpath);
                        this.browser_session.waitForResource(browser, display_item_number_xpath);
                        browser.click(display_item_number_xpath+'//*[@class="md-select-icon"]');
                        var selectNumber = '// md-select-menu/parent::div[@aria-hidden="false"]// *[contains(@class,"md-text") and contains(normalize-space(),"500")]';
                        try{
                            browser.waitForVisible(selectNumber,myWaitDefault);
                        }catch(err){
                            browser.click(display_item_number_xpath+'//*[@class="md-select-icon"]');
                            browser.waitForVisible(selectNumber,myWaitDefault);
                        }   
                        var selectNumberCheck = display_item_number_xpath + '//md-select-value//div[contains(text(),"500")]';
                        try {
                            browser.click(selectNumber);
                            browser.waitForVisible(selectNumberCheck,myWaitDefault);
                        } catch (err) {
                            console.log(err);
                            console.log("second click!");
                            if(browser.isVisible(selectNumber)){
                                browser.click(selectNumber);
                            }else{
                                browser.click(display_item_number_xpath+'//*[@class="md-select-icon"]');
                                browser.click(selectNumber);
                            }                                           
                            
                            browser.waitForVisible(selectNumberCheck,myWaitDefault);
                        }
                    }

                    var item = { "perfsummary": {}, };
                    item["perfsummary"]["scenario_id"] = scenario_id;
                    item["perfsummary"]["settles_date"] = settles_date;
                    switch (cashflow_type_list[index]) {
                        case "Tranche Flows":
                            console.log('--------------------------1. generate json file for tranche flows ----------------------------------')
                            var cashflow_type = cashflow_type_list[index];
                            var tranche_count = 2;
                            console.log("tranche_count:", tranche_count);
                            myTable = cashflow_xpath.portfolioCfresultTable;

                            item = { "perfsummary": {}, };
                            //  in case can get all rows once
                            try {
                                browser.waitForVisible(myTable, myWaitDefault);
                            } catch (error) {//wait data load, some has no data 
                            }
                            if (browser.isVisible(next_page_xpath)) {
                                var display_item_number_xpath = '//md-select[contains(@ng-model,"ctrl.model.numPerPage")]';
                                console.log("display_item_number_xpath:", display_item_number_xpath);
                                browser.waitForVisible(display_item_number_xpath, myWaitDefault);
                                browser.click(display_item_number_xpath+'//*[@class="md-select-icon"]');
                                var selectNumber = '//md-select-menu/parent::div[@aria-hidden="false"]// *[contains(@class,"md-text") and contains(normalize-space(),"500")]';
                                try{
                                    browser.waitForVisible(selectNumber,myWaitDefault);
                                }catch(err){
                                    browser.click(display_item_number_xpath+'//*[@class="md-select-icon"]');
                                    browser.waitForVisible(selectNumber,myWaitDefault);
                                }
                                var selectNumberCheck = display_item_number_xpath + '//md-select-value//div[contains(text(),"500")]';
                                try {
                                    browser.click(selectNumber);
                                    browser.waitForVisible(selectNumberCheck,myWaitDefault);
                                } catch (err) {
                                    console.log(err);
                                    console.log("second click!");
                                    if(browser.isVisible(selectNumber)){
                                        browser.click(selectNumber);
                                    }else{
                                        browser.click(display_item_number_xpath+'//*[@class="md-select-icon"]');
                                        browser.click(selectNumber);
                                    }                                           
                                    
                                    browser.waitForVisible(selectNumberCheck,myWaitDefault);
                                }
                            }
                            
                            this.browser_session.waitForResource(browser, myTable, 200);
                            browser.pause(1000);
                            var table_text = this.browser_session.getTableTextCFS(browser, myTable);
                            console.log('table_text:', table_text);
                            item["perfsummary"]["tranche_name"] = isin_name
                            item["perfsummary"]["scenario_id"] = scenario_id;
                            //item["perfsummary"]["class"] = class_name;
                            item["perfsummary"]["settles_date"] = settles_date;
                            var table_text_len=table_text.length;
                                if (assettype == "CLO"){

                                    // When both interest and principal == 0.00, remove the record from tail.
                                    var remove_record_len = 0;                                   
                                    if (table_text_len > 2){
                                        for (var x = table_text_len-1; x > 1; x--){
                                            console.log(table_text[x]);
                                            if (table_text[x]['Interest'] == '0.00' && table_text[x]['Principal'] == '0.00'){
                                                remove_record_len++;
                                                if(x==2){
                                                    table_text.length = x;
                                                    break;
                                                }
                                                console.log("remove_record_len:" + remove_record_len);
                                            }else{
                                                console.log("Should keep the first " + x + "+1 row of tranche flow");
                                                table_text.length = x+1;
                                                break;
                                            }
                                        }
                                    }
                                    restlen = table_text.length;
                                    //restlenfortranche[class_name] = restlen;
                                    //console.log(restlenfortranche);
                                    // coupon may different for final periods.So all rewrite to '0' ---> cdonet bug
                                    table_text_len=table_text.length;
                                    try{
                                        table_text[table_text_len-1]['Coupon']='0.00'
                                        table_text[table_text_len-2]['Coupon']='0.00'
                                        table_text[table_text_len-1]['Index']='0.00'
                                        table_text[table_text_len-2]['Index']='0.00'
                                    }catch(e){
                                        console.log(e)
                                    }
                                }
                                // console.log("table_text[table_text_len]['Coupon'] BBB",table_text[table_text_len-1]['Coupon'])
                            item["cashflows"] = table_text;
                            cashflow_res[cashflow_type].push(item);
                            //}
                            break;
                        case "Accounts":
                        case "Triggers":
                        case "PDL":
                        case "Hedges":
                        case "Tests":
                            console.log('--------------------------2. generate json file for ' + cashflow_type_list[index] + ' ----------------------------------')
                            var myTable1 = '// div[contains(@ng-if,"[cash.selectedIdentifier].length > 0")]// table';
                            try {
                                browser.waitForVisible(myTable1, myWaitDefault);
                            } catch (error) {//wait data load, some has no data 
                            }
                            var table_length = browser.elements(myTable1).value.length;
                            if (table_length == 0) {// no data displayed in GUI
                                console.log('no data displayed for cashflow type ' + cashflow_type_list[index]);
                                item["cashflows"] = {};
                                cashflow_res[cashflow_type_list[index]] = item;
                                break;
                            }
                            //  console.log("TestsHeader_length:",table_length);
                            for (var i = 1; i <= table_length; i++) {
                                var myTable_index = '(' + myTable1 + ')[' + i + ']';

                                var table_text = this.browser_session.getTableTextCFS(browser, myTable_index);
                                var TestsHeader = this.browser_session.getAnormalTableRowHeader(browser, myTable_index);
                                //console.log('table_text:', table_text);
                                console.log("TestsHeader:", TestsHeader);
                                //##### temp fixed for PDL,because the UI typeset is incorrect #########
                                if (TestsHeader == "" && cashflow_type_list[index] == "PDL") {
                                    TestsHeader = " :: ";
                                }
                                //###### end temp fixed
                                if (assettype == "CLO" && cashflow_type_list[index] == "Accounts" && TestsHeader.length > 10){
                                    console.log("------------------------Deal with Accounts header--------------------------");
                                    if (TestsHeader == "Liquidity Reserve Amount-1"){
                                        TestsHeader = "Liq Res Ac";
                                    } else{
                                        TestsHeader = TestsHeader.substring(0, 10).trim();
                                    }   
                                }
                                if (cashflow_type_list[index] == "Tests" && TestsHeader.indexOf('OC OC') >-1){
                                    console.log("------------------------Deal with Tests header--------------------------");
                                    var headertmp = TestsHeader.split('OC OC');
                                    console.log(headertmp);
                                    TestsHeader = headertmp[0]+' OC'+ headertmp[1];
                                    console.log(TestsHeader);
                                }    
                                item[TestsHeader] = table_text;
                                // console.log('------->' + TestsHeader);
                                if (assettype == "CLO" && cashflow_type_list[index] == "Accounts"){
                                    for (var n = 0; n < table_text.length; n++){
                                        for (var accounts_key in table_text[n]) {
                                            // console.log(accounts_key);
                                            // console.log(table_text[n][accounts_key]);
                                            if (table_text[n][accounts_key] == '-'){
                                                table_text[n][accounts_key] = "0.00";
                                            }
                                            // result_combine[0][j][key] = result_combine[i][j][key];
                                        }
                                    }
                                }
                                if (assettype == "CLO" && (cashflow_type_list[index] == "Accounts" || cashflow_type_list[index] == "Hedges")) {
                                    console.log("We need to remove the rows when all the values are 0.00 or - from the tail");
                                    var acct_len = table_text.length;
                                    var accum1 = 0;
                                    var accum2 = 0;
                                    var keynum = 0;
                                    for (var j = acct_len - 1; j > -1; j--) {
                                        accum1 = 0;
                                        keynum = 0;
                                        for (var field_acct_key in table_text[0]) {
                                            keynum++;
                                            if (table_text[j][field_acct_key] == "0.00" || table_text[j][field_acct_key] == "-") {
                                                accum1++;
                                            }
                                        }
                                        if (accum1 == keynum) { //Accounts = 8, Hedges = 6
                                            accum2++;
                                        } else {
                                            break;
                                        }
                                    }
                                    if(cashflow_type_list[index] == "Accounts"){
                                        try{
                                            table_text[0]["Target"] = "0.00"; //Change Target to 0.00 for the first row.
                                        } catch(e){
                                            console.log(e);
                                        }
                                    }
                                    console.log("We need to remove: " + accum2 + " rows for " + cashflow_type_list[index]);
                                    table_text.length = acct_len - accum2;
                                }
                                //Deal with the rows that only have target and reserve 2 rows at least
                                if (assettype == "CLO" && cashflow_type_list[index] == "Accounts" && table_text.length >2){
                                    console.log("Deal with the rows that only have target and reserve 2 rows at least");
                                    var acct_len = table_text.length;
                                    var accum1 = 0;
                                    var accum2 = 0;
                                    var keynum = 0;
                                    for (var j = acct_len - 1; j > 1; j--) {
                                        accum1 = 0;
                                        keynum = 0;
                                        if (table_text[j]["Target"] != "0.00"){
                                            for (var field_acct_key in table_text[0]) {
                                                keynum++;
                                                if (table_text[j][field_acct_key] == "0.00" || table_text[j][field_acct_key] == "-") {
                                                    accum1++;
                                                }
                                            }
                                            if (accum1 == keynum-1) { //Accounts = 7
                                                accum2++;
                                            } else {
                                                break;
                                            }
                                        } 
                                    }
                                    console.log("We need to remove: " + accum2 + " rows for " + cashflow_type_list[index]);
                                    table_text.length = acct_len - accum2;
                                }
                                try {
                                    if (cashflow_type_list[index] == "Tests"){
                                        for (var n = 0; n < table_text.length; n++){
                                            for (var accounts_key in table_text[n]) {
                                                console.log(accounts_key);
                                                console.log(table_text[n][accounts_key]);
                                                if (table_text[n][accounts_key] == '-'){
                                                    table_text[n][accounts_key] = "0.0000";
                                                }
                                                // result_combine[0][j][key] = result_combine[i][j][key];
                                            }
                                        }
                                    }
                                } catch (e) {
                                    console.log(e)
                                }
                                try {
                                    if (cashflow_type_list[index] == "Tests") {
                                        console.log("We need to remove the rows when all the values are 0.00 or - from the tail");
                                        var tests_len = table_text.length;
                                        var accum1 = 0;
                                        var accum2 = 0;
                                        var keynum = 0;
                                        for (var j = tests_len - 1; j > -1; j--) {
                                            accum1 = 0;
                                            keynum = 0;
                                            for (var field_tests_key in table_text[0]) {
                                                keynum++;
                                                if (table_text[j][field_tests_key] == "0.0000" || table_text[j][field_tests_key] == "-") {
                                                    accum1++;
                                                }
                                            }
                                            if (accum1 == keynum) { //4
                                                accum2++;
                                            } else {
                                                break;
                                            }
                                        }
                                        console.log("We need to remove: " + accum2 + " rows for tests")
                                        table_text.length = tests_len - accum2;
                                    }
                                    if (process.env.NODE_ENV.indexOf('SPS') >-1 && assettype == "CLO" && cashflow_type_list[index] == "Tests"){
                                        table_text.shift();
                                    }
                                } catch (e) {
                                    console.log(e)
                                } 
                                //console.log(item[TestsHeader]);
                            }
                            //Sort the account names
                            if (assettype == "CLO" && cashflow_type_list[index] == "Accounts"){
                                console.log("Sort keys");
                                for (var keys in item) {
                                    console.log('keys:', keys);
                                }
                                var keys = [];
                                var len;
                                var item1 = {};
                                for (var k1 in item) {
                                  if (item.hasOwnProperty(k1)) {
                                    keys.push(k1);
                                  }
                                }
                                console.log(keys);
                                item1['perfsummary']=item['perfsummary'];
                                item1[' :: ']=item[' :: '];
                                console.log("--------------------"+item1['perfsummary']);
                                keys.shift();
                                keys.shift();
                                keys.sort();
                                console.log(keys);
                                len = keys.length;
                                console.log(len);
                                for (var i = 0; i < len; i++) {
                                  k1 = keys[i];
                                  console.log(k1);
                                  item1[k1]=item[k1];
                                  // console.log(item1);
                                }
                                item = item1;
                            }
                            cashflow_res[cashflow_type_list[index]] = item;
                            //console.log('cashflow_res[cashflow_type_list[index]]:', cashflow_res[cashflow_type_list[index]]);
                            //  add Month and Date to all the item of anormal table values
                            for (var keys in cashflow_res[cashflow_type_list[index]]) {
                                console.log('keys:', keys);
                                if (keys != ' :: ' && keys != 'perfsummary') {
                                    if (keys == 'Interest Diversion Test') {
                                        try {
                                            for (var i in item[keys]) {
                                                for (var first_table_key in cashflow_res[cashflow_type_list[index]][' :: '][i]) {
                                                    cashflow_res[cashflow_type_list[index]][keys][i][first_table_key] = cashflow_res[cashflow_type_list[index]][' :: '][i][first_table_key];
                                                }
                                            }
                                        } catch (e) {
                                            console.log(e)
                                        }
                                    } else {
                                        for (var i in item[keys]) {
                                            try {
                                                for (var first_table_key in cashflow_res[cashflow_type_list[index]][' :: '][i]) {
                                                   cashflow_res[cashflow_type_list[index]][keys][i][first_table_key] = cashflow_res[cashflow_type_list[index]][' :: '][i][first_table_key];
                                                }
                                            } catch (e) {
                                                console.log(e)
                                            } 
                                        }
                                    }
                                }
                            }
                            delete cashflow_res[cashflow_type_list[index]][' :: ']
                            break;
                        case "Fees":
                            console.log('--------------------------3. generate json file for Fees ----------------------------------')
                            if (assettype == "CLO" && cashflow_type_list[index] == "Fees") {
                                myTable = cashflow_xpath.portfolioCfresultTable;
                                try {
                                    browser.waitForVisible(myTable, myWaitDefault);
                                } catch (error) {//wait data load, some has no data 
                                }
                                console.log("myTable:", myTable);
                                var table_length = browser.elements(myTable).value.length;
                                console.log('table_length: ' + table_length);
                                if (table_length == 0) {// no data displayed in GUI
                                    console.log('no data displayed for cashflow type ' + cashflow_type_list[index]);
                                    item["cashflows"] = {};
                                    cashflow_res[cashflow_type_list[index]] = item;
                                    break;
                                }
                                if (browser.isVisible(next_page_xpath)) {
                                    var display_item_number_xpath = '//md-select[contains(@ng-model,"ctrl.model.numPerPage")]';
                                    console.log("display_item_number_xpath:", display_item_number_xpath);
                                    browser.waitForVisible(display_item_number_xpath, myWaitDefault);
                                    browser.click(display_item_number_xpath+'//*[@class="md-select-icon"]');
                                    var selectNumber = '//md-select-menu/parent::div[@aria-hidden="false"]// *[contains(@class,"md-text") and contains(normalize-space(),"500")]';
                                    try{
                                        browser.waitForVisible(selectNumber,myWaitDefault);
                                    }catch(err){
                                        browser.click(display_item_number_xpath+'//*[@class="md-select-icon"]');
                                        browser.waitForVisible(selectNumber,myWaitDefault);
                                    }
                                    var selectNumberCheck = display_item_number_xpath + '//md-select-value//div[contains(text(),"500")]';
                                    try {
                                        browser.click(selectNumber);
                                        browser.waitForVisible(selectNumberCheck,myWaitDefault);
                                    } catch (err) {
                                        console.log(err);
                                        console.log("second click!");
                                        if(browser.isVisible(selectNumber)){
                                            browser.click(selectNumber);
                                        }else{
                                            browser.click(display_item_number_xpath+'//*[@class="md-select-icon"]');
                                            browser.click(selectNumber);
                                        }                                           
                                        
                                        browser.waitForVisible(selectNumberCheck,myWaitDefault);
                                    }
                                }
                                
                                this.browser_session.waitForResource(browser, myTable, 200);
                                browser.pause(1000);
                                var table_text = this.browser_session.getTableTextCFS(browser, myTable);
                                console.log("process.env.NODE_ENV" + process.env.NODE_ENV);
                                // if(process.env.NODE_ENV == 'Dev'){
                                //     console.log("This is Dev env, we need to change - to 0.00");
                                //     for (var n = 0; n < table_text.length; n++){
                                //         for (var fees_key in table_text[n]) {
                                //             console.log(fees_key);
                                //             console.log(table_text[n][fees_key]);
                                //             if (table_text[n][fees_key] == '-'){
                                //                 table_text[n][fees_key] = "0.00";
                                //             }
                                //             // result_combine[0][j][key] = result_combine[i][j][key];
                                //         }
                                //     }
                                // }
                                console.log("We need to remove the rows when all the values are 0.00 or - from the tail");
                                var fees_len = table_text.length;
                                var accum1 = 0;
                                var accum2 = 0;
                                var keynum = 0;
                                for (var j = fees_len - 1; j > -1; j--) {
                                    accum1 = 0;
                                    keynum = 0;
                                    for (var field_fees_key in table_text[0]) {
                                        keynum++;
                                        if (table_text[j][field_fees_key] == "0.00" || table_text[j][field_fees_key] == "-") {
                                            accum1++;
                                        }
                                    }
                                    if (accum1 == (keynum-2)) { //11
                                        accum2++;
                                    } else {
                                        break;
                                    }
                                }
                                console.log("We need to remove: " + accum2 + " rows for fees")
                                table_text.length = fees_len - accum2;
                                //  console.log(table_text);
                                item["cashflows"] = table_text;
                                cashflow_res[cashflow_type_list[index]] = item;
                            }
                            else {//for Non-CLO
                                var myTable1 = '// div[contains(@ng-if,"[cash.selectedIdentifier].length > 0")]// table';
                                try {
                                    browser.waitForVisible(myTable1, myWaitDefault);
                                } catch (error) {//wait data load, some has no data 
                                }
                                console.log("myTable1:", myTable1);
                                var table_length = browser.elements(myTable1).value.length;
                                console.log('table_length: ' + table_length);
                                if (table_length == 0) {// no data displayed in GUI
                                    console.log('no data displayed for cashflow type ' + cashflow_type_list[index]);
                                    item["cashflows"] = {};
                                    cashflow_res[cashflow_type_list[index]] = item;
                                    break;
                                }
                                var result_combine = [];
                                for (var i = 1; i <= table_length; i++) {
                                    var myTable_index = '(' + myTable1 + ')[' + i + ']';
                                    var table_text = this.browser_session.getTableTextCFS(browser, myTable_index);
                                    var TestsHeader = this.browser_session.getAnormalTableRowHeader(browser, myTable_index);
                                    console.log('table_text:', table_text);
                                    result_combine.push(table_text);
                                }
                                //combine all item to result_combine[0]
                                for (var i = 1; i < result_combine.length; i++) {
                                    for (var j = 0; j < result_combine[i].length; j++) {
                                        console.log(result_combine[i][j]);
                                        for (key in result_combine[i][j]) {
                                            result_combine[0][j][key] = result_combine[i][j][key];
                                        }
                                    }
                                }
                                item["perfsummary"]["scenario_id"] = scenario_id;
                                //item["perfsummary"]["class"] = class_name;
                                item["perfsummary"]["settles_date"] = settles_date;
                                item["cashflows"] = result_combine[0];
                                cashflow_res[cashflow_type_list[index]] = item;
                            }
                            break;
                        case "Principal Paydown":
                            console.log('--------------------------4. generate json file for Principal Paydown ----------------------------------')
                            var myTable1 = '// div[contains(@ng-if,"[cash.selectedIdentifier].length > 0")]//table';
                            try {
                                browser.waitForVisible(myTable1, myWaitDefault);
                            } catch (error) {//wait data load, some has no data 
                            }
                            console.log("myTable1:", myTable1);
                            var table_length = browser.elements(myTable1).value.length;
                            console.log('table_length: ' + table_length);
                            if (table_length == 0) {// no data displayed in GUI
                                console.log('no data displayed for cashflow type ' + cashflow_type_list[index]);
                                item["cashflows"] = {};
                                cashflow_res[cashflow_type_list[index]] = item;
                                break;
                            }
                            var header_list = this.browser_session.getAnormalTableRowHeader(browser, myTable1, 2).split(' :: ');
                            console.log(header_list);
                            var header_dict = {};
                            var header_count = browser.elements(myTable1 + '/thead/tr[1]/th').value.length;
                            var table_index = 0;
                            for (var i = 1; i <= header_count; i++) {
                                var header_text = browser.getText(myTable1 + '/thead/tr[1]/th[' + i + ']');
                                console.log(i);
                                console.log(header_text);
                                if (header_text != "") {
                                    item[header_text] = [];
                                    var row_count = parseInt(browser.getAttribute(myTable1 + '/thead/tr[1]/th[' + i + ']', "colspan"));
                                    console.log('row_count: ' + row_count);
                                    var text_header_list = [];
                                    text_header_list.push(header_list[0]); //Month
                                    text_header_list.push(header_list[1]); //Date
                                    for (var j = table_index; j < row_count + table_index; j++) {
                                        console.log(i);
                                        console.log(header_list[2 + j]);
                                        text_header_list.push(header_list[2 + j]);
                                    }
                                    header_dict[header_text] = text_header_list;
                                    table_index += row_count;
                                }
                            }
                            console.log(header_dict);//{"Tranches":[],"Collateral":[]}
                            var table_text = this.browser_session.getTableTextCFS(browser, myTable1);
                            for (var i = 0; i < table_text.length; i++) {
                                for (var key in header_dict) {
                                    var tmp = {};
                                    for (var m = 0; m < header_dict[key].length; m++) {
                                        var item_key = header_dict[key][m];
                                        tmp[item_key] = table_text[i][item_key];
                                    }
                                    item[key].push(tmp);
                                }
                            }
                            if(assettype == "CLO"){
                                var prind_len_tranche = item["Tranches"].length;
                                var tranche_class_name;
                                try{
                                    // var rlen = Number(restlenfortranche[tranche_key]);
                                    for(var tranche_class in item["Tranches"][0]){
                                        if(tranche_class.indexOf("Class")>-1){
                                            tranche_class_name = tranche_class;
                                        }
                                    }
                                    for(var l = prind_len_tranche-1; l>restlen-1; l--){
                                        item["Tranches"][l][tranche_class_name] = "-";
                                    } 
                                } catch(error){  
                                }  

                                console.log("We need to remove the rows when all the values are 0.00 or - from the tail for principal paydown - collateral");
                                var prind_len = item["Collateral"].length;
                                var accum1 = 0;
                                var accum2 = 0;
                                var keynum = 0;
                                for (var j = prind_len - 1; j > -1; j--) {
                                    accum1 = 0;
                                    keynum = 0;
                                    for (var field_pd_key in item["Collateral"][0]) {
                                        keynum++;
                                        if (item["Collateral"][j][field_pd_key] == "0.00" || item["Collateral"][j][field_pd_key] == "-") {
                                            accum1++;
                                        }
                                    }
                                    if (accum1 == (keynum-2)) { //6
                                        accum2++;
                                    }else{
                                        break;
                                    }
                                }
                                console.log("We need to remove: " + accum2 + " rows for principal paydown")
                                item["Collateral"].length = prind_len-accum2;
                            }
                            cashflow_res[cashflow_type_list[index]] = item;
                            break;
                        case "Collateral Flows":
                        case "Reinvestment":
                            console.log('--------------------------5. generate json file for ' + cashflow_type_list[index] + ' ----------------------------------')
                            myTable = cashflow_xpath.portfolioCfresultTable;  
                            try {
                                browser.waitForVisible(myTable, myWaitDefault);
                            } catch (error) {//wait data load, some has no data 
                            }
                            if (browser.isVisible(next_page_xpath)) {
                                var display_item_number_xpath = '//md-select[contains(@ng-model,"ctrl.model.numPerPage")]';
                                console.log("display_item_number_xpath:", display_item_number_xpath);
                                browser.waitForVisible(display_item_number_xpath, myWaitDefault);
                                browser.click(display_item_number_xpath+'//*[@class="md-select-icon"]');
                                var selectNumber = '//md-select-menu/parent::div[@aria-hidden="false"]// *[contains(@class,"md-text") and contains(normalize-space(),"500")]';
                                try{
                                    browser.waitForVisible(selectNumber,myWaitDefault);
                                }catch(err){
                                    browser.click(display_item_number_xpath+'//*[@class="md-select-icon"]');
                                    browser.waitForVisible(selectNumber,myWaitDefault);
                                }
                                var selectNumberCheck = display_item_number_xpath + '//md-select-value//div[contains(text(),"500")]';
                                try {
                                    browser.click(selectNumber);
                                    browser.waitForVisible(selectNumberCheck,myWaitDefault);
                                } catch (err) {
                                    console.log(err);
                                    console.log("second click!");
                                    if(browser.isVisible(selectNumber)){
                                        browser.click(selectNumber);
                                    }else{
                                        browser.click(display_item_number_xpath+'//*[@class="md-select-icon"]');
                                        browser.click(selectNumber);
                                    }                                           
                                    
                                    browser.waitForVisible(selectNumberCheck,myWaitDefault);
                                }
                            }                                                      
                            console.log("myTable:", myTable);
                            if (browser.elements(myTable).value.length == 0) {// no data displayed in GUI
                                console.log('no data displayed for cashflow type ' + cashflow_type_list[index]);
                                item["cashflows"] = {};
                                cashflow_res[cashflow_type_list[index]] = item;
                                break;
                            }
                            this.browser_session.waitForResource(browser, myTable, 2000);
                            console.log("-------------->show item number:",browser.getText('//md-select[contains(@ng-model,"ctrl.model.numPerPage")]//md-select-value//div'));
                            console.log("-------------->table row count:",browser.elements(myTable+'//tr').value.length);
                            browser.pause(1000);                            
                            var table_text = this.browser_session.getTableTextCFS(browser, myTable);
                            console.log(table_text);
                            item["perfsummary"]["scenario_id"] = scenario_id;
                            item["perfsummary"]["settles_date"] = settles_date;
                            item["cashflows"] = table_text;
                            //remove the rows when all the values are 0.00 or - from the tail
                            if (assettype == "CLO" && (cashflow_type_list[index] == 'Collateral Flows'|| cashflow_type_list[index] == 'Reinvestment')) {
                                console.log("----------------------We need to remove the rows when all the values are 0.00 or - from the tail");
                                var reinv_len = item["cashflows"].length;
                                console.log(reinv_len);
                                var accum1 = 0;
                                var accum2 = 0;
                                var keynum = 0;
                                for (var j = reinv_len - 1; j > -1; j--) {
                                    accum1 = 0;
                                    keynum = 0;
                                    for (var field_reinv_key in item["cashflows"][0]) {
                                        console.log(field_reinv_key);
                                        keynum++;
                                        console.log(item["cashflows"][j][field_reinv_key]);
                                        if (item["cashflows"][j][field_reinv_key] == "0.00" || item["cashflows"][j][field_reinv_key] == "-") {
                                            accum1++;
                                            console.log(accum1);
                                        }
                                    }
                                    if (accum1 == (keynum-2)) { //collateral = 19, Reinvestment = 10
                                        accum2++;
                                    } else {
                                        break;
                                    }
                                }
                                console.log("We need to remove: " + accum2 + " rows for " + cashflow_type_list[index]);
                                item["cashflows"].length = reinv_len - accum2;
                                console.log(item["cashflows"].length);
                            }
                            cashflow_res[cashflow_type_list[index]] = item;
                            break;
                        default:
                            console.log('##################### No defined this type of cashflow->' + cashflow_type_list[index] + ' ####################');
                            expect(false).toBe(true);
                            break;
                    }
                }
                
                // var file_path = '../../../cashflow_res';
                if(self.isCurrentdate){
                  settles_date='Current Date';
                }
                if(portfolioMode=='portfolio'){
                    var file_name = self.portfolio+'.'+isin_name+'_' + scenario_id+self.economyNum+ self.portfolio_fistloss_type+self.isCustom + '_' + settles_date;
                    var file_path = path.join(process.env.HOME, 'Projects','CS-Structured-QA-SFPortal-G2','cashflow_res','portfolio_cashflow_res');
                    export_res(file_name, file_path, cashflow_res, 'json');
                }else if(portfolioMode=='Price portfolio'){
                    var file_name1 = scenario_id+self.economyNum + self.portfolio_output.replace(' / ','')+ self.portfolio_fistloss_type+self.isCustom + '_' +self.portfolio+'.'+isin_name+'_'+ settles_date;
                    var file_path1 = path.join(process.env.HOME, 'Projects','CS-Structured-QA-SFPortal-G2','cashflow_res','deal_cashflow_res');
                    var file_name2 = self.portfolio+'.'+isin_name+'_' + scenario_id+self.economyNum+ self.portfolio_fistloss_type+self.isCustom + '_' + settles_date;
                    var file_path2 = path.join(process.env.HOME, 'Projects','CS-Structured-QA-SFPortal-G2','cashflow_res','portfolio_cashflow_res');
                    export_res(file_name1, file_path1, cashflow_res, 'json');
                    export_res(file_name2, file_path2, cashflow_res, 'json');
                }else{
                    var file_name = scenario_id+self.economyNum + self.portfolio_output.replace(' / ','')+ self.portfolio_fistloss_type+self.isCustom + '_' +self.portfolio+'.'+isin_name+'_'+ settles_date;
                    var file_path = path.join(process.env.HOME, 'Projects','CS-Structured-QA-SFPortal-G2','cashflow_res','deal_cashflow_res');
                    export_res(file_name, file_path, cashflow_res, 'json');
                }                

                // if (process.env.RunDealRequest == 'True' && process.env.NODE_ENV != 'Prod') {
                if (process.env.RunDealRequest == 'True' && process.env.NODE_ENV != 'Prod') {
                    // var run_cashflow_button = cashflow_xpath.cashflowButton;
                    // browser.getLocationInView(run_cashflow_button);
                    // browser.click(run_cashflow_button);
                    var assumption_body = content_xpath.assumptionsPanel+'//tbody/tr';
                    var deal_list_length = browser.elements(assumption_body).value.length;
                    var run_deal_request_xpath = '//div[contains(@ng-show,"cash.showDebugOutput")]';
                    var toggle_output_button = '//span[contains(text(),"Toggle Debug Output")]';
                    console.log(browser.isVisible(run_deal_request_xpath))
                    if(!browser.isVisible(run_deal_request_xpath)){
                        browser.waitForVisible(toggle_output_button,this.waitMax)
                        browser.getLocationInView(toggle_output_button);
                        try {
                            if (browser.isVisible(toggle_output_button)) {
                                browser.click(toggle_output_button);
                                browser.waitForVisible(run_deal_request_xpath, myWaitDefault);
                            } else {
                                console.log('click toggle output button failed');
                            }
                        } catch (e) {
                            console.log('wait for run deal request');
                            browser.waitForVisible(run_deal_request_xpath, myWaitDefault);
                        }
                    }
                    try{
                        for (var deal_index = 1; deal_index <= deal_list_length; deal_index++) {
                            var deal_element = '('+assumption_body+')['+deal_index+']//td[2]'
                            var tranche_element = '('+assumption_body+')['+deal_index+']//td[4]'
                            var tranche_name = browser.getText(deal_element)+'-'+browser.getText(tranche_element)
                            var scenario_id = scenario_list[0]["scenario_id"];
                            var settles_date = scenarios_used[scenario_id][4];
                            // var file_name = scenario_id + '_' + tranche_name.toUpperCase() + '_' + settles_date;
                            var request_str = browser.getText(run_deal_request_xpath);
                            file_name = 'portfolio_' + file_name + '_request';
                            console.log(run_deal_request_xpath)
                            console.log(request_str)
                            if(process.env.NODE_ENV.indexOf('SPS')!=-1&&assettype=='CLO'){
                                var tmp = request_str.split('\n')[0]
                                console.log("tmp----------",tmp)
                                request_str = request_str.replace(tmp,'')
                                var run_deal_request = JSON.parse(request_str)
                                var file_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res', 'run_deal_request');
                                export_res(file_name, file_path, run_deal_request, 'json');
                            }else{
                                var run_deal_request = request_str.substring(request_str.indexOf("<runDealSettings"), request_str.indexOf("</RundealRequest>"));
                                var file_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res', 'run_deal_request');
                                export_res(file_name, file_path, run_deal_request, 'xml');
                            }
                        }

                    }catch(e){
                        console.log(e)

                    }


                    // var run_deal_request_xpath = '//div[contains(@ng-show,"cash.showDebugOutput")]';
                    // var toggle_output_button = '//span[contains(text(),"Toggle Debug Output")]';
                    // console.log(browser.isVisible(run_deal_request_xpath))
                    // if(!browser.isVisible(run_deal_request_xpath)){
                    //     try {
                    //         if (browser.isVisible(toggle_output_button)) {
                    //             browser.click(toggle_output_button);
                    //             browser.waitForVisible(run_deal_request_xpath, myWaitDefault);
                    //         } else {
                    //             console.log('click toggle output button failed');
                    //         }
                    //     } catch (e) {
                    //         console.log('wait for run deal request');
                    //         browser.waitForVisible(run_deal_request_xpath, myWaitDefault);
                    //     }
                    // }
                    // var request_xml = browser.getText(run_deal_request_xpath);
                    // file_name = 'portfolio_' + file_name + '_request';
                    // // console.log('request_xml:',request_xml);
                    // // var run_deal_request = request_xml.substring(request_xml.indexOf("<runDealSettings"), request_xml.indexOf("</RundealRequest>"));
                    // // file_path = '../../../cashflow_res' + '/run_deal_request';
                    // file_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res', 'run_deal_request');
                    // // file_path ='C:\\Users\\HuBa\\Projects\\CS-Structured-QA-SFPortal-G2\\CLOCFS\\Deal\\cashflow_res\\run_deal_request\\';
                    // export_res(file_name, file_path, request_xml, 'xml');
                    // // console.log('run_deal_request:',run_deal_request);
                    // // close button
                    // browser.click(toggle_output_button);
                }
            }
            if (self.stratifications_flag) {
                console.log('delet all stratifications_flag')
                var apply_stra = '//*[@ng-repeat="item in cash.tabs" and text()="Stratification"]'
                browser.getLocationInView(apply_stra)
                browser.click(apply_stra);
                browser.waitForVisible('//table[contains(@id,"watchlist")]', self.waitDefault);
                if (browser.isExisting('//*[contains(@ng-click,"assumpCtrl.deleteRule")]')) {
                    var stra_length = browser.elements('//*[contains(@ng-click,"assumpCtrl.deleteRule")]').value.length;
                    console.log('stra_length:', stra_length)
                    for (var strItem = 1; strItem <= stra_length; strItem++) {
                        console.log('strItem:', strItem)
                        browser.click('(//*[contains(@ng-click,"assumpCtrl.deleteRule")])[1]');
                    }
                    browser.click('//span[contains(text(),"Save Stratifications")]')
                }
                // close Stratifications
                browser.click('//*[@ng-repeat="item in cash.tabs" and text()="Settings"]');
                self.stratifications_flag = false
            }

        });
};

