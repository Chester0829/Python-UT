// Recommended filename : Then_I_should_see_the_Date_is_#.js
module.exports = function() {
this.Then(/^I should see the Date is "([^"]*)"$/, function (arg1) {
         // Write code here that turns the phrase above into concrete actions
        const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
         var date = arg1 ;
         var date_element = content_xpath.mdyAsOfDate;
         this.browser_session.waitForResource(browser,date_element,this.waitDefault);
         expect(browser.getValue(date_element)).toEqual(date);
       });
};
