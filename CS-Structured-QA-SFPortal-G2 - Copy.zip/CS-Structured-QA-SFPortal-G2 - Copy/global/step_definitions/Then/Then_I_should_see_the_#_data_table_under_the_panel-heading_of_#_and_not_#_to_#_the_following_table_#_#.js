// Recommended filename: Then_I_should_see_the_#_data_table_under_the_panel-heading_of_#_and_not_#_to_#_the_following_table_#_#.js
module.exports = function() {
  this.Then(/^I should see the (only|first|second|third|fourth|fifth|sixth|seventh|eighth|nineth|tenth) data table under the panel-heading of "([^"]*)" and not "([^"]*)" to (contain|match) the following table (header|data) (row by row|in any row)$/, function(tableIndex, panelName, ignorePanel, action, content, checkWay, table) {
    // Write the automation code here
    //browser.pause(1000);
    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    //this.browser_session.waitForRender(browser);
    const my_regex_lib = this.regex_lib;
    var expected_row_list = table.hashes();
    var myTable = this.browser_session.findTableUnderPanel(browser, panelName, ignorePanel, tableIndex);
    browser.getLocationInView(myTable);
    var myBrowserSession = this.browser_session;
    var displayed_row_content;
    if (checkWay == 'in any row') {
      this.browser_session.findInTableAnyRow(myTable, expected_row_list, action);
    } else {
      expected_row_list.forEach(function(expected_row, index) {
        switch (content) {
          case 'header':
          displayed_row_content = myBrowserSession.getTableHeaderText(browser, myTable);
          break;
          case 'data':
          displayed_row_content = myBrowserSession.getTableRowText(browser, myTable, index + 1);
          break;
        };
        switch (action) {
          case 'contain':
          expect(displayed_row_content).toContain(my_regex_lib.replaceRegex(expected_row['row_data']));
          break;
          case 'match':
          expect(displayed_row_content).toMatch(my_regex_lib.replaceRegex(expected_row['row_data']));
          break;
        };
      });
    }
  });
};