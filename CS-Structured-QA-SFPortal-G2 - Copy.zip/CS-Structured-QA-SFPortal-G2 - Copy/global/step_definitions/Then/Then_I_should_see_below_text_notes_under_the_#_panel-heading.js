//Then_I_should_see_below_text_notes_under_the_#_panel-heading.js
module.exports = function() {
	this.Then(/^I should see below text notes under the "([^"]*)" panel\-heading$/, function (panelName,table) {
		// Write code here that turns the phrase above into concrete actions
		// return 'pending';
		switch(panelName){
			case 'BWIC Analyzer:':
				const bwic_xpath = this.xpath_lib.xpathRequire('bwic_xpath');
				var myPanel = bwic_xpath.nameTitle;
				var notesXpath = myPanel + bwic_xpath.notesXpath;
				break;
			case 'Contact Info':
			  var notesXpath = '//*[contains(text(),"Contact Info")]/ancestor::md-card//md-card-content';
			  break;
		}
		var tmp = browser.getText(notesXpath);
		var textNotes = Array.isArray(tmp) ? tmp.join() : tmp;
		// console.log(textNotes);
		// console.log(table.hashes());
		var notesList = table.hashes();
		for(var i=0;i<notesList.length;i++){
			expect(textNotes).toContain(notesList[i]['row_data']);
		}
		

	});

}