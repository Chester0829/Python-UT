//Then_I_should_see_the_Deal_cashflow_assumptions_of_the_following_table_to_the_scenario_#.js
module.exports=function(){
 this.Then(/^I (should not|should) see the Deal cashflow assumptions of the following table to the scenario "([^"]*)"$/, function (arg2, arg1, table) {
    // Write code here that turns the phrase above into concrete actions
    var assumption_list = table.hashes();
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
    var scenario_num = arg1;
    var flag = (arg2 == 'should') ? true : false;
    this.browser_session.waitForResource(browser,cashflow_xpath.dealCfsAssumptions);
    browser.pause(3000);
    browser.waitForVisible(cashflow_xpath.dealcfsCheckBox.replace('__NAME__','scen.run_flag'),this.waitDefault);
    browser.getLocationInView(cashflow_xpath.dealCfsAssumptions);
    var self = this;      
    assumption_list.forEach(function(list_row) {
    console.log("Validating " + list_row['name']  + " " + list_row['value']);

      switch(list_row['name']) {
        case "scen.run_flag":
        case "scen.cal_first_loss":
        case "scen.seed_default":
        case "scen.ignore_input_nonpayment_term":
        case "scen.calc_curve_off_static_bal":
        case "scen.useACHVector":
        case "scen.apply_watch":
        case "scen.apply_loan_level_assumps":
        case 'scen.term_triggers_activate_LTV_trigger':
        case 'scen.term_triggers_activate_DSCR_trigger':
        case 'scen.maturity_trigger_activate_LTV_trigger':
        case 'scen.maturity_trigger_activate_DY_trigger':
        // case 'scen.apply_loan_level_assumps':
          var check_box = '(' + cashflow_xpath.dealcfsCheckBox.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
          var check_flag = '(' + cashflow_xpath.dealcfsCheckBox.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
          var target_attribute = browser.getAttribute(check_flag, 'class');
          console.log(check_flag);
          if(list_row['value']=='checked')
          {
            expect(target_attribute.indexOf('ng-not-empty') > -1).toBe(true);
          }
          if(list_row['value']=='unchecked')
          {
            expect(target_attribute.indexOf('ng-empty')>-1).toBe(true);
          }
          if(list_row['value'] == "disabled")  {
            var disabled_attribute_value = browser.getAttribute(check_flag, 'disabled');
            console.log(list_row['name'] + " " + list_row['value'] + ". actual disabled field value: " + disabled_attribute_value);

            expect(browser.getAttribute(check_flag, 'disabled')).toEqual('true');
          }
          break;
        case "scen.scenType":
          var sentypeText = '(' + cashflow_xpath.mdSelect.replace('__NAME__',list_row['name'])  + ')[' + arg1 + ']' + '//md-select-value//*[contains(@class,"md-text")]';
          if(flag == false){
            expect(browser.getText(sentypeText)).not.toEqual(list_row['value']);
            break;
          }
          expect(browser.getText(sentypeText)).toEqual(list_row['value']);
          break;
        case "scenarioNameSelected":
          var scenName_div = '(//div[@ng-model="' + list_row['name'] + '"])[' + arg1 + ']';
          var scenNameText=scenName_div+'//span[contains(@class,"ui-select-match-text")]/span';
          expect(browser.getText(scenNameText)).toEqual(list_row['value']);
          break;
        case "scen.solve_for":
        case "scen.loss_type":
        case "scen.delinquency_type":
        case "scen.repay_type":
        case "scen.purchase_type":
        case "scen.portfolio_yield_type":
        case "scen.portfolio_loss_type":
        case "scen.deferment_type":
        case "scen.grace_type":
        case "scen.forbear_type":
        case "scen.interest_cap_freq":
        case "scen.BB_type":
        case "scen.reinvest_price_type":
        case "scen.reinvest_pool":
        case "scen.reinvest_rules":
        case "scen.call_option":
        case "scen.force_call":
        case "scen.call_price_type":
        case "scen.prepay_type":
        case "scen.forward_curve":
        case 'scen.NOI_growth_rate_type':
        case 'scen.cap_rate_growth_rate_type':
        case 'scen.term_triggers_select_priority':
        case 'scen.maturity_trigger_select_priority':
        case 'scen.servicer_basis':
        case 'scen.servicer_type':
          var deal_CfSfpSelectInput = '(' + cashflow_xpath.dealCfSfpSelect.replace('__NAME__',list_row['name']) + '//input)[' + arg1 + ']';
          console.log(deal_CfSfpSelectInput);
          var deal_CfSfpSelect = '(' + cashflow_xpath.dealCfSfpSelect.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
          console.log(deal_CfSfpSelect);
          if(flag == false){
            expect(browser.getValue(deal_CfSfpSelectInput)).not.toEqual(list_row['value']);
            break;
          }
          if(list_row['value'] == "disabled")  {
            var disabled_attribute_value = browser.getAttribute(deal_CfSfpSelect, 'disabled');
            console.log('disabled_attribute_value:'+ disabled_attribute_value);
            console.log(list_row['name'] + " " + list_row['value'] + ". actual disabled field value: " + disabled_attribute_value);

            expect(browser.getAttribute(deal_CfSfpSelect, 'disabled')).toEqual('true');
          }
          else {
            expect(browser.getValue(deal_CfSfpSelectInput)).toEqual(list_row['value']);            
          }
          break;
        case "analyticsCtrl.outputType":
        case "analyticsCtrl.scenarioMethod":
        case "analyticsCtrl.scenarioInput":
          var deal_CfSsetting = cashflow_xpath.dealCfSfpSelect.replace('__NAME__',list_row['name']) + '//input';
          console.log('deal_CfSsetting'+ deal_CfSsetting);
          var deal_CfSfpSelect = cashflow_xpath.dealCfSfpSelect.replace('__NAME__',list_row['name']);
          console.log(deal_CfSfpSelect);
          if(list_row['value'] == "disabled")  {
            var disabled_attribute_value = browser.getAttribute(deal_CfSfpSelect, 'disabled');
            console.log('disabled_attribute_value:'+ disabled_attribute_value);
            console.log(list_row['name'] + " " + list_row['value'] + ". actual disabled field value: " + disabled_attribute_value);

            expect(browser.getAttribute(deal_CfSfpSelect, 'disabled')).toEqual('true');
          }
          else {
            expect(browser.getValue(deal_CfSsetting)).toEqual(list_row['value']);
          }
          break;
        // // case "scen.cap_rate_growth_rate_type":
        // // case "scen.NOI_growth_rate_type":
        // case "scen.term_triggers_select_priority":
        // case "scen.maturity_trigger_select_priority":
        // case "scen.servicer_basis":
        // case "scen.servicer_type":
        // // case "scen.apply_loan_level_assumps":
        //   var assumptions_select = '(' + cashflow_xpath.dealCfsSelect.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
        //   console.log(assumptions_select);
        //   var disabled_attribute_value = browser.getAttribute(assumptions_select, 'disabled');
        //   console.log(list_row['name'] + " " + list_row['value'] + ". actual disabled field value: " + disabled_attribute_value);

        //   if(list_row['value'] == "disabled") {
        //     expect(disabled_attribute_value).toEqual('true');
        //   }
        //   else {
        //     expect(browser.getValue(assumptions_select)).toEqual(list_row['value']);
        //   }
        //   break;
        case "analyticsCtrl.scenarioMidPoint":
          var assumptions_input = cashflow_xpath.dealCfsInput.replace('__NAME__',list_row['name']);
          self.browser_session.waitForResource(browser,assumptions_input);
          console.log(list_row['name']  + " " + list_row['value'] + browser.getValue(assumptions_input));
          expect(browser.getValue(assumptions_input)).toEqual(list_row['value']);
          break;
        case "scen.settle_date":
        case "scen.prepay_rate":
        case "scen.loss_rate":
        case "scen.delinquency_rate":
        case "scen.adv_loss_rate":
        case "scen.adv_lag_mon":
        case "scen.repay_rate":
        case "scen.purchase_rate":
        case "scen.portfolio_yield_rate":
        case "scen.portfolio_loss_rate":
        case "scen.deferment_rate":
        case "scen.grace_rate":
        case "scen.forbear_rate":
        case "scen.BB_utilization_rate":
        case "scen.subsidy_payment_delay":
        case "scen.SAP_payment_delay":
        case "scen.prinLossSeverityPctNonPerf":
        case "scen.rec_lag":
        case "scen.alloc_mon":
        case "scen.reinvest_price":
        case "scen.reinvDefaultLockout":
        case "scen.NOI_growth_rate":
        case "scen.cap_rate_growth_rate":
        case "scen.term_triggers_LTV_liquidate":
        case "scen.term_triggers_LTV_months":
        case "scen.term_triggers_LTV_loss":
        case "scen.term_triggers_DSCR_liquidate":
        case "scen.term_triggers_DSCR_months":
        case "scen.term_triggers_DSCR_loss":
        case "scen.maturity_trigger_LTV_payoff":
        case "scen.maturity_trigger_LTV_liquidate":
        case "scen.maturity_trigger_LTV_loss":
        case "scen.maturity_trigger_LTV_extension":
        case "scen.maturity_trigger_LTV_end_of_extension_liq_or_payoff":
        case "scen.maturity_trigger_LTV_end_of_extension_loss":
        case "scen.maturity_trigger_DY_payoff":
        case "scen.maturity_trigger_DY_liquidate":
        case "scen.maturity_trigger_DY_loss":
        case "scen.maturity_trigger_DY_extension":
        case "scen.maturity_trigger_DY_end_of_extension_liq_or_payoff":
        case "scen.maturity_trigger_DY_end_of_extension_loss":
        case "scen.servicer_rate":
        case "scen.call_date":
        case "scen.plus_minus_months":
        case "scen.reinvest_spread":
        case "scen.reinvest_term":
        case "scen.call_price":
          var assumptions_input = '(' + cashflow_xpath.dealCfsInput.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
          var disabled_attribute_value = browser.getAttribute(assumptions_input, 'disabled');
          //console.log(list_row['name']  + " " + list_row['value'] + ". actual disabled field value: " + disabled_attribute_value);

          if(list_row['value'] == "disabled") {
            expect(browser.getAttribute(assumptions_input, 'disabled')).toEqual('true');
          }
          else {
            expect(browser.getValue(assumptions_input)).toEqual(list_row['value']);
          }

          break;

      }
    });  
  });
}
