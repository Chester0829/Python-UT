// Recommended filename: Then_I_should_see_the_#_expandable-table_under_the_#_card_to_#_the_following_table_#_#.js
module.exports = function() {
  this.Then(/^I should see the (only|1st|2nd|3rd|4th) expandable\-table under the "([^"]*)" card to (contain|match) the following table (header|row\-data|regex) (in\-any\-row|row\-by\-row)$/,
    {timeout: process.env.StepTimeoutInMS*5}, function(tableIndex, cardName, testAction, contentType, checkMethod, table) {
    // Write the automation code here
    const dataViewerPage_xpath = this.xpath_lib.xpathRequire('dataViewerPage_xpath');
    const expandableTable_xpath = this.xpath_lib.xpathRequire('expandableTable_xpath');

    if(cardName.toLowerCase() == 'current')
    {
      cardName = this.visualizeName;
    }
    var myVisualization_card = dataViewerPage_xpath.titled_Visualization_card.replace('__TITLE__', cardName);

    var expected_row_list = table.hashes();

    var myHdrAppend = expandableTable_xpath.hdrAppend;
    var myRowAppend = expandableTable_xpath.rowAppend;
    var myLeftTableGrid = expandableTable_xpath.leftTableGrid;
    var myRightTableGrid = expandableTable_xpath.rightTableGrid;
    var myTableHeaderGrid = expandableTable_xpath.tableHeaderGrid;
    var myTableBodyGrid = expandableTable_xpath.tableBodyGrid;
    var myTableIndex;
    var myLeftDisplayToCheck_xpath;
    var myRightDisplayToCheck_xpath;
    var myLeftDisplayToCheck_text;
    var myRightDisplayToCheck_text;
    var combinedDisplayedText
    var robot_session = this.robot_session;

    switch (tableIndex) {
      default:
      case "1st":
        myTableIndex = 1;
        break;
      case "2nd":
        myTableIndex = 2;
        break;
      case "2nd":
        myTableIndex = 3;
        break;
      case "4th":
        myTableIndex = 4;
        break;
    }

    var myLeftTable = '(' + myVisualization_card + myLeftTableGrid + ')[' + myTableIndex + ']';
    var myRightTable = '(' + myVisualization_card + myRightTableGrid + ')[' + myTableIndex + ']';
    var myLeftTableHdr = myLeftTable + myTableHeaderGrid;
    var myLeftTableBdy = myLeftTable + myTableBodyGrid;
    var myRightTableHdr = myRightTable + myTableHeaderGrid;
    var myRightTableBdy = myRightTable + myTableBodyGrid;
    browser.getLocationInView(myLeftTable);

    expected_row_list.forEach(function(expected_row, rowIndex) {
      switch (checkMethod) {
        case "in-any-row":
          // set displayed content
          switch (contentType) {
            case 'header':
              myLeftDisplayToCheck_xpath = myLeftTableHdr;
              myRightDisplayToCheck_xpath = myRightTableHdr;
              myLeftDisplayToCheck_text = browser.getText(myLeftDisplayToCheck_xpath).replace(/[\r\n]/g, ' :: ');
              myRightDisplayToCheck_text = browser.getText(myRightDisplayToCheck_xpath).replace(/[\r\n]/g, ' :: ');
              break;
            case 'row-data':
              myLeftDisplayToCheck_xpath = myLeftTableBdy;
              myRightDisplayToCheck_xpath = myRightTableBdy;
              // '/../..' to get text from parent div for the entire table
              myLeftDisplayToCheck_text = browser.getText(myLeftDisplayToCheck_xpath + '/../..').replace(/[\r\n]/g, ' :: ');
              myRightDisplayToCheck_text = browser.getText(myRightDisplayToCheck_xpath + '/../..').replace(/[\r\n]/g, ' :: ');
              break;
          };
          break;
        case "row-by-row":
          switch (contentType) {
            case 'header':
              myLeftDisplayToCheck_xpath = '(' + myLeftTableHdr + myHdrAppend + ')[' + (rowIndex + 1) + ']';
              myRightDisplayToCheck_xpath = '(' + myRightTableHdr + myHdrAppend + ')[' + (rowIndex + 1) + ']';
              myRightDisplayToCheck_text = browser.getText(myRightDisplayToCheck_xpath).replace(/[\r\n]/g, ' :: ');
              break;
            case 'row-data':
              myLeftDisplayToCheck_xpath = '(' + myLeftTableBdy + myRowAppend + ')[' + (rowIndex + 1) + ']';
              myRightDisplayToCheck_xpath = '(' + myRightTableBdy + myRowAppend + ')[' + (rowIndex + 1) + ']';
              myLeftDisplayToCheck_text = browser.getText(myLeftDisplayToCheck_xpath).replace(/[\r\n]/g, ' :: ');
              myRightDisplayToCheck_text = browser.getText(myRightDisplayToCheck_xpath).replace(/[\r\n]/g, ' :: ');
              break;
          };
          break;  
      }

      switch (testAction) {
        case 'contain':
          if (expected_row['left']) {
            expect(myLeftDisplayToCheck_text).toContain(expected_row['left']);
          }
          if (expected_row['right']) {
            expect(myRightDisplayToCheck_text).toContain(expected_row['right']);
          }
          break;
        case 'match':
          if (expected_row['left']) {
            expect(myLeftDisplayToCheck_text).toMatch(expected_row['left']);
          }
          if (expected_row['right']) {
            expect(myRightDisplayToCheck_text).toMatch(expected_row['right']);
          }
          break;
      }

    });
    browser.pause(500);
  });
}