//  Then_I_save_the_cashflow_results_and_convert_them_to_json_file.js
module.exports = function () {
    this.Then(/^I save the (cashflow|clickwrap-cashflow|visitor-clickwrap-cashflow) results for "([^"]*)" asset class and convert them to json file$/,
        { timeout: process.env.StepTimeoutInMS * 10 },
        function (pagetype, assettype, table) {
            var self = this;
            this.browser_session.waitForResource(browser);
            var fs = require("fs");
            var path = require('path');
            const cashflow_xpath = this.xpath_lib.xpathRequire("cashflow_xpath");
            const content_xpath = this.xpath_lib.xpathRequire("content_xpath");
            var cashflow_res = {};
            var run_deal_request_flag = table.hashes()[0]["run_deal_request"];
            var irr_purchase_date = table.hashes()[0]["irr_purchase_date"];
            var run_particular_tranche = table.hashes()[0]["run_particular_tranche"];
            var principal_paydown = table.hashes()[0]["principal_paydown"] || 'All';
            var myTable = "(" + cashflow_xpath.dealcfsCashflowRusult + ")//table";
            var mySelectCaret_xpath;
            var panelName = "Results";
            var myWaitDefault = self.waitDefault;
            var myPanel = content_xpath.titledSectionLowercase.replace("__TITLE__", panelName.toLowerCase());
            self.assettype = assettype;
            self.pagetype = pagetype;
            var restlen;
            var restlenfortranche = {};
            var myYieldTableElement = '(' + myPanel + content_xpath.descendantDataTable + ')[1]';
            var myTrancheStatisticsElement = '(' + myPanel + content_xpath.descendantDataTable + ')[2]';

            var list_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'scripts','ScenariosList','cfs_regression_list.json' );
            var content=fs.readFileSync(list_path,'utf8');
            var cloRegressionList = JSON.parse(content);

            var deal_name_xpath = '//div[@class="module-name-banner-name"]/div[@class="inline-block"]';
            browser.waitForVisible(deal_name_xpath, self.waitDefault);
            console.log(browser.isVisible(deal_name_xpath));
            var deal_name = browser.getText(deal_name_xpath);
            console.log(deal_name);

            var resultTable = {};
            // var cf_scenario_list = self.scenario_list;
            // var cf_scenario_list_length = cf_scenario_list.length;
            // var cf_scenarios_used = self.scenarios_used;
            var yield_id = 'price_001';
            var irr_id = 'IRR_001';
            var timeOut = 60*1000;

            if(yield_id.indexOf('price')>-1){
                var yield_input_key = 'price'
                var yield_result_key = 'dm/yield'
                var yield_reuslt_dm_key = 'dm'
                var yield_result_yield_key = 'yield'
            }else{
                var yield_input_key = 'dm (bps)'
                var yield_result_key = 'price'
            }

            console.log('yield_result_key:'+yield_result_key)
            if(yield_id.indexOf('price')>-1){
                console.log('yield_reuslt_dm_key:'+yield_reuslt_dm_key)
            }
            switch (assettype) {
                case "CLO":
                    //////// Please don't delete below line
                    //StartChangeType
                    var cashflow_type_list = ["Tranche Flows", "Deal Flows", "Collateral Flows", "Fees", "Tests", "Reinvestment", "Accounts", "Hedges", "Principal Paydown"];
                    //EndChangeType 
                    ///////Please don't delete above line

                    //var cashflow_type_list = ["Deal Flows"];
                    break;
                case "CLO EditDeal":
                    var cashflow_type_list = ["Tranche Flows", "Collateral Flows"];
                    break;
                case "ABS":
                case "AUTO":
                case "CARDS":
                case "SLABS":
                case "CMBS":
                    // var cashflow_type_list = ["Collateral Flows"];
                    //var cashflow_type_list = ["Deal Flows"];
                    var cashflow_type_list = ["Tranche Flows", "Deal Flows", "Collateral Flows", "Fees", "Accounts", "Hedges", "Triggers", "Principal Paydown"];
                    break;
                case "RMBS":
                    //var cashflow_type_list = ["Triggers","PDL"];
                    var cashflow_type_list = ["Tranche Flows", "Deal Flows", "Collateral Flows", "Fees", "Accounts", "Hedges", "Triggers", "PDL", "Principal Paydown"];
                    break;
            }
            // var cashflow_type_list = ["Tranche Flows","Collateral Flows"];
            var scenario_list_xpath = myPanel + content_xpath.named_mdSelectIcon2.replace("__NAME__", "analyticsCtrl.selectedScen");
            var scenario_list = self.scenario_list;
            var scenario_list_length = scenario_list.length;
            var scenarios_used = self.scenarios_used;
            console.log('self.scenario_used:', scenarios_used);

            //  defined the write function
            var export_res = function (file_name, file_path, file_content, file_type) {
                var myDate = new Date();
                var month = myDate.getMonth() + 1;
                var day = myDate.getDate();
                var today = '0' + month + day;
                file_name = file_name + '_' + today + '.' + file_type;
                if (file_type == 'json') {
                    var data_json = JSON.stringify(file_content);
                } else {
                    var data_json = file_content;
                }
                //if (fs.existsSync(file_path)) {
                //    console.log(file_path + ' exist!') 
                //} else {
                //    fs.mkdir(file_path, function (err) {
                //        if (err) {
                //            console.log(err);
                //            throw err;
                //        }
                //        console.log('make dir success.');
                //    });
                //}
                self.utility_lib.mkdirsSync(file_path);
                // console.log("--------------------------cash flow---------------------------------",casgflow_json);
                fs.writeFile(file_path + '/' + file_name, data_json, { flag: "w" }, function (err) {
                    if (err) {
                        console.log(file_name + " saved failed!");
                        return console.log(err);
                    } else {
                        console.log(file_name + " saved successfully!");
                    }

                })
            }; 
            //////////create Yield Template
            var full_scenarios_list = self.cashflow_session.createYieldJsonTemplate(scenario_list,scenarios_used)
            var file_scen_name =  self.cashflow_session.createfilename(scenario_list)
                      // file_scen_name = file_scen_name + '_' + scenario_id;

            //  select all the scenario we run
            for (var scen_index = 1; scen_index <= scenario_list_length; scen_index++) {
                var sfwdealID;
                var scenario_id = scenario_list[scen_index - 1]["scenario_id"];
                //  traverse the cash flow type list which we defined before
                console.log(scenario_id)
                console.log(cloRegressionList)
                console.log(cloRegressionList['CLORegressionSecnarios'].indexOf(scenario_id))
                for (var index in cashflow_type_list) {

                    //  console.log(cashflow_type_list[index]);
                    if (run_particular_tranche != 'All' && cashflow_type_list[index] == 'Deal Flows') {
                        continue;
                    }
                    if (cloRegressionList['CLORegressionSecnarios'].indexOf(scenario_id)=='-1' && cashflow_type_list[index] == 'Deal Flows'){
                        continue;
                    }
                    else {
                        cashflow_res[cashflow_type_list[index]] = [];
                    }
                    mySelectCaret_xpath = myPanel + content_xpath.named_mdSelectIcon2.replace("__NAME__", "analyticsCtrl.cashflow_type");
                    console.log("click try: " + mySelectCaret_xpath);
                    browser.click(mySelectCaret_xpath);
                    var select_item = content_xpath.namedSelectItem.replace("__NAME__", cashflow_type_list[index]);
                    console.log("select_item:", select_item);
                    self.browser_session.waitForResource(browser, select_item);
                    console.log('--------------------------selected cashflow type:' + browser.getText(select_item));
                    browser.click(select_item);
                    var selectedTypeCheck = content_xpath.selectedCashflowsType.replace("__text__", cashflow_type_list[index]);
                    console.log('----------------selected type check:' + selectedTypeCheck);
                    browser.waitForVisible(selectedTypeCheck, myWaitDefault);
                    browser.pause(1000);

                    
                    if (assettype == 'CLO' || assettype == 'CLO EditDeal') {
                        var settles_date = scenarios_used[scenario_id][4];
                    } else {
                        var settles_date = scenarios_used[scenario_id][5];
                    }
                    if (scenario_list_length != 1) {
                        browser.click(scenario_list_xpath);
                        console.log(scenario_list_xpath);
                        var select_item = "(" + content_xpath.namedSelectItem.replace("__NAME__", "") + ")[" + scen_index + "]";
                        console.log("select_scen:", select_item);
                        try {
                            browser.waitForVisible(select_item, self.waitDefault);
                        } catch (e) {
                            browser.click(scenario_list_xpath);
                            console.log('try again:', scenario_list_xpath);
                        }
                        self.browser_session.waitForResource(browser, select_item);
                        console.log('--------------------------selected scenario:' + browser.getText(select_item));
                        browser.click(select_item);
                        var scenarios_listText_element = '//md-select[@ng-model="analyticsCtrl.selectedScen"]//*[@class="md-text"]'
                        var scens_text = browser.getText(scenarios_listText_element).trim()
                        expect(scens_text.substr(scens_text.length - 1, 1) == scen_index).toBe(true, scens_text, scen_index)
                    }
                    //TODO... what if data row >500
                    //  make sure could catch all rows once,change show items number to 500 directly
                    var next_page_xpath = '//li[@class="pagination-next"]/a[contains(@ng-click,"selectPage(page + 1,")]';
                    console.log("next_page:", next_page_xpath);
                    // if (browser.isVisible(next_page_xpath)) {
                    //     var display_item_number_xpath = myTable + '// md-select[contains(@ng-model,"ctrl.model.numPerPage")]';
                    //     console.log("display_item_number_xpath:", display_item_number_xpath);
                    //     self.browser_session.waitForResource(browser, display_item_number_xpath);
                    //     browser.click(display_item_number_xpath);
                    //     var selectNumber = '// md-select-menu/parent::div[@aria-hidden="false"]// *[contains(@class,"md-text") and contains(normalize-space(),"500")]';
                    //     try {
                    //         browser.click(selectNumber);
                    //     } catch (err) {
                    //         console.log(err);
                    //         console.log("second click!");
                    //         browser.click(selectNumber);
                    //     }
                    // }

                    var tranche_select_box = content_xpath.titledSectionLowercase.replace("__TITLE__", panelName.toLowerCase()) + "// select";
                    var tranche_select_xpath = tranche_select_box + "// option";
                    console.log("tranche_select_xpath:", tranche_select_xpath);
                    var tranche_name = browser.getValue(tranche_select_box);
                    console.log('default tranche_name' + tranche_name);
                    sfwdealID = tranche_name.split('.')[0];
                    var item = { "perfsummary": {}, };
                    item["perfsummary"]["scenario_id"] = scenario_id;
                    item["perfsummary"]["settles_date"] = settles_date;
                    if (sfwdealID == 'MJXVEN2C'){
                        var unused_type_list = ['Deal Flows',"Accounts", "Principal Paydown"]
                        unused_type_list.forEach(function(unused_item){
                            if (cashflow_type_list.indexOf(unused_item)>-1){
                                delete cashflow_type_list[cashflow_type_list.indexOf(unused_item)]
                            }
                        });
                    }
                    if (sfwdealID == 'SASCO20T'){
                        var unused_type_list = ['Deal Flows',"Accounts"]
                        unused_type_list.forEach(function(unused_item){
                            if (cashflow_type_list.indexOf(unused_item)>-1){
                                delete cashflow_type_list[cashflow_type_list.indexOf(unused_item)]
                            }
                        });
                    }
                    // if(sfwdealID == 'SASCO20T' && cashflow_type_list.indexOf('Deal Flows')){
                    //     delete cashflow_type_list[cashflow_type_list.indexOf('Deal Flows')]
                    // }

                    if(run_particular_tranche!='All'){
                        ////get isin name
                        var PricingInfoSearch = '(//*[@ng-model="ctrl.model.searchString"])[1]';
                        browser.getLocationInView(PricingInfoSearch);
                        console.log('run_particular_tranche:'+run_particular_tranche);
                        var class_name_info=run_particular_tranche.split('.')[1];
                        console.log('class_name_info:'+class_name_info);
                        browser.setValue(PricingInfoSearch,class_name_info);
                        if(assettype == 'CMBS'){
                            var isin_element = '//span[contains(@ng-bind-html,"ctrl.getFormattedEntry") and text()="__TRANCHE__"]/ancestor::tr/td[2]';
                        }else{
                            var isin_element = '//a[contains(@ui-sref,"deal.tranches") and text()="__TRANCHE__"]/ancestor::tr/td[2]';
                        }
                        isin_element=isin_element.replace('__TRANCHE__',run_particular_tranche.split('.')[1]);
                        console.log('------isin_element:'+isin_element);
                        try{
                            browser.waitForVisible(isin_element, myWaitDefault);
                        }catch(error){
                            var display_item_number_xpath = '//sfp-data-table[@table="pricingInfoCtrl.pricingInfoTable"]//md-select[contains(@ng-model,"ctrl.model.numPerPage")]';
                            console.log("display_item_number_xpath:", display_item_number_xpath);
                            browser.waitForVisible(display_item_number_xpath, myWaitDefault);
                            browser.click(display_item_number_xpath + '//*[@class="md-select-icon"]');
                            var selectNumber = '//md-select-menu/parent::div[@aria-hidden="false"]//md-option[@value="500"]';
                            browser.pause(2000);
                            browser.waitForVisible(selectNumber, myWaitDefault);
                            browser.click(selectNumber); 
                            browser.waitForVisible(isin_element, myWaitDefault);      
                        }
                        console.log(browser.getText(isin_element));
                        var isin_name = browser.getText(isin_element).split('/').slice(-1).toString().trim();
                    }
                            
                    switch (cashflow_type_list[index]) {
                        case "Tranche Flows":
                            console.log('--------------------------1. generate json file for tranche flows ----------------------------------')
                            var cashflow_type = cashflow_type_list[index];
                            var tranche_count = browser.selectorExecute(tranche_select_xpath, function (selects) {
                                return selects.length;
                            });
                            myTable = "(" + cashflow_xpath.dealcfsCashflowRusult + ")//table";
                            console.log("tranche_count:", tranche_count);

                            if (run_particular_tranche == 'All') {
                                for (var tranche_index = 0; tranche_index < tranche_count; tranche_index++) {
                                    //  reset the item object for each tranche
                                    item = { "perfsummary": {}, };
                                    //  in case can get all rows once
                                    try {
                                        browser.waitForVisible(myTable, myWaitDefault);
                                    } catch (error) {//wait data load, some has no data 
                                    }
                                    // select tranche
                                    browser.selectByIndex(tranche_select_box, tranche_index);
                                    browser.pause(1000);
                                    var tranche_name = browser.getValue(tranche_select_box);
                                    sfwdealID = tranche_name.split('.')[0];
                                    var class_name = tranche_name.split('.')[1];
                                    console.log("current_tranche_name:", tranche_name);
                                    self.browser_session.waitForResource(browser, myTable, 200);
                                    // select period
                                    if (browser.isVisible(next_page_xpath)) {
                                        var display_item_number_xpath = '//sfp-data-table[@table="analyticsCtrl.selectedTrancheFlowsTable"]//md-select[contains(@ng-model,"ctrl.model.numPerPage")]';
                                        console.log("display_item_number_xpath:", display_item_number_xpath);
                                        browser.waitForVisible(display_item_number_xpath, myWaitDefault);
                                        browser.click(display_item_number_xpath + '//*[@class="md-select-icon"]');
                                        var selectNumber = '// md-select-menu/parent::div[@aria-hidden="false"]// *[contains(@class,"md-text") and contains(normalize-space(),"500")]';
                                        try {
                                            browser.waitForVisible(selectNumber, myWaitDefault);
                                        } catch (err) {
                                            browser.click(display_item_number_xpath + '//*[@class="md-select-icon"]');
                                            browser.waitForVisible(selectNumber, myWaitDefault);
                                        }
                                        var selectNumberCheck = display_item_number_xpath + '//md-select-value//div[contains(text(),"500")]';
                                        try {
                                            browser.click(selectNumber);
                                            browser.waitForVisible(selectNumberCheck, myWaitDefault);
                                        } catch (err) {
                                            console.log(err);
                                            console.log("second click!");
                                            if (browser.isVisible(selectNumber)) {
                                                browser.click(selectNumber);
                                            } else {
                                                browser.click(display_item_number_xpath + '//*[@class="md-select-icon"]');
                                                browser.click(selectNumber);
                                            }
                                            browser.waitForVisible(selectNumberCheck, myWaitDefault);
                                        }
                                        var show_period_element = display_item_number_xpath + "//span/div[@class='md-text']";
                                        expect(browser.getText(show_period_element) == '500').toBe(true, show_period_element);
                                    }
                                    self.browser_session.waitForResource(browser, myTable, 200);
                                    browser.pause(1000);
                                    var table_text = self.browser_session.getTableTextCFS(browser, myTable);
                                    item["perfsummary"]["tranche_name"] = tranche_name;
                                    item["perfsummary"]["class"] = class_name;
                                    item["perfsummary"]["scenario_id"] = scenario_id;
                                    item["perfsummary"]["settles_date"] = settles_date;
                                    var table_text_len = table_text.length;
                                    console.log(table_text_len);

                                    if(assettype == "CLO" || assettype == 'CLO EditDeal'){
    
                                        // When both interest and principal == 0.00, remove the record from tail.
                                        var remove_record_len = 0;
                                        if (table_text_len > 2) {
                                            for (var x = table_text_len - 1; x > 1; x--) {
                                                console.log(table_text[x]);
                                                if (table_text[x]['Interest'] == '0.00' && table_text[x]['Principal'] == '0.00') {
                                                    remove_record_len++;
                                                    if (x == 2) {
                                                        table_text.length = x;
                                                        break;
                                                    }
                                                    console.log("remove_record_len:" + remove_record_len);
                                                } else {
                                                    console.log("Should keep the first " + x + "+1 row of tranche flow");
                                                    table_text.length = x + 1;
                                                    break;
                                                }
                                            }
                                        }
                                        table_text_len = table_text.length;
                                        console.log(table_text_len);
                                       // coupon may different for final periods.So all rewrite to '0' ---> cdonet bug->WSAAPI-5166
                                        try {
                                            // console.log(table_text[table_text_len-1]);
                                            table_text[table_text_len - 1]['Coupon'] = '0.00';
                                            table_text[table_text_len - 2]['Coupon'] = '0.00';
                                            table_text[table_text_len - 1]['Index'] = '0.00';
                                            table_text[table_text_len - 2]['Index'] = '0.00';
                                        } catch (e) {
                                            console.log(e);
                                        }
                                        restlen = table_text.length;
                                        restlenfortranche[class_name] = restlen;
                                        console.log(restlenfortranche);
                                    }
                                    item["cashflows"] = table_text; 
                                    cashflow_res[cashflow_type].push(item);
                                    //////////////////////Get Price and IRR/////////////////////////////////////////
                                    var runningBar = '//*[contains(@ng-if,"analyticsCtrl.priceYieldRunning")]';
                                   //wait first loss caculate end
                                   try {
                                       browser.waitForExist(runningBar,2000);
                                       browser.waitForVisible(runningBar,2000);
                                       self.browser_session.waitForLoading(browser,runningBar,1000,timeOut);
                                   }catch (e) {
                                       console.log(e);
                                   }
                                   self.cashflow_session.verifyPriceSetting(myYieldTableElement);
                                   self.cashflow_session.setIRRDate(irr_purchase_date);
                                   var myYiledTableArray = self.cashflow_session.getYieldTableTable(myYieldTableElement)
                                   var myTrancheStaticArray = self.cashflow_session.getTrancheStatTable(myTrancheStatisticsElement)
                                   var yield_scen_lists = self.cashflow_session.generateYieldJson(run_particular_tranche,myYiledTableArray,yield_input_key,yield_result_key,yield_reuslt_dm_key,yield_result_yield_key,scen_index)
                                   var yileditem = {"perfsummary": {},"result": {}};
                                   yileditem["perfsummary"]["scenario_id"] = scenario_id;
                                   yileditem["perfsummary"]["class"] = class_name;
                                   yileditem["perfsummary"]["settles_date"] = settles_date;
                                   yileditem["perfsummary"]["yield_id"] = yield_id;
                                   yileditem["perfsummary"]["tranche_name"] = tranche_name;
                                   yileditem["result"] = yield_scen_lists;
                                   full_scenarios_list[scenario_id]["Yield Table"].push(yileditem);

                                   var trancheStat_scen_lists = self.cashflow_session.generateTrancheStatJson(run_particular_tranche,myTrancheStaticArray,scen_index)
                                   var Statitem = {"perfsummary": {},"result": {}};
                                   Statitem["perfsummary"]["scenario_id"] = scenario_id;
                                   Statitem["perfsummary"]["class"] = class_name;
                                   Statitem["perfsummary"]["settles_date"] = settles_date;
                                   Statitem["perfsummary"]["irr_id"] = irr_id;
                                   Statitem["perfsummary"]["tranche_name"] = tranche_name;
                                   Statitem["result"] = trancheStat_scen_lists;
                                   full_scenarios_list[scenario_id]["Tranche Statistics"].push(Statitem);
                               ////////////////////////////////////////////////////////////////////////////////////////
                                }
                            }
                            else {
                                item = { "perfsummary": {}, };
                                try {
                                    browser.waitForVisible(myTable, myWaitDefault);
                                } catch (error) {//wait data load, some has no data 
                                }
                                //select tranche
                                browser.click(tranche_select_box);
                                var select_tranche = (tranche_select_box + '/option[text()="__TRANCHE__"]').replace('__TRANCHE__', run_particular_tranche);
                                browser.click(select_tranche);

                                var tranche_name = run_particular_tranche;
                                sfwdealID = tranche_name.split('.')[0];
                                var class_name = tranche_name.split('.')[1];
                                console.log("current_tranche_name:", tranche_name);
                                self.browser_session.waitForResource(browser, myTable, 200);
                                //select period
                                if (browser.isVisible(next_page_xpath)) {
                                    var display_item_number_xpath = '//sfp-data-table[@table="analyticsCtrl.selectedTrancheFlowsTable"]//md-select[contains(@ng-model,"ctrl.model.numPerPage")]';
                                    console.log("display_item_number_xpath:", display_item_number_xpath);
                                    browser.waitForVisible(display_item_number_xpath, myWaitDefault);
                                    browser.click(display_item_number_xpath + '//*[@class="md-select-icon"]');
                                    var selectNumber = '// md-select-menu/parent::div[@aria-hidden="false"]// *[contains(@class,"md-text") and contains(normalize-space(),"500")]';
                                    try {
                                        browser.waitForVisible(selectNumber, myWaitDefault);
                                    } catch (err) {
                                        browser.click(display_item_number_xpath + '//*[@class="md-select-icon"]');
                                        browser.waitForVisible(selectNumber, myWaitDefault);
                                    }
                                    var selectNumberCheck = display_item_number_xpath + '//md-select-value//div[contains(text(),"500")]';
                                    try {
                                        browser.click(selectNumber);
                                        browser.waitForVisible(selectNumberCheck, myWaitDefault);
                                    } catch (err) {
                                        console.log(err);
                                        console.log("second click!");
                                        if (browser.isVisible(selectNumber)) {
                                            browser.click(selectNumber);
                                        } else {
                                            browser.click(display_item_number_xpath + '//*[@class="md-select-icon"]');
                                            browser.click(selectNumber);
                                        }
                                        browser.waitForVisible(selectNumberCheck, myWaitDefault);
                                    }
                                    var show_period_element = display_item_number_xpath + "//span/div[@class='md-text']"
                                    expect(browser.getText(show_period_element) == '500').toBe(true, show_period_element)
                                }
                                // browser.click(tranche_select_box);
                                // var select_tranche = (tranche_select_box + '/option[text()="__TRANCHE__"]').replace('__TRANCHE__', run_particular_tranche);
                                // browser.click(select_tranche);

                                // var tranche_name = run_particular_tranche;
                                // sfwdealID = tranche_name.split('.')[0];
                                // var class_name = tranche_name.split('.')[1];
                                // console.log("current_tranche_name:", tranche_name);
                                self.browser_session.waitForResource(browser, myTable, 200);
                                browser.pause(1000);
                                var table_text = self.browser_session.getTableTextCFS(browser, myTable);
                                // ////get isin name
                                // var PricingInfoSearch = '//*[@ng-model="ctrl.model.searchString"]';
                                // console.log('run_particular_tranche:'+run_particular_tranche)
                                // var class_name_info=run_particular_tranche.split('.')
                                // browser.setValue(PricingInfoSearch,class_name_info)
                                // console.log('run_particular_tranche:'+class_name_info)
                                // var isin_element = '//a[contains(@ui-sref,"deal.tranches") and text()="__TRANCHE__"]/ancestor::tr/td[2]'
                                // isin_element=isin_element.replace('__TRANCHE__',run_particular_tranche.split('.')[1])
                                // console.log('------isin_element:'+isin_element)
                                // console.log(browser.getText(isin_element))
                                // var isin_name = browser.getText(isin_element).split('/').slice(-1).trim()
                                // if (assettype == 'CLO') {
                                //     var deal_name1 = table.hashes()[0]["deal_name"];
                                // } else {
                                //     var deal_name1 = deal_name.split(',')[0];
                                // }
                                item["perfsummary"]["tranche_name"] = isin_name;
                                item["perfsummary"]["scenario_id"] = scenario_id;
                                item["perfsummary"]["settles_date"] = settles_date;
                                //item["perfsummary"]["class"] = class_name;
                                var table_text_len = table_text.length;
                                console.log(table_text_len)
                                // console.log("table_text[table_text_len]['Coupon'] AAAA",table_text[table_text_len-1]['Coupon'])
                                if (assettype == "CLO" || assettype == 'CLO EditDeal'){
                                    // When both interest and principal == 0.00, remove the record from tail.
                                    var remove_record_len = 0;
                                    if (table_text_len > 2) {
                                        for (var x = table_text_len - 1; x > 1; x--) {
                                            console.log(table_text[x]);
                                            if (table_text[x]['Interest'] == '0.00' && table_text[x]['Principal'] == '0.00') {
                                                remove_record_len++;
                                                if (x == 2) {
                                                    table_text.length = x;
                                                    break;
                                                }
                                                console.log("remove_record_len:" + remove_record_len);
                                            } else {
                                                console.log("Should keep the first " + x + "+1 row of tranche flow");
                                                table_text.length = x + 1;
                                                break;
                                            }
                                        }
                                    }
                                    restlen = table_text.length;
                                    restlenfortranche[class_name] = restlen;
                                    console.log(restlenfortranche);
                                    table_text_len = table_text.length;
                                    console.log(table_text_len);
                                    // coupon may different for final periods.So all rewrite to '0' ---> cdonet bug
                                    try {
                                        table_text[table_text_len - 1]['Coupon'] = '0.00'
                                        table_text[table_text_len - 2]['Coupon'] = '0.00'
                                        table_text[table_text_len - 1]['Index'] = '0.00'
                                        table_text[table_text_len - 2]['Index'] = '0.00'
                                    } catch (e) {
                                        console.log(e)
                                    }
                                }
                                // console.log("table_text[table_text_len]['Coupon'] BBB",table_text[table_text_len-1]['Coupon'])
                                item["cashflows"] = table_text;
                                cashflow_res[cashflow_type].push(item);

                                 ////////////////////////Get Price and IRR/////////////////////////////////////////
                                 var runningBar = '//*[contains(@ng-if,"analyticsCtrl.priceYieldRunning")]';
                                 //wait first loss caculate end
                                 try {
                                   browser.waitForExist(runningBar,2000);
                                   browser.waitForVisible(runningBar,2000);
                                   self.browser_session.waitForLoading(browser,runningBar,1000,timeOut);
                                 }catch (e) {
                                   console.log(e);
                                 }
                                 self.cashflow_session.verifyPriceSetting(myYieldTableElement);
                                 self.cashflow_session.setIRRDate(irr_purchase_date);
                                 var myYiledTableArray = self.cashflow_session.getYieldTableTable(myYieldTableElement)
                                 var myTrancheStaticArray = self.cashflow_session.getTrancheStatTable(myTrancheStatisticsElement)
                                 var yield_scen_lists = self.cashflow_session.generateYieldJson(run_particular_tranche,myYiledTableArray,yield_input_key,yield_result_key,scen_index)
                                 var yileditem = {"perfsummary": {},"result": {}};
                                 yileditem["perfsummary"]["scenario_id"] = scenario_id;
                                 yileditem["perfsummary"]["settles_date"] = settles_date;
                                 yileditem["perfsummary"]["yield_id"] = yield_id;
                                 // var deal_name1 = deal_name.split(',')[0];
                                yileditem["perfsummary"]["tranche_name"] = isin_name;
                        

                                 var trancheStat_scen_lists = self.cashflow_session.generateTrancheStatJson(run_particular_tranche,myTrancheStaticArray,scen_index)
                                 var Statitem = {"perfsummary": {},"result": {}};
                                 Statitem["perfsummary"]["scenario_id"] = scenario_id;
                                 Statitem["perfsummary"]["settles_date"] = settles_date;
                                 Statitem["perfsummary"]["irr_id"] = irr_id;
                                  Statitem["perfsummary"]["tranche_name"] = isin_name;
                                 // var deal_name1 = deal_name.split(',')[0];
                                 // Statitem["perfsummary"]["tranche_name"] = deal_name1.toUpperCase() + '-' + class_name;
                                 Statitem["result"] = trancheStat_scen_lists;
                                 full_scenarios_list[scenario_id]["Tranche Statistics"].push(Statitem);
                                 /////////////////////////////////////////////////////////////////////////////////////////////
                            }
                            break;
                        case "Accounts":
                        case "Triggers":
                        case "PDL":
                        case "Hedges":
                        case "Tests":
                            console.log('--------------------------2. generate json file for ' + cashflow_type_list[index] + ' ----------------------------------')
                            myTable = '// div[contains(@ng-if,"[cash.selectedIdentifier].length > 0")]// table';
                            try {
                                browser.waitForVisible(myTable, myWaitDefault);
                            } catch (error) {//wait data load, some has no data 
                            }
                            var table_length = browser.elements(myTable).value.length;
                            if (table_length == 0) {// no data displayed in GUI
                                console.log('no data displayed for cashflow type ' + cashflow_type_list[index]);
                                item["cashflows"] = {};
                                cashflow_res[cashflow_type_list[index]] = item;
                                break;
                            }
                            //Don't output accounts for BD_17-2
                            if (sfwdealID == "BD_17-2" && cashflow_type_list[index] == "Accounts"){
                                break;
                            }
                            //  console.log("TestsHeader_length:",table_length);
                            for (var i = 1; i <= table_length; i++) {
                                var myTable_index = '(' + myTable + ')[' + i + ']';

                                var table_text = self.browser_session.getTableTextCFS(browser, myTable_index);
                                var TestsHeader = self.browser_session.getAnormalTableRowHeader(browser, myTable_index);
                                //console.log('table_text:', table_text);
                                // console.log("TestsHeader:", TestsHeader);
                                //##### temp fixed for PDL,because the UI typeset is incorrect #########
                                if (TestsHeader == "" && cashflow_type_list[index] == "PDL") {
                                    TestsHeader = " :: ";
                                }
                                //###### end temp fixed
                                // if (sfwdealID == "BD_17-2" && cashflow_type_list[index] == "Accounts"){
                                //     if (TestsHeader == "Interest-1"){
                                //         TestsHeader = "Interest";
                                //     }
                                //     if (TestsHeader == "Principal-2"){
                                //         TestsHeader = "Principal";
                                //     }
                                // }
                                if (assettype == "CLO" && cashflow_type_list[index] == "Accounts" && TestsHeader.length > 10){
                                    console.log("------------------------Deal with Accounts header--------------------------");
                                    if (TestsHeader == "Liquidity Reserve Amount-1"){
                                        TestsHeader = "Liq Res Ac";
                                    } else {
                                        TestsHeader = TestsHeader.substring(0, 10).trim();
                                    }   
                                }
                                if (cashflow_type_list[index] == "Tests" && TestsHeader.indexOf('OC OC') >-1){
                                    console.log("------------------------Deal with Tests header--------------------------");
                                    var headertmp = TestsHeader.split('OC OC');
                                    console.log(headertmp);
                                    TestsHeader = headertmp[0]+' OC'+ headertmp[1];
                                    console.log(TestsHeader);
                                }    
                                item[TestsHeader] = table_text;
                                // console.log('------->' + TestsHeader);
                                if (assettype == "CLO" && cashflow_type_list[index] == "Accounts") {
                                    for (var n = 0; n < table_text.length; n++) {
                                        for (var accounts_key in table_text[n]) {
                                            // console.log(accounts_key);
                                            // console.log(table_text[n][accounts_key]);
                                            if (table_text[n][accounts_key] == '-') {
                                                table_text[n][accounts_key] = "0.00";
                                            }
                                            // result_combine[0][j][key] = result_combine[i][j][key];
                                        }
                                    }
                                }
                                if (assettype == "CLO" && (cashflow_type_list[index] == "Accounts" || cashflow_type_list[index] == "Hedges")) {
                                    console.log("We need to remove the rows when all the values are 0.00 or - from the tail");
                                    var acct_len = table_text.length;
                                    var accum1 = 0;
                                    var accum2 = 0;
                                    var keynum = 0;
                                    for (var j = acct_len - 1; j > -1; j--) {
                                        accum1 = 0;
                                        keynum = 0;
                                        for (var field_acct_key in table_text[0]) {
                                            keynum++;
                                            if (table_text[j][field_acct_key] == "0.00" || table_text[j][field_acct_key] == "-") {
                                                accum1++;
                                            }
                                        }
                                        if (accum1 == keynum) { //Accounts = 8, Hedges = 6
                                            accum2++;
                                        } else {
                                            break;
                                        }
                                    }
                                    if(cashflow_type_list[index] == "Accounts"){
                                        try{
                                            table_text[0]["Target"] = "0.00"; //Change Target to 0.00 for the first row.
                                        } catch(e){
                                            console.log(e);
                                        }
                                    }
                                    console.log("We need to remove: " + accum2 + " rows for " + cashflow_type_list[index]);
                                    table_text.length = acct_len - accum2;
                                }
                                //Deal with the rows that only have target and reserve 2 rows at least
                                if (assettype == "CLO" && cashflow_type_list[index] == "Accounts" && table_text.length >2){
                                    console.log("Deal with the rows that only have target and reserve 2 rows at least");
                                    var acct_len = table_text.length;
                                    var accum1 = 0;
                                    var accum2 = 0;
                                    var keynum = 0;
                                    for (var j = acct_len - 1; j > 1; j--) {
                                        accum1 = 0;
                                        keynum = 0;
                                        if (table_text[j]["Target"] != "0.00"){
                                            for (var field_acct_key in table_text[0]) {
                                                keynum++;
                                                if (table_text[j][field_acct_key] == "0.00" || table_text[j][field_acct_key] == "-") {
                                                    accum1++;
                                                }
                                            }
                                            if (accum1 == keynum-1) { //Accounts = 7
                                                accum2++;
                                            } else {
                                                break;
                                            }
                                        } 
                                    }
                                    console.log("We need to remove: " + accum2 + " rows for " + cashflow_type_list[index]);
                                    table_text.length = acct_len - accum2;
                                }
                                try {
                                    if (cashflow_type_list[index] == "Tests") {
                                        for (var n = 0; n < table_text.length; n++) {
                                            for (var accounts_key in table_text[n]) {
                                                // console.log(accounts_key);
                                                // console.log(table_text[n][accounts_key]);
                                                if (table_text[n][accounts_key] == '-') {
                                                    table_text[n][accounts_key] = "0.0000";
                                                }
                                                // result_combine[0][j][key] = result_combine[i][j][key];
                                            }
                                        }
                                    }
                                } catch (e) {
                                    console.log(e);
                                }
                                try {
                                    if (cashflow_type_list[index] == "Tests") {
                                        console.log("We need to remove the rows when all the values are 0.00 or - from the tail");
                                        var tests_len = table_text.length;
                                        var accum1 = 0;
                                        var accum2 = 0;
                                        var keynum = 0;
                                        for (var j = tests_len - 1; j > -1; j--) {
                                            accum1 = 0;
                                            keynum = 0;
                                            for (var field_tests_key in table_text[0]) {
                                                keynum++;
                                                if (table_text[j][field_tests_key] == "0.0000" || table_text[j][field_tests_key] == "-") {
                                                    accum1++;
                                                }
                                            }
                                            if (accum1 == keynum) { //4
                                                accum2++;
                                            } else {
                                                break;
                                            }
                                        }
                                        console.log("We need to remove: " + accum2 + " rows for tests")
                                        table_text.length = tests_len - accum2;
                                    }
                                    if (process.env.NODE_ENV.indexOf('SPS') > -1 && assettype == "CLO" && cashflow_type_list[index] == "Tests") {
                                        table_text.shift();
                                    }
                                } catch (e) {
                                    console.log(e)
                                }
                                //console.log(item[TestsHeader]);
                            }
                            //Sort the account names
                            if (assettype == "CLO" && cashflow_type_list[index] == "Accounts") {
                                console.log("Sort keys");
                                for (var keys in item) {
                                    console.log('keys:', keys);
                                }
                                var keys = [];
                                var len;
                                var item1 = {};
                                for (var k1 in item) {
                                    if (item.hasOwnProperty(k1)) {
                                        keys.push(k1);
                                    }
                                }
                                console.log(keys);
                                item1['perfsummary'] = item['perfsummary'];
                                item1[' :: '] = item[' :: '];
                                console.log("--------------------" + item1['perfsummary']);
                                keys.shift();
                                keys.shift();
                                keys.sort();
                                console.log(keys);
                                len = keys.length;
                                console.log(len);
                                for (var i = 0; i < len; i++) {
                                    k1 = keys[i];
                                    console.log(k1);
                                    item1[k1] = item[k1];
                                    // console.log(item1);
                                }
                                item = item1;
                            }
                            cashflow_res[cashflow_type_list[index]] = item;
                            //console.log('cashflow_res[cashflow_type_list[index]]:', cashflow_res[cashflow_type_list[index]]);
                            //  add Month and Date to all the item of anormal table values
                            for (var keys in cashflow_res[cashflow_type_list[index]]) {
                                console.log('keys:', keys);
                                if (keys != ' :: ' && keys != 'perfsummary') {
                                    if (keys == 'Interest Diversion Test') {
                                        try {
                                            for (var i in item[keys]) {
                                                for (var first_table_key in cashflow_res[cashflow_type_list[index]][' :: '][i]) {
                                                    cashflow_res[cashflow_type_list[index]][keys][i][first_table_key] = cashflow_res[cashflow_type_list[index]][' :: '][i][first_table_key];
                                                }
                                            }
                                        } catch (e) {
                                            console.log(e)
                                        }
                                    } else {
                                        for (var i in item[keys]) {
                                            try {
                                                for (var first_table_key in cashflow_res[cashflow_type_list[index]][' :: '][i]) {
                                                    cashflow_res[cashflow_type_list[index]][keys][i][first_table_key] = cashflow_res[cashflow_type_list[index]][' :: '][i][first_table_key];
                                                }
                                            } catch (e) {
                                                console.log(e)
                                            }
                                        }
                                    }
                                }
                            }
                            delete cashflow_res[cashflow_type_list[index]][' :: ']
                            break;
                        case "Fees":
                            console.log('--------------------------3. generate json file for Fees ----------------------------------')
                            if (assettype == "CLO" && cashflow_type_list[index] == "Fees") {
                                myTable = "(" + cashflow_xpath.dealcfsCashflowRusult + ")//table";
                                try {
                                    browser.waitForVisible(myTable, myWaitDefault);
                                } catch (error) {//wait data load, some has no data 
                                }
                                console.log("myTable:", myTable);
                                var table_length = browser.elements(myTable).value.length;
                                console.log('table_length: ' + table_length);
                                if (table_length == 0) {// no data displayed in GUI
                                    console.log('no data displayed for cashflow type ' + cashflow_type_list[index]);
                                    item["cashflows"] = {};
                                    cashflow_res[cashflow_type_list[index]] = item;
                                    break;
                                }
                                if (browser.isVisible(next_page_xpath)) {
                                    var display_item_number_xpath = '//sfp-data-table[@table="analyticsCtrl.selectedManagementFeesTable"]// md-select[contains(@ng-model,"ctrl.model.numPerPage")]';
                                    console.log("display_item_number_xpath:", display_item_number_xpath);
                                    browser.waitForVisible(display_item_number_xpath, myWaitDefault);
                                    browser.click(display_item_number_xpath + '//*[@class="md-select-icon"]');
                                    var selectNumber = '// md-select-menu/parent::div[@aria-hidden="false"]// *[contains(@class,"md-text") and contains(normalize-space(),"500")]';
                                    try {
                                        browser.waitForVisible(selectNumber, myWaitDefault);
                                    } catch (err) {
                                        browser.click(display_item_number_xpath + '//*[@class="md-select-icon"]');
                                        browser.waitForVisible(selectNumber, myWaitDefault);
                                    }
                                    var selectNumberCheck = display_item_number_xpath + '//md-select-value//div[contains(text(),"500")]';
                                    try {
                                        browser.click(selectNumber);
                                        browser.waitForVisible(selectNumberCheck, myWaitDefault);
                                    } catch (err) {
                                        console.log(err);
                                        console.log("second click!");
                                        if (browser.isVisible(selectNumber)) {
                                            browser.click(selectNumber);
                                        } else {
                                            browser.click(display_item_number_xpath + '//*[@class="md-select-icon"]');
                                            browser.click(selectNumber);
                                        }
                                        browser.waitForVisible(selectNumberCheck, myWaitDefault);
                                    }
                                    var show_period_element = display_item_number_xpath + "//span/div[@class='md-text']"
                                    expect(browser.getText(show_period_element) == '500').toBe(true, show_period_element)
                                }
                                self.browser_session.waitForResource(browser, myTable, 200);
                                browser.pause(1000);
                                var table_text = self.browser_session.getTableTextCFS(browser, myTable);
                                console.log("process.env.NODE_ENV" + process.env.NODE_ENV);
                                // if(process.env.NODE_ENV == 'Dev'){
                                //     console.log("self is Dev env, we need to change - to 0.00");
                                //     for (var n = 0; n < table_text.length; n++){
                                //         for (var fees_key in table_text[n]) {
                                //             console.log(fees_key);
                                //             console.log(table_text[n][fees_key]);
                                //             if (table_text[n][fees_key] == '-'){
                                //                 table_text[n][fees_key] = "0.00";
                                //             }
                                //             // result_combine[0][j][key] = result_combine[i][j][key];
                                //         }
                                //     }
                                // }
                                console.log("We need to remove the rows when all the values are 0.00 or - from the tail");
                                var fees_len = table_text.length;
                                var accum1 = 0;
                                var accum2 = 0;
                                var keynum = 0;
                                for (var j = fees_len - 1; j > -1; j--) {
                                    accum1 = 0;
                                    keynum = 0;
                                    for (var field_fees_key in table_text[0]) {
                                        keynum++;
                                        if (table_text[j][field_fees_key] == "0.00" || table_text[j][field_fees_key] == "-") {
                                            accum1++;
                                        }
                                    }
                                    if (accum1 == (keynum-2)) { //11
                                        accum2++;
                                    } else {
                                        break;
                                    }
                                }
                                console.log("We need to remove: " + accum2 + " rows for fees")
                                table_text.length = fees_len - accum2;
                                //  console.log(table_text);
                                item["cashflows"] = table_text;
                                cashflow_res[cashflow_type_list[index]] = item;
                            }
                            else {//for Non-CLO
                                myTable = '// div[contains(@ng-if,"[cash.selectedIdentifier].length > 0")]// table';
                                try {
                                    browser.waitForVisible(myTable, myWaitDefault);
                                } catch (error) {//wait data load, some has no data 
                                }
                                console.log("myTable:", myTable);
                                var table_length = browser.elements(myTable).value.length;
                                console.log('table_length: ' + table_length);
                                if (table_length == 0) {// no data displayed in GUI
                                    console.log('no data displayed for cashflow type ' + cashflow_type_list[index]);
                                    item["cashflows"] = {};
                                    cashflow_res[cashflow_type_list[index]] = item;
                                    break;
                                }
                                var result_combine = [];
                                for (var i = 1; i <= table_length; i++) {
                                    var myTable_index = '(' + myTable + ')[' + i + ']';
                                    var table_text = self.browser_session.getTableTextCFS(browser, myTable_index);
                                    var TestsHeader = self.browser_session.getAnormalTableRowHeader(browser, myTable_index);
                                    console.log('table_text:', table_text);
                                    result_combine.push(table_text);
                                }
                                //combine all item to result_combine[0]
                                for (var i = 1; i < result_combine.length; i++) {
                                    for (var j = 0; j < result_combine[i].length; j++) {
                                        console.log(result_combine[i][j]);
                                        for (key in result_combine[i][j]) {
                                            result_combine[0][j][key] = result_combine[i][j][key];
                                        }
                                    }
                                }
                                item["cashflows"] = result_combine[0];
                                cashflow_res[cashflow_type_list[index]] = item;
                            }
                            break;
                        case "Principal Paydown":
                            console.log('--------------------------4. generate json file for Principal Paydown ----------------------------------')
                            myTable = '// div[contains(@ng-if,"[cash.selectedIdentifier].length > 0")]//table';
                            try {
                                browser.waitForVisible(myTable, myWaitDefault);
                            } catch (error) {//wait data load, some has no data 
                            }
                            console.log("myTable:", myTable);
                            var table_length = browser.elements(myTable).value.length;
                            console.log('table_length: ' + table_length);
                            if (table_length == 0) {// no data displayed in GUI
                                console.log('no data displayed for cashflow type ' + cashflow_type_list[index]);
                                item["cashflows"] = {};
                                cashflow_res[cashflow_type_list[index]] = item;
                                break;
                            }
                            var header_list = self.browser_session.getAnormalTableRowHeader(browser, myTable, 2).split(' :: ');
                            console.log(header_list);
                            var header_dict = {};
                            var header_count = browser.elements(myTable + '/thead/tr[1]/th').value.length;
                            var table_index = 0;
                            for (var i = 1; i <= header_count; i++) {
                                var header_text = browser.getText(myTable + '/thead/tr[1]/th[' + i + ']');
                                console.log(i);
                                console.log(header_text);
                                if (header_text != "") {
                                    item[header_text] = [];
                                    var row_count = parseInt(browser.getAttribute(myTable + '/thead/tr[1]/th[' + i + ']', "colspan"));
                                    console.log('row_count: ' + row_count);
                                    var text_header_list = [];
                                    text_header_list.push(header_list[0]); //Month
                                    text_header_list.push(header_list[1]); //Date
                                    for (var j = table_index; j < row_count + table_index; j++) {
                                        console.log(i);
                                        console.log(header_list[2 + j]);
                                        if (principal_paydown == 'All') {
                                            text_header_list.push(header_list[2 + j]);
                                        }
                                        else {
                                            if (header_list[2 + j] == principal_paydown || header_list[2 + j].indexOf('Class') == -1) {
                                                text_header_list.push(header_list[2 + j]);
                                            }
                                        }
                                    }
                                    header_dict[header_text] = text_header_list;
                                    table_index += row_count;
                                }
                            }
                            console.log(header_dict);//{"Tranches":[],"Collateral":[]}
                            var table_text = self.browser_session.getTableTextCFS(browser, myTable);
                            for (var i = 0; i < table_text.length; i++) {
                                for (key in header_dict) {
                                    var tmp = {};
                                    for (var m = 0; m < header_dict[key].length; m++) {
                                        var item_key = header_dict[key][m];
                                        tmp[item_key] = table_text[i][item_key];
                                    }
                                    item[key].push(tmp);
                                }
                            }
                            var prind_len_tranche = item["Tranches"].length;
                            if(assettype == "CLO"){
                                //deal with the length to be same as tranche flow
                                try{
                                    for(var tranche_key in restlenfortranche){
                                        var rlen = Number(restlenfortranche[tranche_key]);
                                        for (var l = prind_len_tranche - 1; l > rlen - 1; l--) {
                                            item["Tranches"][l]["Class " + tranche_key + " Balance"] = "-";
                                        }
                                    }
                                } catch (error) {
                                }

                                //Sort the tranche names in principal paydown->tranche output
                                console.log("------Sort the tranche names in principal paydown->tranche output-----");
                                var keys = [];
                                var len;
                                var item1 = {};
                                for (var k1 in item["Tranches"][0]) {
                                  if (item["Tranches"][0].hasOwnProperty(k1)) {
                                    keys.push(k1);
                                  }
                                }
                                console.log(keys);
                                keys.shift();
                                keys.shift();
                                keys.sort();
                                console.log(keys);
                                len = keys.length;
                                console.log(len);
                                for(var x = 0; x < prind_len_tranche; x++){
                                    item1 = {};
                                    for (var i = 0; i < len; i++) {
                                        item1['Month']=item["Tranches"][x]['Month'];
                                        item1['Date']=item["Tranches"][x]['Date'];
                                        k1 = keys[i];
                                        console.log(k1);
                                        item1[k1]=item["Tranches"][x][k1];
                                        // console.log(item1);
                                    }
                                    item["Tranches"][x] = item1; 
                                }

                                console.log("We need to remove the rows when all the values are 0.00 or - from the tail for principal paydown - collateral");
                                var prind_len = item["Collateral"].length;
                                var accum1 = 0;
                                var accum2 = 0;
                                var keynum = 0;
                                for (var j = prind_len - 1; j > -1; j--) {
                                    accum1 = 0;
                                    keynum = 0;
                                    for (var field_pd_key in item["Collateral"][0]) {
                                        keynum++;
                                        if (item["Collateral"][j][field_pd_key] == "0.00" || item["Collateral"][j][field_pd_key] == "-") {
                                            accum1++;
                                        }
                                    }
                                    if (accum1 == (keynum-2)) { //6
                                        accum2++;
                                    } else {
                                        break;
                                    }
                                }
                                console.log("We need to remove: " + accum2 + " rows for principal paydown")
                                item["Collateral"].length = prind_len - accum2;
                            }
                            cashflow_res[cashflow_type_list[index]] = item;
                            break;
                        case "Collateral Flows":
                        case "Reinvestment":
                            console.log('--------------------------5. generate json file for ' + cashflow_type_list[index] + ' ----------------------------------')
                            myTable = "(" + cashflow_xpath.dealcfsCashflowRusult + ")//table";
                            console.log(myTable);
                            console.log(next_page_xpath);
                            try {
                                browser.waitForVisible(myTable, myWaitDefault);
                            } catch (error) {//wait data load, some has no data 
                            }
                            if (browser.isVisible(next_page_xpath)) {
                                if (cashflow_type_list[index] == 'Reinvestment') {
                                    var display_item_number_xpath1 = '//sfp-data-table[@table="analyticsCtrl.reinvestmentTable"]// md-select[contains(@ng-model,"ctrl.model.numPerPage")]';
                                }
                                else {
                                    var display_item_number_xpath1 = '//sfp-data-table[@table="analyticsCtrl.selectedCollateralFlowDetail"]// md-select[contains(@ng-model,"ctrl.model.numPerPage")]';
                                }
                                console.log("display_item_number_xpath:", display_item_number_xpath1);
                                browser.waitForVisible(display_item_number_xpath1, myWaitDefault);
                                browser.click(display_item_number_xpath1 + '//*[@class="md-select-icon"]');
                                var selectNumber = '//md-select-menu/parent::div[@aria-hidden="false"]// *[contains(@class,"md-text") and contains(normalize-space(),"500")]';
                                try {
                                    browser.waitForVisible(selectNumber, myWaitDefault);
                                } catch (err) {
                                    browser.click(display_item_number_xpath1 + '//*[@class="md-select-icon"]');
                                    browser.waitForVisible(selectNumber, myWaitDefault);
                                }
                                var selectNumberCheck = display_item_number_xpath1 + '//md-select-value//div[contains(text(),"500")]';
                                try {
                                    browser.click(selectNumber);
                                    browser.waitForVisible(selectNumberCheck, myWaitDefault);
                                } catch (err) {
                                    console.log(err);
                                    console.log("second click!");
                                    if (browser.isVisible(selectNumber)) {
                                        browser.click(selectNumber);
                                    } else {
                                        browser.click(display_item_number_xpath1 + '//*[@class="md-select-icon"]');
                                        browser.click(selectNumber);
                                    }
                                    browser.waitForVisible(selectNumberCheck, myWaitDefault);
                                }
                                var show_period_element = display_item_number_xpath1 + "//span/div[@class='md-text']"
                                expect(browser.getText(show_period_element) == '500').toBe(true, show_period_element)
                            }
                            console.log("myTable:", myTable);
                            if (browser.elements(myTable).value.length == 0) {// no data displayed in GUI
                                console.log('no data displayed for cashflow type ' + cashflow_type_list[index]);
                                item["cashflows"] = {};
                                cashflow_res[cashflow_type_list[index]] = item;
                                break;
                            }
                            self.browser_session.waitForResource(browser, myTable, 200);
                            if (cashflow_type_list[index] == 'Reinvestment') {
                                console.log("-------------->show item number:", browser.getText('//sfp-data-table[@table="analyticsCtrl.reinvestmentTable"]// md-select[contains(@ng-model,"ctrl.model.numPerPage")]//md-select-value//div'));
                            } else {
                                console.log("-------------->show item number:", browser.getText('//sfp-data-table[@table="analyticsCtrl.selectedCollateralFlowDetail"]// md-select[contains(@ng-model,"ctrl.model.numPerPage")]//md-select-value//div'));
                            }
                            console.log("-------------->table row count:", browser.elements(myTable + '//tr').value.length);
                            browser.pause(1000);
                            var table_text = self.browser_session.getTableTextCFS(browser, myTable);
                            // console.log(table_text);
                            item["perfsummary"]["scenario_id"] = scenario_id;
                            item["perfsummary"]["settles_date"] = settles_date;
                            item["cashflows"] = table_text;
                            //remove the rows when all the values are 0.00 or - from the tail
                            if (assettype == "CLO" && (cashflow_type_list[index] == 'Collateral Flows'|| cashflow_type_list[index] == 'Reinvestment')) {
                                console.log("----------------------We need to remove the rows when all the values are 0.00 or - from the tail");
                                var reinv_len = item["cashflows"].length;
                                console.log(reinv_len);
                                var accum1 = 0;
                                var accum2 = 0;
                                var keynum = 0;
                                for (var j = reinv_len - 1; j > -1; j--) {
                                    accum1 = 0;
                                    keynum = 0;
                                    for (var field_reinv_key in item["cashflows"][0]) {
                                        console.log(field_reinv_key);
                                        keynum++;
                                        console.log(item["cashflows"][j][field_reinv_key]);
                                        if (item["cashflows"][j][field_reinv_key] == "0.00" || item["cashflows"][j][field_reinv_key] == "-") {
                                            accum1++;
                                            console.log(accum1);
                                        }
                                    }
                                    if (accum1 == (keynum-2)) { //collateral = 19, Reinvestment = 10
                                        accum2++;
                                    } else {
                                        break;
                                    }
                                }
                                console.log("We need to remove: " + accum2 + " rows for " + cashflow_type_list[index]);
                                item["cashflows"].length = reinv_len - accum2;
                                console.log(item["cashflows"].length);
                            }
                            cashflow_res[cashflow_type_list[index]] = item;
                            break;
                        case "Deal Flows":
                            if (run_particular_tranche == 'All') {
                                console.log('--------------------------6. generate json file for Deal Flows ----------------------------------')
                                //reset the scroll let to beginning
                                browser.execute('document.evaluate(\'//div[@ref="eBodyViewport"]\',document).iterateNext().scrollLeft=0');
                                var dealflow_panel = '//div[@id="sfp-ag-grid"]';
                                browser.waitForVisible(dealflow_panel, myWaitDefault);
                                browser.getLocationInView(dealflow_panel);
                                var dl_content_xpath = '//div[@ref="__NAME__"]';
                                var leftHeader = dl_content_xpath.replace('__NAME__', 'ePinnedLeftHeader');
                                var eHeader = dl_content_xpath.replace('__NAME__', 'eHeaderContainer');
                                var eLeftContent = dl_content_xpath.replace('__NAME__', 'eLeftContainer');
                                var eBodyContent = dl_content_xpath.replace('__NAME__', 'eBodyContainer');

                                //######################### 1.calculate the scroll step length #######################
                                var display_column_count = browser.elements(eHeader + '/div[2]/div').value.length;
                                var row_width_px = 200;
                                var row_height_px = 25;
                                console.log('display_column_count: ' + display_column_count);
                                if (display_column_count > 0) {
                                    var row_width = browser.getAttribute(eHeader + '/div[2]/div[1]', 'style');
                                    console.log(row_width);
                                    row_width = '{' + row_width.replace(/;/g, ',').replace(/px/g, '') + '}';
                                    console.log(row_width);
                                    row_width_px = eval('(' + row_width + ')').width;
                                    console.log('row_width_px: ' + row_width_px);
                                }

                                var display_row_count = browser.elements(eBodyContent + '/div').value.length;
                                if (display_row_count > 0) {
                                    var row_height = browser.getAttribute(eBodyContent + '/div[1]', 'style');
                                    console.log(row_height);
                                    row_height = '{' + row_height.replace(/;/g, ',').replace(/\)/g, '').replace('translateY(', '').replace(/px/g, '') + '}';
                                    console.log(row_height);
                                    row_height_px = eval('(' + row_height + ')').height;
                                    console.log('row_height_px: ' + row_height_px);
                                }

                                //######################### 2.get the header info and save to dict ####################
                                var actual_scroll_left = 0;
                                var second_header_dict = {};
                                var first_header_dict = {};
                                var senond_left_header_dict = {};
                                var time = 0;//a flag stop scroll left when time == 2

                                var senond_left_heade_row_count = browser.elements(leftHeader + '/div[2]/div').value.length;
                                for (var n = 1; n <= senond_left_heade_row_count; n++) {//get second left header dict
                                    var senond_left_heade_item = leftHeader + '/div[2]/div[' + n + ']';
                                    var senond_left_heade_key = browser.getAttribute(senond_left_heade_item, 'col-id');
                                    var senond_left_heade_value = browser.getAttribute(senond_left_heade_item + '//span[@ref="eText"]', 'innerHTML');
                                    senond_left_header_dict[senond_left_heade_key] = senond_left_heade_value;
                                }
                                console.log('--------second_left_header_dict--------');
                                console.log(senond_left_header_dict);
                                var header_scroll_left_length = 0;// the length to scroll
                                do { // left scroll, the scroll step length is display_column_count * row_width_px
                                    //  re-get display_column_count every time, coz it changed after scroll
                                    display_column_count = browser.elements(eHeader + '/div[2]/div').value.length;
                                    var scroll_left_step = display_column_count * row_width_px; // scroll left step length
                                    var first_header_row_count = browser.elements(eHeader + '/div[1]/div').value.length;
                                    for (var m = 1; m <= first_header_row_count; m++) {//get first header dict
                                        var first_header_item = eHeader + '/div[1]/div[' + m + ']';
                                        var first_header_key = browser.getAttribute(first_header_item, 'col-id');
                                        var first_header_value = browser.getAttribute(first_header_item + '//span[@ref="agLabel"]', 'innerHTML');
                                        first_header_dict[first_header_key] = first_header_value;
                                        item[first_header_value] = {};
                                    }
                                    console.log('--------first_header_dict--------');
                                    console.log(first_header_dict);

                                    // get the second header dict
                                    for (var j = 1; j <= display_column_count; j++) {
                                        var second_header_item = eHeader + '/div[2]/div[' + j + ']';
                                        var second_header_key = browser.getAttribute(second_header_item, 'col-id');
                                        // not use getText,coz when Displayed is false, text is ''
                                        //var second_header_value = browser.getText(second_header_item + '//span[@ref="eText"]');
                                        var second_header_value = browser.getAttribute(second_header_item + '//span[@ref="eText"]', 'innerHTML');
                                        second_header_dict[second_header_key] = second_header_value;
                                    }
                                    console.log('--------second_header_dict--------');
                                    console.log(second_header_dict);
                                    header_scroll_left_length += scroll_left_step;
                                    var scroll_left_script = 'document.evaluate(\'//div[@ref="eBodyViewport"]\',document).iterateNext().scrollLeft=' + header_scroll_left_length;
                                    browser.execute(scroll_left_script);
                                    var actual_scroll_left_dict = browser.execute(' return document.evaluate(\'//div[@ref="eBodyViewport"]\',document).iterateNext().scrollLeft');
                                    console.log(actual_scroll_left_dict);
                                    actual_scroll_left = actual_scroll_left_dict.value;
                                    console.log('actual_scroll_left: ' + actual_scroll_left);
                                    console.log('scroll left length:' + header_scroll_left_length);
                                    if (actual_scroll_left < header_scroll_left_length)
                                        time++;
                                } while (time < 2);// scroll the left to the end

                                //######################### 3.get the left side data  #####################
                                var left_content_dict_list = {};
                                var scroll_top_length = 0;
                                var actual_scroll_top = 0;
                                var time_top = 0;
                                do {//scroll top
                                    //reset the scroll let to beginning
                                    display_row_count = browser.elements(eLeftContent + '/div').value.length;
                                    var scroll_top_step = display_row_count * row_height_px;// scroll top step length
                                    //get left side data
                                    for (var j = 1; j <= display_row_count; j++) {
                                        var left_content_dict = {};
                                        var row_list_item = eLeftContent + '/div[' + j + ']';
                                        var row_list_key = browser.getAttribute(row_list_item, 'row-id');
                                        //if already has added the row to left_content_dict_list
                                        if (left_content_dict_list.hasOwnProperty(row_list_key)) {
                                            continue;
                                        }
                                        var row_div_length = browser.elements(row_list_item + '/div').value.length;
                                        for (var a = 1; a <= row_div_length; a++) {
                                            var row_item = row_list_item + '/div[' + a + ']';
                                            var row_item_key = browser.getAttribute(row_item, 'col-id');
                                            var row_item_value = browser.getAttribute(row_item, 'innerHTML');
                                            //console.log(row_item_key + '----->' + row_item_value);
                                            left_content_dict[senond_left_header_dict[row_item_key]] = row_item_value;
                                        }
                                        left_content_dict_list[row_list_key] = left_content_dict;
                                    }
                                    console.log('--------left_content_dict_list--------');
                                    console.log(left_content_dict_list);
                                    scroll_top_length += scroll_top_step;
                                    var scroll_top_script = 'document.evaluate(\'//div[@ref="eBodyViewport"]\',document).iterateNext().scrollTop=' + scroll_top_length;
                                    browser.execute(scroll_top_script);
                                    var actual_scroll_top_dict = browser.execute(' return document.evaluate(\'//div[@ref="eBodyViewport"]\',document).iterateNext().scrollTop');
                                    actual_scroll_top = actual_scroll_top_dict.value;
                                    console.log('actual_scroll_top: ' + actual_scroll_top);
                                    console.log('scroll top length: ' + scroll_top_length);
                                    if (actual_scroll_top < scroll_top_length)
                                        time_top++;
                                } while (time_top < 2);
                                //######################### 4.push left side data to cashflow_res #####################
                                // add left content to canshflow_res
                                for (var key_first_header in first_header_dict) {
                                    item[first_header_dict[key_first_header]] = self.browser_session.deepCopy(left_content_dict_list);
                                }
                                // console.log(item);
                                browser.execute('document.evaluate(\'//div[@ref="eBodyViewport"]\',document).iterateNext().scrollTop=0');
                                //######################### 5.get the right side data and push to cashflow_res #####################

                                var scroll_top_length = 0;//the length to top scroll
                                var actual_scroll_top = 0;
                                var time_top = 0;
                                var value_is_hyphen_dict = {};
                                do {//scroll top
                                    //reset the scroll let to beginning
                                    browser.execute('document.evaluate(\'//div[@ref="eBodyViewport"]\',document).iterateNext().scrollLeft=0');
                                    display_row_count = browser.elements(eLeftContent + '/div').value.length;
                                    var scroll_top_step = display_row_count * row_height_px;// scroll top step length
                                    //scroll left
                                    var scroll_left_length = 0;
                                    var time_left = 0;
                                    //get right side data
                                    do {
                                        display_column_count = browser.elements(eHeader + '/div[2]/div').value.length;
                                        var scroll_left_step = display_column_count * row_width_px; // scroll left step length
                                        for (var c = 1; c <= display_row_count; c++) {
                                            var row_list_item = eBodyContent + '/div[' + c + ']';
                                            var row_list_key = browser.getAttribute(row_list_item, 'row-id');
                                            var row_div_length = browser.elements(row_list_item + '/div').value.length;
                                            for (var d = 1; d <= row_div_length; d++) {
                                                var row_item = row_list_item + '/div[' + d + ']';
                                                var row_item_key = browser.getAttribute(row_item, 'col-id');
                                                var key_index = parseInt(row_item_key.split('_')[1]) + 1;
                                                var first_header_value = first_header_dict[key_index + '_0'];//get the value of key in first_header_dict
                                                //############## Enhencement ##################
                                                //1.if key exists, no need to get value ,for it's duplicate
                                                if (item[first_header_value][row_list_key].hasOwnProperty(second_header_dict[row_item_key])) {
                                                    continue;
                                                }
                                                // hyphen_key = trancheName+columnName ex:Class A1 - /XS2036104243_b_1,
                                                //use for when column is -, then following row for self coulmn value is -
                                                var hyphen_key = first_header_value + '_' + row_item_key;
                                                // 2. if the row value is - and then make all next rows' value to -  
                                                if (value_is_hyphen_dict.hasOwnProperty(hyphen_key) && parseInt(row_list_key) > value_is_hyphen_dict[hyphen_key]) {
                                                    item[first_header_value][row_list_key][second_header_dict[row_item_key]] = '-';
                                                    continue;
                                                }
                                                //############## End Enhencement ##################
                                                var row_item_value = browser.getAttribute(row_item, 'innerHTML');
                                                // if value is - ,add key-value to value_is_hyphen_dict,key is trancheName+columnName
                                                if (row_item_value == '-') {
                                                    value_is_hyphen_dict[hyphen_key] = parseInt(row_list_key);
                                                }
                                                //add right side data to canshflow_res
                                                item[first_header_value][row_list_key][second_header_dict[row_item_key]] = row_item_value;
                                            }
                                        }
                                        //console.log('--------item data--------');
                                        scroll_left_length += scroll_left_step ;
                                        var scroll_left_script = 'document.evaluate(\'//div[@ref="eBodyViewport"]\',document).iterateNext().scrollLeft=' + scroll_left_length;
                                        browser.execute(scroll_left_script);
                                        var actual_scroll_left_dict = browser.execute(' return document.evaluate(\'//div[@ref="eBodyViewport"]\',document).iterateNext().scrollLeft');
                                        actual_scroll_left = actual_scroll_left_dict.value;
                                        console.log('actual_scroll_left: ' + actual_scroll_left);
                                        console.log('scroll left length:' + scroll_left_length);
                                        if (actual_scroll_left < scroll_left_length)
                                            time_left++;
                                    } while (time_left < 2);
                                    scroll_top_length += scroll_top_step;
                                    var scroll_top_script = 'document.evaluate(\'//div[@ref="eBodyViewport"]\',document).iterateNext().scrollTop=' + scroll_top_length;
                                    browser.execute(scroll_top_script);
                                    var actual_scroll_top_dict = browser.execute(' return document.evaluate(\'//div[@ref="eBodyViewport"]\',document).iterateNext().scrollTop');
                                    actual_scroll_top = actual_scroll_top_dict.value;
                                    console.log('actual_scroll_top: ' + actual_scroll_top);
                                    console.log('scroll top length: ' + scroll_top_length);
                                    if (actual_scroll_top < scroll_top_length)
                                        time_top++;
                                } while (time_top < 2);
                                // put the value from {key:value} to [value]
                                for (var key in item) {
                                    if (key != 'perfsummary') {
                                        var list = [];
                                        for (var item_key in item[key]) {
                                            list.push(item[key][item_key]);
                                        }
                                        item[key] = list;
                                    }
                                }
                                if (assettype == "CLO"){
                                    console.log("--------------------Change value to - when interest and principal are both 0.00 for deal flow---");
                                    for (var key in item) {
                                        if (key != 'perfsummary') {
                                            console.log(item[key]);
                                            console.log(item[key][0]);
                                            var record_len = item[key].length;
                                            console.log("record_len:"+record_len);
                                            if (record_len > 2){
                                                for (var z = record_len-1; z > 1; z--){
                                                    if (item[key][z]['Interest'] == '0.00' && item[key][z]['Principal'] == '0.00'){
                                                        item[key][z]['End Balance'] = '-';
                                                        item[key][z]['Interest'] = '-';
                                                        item[key][z]['Principal'] = '-';
                                                        item[key][z]['Loss'] = '-';
                                                        item[key][z]['Attachment'] = '-';
                                                        item[key][z]['Detachment'] = '-';
                                                        item[key][z]['Implied Losses'] = '-';
                                                        item[key][z]['Implied Subordinate Amount'] = '-';
                                                        console.log("Change deal flow value to -");
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    //sort for different tranches
                                    console.log("------Sort by different tranche names in deal flow--------");
                                    var keys = [];
                                    var len;
                                    var item1 = {};
                                    for (var k1 in item) {
                                      if (item.hasOwnProperty(k1)) {
                                        keys.push(k1);
                                      }
                                    }
                                    console.log(keys);
                                    item1['perfsummary']=item['perfsummary'];
                                    console.log("--------------------"+item1['perfsummary']);
                                    keys.shift();
                                    keys.sort();
                                    console.log(keys);
                                    len = keys.length;
                                    console.log(len);
                                    for (var i = 0; i < len; i++) {
                                      k1 = keys[i];
                                      console.log(k1);
                                      item1[k1]=item[k1];
                                    }
                                    item = item1;
                                }
                                cashflow_res[cashflow_type_list[index]] = item;
                                break;
                            }
                            else {
                                break;
                            }
                        default:
                            console.log('##################### No defined self type of cashflow->' + cashflow_type_list[index] + ' ####################');
                            expect(false).toBe(true);
                            break;
                    }
                }
                console.log('self.firstloss'+self.firstloss)
                if(self.firstloss){
                    scenario_id = scenario_id+'firstloss'
                }
                if(self.isCurrentdate){
                    settles_date = 'Current Date'
                }
                console.log(self.override_rule)
                if (run_particular_tranche == 'All' && assettype == 'CLO EditDeal') {
                    var file_name = scenario_id + '_' + self.override_rule + '_' + sfwdealID + '_' + settles_date;
                    var price_irr_file_name = sfwdealID + '_' + file_scen_name+'_' + yield_id + '_' + irr_id + '_' + settles_date;
                } else if (run_particular_tranche == 'All') {
                    var file_name = scenario_id + '_' + sfwdealID + '_' + settles_date;
                    var price_irr_file_name = sfwdealID + '_' + file_scen_name+'_' + yield_id + '_' + irr_id + '_' + settles_date;
                }
                else {
                    console.log("deal_name1:" + isin_name);
                    var file_name = isin_name + '_' + scenario_id+self.economyNum+self.isCustom+'_'+settles_date;
                     var price_irr_file_name =isin_name + '_'+file_scen_name+'_' + yield_id + '_' + irr_id + '_' + settles_date;
                }
                // var file_path = '../../../cashflow_res';
                switch (pagetype) {
                    case 'cashflow':
                        if (run_particular_tranche == 'All') {
                            var folder_name = 'deal_cashflow_res';
                        }
                        else {
                            var folder_name = 'portfolio_cashflow_in_deal_res';
                        }
                        break;
                    case 'clickwrap-cashflow':
                        var folder_name = 'clickwrap_cashflow_res';
                        break;
                    case 'visitor-clickwrap-cashflow':
                        var folder_name = 'visitor_clickwrap_cashflow_res';
                        break;
                    default:
                        var folder_name = 'deal_cashflow_res';
                        break;
                }
                //compatible new cashflow page,save result to a new folder
                //if (process.env.NEW_CF == "Y") {
                //    folder_name = folder_name + '_new';
                //}
                var file_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res', folder_name);
                console.log(file_path)
                export_res(file_name, file_path, cashflow_res, 'json');
                export_res(price_irr_file_name,file_path,full_scenarios_list,'json')
                if (process.env.RunDealRequest == 'True' && scenario_list_length == 1 && process.env.NODE_ENV != 'Prod') {
                    // if (process.env.RunDealRequest == 'True' && scenario_list_length == 1 && process.env.NODE_ENV == 'Dev') {
                    // var run_deal_request_xpath = '//div[contains(@ng-repeat,"item in analyticsCtrl.debugOutput track by")][2]';
                    // var toggle_output_button = '//span[contains(text(),"Toggle Debug Output")]';
                    // try {
                    //     if (browser.isVisible(toggle_output_button)) {
                    //         browser.click(toggle_output_button);
                    //         browser.waitForVisible(run_deal_request_xpath, myWaitDefault);
                    //     } else {
                    //         console.log('click toggle output button failed');
                    //     }
                    // } catch (e) {
                    //     console.log('wait for run deal request');
                    //     browser.waitForVisible(run_deal_request_xpath, myWaitDefault);
                    // }
                    // 
                    // 
                    var toggle_output_button = '//span[contains(text(),"Toggle Debug Output")]';
                    if(process.env.NODE_ENV.indexOf('SPS')!=-1){
                        var run_deal_request_xpath = '//div[contains(@ng-repeat,"item in analyticsCtrl.debugOutput track by")]';
                    }else{
                        var run_deal_request_xpath = '//div[contains(@ng-repeat,"item in analyticsCtrl.debugOutput track by")][2]'
                    }
                    try {
                        browser.waitForVisible(toggle_output_button,this.waitMax)
                        browser.getLocationInView(toggle_output_button);
                        if (browser.isVisible(toggle_output_button)&&!browser.isVisible(run_deal_request_xpath)) {
                            browser.click(toggle_output_button);
                            browser.waitForVisible(run_deal_request_xpath, myWaitDefault);
                            self.browser_session.waitForResource(browser,run_deal_request_xpath)
                        } else {
                            console.log('click toggle output button failed');
                        }
                    } catch (e) {
                        console.log('wait for run deal request');
                        browser.waitForVisible(run_deal_request_xpath, myWaitDefault);
                        self.browser_session.waitForResource(browser,run_deal_request_xpath)
                    }
                    try{ 
                        for (var scen_index = 1; scen_index <= scenario_list_length; scen_index++) {
                            var scenario_id = scenario_list[scen_index - 1]["scenario_id"];
                            var settles_date = scenarios_used[scenario_id][4];
                            var request_str = browser.getText(run_deal_request_xpath);
                            console.log(run_deal_request_xpath)
                            console.log(request_str)
                            // var file_name = scenario_id + '_' + sfwdealID + '_' + settles_date+'_request';
                            file_name = file_name+'_request'
                            if(process.env.NODE_ENV.indexOf('SPS')!=-1 && (assettype == 'CLO' || assettype =='CLO EditDeal')){
                                request_str = request_str.replace(/Cashflow Request for Scen \d/g,'').replace(/_FLC_Principal/g,'').replace(/_FLC_Interest/g,'')
                                var run_deal_request = JSON.parse(request_str)
                                var file_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res', 'run_deal_request');
                                export_res(file_name, file_path, run_deal_request, 'json');
                            }else{
                                var run_deal_request = request_str.substring(request_str.indexOf("<runDealSettings"), request_str.indexOf("</RundealRequest>"));
                                var file_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res', 'run_deal_request');
                                export_res(file_name, file_path, run_deal_request, 'xml');
                            }

                        }

                    }catch(e){
                        console.log(e)

                    }

                    
                    // var request_xml = browser.getText(run_deal_request_xpath);
                    // file_name = file_name + '_request';
                    // // console.log('request_xml:',request_xml);
                    // var run_deal_request = request_xml.substring(request_xml.indexOf("<runDealSettings"), request_xml.indexOf("</RundealRequest>"));
                    // // file_path = '../../../cashflow_res' + '/run_deal_request';
                    // file_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res', 'run_deal_request');
                    // export_res(file_name, file_path, run_deal_request, 'xml');
                    // console.log('run_deal_request:',run_deal_request);
                }
            }

            if (self.stratifications_flag) {
                console.log('delet all stratifications_flag')
                var apply_stra = '//a[contains(text(),"Apply Stratification")]'
                browser.getLocationInView(apply_stra)
                browser.click(apply_stra);
                browser.waitForVisible('//table[contains(@id,"watchlist")]', self.waitDefault);
                if (browser.isExisting('//*[contains(@ng-click,"assumpCtrl.deleteRule")]')) {
                    var stra_length = browser.elements('//*[contains(@ng-click,"assumpCtrl.deleteRule")]').value.length;
                    console.log('stra_length:', stra_length)
                    for (var strItem = 1; strItem <= stra_length; strItem++) {
                        console.log('strItem:', strItem)
                        browser.click('(//*[contains(@ng-click,"assumpCtrl.deleteRule")])[1]');
                    }
                    browser.click('//span[contains(text(),"Save Stratifications")]')
                }
                // close Stratifications
                browser.click('//*[contains(@ng-click,"assumpCtrl.colWatchList = false")]');
                self.stratifications_flag = false
            }

        });
};

