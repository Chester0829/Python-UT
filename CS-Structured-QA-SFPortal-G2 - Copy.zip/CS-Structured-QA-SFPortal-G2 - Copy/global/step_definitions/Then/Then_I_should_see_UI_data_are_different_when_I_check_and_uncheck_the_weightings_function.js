module.exports=function(){
  this.Then(/^I should see UI data are different when I check and uncheck the weightings function$/, function () {
         

         var excludeWeightingsData = this.excludeWeightingsData;         
         var weightingsData = this.weightingsData;            

         for(var i=0;i<excludeWeightingsData.length;i++){           
           console.log('excludeWeightingsData---------->',excludeWeightingsData[i]);
           console.log('weightingsData---------->',weightingsData[i]);
           expect(excludeWeightingsData[i]).not.toEqual(weightingsData[i]); 
         }

       });
}