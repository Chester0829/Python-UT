 //Then_I_run_deal cashflows_and_should_see_cashflow_result_within_#_minutes.js
module.exports = function(){ 
      this.Then(/^I run (deal|portfolio) cashflows and should see cashflow result within "([^"]*)" minutes$/,  
       { timeout: process.env.StepTimeoutInMS * 5 },
          function (runtype,arg1) {
         // Write code here that turns the phrase above into concrete actions


         var timeOut = arg1*60*1000;
         const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');

         if(runtype == 'deal'){             
             this.browser_session.waitForResource(browser,cashflow_xpath.dealCfsAssumptions);
             browser.getLocationInView(cashflow_xpath.dealRunCashflow);
             browser.click(cashflow_xpath.dealRunCashflow);
             try {
                 browser.waitForExist(cashflow_xpath.dealCfsRunprogressBar,this.waitDefault);
                 browser.waitForVisible(cashflow_xpath.dealCfsRunprogressBar,this.waitDefault);
                 this.browser_session.waitForLoading(browser,cashflow_xpath.dealCfsRunprogressBar,1000,timeOut);
                 browser.waitForVisible(cashflow_xpath.dealcfsCashflowRusult,this.waitDefault);
             }catch (e) {
                 console.log(e);
                 console.log("wait for second time as the running bar does not visible");
                 browser.waitForExist(cashflow_xpath.dealCfsRunprogressBar,this.waitDefault);
                 browser.waitForVisible(cashflow_xpath.dealCfsRunprogressBar,this.waitDefault);
                 this.browser_session.waitForLoading(browser,cashflow_xpath.dealCfsRunprogressBar,1000,timeOut);
                 browser.waitForVisible(cashflow_xpath.dealcfsCashflowRusult,timeOut);
             }
                 browser.pause(800);
                 expect(browser.isVisible(cashflow_xpath.dealCfsResultprogressBar)).toBe(false,'dealCfsResultprogressBar still show');
                 expect(browser.isVisible(cashflow_xpath.dealCfsRunprogressBar)).toBe(false,'dealCfsRunprogressBar still show');
         }
         else{
             var run_cashflow_button = cashflow_xpath.cashflowButton;
             // this.browser_session.waitForResource(browser,cashflow_xpath.dealCfsAssumptions);
             browser.getLocationInView(run_cashflow_button);
             browser.click(run_cashflow_button);
             try {
                 browser.waitForExist(cashflow_xpath.cashflowProcess,this.waitDefault);
                 browser.waitForVisible(cashflow_xpath.cashflowProcess,this.waitDefault);
                 this.browser_session.waitForLoading(browser,cashflow_xpath.cashflowProcess,1000,timeOut);
                 browser.waitForVisible(cashflow_xpath.portfolioCashflowResult,this.waitDefault);
             }catch (e) {
                 console.log(e);
                 console.log("wait for second time as the running bar does not visible");
                 browser.waitForExist(cashflow_xpath.cashflowProcess,this.waitDefault);
                 browser.waitForVisible(cashflow_xpath.cashflowProcess,this.waitDefault);
                 this.browser_session.waitForLoading(browser,cashflow_xpath.cashflowProcess,1000,timeOut);
                 browser.waitForVisible(cashflow_xpath.portfolioCashflowResult,timeOut);
             }
                 browser.pause(800);
                 expect(browser.isVisible(cashflow_xpath.dealCfsResultprogressBar)).toBe(false,'dealCfsResultprogressBar still show');
                 expect(browser.isVisible(cashflow_xpath.cashflowProcess)).toBe(false,'cashflowProcess still show');
         }
       }); 
};