module.exports = function() {
  this.Then(/^I should see the page redirect to (deal|issuer|tranche|manager|industry|loan|portfolio) page$/, function (pageType) {
    // Write the automation code here
    // pending();
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');

    this.browser_session.waitForLoading(browser);
    var target_url = browser.getUrl();
    console.log(target_url);
    switch(pageType){
        case 'deal':
            expect(target_url).toContain('/deal/summary/');
            break;
        case 'issuer':
            expect(target_url).toContain('/issuer/');
            break;
        case 'tranche':
            expect(target_url).toContain('/deal/tranches/');
            break;
        case 'manager':
            expect(target_url).toContain('/manager/summary/');
            break;
        case 'industry':
            expect(target_url).toContain('/industry/');
            break;
        case 'loan':
            expect(target_url).toContain('/loan/');
            break;
        case 'portfolio':
            expect(target_url).toContain('/portfolio/positions/');
            break;
    }   
  });
};