// Then_I_should_see_the_vector_named_#_has_the_following_settings_in_the_#_tab.js
// CMBS portfolio cashflow 
module.exports = function() {
this.Then(/^I should see the vector named "([^"]*)" has the following settings in the "([^"]*)" tab$/, function (vectorName, tabName, table) {
    // Write code here that turns the phrase above into concrete actions
    var cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
    this.browser_session.waitForResource(browser);
    var root_path = cashflow_xpath.vectors;
    // cmbs cashflow xpath
    var xpathInfo = {
      'Prepayment':{
        'name':'//sfp-text-input[@ng-model="vectorCtrl.currPrePayVec[\'name\']"]//input',
        'name1':'//input[@ng-model="vectorCtrl.currPrePayVec[\'name\']"]',
        'assumption':'//md-select[@ng-model="vectorCtrl.currPrePayVec.vectorDetail.ppydefTypeCode"]',
        'apply_seasoning':'//md-select[@ng-model="vectorCtrl.currPrePayVec.vectorDetail.ppydefVector[\'vectorSeasoning\']"]',
        'month': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.prepay_periods_data[$index].month"]',
        'rate': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.prepay_periods_data[$index].rate"]',
      },
      'Default':{
        'name':'//sfp-text-input[@ng-model="vectorCtrl.currDefaultVec[\'name\']"]//input',
        'name1':'//input[@ng-model="vectorCtrl.currDefaultVec[\'name\']"]',
        'assumption':'//md-select[@ng-model="vectorCtrl.currDefaultVec.vectorDetail.ppydefTypeCode"]',
        'apply_seasoning':'//md-select[@ng-model="vectorCtrl.currDefaultVec.vectorDetail.ppydefVector[\'vectorSeasoning\']"]',
        'month': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.def_periods_data[$index].month"]',
        'rate': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.def_periods_data[$index].rate"]',
      },
      'Loss Vectors':{
        'name':'//sfp-text-input[@ng-model="vectorCtrl.currLossVec[\'name\']"]//input',
        'name1':'//input[@ng-model="vectorCtrl.currLossVec[\'name\']"]',
        'apply_seasoning':'//md-select[@ng-model="vectorCtrl.currLossVec.vectorDetail[\'vectorSeasoning\']"]',
        'month': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.loss_periods_data[$index].month"]',
        'rate': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.loss_periods_data[$index].rate"]',
      },
      'Asset Class Vectors':{
        'name':'//sfp-text-input[@ng-model="vectorCtrl.currAssetVec[\'name\']"]//input',
        'name1':'//input[@ng-model="vectorCtrl.currAssetVec[\'name\']"]',
        'apply_seasoning':'//md-select[@ng-model="vectorCtrl.currAssetVec.vectorDetail[\'vectorSeasoning\']"]',
        'vector_type':'//md-select[@ng-model="vectorCtrl.vectorType"]',
        'asset_class':'//*[@ng-model="vectorCtrl.assetClass"]',
        'month': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.asset_periods_data[$index].month"]',
        'rate': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.asset_periods_data[$index].rate"]',
      }
    };

    var targetXpath = xpathInfo[tabName];
    console.log(targetXpath);

    var tableList = table.hashes();
    var name = tableList[0]['name'];
    var assumption = tableList[0]['assumption'];
    var apply_seasoning = tableList[0]['apply_seasoning'];
    var month = tableList[0]['month'].split(',');
    var rate = tableList[0]['rate'].split(',');
    var vector_type = tableList[0]['vector_type'];
    var asset_class = tableList[0]['asset_class'];

    var recordName = browser.getValue(targetXpath['name1']);
    expect(name).toBe(recordName);
    browser.pause(100);

    // input month and rate for all
    for(var i=0;i<month.length;i++){
      var tmonth = month[i];
      var trate = rate[i];
      expect(browser.getValue(targetXpath['month'].replace('__INDEX__',i+1))).toBe(tmonth);
      browser.pause(100);
      expect(browser.getValue(targetXpath['rate'].replace('__INDEX__',i+1))).toBe(trate);
      browser.pause(100);
    }

    if(apply_seasoning){
    expect(browser.getText(targetXpath['apply_seasoning'])).toBe(apply_seasoning);
    browser.pause(500);
    }

    if(assumption){
      expect(browser.getText(targetXpath['assumption'])).toBe(assumption);
      browser.pause(500);
    }

    if(asset_class){
      browser.pause(500);
      expect(browser.getText(targetXpath['asset_class'])).toBe(asset_class);
      console.log(browser.getText(targetXpath['asset_class']));
    }

    if(vector_type){
      browser.pause(500);
      expect(browser.getText(targetXpath['vector_type'])).toBe(vector_type);
      console.log(browser.getText(targetXpath['vector_type']));
    }
  });
}