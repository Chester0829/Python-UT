  //Then_I_delete_the_#_item_that_before_created_under_the_#_panel-heading.js
  module.exports = function() {
  this.Then(/^I delete the "([^"]*)" item that before created under the "([^"]*)" panel\-heading$/, function (itemName, panelName) {
         // Write code here that turns the phrase above into concrete actions
          const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
          const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
          var table_tr = content_xpath.nomarlTable.replace('__NAME__',"table cftable")+"//tr";
          var ItemDelete = content_xpath.nomarlTable.replace('__NAME__',"table cftable")+cashflow_xpath.cashflowReinDelete;
          var length = browser.elements(table_tr).value.length
          for (var i = 0; i < length; i++) {
            var text = browser.getValue("("+table_tr+")["+(i+1)+"]//input");
            console.log("("+table_tr+")["+(i+1)+"]//input");
            console.log(text);
             if (browser.getValue("("+table_tr+")["+(i+1)+"]//input") == itemName) {
                console.log('delete');
                browser.click("("+ItemDelete+")["+(i+1)+"]");
                length--;
             }
         }
        this.browser_session.waitForResource(browser,table_tr);
       });
}