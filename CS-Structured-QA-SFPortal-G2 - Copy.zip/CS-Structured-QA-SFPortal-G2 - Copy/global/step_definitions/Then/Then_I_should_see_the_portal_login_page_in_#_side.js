module.exports = function(){
  this.Then(/^I should see the portal login page in (normal|clickwrap) side$/,
    function(pageType){
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      const clickwrap_xpath = this.xpath_lib.xpathRequire('clickwrap_xpath');
      const loginPage_xpath = this.xpath_lib.xpathRequire('loginPage_xpath');

      var agreementForm = clickwrap_xpath.agreementForm;

      if(pageType == 'clickwrap'){
        var isAgreeShow = browser.isVisible(agreementForm);
        console.log(isAgreeShow);
        expect(isAgreeShow).toEqual(false);
      }

      var myLoginForm = loginPage_xpath.signIn_form;
      console.log(myLoginForm);
      browser.waitForVisible(myLoginForm, this.waitDefault);
    });
}