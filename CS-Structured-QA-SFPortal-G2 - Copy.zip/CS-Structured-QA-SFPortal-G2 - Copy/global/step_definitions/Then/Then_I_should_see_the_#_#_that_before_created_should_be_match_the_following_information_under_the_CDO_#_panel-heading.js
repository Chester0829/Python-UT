// Then_I_should_see_the_rule_that_before_created_should_be_match_the_following_information_under_the_CDO_#_panel-heading.js
// only for Stratification
module.exports = function(){
  this.Then(/^I should see the (only|first|second|last|third|fourth|fifth|sixth) (rule|reinvestments) that before created should be match the following information under the CDO "([^"]*)" panel\-heading$/, function (tableIndex,tableType,panelName, table) {
      // Write code here that turns the phrase above into concrete actions
      const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');

      var rule_item_list = table.hashes();
      var table_tr_length = browser.elements(cashflow_xpath.StratificationTable+"//tbody//tr").value.length;
      console.log(table_tr_length);
      for(var i=0;i<rule_item_list.length;i++){
        var column = rule_item_list[i]['row_item'];
        var value = rule_item_list[i]['value']; 
        var nIndex = 1;
        var targetItem=false;
        // console.log('column: ' + column + ', value: ' + value);
        switch(tableIndex){
          case 'only':
          case 'first':
            nIndex = 1;
          break;
          case 'second':
            nIndex = 2;
          break;
          case 'third':
            nIndex = 3;
          break;
          case 'fourth':
            nIndex = 4;
          break;
          case 'fifth':
            nIndex = 5;
          break;
          case 'sixth':
            nIndex = 6;
          break;
          case 'last':
            nIndex = table_tr_length;
          break;
          default:
          break;
        }
        switch(column){
          case 'table cftable':
           var table_tr = content_xpath.nomarlTable.replace('__NAME__',"table cftable")+"//tr";
           var length = browser.elements(table_tr).value.length;
           for (var i = 0; i < length; i++) {
            var text = browser.getValue("("+table_tr+")["+(i+1)+"]//input");
            console.log("("+table_tr+")["+(i+1)+"]//input");
            console.log(text);
            var itemElement = "("+table_tr+")["+(i+1)+"]//input";
             if (browser.getValue(itemElement) == value) {
              targetItem = true;
              browser.click(itemElement);
             }
         }
          expect(targetItem).toBe(true);
          this.browser_session.waitForResource(browser,table_tr);
          break;
          case 'item.adjustable':
          case 'item.bankLoans':
          case 'item.juniorSenior':
          case 'item.country':
          case 'item.rating':
          case 'assumpCtrl.postReinv.autoReinvEnd':
          case 'assumpCtrl.postReinv.reinvestOverride':
            // var mdSelect = '//md-select[@ng-model="'+ column +'"]';
            var mdSelect = '('+cashflow_xpath.mdSelect.replace('__NAME__',column)+')['+nIndex+']';
            var tmp = browser.isVisible(mdSelect);
            var mdSelectLen = Array.isArray(tmp) ? tmp.length : 1; 
            // console.log('(' + mdSelect +')[' + mdSelectLen + ']');
           if(value == 'disabled'){
            var isDisable = browser.getAttribute('(' + mdSelect +')[' + mdSelectLen + ']','disabled');
            console.log(isDisable);
            expect(isDisable).toEqual(disabled);
          }else{
            expect(browser.getText('(' + mdSelect +')[' + mdSelectLen + ']')).toEqual(value);
          }
            break;

          case 'watch.min2':
          case 'watch.max2':
          case 'watch.type1':
          case 'watch.type2':
          case 'watch.type3':
          case 'watch.prepaytype':
          case 'watch.defaulttype':
          case 'watch.lossType':
            var mdSelect = '('+cashflow_xpath.mdSelect.replace('__NAME__',column)+')';
            var tmp = browser.isVisible(mdSelect);
            var mdSelectLen = Array.isArray(tmp) ? tmp.length : 1; 
            // console.log('(' + mdSelect +')[' + mdSelectLen + ']');
           if(value == 'disabled'){
            var isDisable = browser.getAttribute('(' + mdSelect +')[' + mdSelectLen + ']','disabled');
            console.log(isDisable);
            expect(isDisable).toEqual(disabled);
          }else{
            expect(browser.getText('(' + mdSelect +')[' + mdSelectLen + ']')).toEqual(value);
          }
          break;

          case 'watch.min1':
            // var uiSelectMatch = '('+'//div[@ng-model="'+ column +'"]'+')['+nIndex+']';
            var uiSelectMatch = '//div[@ng-model="'+ column +'"]';
            var tmp = browser.isVisible(uiSelectMatch);
            var uiSelectMatchLen = Array.isArray(tmp) ? tmp.length : 1;
            // console.log('(' + uiSelectMatch + ')[' + uiSelectMatchLen +']');
            expect(browser.getText('(' + uiSelectMatch + ')[' + uiSelectMatchLen +']')).toEqual(value);
            break;
          case 'watch.max1':
          case 'watch.max3':
          case 'watch.min3':
          case 'watch.prepayrate':
          case 'watch.defaultrate':
          case 'watch.lossrate':
          case 'watch.lagmonths':
          case 'watch.defaultDate':
          case 'watch.cccDateIn':
          case 'watch.cccDateOut':
          case 'watch.lossRate':
            // var sfpTextInput = '//sfp-text-input[@ng-model="'+ column +'"]//input';
            var sfpTextInput = '('+cashflow_xpath.sfpTextInput.replace('__NAME__',column) + '//input'+')';
            var tmp = browser.isVisible(sfpTextInput);
            if(!tmp){
              sfpTextInput = '('+'//input[@ng-model="'+ column +'"]'+')';
              tmp = browser.isVisible(sfpTextInput); 
            }
            var sfpTextInputLen = Array.isArray(tmp) ? tmp.length : 1;
            // console.log('(' + sfpTextInput + ')[' + sfpTextInputLen + ']');
            if(column=="item.value1" || column == "item.value2"||column=="item.value3" || column == "item.value4" || column == "item.value5" || column == "item.value6" || column == "item.value7" || column == "item.value8" || column == "item.value9" || column == "item.value10" || column == "item.value11" || column == "item.value12" || column == "item.value13" || column == "item.value14" || column == "item.value15" || column == "item.value16" || column == "item.value17" || column == "item.value18" || column == "item.value19" || column == "item.value20" || column == "item.value21" || column == "item.value22" || column == "item.value23" || column == "item.value24"){
              sfpTextInput = '(//input[@ng-model="item.value"])['+column.substr(10)+']';
              console.log(sfpTextInput);
              tmp = browser.isVisible(sfpTextInput); 
              sfpTextInputLen = 1;
            }
            if(value == 'disabled'){
              var isDisable = browser.getAttribute('(' + sfpTextInput + ')[' + sfpTextInputLen + ']','disabled');
              expect(isDisable).toEqual('true');
            }else{
              expect(browser.getValue('(' + sfpTextInput + ')[' + sfpTextInputLen + ']')).toEqual(value);
            }
            break;

           case 'item.companyName':
          case 'item.term':
          case 'item.coupon':
          case 'item.margin':
          case 'item.recoveryRate':
          case 'item.floor':
          case 'item.price':
          case 'item.mktprice':
          case 'row.months':
          case 'item.value':
          case 'assumpCtrl.postReinv.customDate':
          case 'assumpCtrl.postReinv.period':
          case 'assumpCtrl.postReinv.intraPeriod':
          case 'item.value1':
          case 'item.value2':
          case 'item.value3':
          case 'item.value5':
          case 'item.value6':
          case 'item.value7':
          case 'item.value8':
          case 'item.value9':
          case 'item.value10':
          case 'item.value11':
          case 'item.value12':
          case 'item.value13':
          case 'item.value14':
          case 'item.value15':
          case 'item.value16':
          case 'item.value17':
          case 'item.value18':
          case 'item.value19':
          case 'item.value20':
          case 'item.value21':
          case 'item.value22':
          case 'item.value23':
          case 'item.value24':
            // var sfpTextInput = '//sfp-text-input[@ng-model="'+ column +'"]//input';
            var sfpTextInput = '('+cashflow_xpath.sfpTextInput.replace('__NAME__',column) + '//input'+')['+nIndex+']';
            var tmp = browser.isVisible(sfpTextInput);
            if(!tmp){
              sfpTextInput = '('+'//input[@ng-model="'+ column +'"]'+')['+nIndex+']';
              tmp = browser.isVisible(sfpTextInput); 
            }
            var sfpTextInputLen = Array.isArray(tmp) ? tmp.length : 1;
            // console.log('(' + sfpTextInput + ')[' + sfpTextInputLen + ']');
            if(column=="item.value1" || column == "item.value2"||column=="item.value3" || column == "item.value4" || column == "item.value5" || column == "item.value6" || column == "item.value7" || column == "item.value8" || column == "item.value9" || column == "item.value10" || column == "item.value11" || column == "item.value12" || column == "item.value13" || column == "item.value14" || column == "item.value15" || column == "item.value16" || column == "item.value17" || column == "item.value18" || column == "item.value19" || column == "item.value20" || column == "item.value21" || column == "item.value22" || column == "item.value23" || column == "item.value24"){
              sfpTextInput = '(//input[@ng-model="item.value"])['+column.substr(10)+']';
              console.log(sfpTextInput);
              tmp = browser.isVisible(sfpTextInput); 
              sfpTextInputLen = 1;
            }
            if(value == 'disabled'){
              var isDisable = browser.getAttribute('(' + sfpTextInput + ')[' + sfpTextInputLen + ']','disabled');
              expect(isDisable).toEqual('true');
            }else{
              expect(browser.getValue('(' + sfpTextInput + ')[' + sfpTextInputLen + ']')).toEqual(value);
            }
            break;

          case 'assumpCtrl.postReinv.prepayment':
          case 'assumpCtrl.postReinv.prepayment':
          case 'assumpCtrl.postReinv.scheduled':
          case 'assumpCtrl.postReinv.recoveries':
          case 'assumpCtrl.postReinv.prepayment2':
          case 'assumpCtrl.postReinv.scheduled2':
          case 'assumpCtrl.postReinv.scheduled2':
          case 'assumpCtrl.postReinv.recoveries2':
           var mdCheckBox = '('+cashflow_xpath.mdCheckbox.replace('__NAME__',column)+')['+nIndex+']';
           var checkStatus = browser.getAttribute(mdCheckBox,'aria-checked');
           if(value=='unchecked'){
            expect(checkStatus).toEqual("false");
           }else{
            expect(checkStatus).toEqual("true");
           }
           break;
        }
  
      }


    });

}
