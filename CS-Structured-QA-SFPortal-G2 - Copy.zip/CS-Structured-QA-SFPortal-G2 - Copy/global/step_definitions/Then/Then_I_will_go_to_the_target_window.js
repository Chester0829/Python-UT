// Then I will go to the target window
module.exports = function() {
	this.Then(/^I will go to the target window$/,
	{timeout:process.env.StepTimeoutInMS*5},
	function(){
		browser.switchTab(this.currentWindowHandle);
		this.browser_session.waitForResource(browser);
		// var allWindowHandles = browser.windowHandles()['value'];
		// console.log(browser.windowHandles());
		// console.log(this.currentWindowHandle);
		// console.log('-----------------------');
		// for(var i=0;i<allWindowHandles.length;i++){
		// 	console.log(allWindowHandles[i]);
		// 	if(allWindowHandles[i] != this.currentWindowHandle){
		// 		console.log('******************');
		// 		browser.close(allWindowHandles[i]);
				      	
  //     }
		// }
		
	});
}