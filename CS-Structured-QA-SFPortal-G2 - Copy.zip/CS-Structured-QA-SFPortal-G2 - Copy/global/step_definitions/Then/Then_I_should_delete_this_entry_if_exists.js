// Then_I_should_delete_this_entry_if_exists.js
module.exports = function() {
	this.Then(/^I should delete this entry if "([^"]*)" exists$/, function (name) {
		// Write code here that turns the phrase above into concrete actions
		const screenerPage_xpath = this.xpath_lib.xpathRequire('screenerPage_xpath');
		// cmbs screen
		var root_path = '//*[@table="vm.screenerSavedTable"]//table/tbody';
		var tmp = browser.getText(root_path + '//tr');
		var trList = Array.isArray(tmp) ? tmp : [tmp];
		var deleteIcon = screenerPage_xpath.deleteIcon;
		// delete
		for(var i=0;i<trList.length;i++){
			if(trList[i].indexOf(name) != -1){
				browser.click('(' + deleteIcon + ')[' + (i+1) +']');
				browser.pause(500);
			}
		}



	});
}