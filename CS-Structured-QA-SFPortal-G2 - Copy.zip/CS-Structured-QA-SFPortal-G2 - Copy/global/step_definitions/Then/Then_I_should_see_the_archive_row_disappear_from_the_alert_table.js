module.exports=function(){
  this.Then(/^I should see the archive row disappear from the alert table$/, function () {
         // Write code here that turns the phrase above into concrete actions
         
         console.log(this.archiveRow);
         const portfolioPage_xpath = this.xpath_lib.xpathRequire('portfolioPage_xpath');
         var alertsTableBody=portfolioPage_xpath.alertsTableBody;
         browser.pause(500);

         var alertRows = browser.getText(alertsTableBody);
         expect(alertRows).not.toContain(this.archiveRow);

       });
}