//Recommended filename : Then_I_click_#_tab_and_apply_following_table_to_edit_deal_frame.js
module.exports=function(){
       this.Then(/^I click "([^"]*)" tab and apply following table to edit deal frame$/, function (arg1, table) {
         // Write code here that turns the phrase above into concrete actions
          const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
          var expect_row_list = table.hashes();
          var editTab = cashflow_xpath.editDealFrame + cashflow_xpath.editDealTab.replace('__TAB__',arg1);
          browser.getLocationInView(editTab);
          browser.click(editTab);
          this.browser_session.waitForResource(browser,cashflow_xpath.editDealFrame);
          var table_html = browser.getHTML(cashflow_xpath.editDealTable);
          var editDealTable_json = this.tabletojson.convert(table_html)[0];
          expect_row_list.forEach(function(expect_row){
              if(arg1 == 'Tranches'){
                var trancheName = expect_row.Class;
                var balance_override = cashflow_xpath.editTrancheDealRow.replace('__NAME__',trancheName)+cashflow_xpath.editDealBalance;
                if(expect_row['Balance Override']!=""){
                    browser.setValue(balance_override,expect_row['Balance Override']);
                }
                var coupon_spread = cashflow_xpath.editTrancheDealRow.replace('__NAME__',trancheName)+cashflow_xpath.editDealCouponSpread;
                console.log("expect_row['Coupon/Spread']:"+expect_row['Coupon/Spread']);
                if(expect_row['Coupon/Spread']!=""){
                    browser.setValue(coupon_spread,expect_row['Coupon/Spread']);
                }
              }
              if(arg1 == 'Collateral'){
                var collateral_Index = expect_row.Index;
                var balance_override = "("+cashflow_xpath.editCollateralDealRow+cashflow_xpath.editDealBalance+")["+collateral_Index+"]";
                if(expect_row['Balance Override']!=""){
                  browser.setValue(balance_override,expect_row['Balance Override']);
                } 
                var coupon_spread = "("+cashflow_xpath.editCollateralDealRow+cashflow_xpath.editDealCouponSpread+")["+collateral_Index+"]";
                if(expect_row['Coupon/Spread']!=""){
                  browser.setValue(coupon_spread,expect_row['Coupon/Spread']);
                }
              }
          });
          this.browser_session.waitForResource(browser,cashflow_xpath.editDealFrame);
       });
}