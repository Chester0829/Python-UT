module.exports = function(){
  this.Then(/^I should see a message box show no access to "([^"]*)" page$/, function (linkName) {

    const clickwrap_xpath = this.xpath_lib.xpathRequire('clickwrap_xpath');
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');

    var bannerContain = content_xpath.contentBannerContainer;
    if(linkName != 'manager' && linkName != 'issuer' &&linkName!='OTTI Setting'){
      browser.waitForVisible(bannerContain,this.waitDefault);      
    }    
    browser.pause(1000);
        
    switch(linkName){      
      case 'History':
          var accessName = linkName.toLowerCase();
          break;
      case 'Transactions':
          var accessName = 'Transaction';
          break;
      case 'Benchmarking':
          var accessName = 'Benchmark';
          break;      
      case 'Scenarios':
          var accessName = 'Scenario';
          break;
      case 'OTTI Setting':
          var accessName = 'OTTI';
          break;
      default:          
          var accessName = linkName;
          break;        
    }
    var accessDeniedMesBox = clickwrap_xpath.accessDeniedMessageBox.replace('__TEXT1__',accessName).replace('__TEXT2__',accessName);
    console.log(accessDeniedMesBox);
    browser.waitForVisible(accessDeniedMesBox,this.waitDefault);
    browser.pause(1000);

  }
)};