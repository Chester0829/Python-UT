//Then_I_should_see_data_for_the_folliwng_field_are_all_#_in_#_data_table_under_the_#_panel-heading.js
module.exports = function () {
  this.Then(/^I should see data for the following field are all (different|same) in "([^"]*)" data table under the "([^"]*)" panel\-heading$/, function (compare, tableclass, panelName, table) {
    // Write code here that turns the phrase above into concrete actions
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    var myPanel = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase());
    var row_list = table.hashes();
    var self = this;

    for (var k = 0; k < row_list.length; k++) {
      console.log(row_list.length);
      //the class for table
      if(self.page == "Dynamic CFs New"){
        tableclass = "results-table";
      }
      var fieldRow = content_xpath.filedrow.replace('__TABLE__', tableclass).replace('__FILED__', row_list[k].field);
      var checktext_array = browser.getText(fieldRow + '//td');
      console.log(checktext_array);
      var fieldcount = browser.elements(fieldRow + '//td').value.length;
      console.log(fieldcount);
      for (var i = 2; i <= fieldcount; i++) {
        for (var j = i + 1; j <= fieldcount; j++) {
          var bench_cell = browser.getText(fieldRow + '//td[' + i + ']');
          var compare_cell = browser.getText(fieldRow + '//td[' + j + ']');
          console.log(bench_cell);
          console.log(compare_cell);
          //for the layout is change, all 10 scenarios are dispayed event not check run_flag.
          if (self.page == "Dynamic CFs New" && compare_cell == "")
            continue;
          //use try catch and let this step pass , because now staging side have something wrong. 
          // try{
          if (compare == 'different') {
            expect(bench_cell == compare_cell).toBe(false);
          }
          else if (compare == 'same') {
            expect(bench_cell == compare_cell).toBe(true);
          }
          // }
          // catch(e){
          // }
        }
      }
    }
  });
}