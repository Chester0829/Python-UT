//Then_I_should_see_the_new_charts_are_blank.js
module.exports = function() {
  this.Then(/^I should see the last "([^"]*)" charts are blank$/, function (number) {
         // Write code here that turns the phrase above into concrete actions
          const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
          var fields_box = content_xpath.charts_fields
          var fields_length=browser.elements(fields_box).value.length
          for(var item=fields_length;item>(fields_length-number);item--){
            var fields_element='('+fields_box+')['+item+']/span';
            console.log(fields_element)
            expect(browser.isExisting(fields_element)).toBe(false)
          }

        
       })
};
 