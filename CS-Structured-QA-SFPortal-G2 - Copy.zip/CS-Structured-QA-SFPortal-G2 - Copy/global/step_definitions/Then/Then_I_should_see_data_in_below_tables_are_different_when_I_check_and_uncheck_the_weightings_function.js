module.exports=function(){
  this.Then(/^I should see data in below tables are different when I check and uncheck the weightings function$/, function (table) {
         // Write code here that turns the phrase above into concrete actions
         const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
         var ptCheckbox = content_xpath.modeCheckbox.replace('__NAME__','ptFlag');
         var weightingsCheckbox = content_xpath.modeCheckbox.replace('__NAME__','isOwnNotional');
         var applyButton = content_xpath.applyButton;

         var customize = "//a[contains(text(),'Customize')]";
         if(!browser.isVisible(content_xpath.customizeDropDown)){
            browser.waitForVisible(customize,this.waitDefault);
            browser.click(customize);
            browser.waitForVisible(content_xpath.customizeDropDown,this.waitMax);
         }
         var ptAttribute = browser.getAttribute(ptCheckbox,'class');
         var weightingsAttribute = browser.getAttribute(weightingsCheckbox,'class');         
         if(ptAttribute.indexOf('ng-empty')!=-1){
           browser.click(ptCheckbox);
         }
         if(weightingsAttribute.indexOf('ng-empty')!=-1){
           browser.click(weightingsCheckbox);
         }
         browser.pause(50);
         browser.click(applyButton);
         this.browser_session.waitForLoading(browser);

         var self=this;

         var expect_list = table.hashes();
         console.log(expect_list);

         var getTableData = function(tableList){
           var tableData = new Object();
           tableList.forEach(function(list_row){
             var myTable;
             if(list_row['widget']=='Concentration Report Chart Builder'){
               var mySelectCaret_xpath = '('+content_xpath.titledPanel.replace('__TITLE__',list_row['widget']) + '//span[@class="md-select-icon"])[1]';
               var select_item = content_xpath.namedSelectItem.replace('__NAME__', list_row['metric']);
               browser.click(mySelectCaret_xpath);
               browser.waitForVisible(select_item,self.waitDefault);
               browser.click(select_item);
               browser.pause(10*1000);
               myTable = content_xpath.titledPanel.replace('__TITLE__',list_row['widget']) + '//a';
               var tableContent = browser.getText(myTable);
               tableData[list_row['widget']+'/'+list_row['metric']]= tableContent;  
             }else{
               myTable = content_xpath.titledPanel.replace('__TITLE__',list_row['widget']) + '//tbody'; 
               var tableContent = browser.getText(myTable);
               tableData[list_row['widget']]= tableContent;              
             }             
           });
           return tableData;
         }

         var excludeWeightingsData = getTableData(expect_list);         
         // console.log(excludeWeightingsData);

         browser.click(weightingsCheckbox);
         browser.pause(50);
         browser.click(applyButton);
         this.browser_session.waitForLoading(browser);

         browser.refresh();
         this.browser_session.waitForResource(browser);
         this.browser_session.waitForLoading(browser);
         browser.waitForVisible(customize,this.waitDefault);
         browser.click(customize);
         browser.waitForVisible(content_xpath.customizeDropDown,this.waitMax);
         weightingsAttribute = browser.getAttribute(weightingsCheckbox,'class');
         if(weightingsAttribute.indexOf('ng-not-empty')!=-1){
           browser.click(weightingsCheckbox);
           browser.pause(50);
           browser.click(applyButton);
           this.browser_session.waitForLoading(browser);
         }                  

         var weightingsData = getTableData(expect_list);         
         // console.log(weightingsData);

         // expect_list.forEach(function(list_row){
         //   console.log('widget------------>',list_row['widget']);
         //   console.log('excludeWeightingsData------------>',excludeWeightingsData[list_row['widget']]);
         //   console.log('weightingsData------------>',weightingsData[list_row['widget']]);
         //   expect(excludeWeightingsData[list_row['widget']]).not.toEqual(weightingsData[list_row['widget']]);
         // });

         for(var dataKey in excludeWeightingsData){
           console.log(dataKey);
           console.log('excludeWeightingsData---------->',excludeWeightingsData[dataKey]);
           console.log('weightingsData---------->',weightingsData[dataKey]);
           expect(excludeWeightingsData[dataKey]).not.toEqual(weightingsData[dataKey]); 
         }

       });
}