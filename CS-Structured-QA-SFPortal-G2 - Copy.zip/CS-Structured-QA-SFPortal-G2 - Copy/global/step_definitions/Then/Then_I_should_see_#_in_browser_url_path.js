// Recommended filename: Then_I_should_see_the_url_path_to_include_#.js
module.exports = function() {
  this.Then(/^I should see the url path to include "([^"]*)"$/, function (urlPath) {
    expect(browser.getUrl()).toContain(urlPath);
  });
};
