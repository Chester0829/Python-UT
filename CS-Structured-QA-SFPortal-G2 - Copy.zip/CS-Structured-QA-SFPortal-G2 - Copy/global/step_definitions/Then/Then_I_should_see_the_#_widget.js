// Recommended filename: Then_I_should_see_#_widget.js
module.exports = function() {
  this.Then(/^I should see the "([^"]*)" widget$/, function (widgetName) {
    // Write the automation code here
    // pending();
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    
    this.browser_session.waitForResource(browser);
    // this.browser_session.waitForLoading(browser);

    if(widgetName == 'Trade History'){
        var enableButton_xpath = content_xpath.namedButton.replace('__NAME__', 'Enable Trade Tracking');
        var disableButton_xpath = content_xpath.namedButton.replace('__NAME__', 'Disable Trade Tracking');
        if(browser.isVisible(enableButton_xpath)){
            browser.click(enableButton_xpath);
            browser.waitForVisible(disableButton_xpath,this.waitMax);
        }
    }
    // if(widgetName == 'Assumptions'){
    //   // record feature's assumptions for CLO Deal Cashflow
    //   this.assumptionsList = [];
    // }
    if (widgetName == 'Customized Filter' || widgetName == 'Comparables'){
        var widget_xpath = content_xpath.sfp_cardWidget.replace('__WIDGETNAME__', widgetName);
    }else{
        var widget_xpath = content_xpath.widget_panel.replace('__WIDGETNAME__', widgetName);
    }

    browser.waitForVisible(widget_xpath,this.waitMax);
    // this.browser_session.waitForResource(browser); 
  });
};
