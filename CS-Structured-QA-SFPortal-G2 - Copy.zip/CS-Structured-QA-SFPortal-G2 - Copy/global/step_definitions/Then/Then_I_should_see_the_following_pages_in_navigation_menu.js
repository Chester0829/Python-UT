//Then_I_should_see_the_following_pages_in_navigation_menu.js
module.exports = function(){
 this.Then(/^I should see the following pages in navigation menu$/, function (table) {
         // Write code here that turns the phrase above into concrete actions
  const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
  this.browser_session.waitForResource(browser);
  this.browser_session.waitForLoading(browser);
  var row_list = table.hashes();
  var menuIcon = content_xpath.mainMenu;

  for(var i = 0; i<row_list.length; i++){
    var menu = menuIcon.replace('__NAV__', row_list[i].name);
    console.log(menu);
    browser.waitForVisible(menu,this.waitDefault);
    if(row_list[i].name == 'Home'){
      expect(browser.waitForVisible(menu,this.waitDefault)).toBe(true);
    }
    else if(row_list[i].name == 'Menu'){
      browser.click(menu);
      var pageName = content_xpath.pagesInMenu.replace('__CATEGORY__', row_list[i].category).replace('__PAGENAME__', row_list[i].pages);
      console.log(pageName);
      var tmp = browser.getText(pageName);
      console.log(tmp);
      var linkText = Array.isArray(tmp) ? tmp[0].trim() : tmp.trim();
      expect(linkText).toEqual(row_list[i].pages);
      expect(browser.waitForVisible(pageName,this.waitDefault)).toBe(true);

      // expect the number is the same
      var elements = browser.elements('//md-card[contains(@class, "main-menu")]//ul//li//a')['value'];
      console.log(elements.length);
      console.log(row_list.length);
      expect(elements.length).toEqual(row_list.length);
    }  
  }
 });
};