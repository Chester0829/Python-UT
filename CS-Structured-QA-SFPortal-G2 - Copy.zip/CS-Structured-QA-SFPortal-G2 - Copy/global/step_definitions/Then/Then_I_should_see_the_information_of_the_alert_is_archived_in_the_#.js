//Then_I_should_see_below_text_notes_under_the_#_panel-heading.js
module.exports = function() {
	this.Then(/^I should see the information of the alert is archived in the (Journal|Journal Comment)$/, function (targetPosition) {
		// Write code here that turns the phrase above into concrete actions
		var archiveArray = this.archiveArray;
		const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
		var journalPanel = content_xpath.titledPanel.replace('__TITLE__','Journal');

		switch(targetPosition){
			case 'Journal':
			  browser.pause(2000);				
				var notesXpath = '(' + journalPanel + '//journal-entries//span[contains(@ng-bind-html,"journal.data")]/div)[1]';
				break;
			case 'Journal Comment':
			  browser.pause(1000);
			  var notesXpath = journalPanel + '//trix-editor';
			  break;
		}
		var tmp = browser.getText(notesXpath);
		var textNotes = Array.isArray(tmp) ? tmp.join() : tmp;
		console.log(textNotes);
		
		for(var i in archiveArray){
			try{
				console.log(i);
				console.log(archiveArray[i]);
				if(archiveArray[i]=='-'){
					archiveArray[i]='';
				}
				var archiveItem = i + ": " +archiveArray[i];								
				expect(textNotes).toContain(archiveItem);
				console.log(archiveItem);
			}catch(e){
				if(archiveArray[i]=='-'){
					archiveArray[i]='';
				}
				var archiveItem = i + ":" +archiveArray[i];
			  expect(textNotes).toContain(archiveItem);
			  console.log(archiveItem);
			}			
		}
		if(targetPosition=='Journal'){
			browser.waitForVisible('//*[contains(., "Archived Successfully")]', this.waitDefault);
		}		

	});

}