//Then_I_should_see_the_export_#_file_content_the_same_as_UI.js
module.exports = function() {
       this.Then(/^I should see the export "([^"]*)" file content the same as UI$/, {timeout: 600*1000},function (arg1) {
         // Write code here that turns the phrase above into concrete actions
        const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
        const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
        // const path = require('path');
        // const fs = require('fs');
        var editDealTable = cashflow_xpath.editDealTable;
        console.log(this.file_target_data[0].length);
        var uicount = this.browser_session.getAnormalTableRowCount(browser,editDealTable,true);
        expect(uicount).toEqual(this.file_target_data[0].length);
        var self = this;
        var readRowCount;
        if(self.file_target_data[0].length<=10){
          readRowCount=self.file_target_data[0].length;
        }
        else{
          readRowCount=10;
        }
        for(var i =0;i<readRowCount;i++){
          var expect_row = self.file_target_data[0][i].replace(/"/g,'').replace(/,/g,'').replace(/  /g,' ');
          console.log(expect_row);
          var UI_row = self.browser_session.getAnormalTableRowText(browser,editDealTable,i+1,',',true).replace(/,/g,''); 
          console.log(UI_row);
          expect(UI_row).toEqual(expect_row);
        }
       });
}