//Recommended filename : Then_I_get_the_support's_settles_date_from_edit_deal_frame_note.js
module.exports = function() {
       this.Then(/^I get the support's settles date from edit deal frame note$/, function () {
         // Write code here that turns the phrase above into concrete actions
         const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
         browser.getLocationInView(cashflow_xpath.editDealNote);
         var noteText = browser.getText(cashflow_xpath.editDealNote);
         console.log(noteText);
         var dateReg = /\d{4}-\d{2}-\d{2}/;
         var dateIndex = noteText.search(dateReg);
         console.log(dateIndex);
         this.settleDate = noteText.substr(dateIndex,10);
         console.log(this.settleDate);
       });
}; 