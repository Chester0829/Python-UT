// Recommended filename: Then_I_should_not_see_any_of_these_keywords_in_the_page_content.js
module.exports = function() {
  this.Then(/^I should not see the "([^"]*)" table data$/, function (widgetName) {
    // Write the automation code here
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);

    var widget_tabelData = content_xpath.titled_Panel_Table.replace('__NAME__', widgetName);
    expect(this.browser_session.elementSomeVisible(browser,widget_tabelData)).toBe(false);
  }
)};
