  //Then_I_apply_following_table_to_export_#_file.js  
  module.exports = function() {
       this.Then(/^I apply following table to export "([^"]*)" file$/, function (arg1, table) {
         // Write code here that turns the phrase above into concrete actions
         return 'pending';
       });
}