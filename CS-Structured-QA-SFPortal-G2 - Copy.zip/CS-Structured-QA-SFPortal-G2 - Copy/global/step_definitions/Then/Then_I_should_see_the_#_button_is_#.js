module.exports = function() {
  this.Then(/^I should see the "([^"]*)" button is (disabled|enabled)$/,
   function (buttonName,btnStatus) {
    // Write the automation code here
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const clickwrap_xpath = this.xpath_lib.xpathRequire('clickwrap_xpath'); 
    var button_xpath='//button[contains(.,"__NAME__") and contains(@disabled,"disabled")]';

    if (btnStatus == 'disabled') {
      if(buttonName == 'Home'){
          expect(browser.isVisible(clickwrap_xpath.homeDisabled)).toEqual(true);          
      }else{
          expect(browser.isVisible(button_xpath.replace('__NAME__',buttonName))).toEqual(true);
      }
    }
    
   }
)};