  // Recommended filename: When_I_apply_the_portfolio_cashflow_assumptions_of_the_following_table_to_the_first_#_tranche_and_run_cashflow.js
  module.exports = function() {
    this.When(/^I apply the portfolio cashflow assumptions of the following table to the first (.*) tranches and (run|not run) cashflow$/, {timeout: 300*1000}, function (batchSize,action,table) {
      // Write the automation code here
      var assumption_list = table.hashes();
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
      // var cashflow_div = '//div[@id="cashflows"]';
      var settings_div = content_xpath.settingPanel;
      var assumption_div = content_xpath.assumptionsPanel; 
      var run_cashflow_button = cashflow_xpath.cashflowButton;
      var cash_assetClasses = content_xpath.tabList1.replace('__TYPE__','cash.assetClassTypes');
      const dateFormat = require('dateformat');
      console.log(cash_assetClasses);
      //browser.waitForVisible(cash_assetClasses,this.waitDefault);
      this.browser_session.waitForLoading(browser);
      this.browser_session.waitForResource(browser,cash_assetClasses);
      if(browser.isVisible(cash_assetClasses)==false)
      {
        cash_assetClasses = content_xpath.tabList.replace('__TYPE__','cash.assetClassTypes');
      }
      var numOf_assetClasses = browser.elements(cash_assetClasses).value.length;
      var cash_assetClassTabs = [];
      var assetClasee_table;
      var set_size;
      var set_offset;
      var portfolio_output;
      var benchmark;
      var self = this;
      this.isCustom = "MR";
      this.portfolio_fistloss_type='';

      // filed cash_assetClassTabs array from page
      for (var i=0; i<numOf_assetClasses; i++){
        var tab = {};
        tab.selector = '('+cash_assetClasses+')['+(i+1)+']';
        tab.text = browser.getText(tab.selector).split(' ');
        tab.name = tab.text[0];
        tab.itemCount = Number(tab.text[1].replace(/[{()}]/g, ''));
        cash_assetClassTabs[i] = tab;
        console.log('tab.itemCount:'+tab.itemCount);
      }
      cash_assetClassTabs.forEach(function(tab) {
        if (tab.name === 'All') {
          set_size = parseInt(tab.itemCount);
          console.log('set_size：'+set_size);
        }
      });
      //this.browser_session.waitForResource(browser,cashflow_xpath.dealCfsAssumptions);
      //browser.getLocationInView(content_xpath.assumptionsContent);
      // console.log(assumption_list);
      
      ////////API to get dealist////////////////
      // var license = this.api_session.getLicense(this.test_user);
      // var fxRates = this.api_session.getFxRates(license);
      // console.log('-----');
      // console.log(fxRates);
      // var portfolio_id = this.api_session.getPortfolioInfo(this.portfolio, license).portfolioId;
      // var dealList = this.api_session.getDealList(portfolio_id,license,fxRates);
      assumption_list.forEach(function(list_row) {
      console.log(list_row['name']);
      switch (list_row['name']) {
          case "cash.output_type":
            portfolio_output = list_row['value'];
            self.portfolio_output = portfolio_output;
            var selectPicker_select = content_xpath.selectPicker.replace('__SELECTNAME__','Output Type');
            browser.click(selectPicker_select);
            if (browser.isVisible(content_xpath.selectBox2)) {
              browser.click(content_xpath.selectOption.replace('__OPTION__',list_row['value']));
            }
            browser.pause(1000);
            break;
          case "cash.settles_date":
            var settleDateInput = cashflow_xpath.cashflowPortfolioInput.replace('__NAME__',list_row['name']);
            console.log(settleDateInput);
            //browser.click(selectPicker_select);
            if (list_row['value'] == 'current date' || list_row['value']=='Current Date') {
              browser.click(settleDateInput);
              var today = cashflow_xpath.settleDateToday;
              browser.click(today);
              console.log(browser.getValue(settleDateInput));
              console.log(browser.getValue(settleDateInput));
              var date = browser.getValue(settleDateInput);
              date = date.replace(/-/g,'/');
              var date = new Date(date);
              date.setDate(date.getDate() - 2);
              var new_date = dateFormat(date,"yyyy-mm-dd");
              var portfolio_date= new_date.split('-')[1]+'/'+ new_date.split('-')[2]+'/' + new_date.split('-')[0];
              console.log(portfolio_date);
              browser.setValue(settleDateInput,portfolio_date);
              console.log("has set " + list_row['name'] + " to " + portfolio_date);
              self.isCurrentdate = true;
            }else{
              browser.setValue(settleDateInput, list_row['value']); 
              self.isCurrentdate = false;           
            }  
            break;          
          case "cash.cashflowOutputType":
             var selectPicker_select = content_xpath.selectPicker.replace('__SELECTNAME__','Cashflow Output')
            browser.click(selectPicker_select)
            if (browser.isVisible(content_xpath.selectBox2)) {
              if(list_row['value']=='ENV_OUTPUT'){
               var cfs_output_type = process.env.output_type
               if (cfs_output_type==undefined) {
                cfs_output_type="Monthly"; 
              }
              if (cfs_output_type == 'Payment'){
                cfs_output_type = 'Payment Dates'
              }
              console.log('Cashflow output type:',cfs_output_type);
              browser.click(content_xpath.selectOption.replace('__OPTION__',cfs_output_type));
              }else{
                browser.click(content_xpath.selectOption.replace('__OPTION__',list_row['value']));
              }
            }
            browser.pause(500);
            break;
          case "cash.selectedAssetClass":
            // base on tab name set table and offset
            self.selectedAssetClass = list_row['value'];
            // switch (list_row['value']) {
            //   case "All":
            //   assetClasee_table = '//div[contains(@*, "cash")]//table[contains(., "U.S.")]';
            //   set_offset = 0;
            //   break;
            //   case "ABS":
            //   assetClasee_table = '//div[contains(@*, "cash")]//table[contains(., "U.S. Floorplans ABS")]';
            //   set_offset = 0;
            //   break;
            //   case "CARDS":
            //   assetClasee_table = '//div[contains(@*, "cash")]//table[contains(., "U.S. ABS - Credit Cards")]';
            //   set_offset = 0;
            //   break;
            //   case "CDO":
            //   assetClasee_table = '//div[contains(@*, "cash")]//table[contains(., "U.S. CLO")]';
            //   set_offset = 0;
            //   break;
            // }
            // click the tab
              // var target_item = cash_assetClasses + content_xpath.namedDescendantTab.replace('__NAME__',list_row['value']);
              var target_item = cash_assetClasses + cashflow_xpath.cfnamedDescendantTab.replace('__NAME__',list_row['value']);
              console.log(target_item);
              browser.waitForVisible(target_item,self.waitDefault);
              browser.click(target_item);
              // browser.waitForVisible(assetClasee_table,self.waitDefault);
              // self.browser_session.waitForResource(browser,assetClasee_table);
              break;
          case "cash.apply_watch":
            var check_box = cashflow_xpath.mdCheckbox.replace('__NAME__',list_row['name']);
            //var target_item = check_box + '//div[@class="md-icon"]'
            var target_attribute = browser.getAttribute(check_box, 'class');
            if ((list_row['value']=='checked' && target_attribute.indexOf('ng-empty') > -1) || (list_row['value']=='unchecked' && target_attribute.indexOf('ng-not-empty') > -1)){
                  console.log(check_box);
                  browser.click(check_box);
                  browser.pause(100);
                 }  
            break;
          case "cash.isCustomRates":
            var check_box = cashflow_xpath.mdCheckbox.replace('__NAME__',list_row['name']);
            //var target_item = check_box + '//div[@class="md-icon"]'
            var target_attribute = browser.getAttribute(check_box, 'class');
            if ((list_row['value']=='checked' && target_attribute.indexOf('ng-empty') > -1) || (list_row['value']=='unchecked' && target_attribute.indexOf('ng-not-empty') > -1)){
                  console.log(check_box);
                  browser.click(check_box);
                  browser.pause(100);
            } 
            if(list_row['value']=='checked'){
              self.isCustom = "CR";              
            }else{
              self.isCustom = "MR";
            }
            break;
          case "tranche.run_flag":
            var run_flag = assumption_div + cashflow_xpath.cashflow_runflag;
            self.browser_session.clickNoWhere(browser);
            if (list_row['value'] == 'checked') {
              if(batchSize == 'all'){
                browser.click('//*[@ng-click="cash.selectAllTranches()"]');
                console.log('all set_size:'+set_size);
                self.set_size = set_size;
                console.log(self.set_size);
              }else{
                console.log(set_size);
                console.log(batchSize);
              // if(set_size=='undefined'){set_size=batchSize}
                // var portfolioSearch = cashflow_xpath.portfolioSearchButton;
                  for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
                // for (var j = 1; j <= Math.min(set_size, batchSize); j++) {
                //   var dealname = dealNameList[j];
                //   console.log('dealname : ' + dealname);
                //   browser.setValue(portfolioSearch,dealname);
                //   var tr_number = assumption_div + '//table//tbody//tr';
                //   var tr_length = browser.elements.value.length;
                //   console.log(tr_length);
                  // for (var i =1; i<=tr_length ; i++){
                    var target_item = '(' + run_flag + ')[' + (i) + ']';
                    var target_attribute = browser.getAttribute(target_item, 'class');  
                    while (target_attribute.indexOf('ng-empty') > -1) {
                     // only exit when target is not empty
                     browser.waitForVisible(target_item,self.waitDefault);
                     browser.click(target_item);
                     browser.pause(100);
                     target_attribute = browser.getAttribute(target_item, 'class');
                  } 

                  }          
                // }
              }
            }else {
              if(batchSize == 'none'){
                browser.click('//*[@ng-click="cash.selectNoneTranche()"]');
              }else{
                for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
                  //  var dealname = dealNameList[j];
                  // console.log('dealname : ' + dealname);
                  // browser.setValue(portfolioSearch,dealname);
                  // var tr_number = assumption_div + '//table//tbody//tr';
                  // var tr_length = browser.elements.value.length;
                  // console.log(tr_length);
                  // for (var i =1; i<=tr_length ; i++){
                var target_item = '(' + run_flag + ')[' + (set_offset + i) + ']';
                var target_attribute = browser.getAttribute(target_item, 'class');
                while (target_attribute.indexOf('ng-not-empty') > -1) {
                  // only exit when target is empty
                  browser.click(target_item);
                  browser.pause(100);
                  target_attribute = browser.getAttribute(target_item, 'class');
                }
                }           
               // }
              }
            }
            break; 
          case "tranche.seed_default":
          case "tranche.ignore_input_nonpayment_term":
          case "tranche.calc_curve_off_static_bal":
          case "tranche.term_triggers_activate_LTV_trigger":
          case "tranche.term_triggers_activate_DSCR_trigger":
          case "tranche.maturity_trigger_activate_LTV_trigger":
          case "tranche.maturity_trigger_activate_DY_trigger":
            var target_set = assumption_div + content_xpath.inputoption.replace('__NAME__',list_row['name']);
            console.log(target_set);
            for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
              var target_item = '(' + target_set + ')[' + i + ']';
              console.log(target_item);
              var target_attribute = browser.getAttribute(target_item, 'class');
              console.log(target_attribute);
              if ((list_row['value']=='checked' && target_attribute.indexOf('ng-empty') > -1) || (list_row['value']=='unchecked' && target_attribute.indexOf('ng-not-empty') > -1)){
                console.log(target_item);
                browser.click(target_item);
                browser.pause(100);
               } 
               // else {
               //  //var target_item = '(' + target_set + ')[' + (set_offset + i) + ']';
               //  while (target_attribute.indexOf('ng-not-empty') > -1) {
               //    // only exit when target is empty
               //    browser.click(target_item);
               //    browser.pause(100);
               //    //target_attribute = browser.getAttribute(target_item, 'class');
               //  }           
              // } 
            }
            break;   
          case "tranche.repay_rate":
          case "tranche.price":
          case "tranche.loss_rate":
          case "tranche.purchase_rate":
          case "tranche.portfolio_yield_rate":
          case "tranche.prepay_rate":
          case "tranche.buy_price":
          case "tranche.buy_date":
          case "tranche.default_rate":
          case "tranche.price":
          case "tranche.prinLossSeverityPctNonPerf":
          case "tranche.rec_lag":
          case "tranche.reinvDefaultLockout":
          case "tranche.reinvest_spread":
          case "tranche.reinvest_term":
          case "tranche.call_date":
          case "tranche.call_price":
          case "tranche.alloc_mon":
          case "tranche.call_date":
          case "tranche.delinquency_rate":
          case "tranche.adv_loss_rate":
          case "tranche.adv_lag_mon":
          case "tranche.portfolio_loss_rate":
          case "tranche.deferment_rate":
          case "tranche.grace_rate":
          case "tranche.forbear_rate":
          case "tranche.subsidy_payment_delay":
          case "tranche.SAP_payment_delay":
          case "tranche.BB_utilization_rate":
          case "tranche.NOI_growth_rate":
          case "tranche.plus_minus_months":
          case "tranche.cap_rate_growth_rate":
          case "tranche.term_triggers_LTV_liquidate":
          case "tranche.term_triggers_LTV_months":
          case "tranche.term_triggers_LTV_loss":
          case "tranche.term_triggers_DSCR_liquidate":
          case "tranche.term_triggers_DSCR_months":
          case "tranche.term_triggers_DSCR_loss":
          case "tranche.maturity_trigger_LTV_payoff":
          case "tranche.maturity_trigger_LTV_liquidate":
          case "tranche.maturity_trigger_LTV_loss":
          case "tranche.maturity_trigger_LTV_extension":
          case "tranche.maturity_trigger_LTV_end_of_extension_liq_or_payoff":
          case "tranche.maturity_trigger_LTV_end_of_extension_loss":
          case "tranche.maturity_trigger_DY_payoff":
          case "tranche.maturity_trigger_DY_liquidate":
          case "tranche.maturity_trigger_DY_loss":
          case "tranche.maturity_trigger_DY_extension":
          case "tranche.maturity_trigger_DY_end_of_extension_liq_or_payoff":
          case "tranche.maturity_trigger_DY_end_of_extension_loss":
          case "tranche.servicer_rate":
            var target_set = assumption_div + content_xpath.inputoption.replace('__NAME__',list_row['name']);
            console.log(target_set);
            for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
              var target_item = '(' + target_set + ')[' + i + ']';
              console.log(target_item);
              browser.setValue(target_item, list_row['value']);
            }
            break;
          case "tranche.yield_pct":
          case "tranche.dm":
            var target_set = assumption_div + content_xpath.inputoption.replace('__NAME__',list_row['name']);
            console.log(target_set);
            for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
              var target_item = '(' + target_set + ')[' + i + ']';
              console.log(target_item);
              var target_attribute = browser.getAttribute(target_item, 'disabled');
              console.log(target_attribute);
              if(target_attribute == null){
                browser.setValue(target_item, list_row['value']);
              }  
            }
            break;
          case "tranche.solve_for":
          case "tranche.benchmark":
          case "tranche.repay_type":
          case "tranche.purchase_type":
          case "tranche.portfolio_yield_type":
          case "tranche.prepay_type":
          // case "tranche.first_loss_threshold":
          case "tranche.default_type":
          case "tranche.loss_type":
          case "tranche.reinvest_price_type":
          case "tranche.reinvest_pool":
          case "tranche.reinvest_rules":
          case "tranche.first_loss_threshold":
          case "tranche.call_price_type":
          case "tranche.call_option":
          case "tranche.force_call":
          case "tranche.delinquency_type":
          case "tranche.portfolio_loss_type":
          case "tranche.deferment_type":
          case "tranche.grace_type":
          case "tranche.forbear_type":
          case "tranche.interest_cap_freq":
          case "tranche.NOI_growth_rate_type":
          case "tranche.cap_rate_growth_rate_type":
          case "tranche.term_triggers_select_priority":
          case "tranche.maturity_trigger_select_priority":
          case "tranche.servicer_basis":
          case "tranche.servicer_type":
            if (list_row['name']=='tranche.benchmark' && process.env.NODE_ENV.indexOf('SPS')==-1){
               list_row['value']=list_row['value'].replace('TSY','LIBOR');
            }
            if (list_row['name']=='tranche.benchmark' && process.env.NODE_ENV.indexOf('SPS')>-1){
               list_row['value']=list_row['value'].replace('LIBOR','TSY');
            }
            if (list_row['name']=='tranche.benchmark'){
              if(list_row['value'].indexOf('LIBOR')>-1){
                console.log("this.benchmark1");
                benchmark = list_row['value'].replace('LIBOR','Tsy');
              }
              else{
                console.log("this.benchmark2");
                benchmark = list_row['value'].replace('TSY','Tsy');
              } 
            }
            var target_set = assumption_div + cashflow_xpath.selectButton.replace('__NAME__',list_row['name']);
            for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
              var target_item = '(' + target_set + ')[' + i + ']';
              console.log(target_item);
              console.log(list_row['value']);
              browser.waitForVisible(target_item,self.waitDefault);
              browser.selectByVisibleText(target_item,list_row['value']);
              console.log(browser.getText(target_item));
            }
            if(list_row['name']=='tranche.first_loss_threshold'){
              self.portfolio_fistloss_type=list_row['value']
            }
              // var target_set = assumption_div + cashflow_xpath.sfpSelectOption.replace('__NAME__',list_row['name']);
              // for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
              //   var target_item = '(' + target_set + ')[' + i + ']';
              //   console.log(target_item);
              //   console.log(list_row['value']);
              //   browser.click(target_item);
              //   browser.waitForVisible(assumption_div + cashflow_xpath.cfsfpSelDropDown.replace('__NAME__',list_row['name']),self.waitDefault);
              //   browser.click(assumption_div +cashflow_xpath.cfsfpDropSelItem.replace('__NAME__',list_row['name']).replace('__ITEM__',list_row['value']));
              //   browser.getText(target_item);
              //   console.log(browser.getText(target_item));
              // }
             break;
          }
        });
      if(action == 'run'){
        browser.click(run_cashflow_button);
        browser.pause(1000);  
      }
      this.batchSize = batchSize;
      this.set_size = set_size;      
      this.benchmark = benchmark;
      console.log(this.benchmark);
    });
  };
 