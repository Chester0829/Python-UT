// Recommended filename: When_I_download_#_file_under_the_performance_charts_widget_by_click_the_#_icon_in_performance_page_in_#_mode.js
// only for performance charts page
module.exports = function() {
	this.When(/^I download "([^"]*)" file under the performance charts widget by click the "([^"]*)" icon in performance page in (portfolio|manager|deal) mode$/, 
	{timeout: process.env.StepTimeoutInMS*9},
	function (fileType, downloadButton, mode) {
    // Write code here that turns the phrase above into concrete actions
    // return 'pending';
  	this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    //this.browser_session.waitForRender(browser);
  	const performancePage_xpath = this.xpath_lib.xpathRequire('performancePage_xpath');
  	var chartTtile = this.xpath_lib.xpathRequire('chartTitle');
  	var today = this.time_lib.getTime();
    var fs = require('fs');
   //  var moment = require('moment');
  	// var today = moment().local().format('DD-MMM-YYYY');

  	var downloadIcon = performancePage_xpath.downloadIcon;
  	// var fileTextIcon = performancePage_xpath.fileTextIcon.replace('__FILETYPE__',fileType.toUpperCase());
    var fileTextIcon = performancePage_xpath.fileTextIcon.replace('__FILETYPE__',fileType.toLowerCase());

  	browser.waitForVisible(downloadIcon,120*1000);
  	// console.log(browser.elements(downloadIcon).value);
  	var downloadValueList = browser.elements(downloadIcon).value;
  	// var fileTextIconList = browser.elements(downloadIcon + '/following-sibling::*' + fileTextIcon).value;

  	var chartTitleList = chartTtile[mode];
  	var widgetName = 'Performance';
    if (this.deal == 'Dell Equipment Finance Trust 2016-1'||this.deal == 'Flexi ABS Trust 2017-1'||this.deal == 'Ford Credit Auto Owner Trust 2015-C'||this.deal == 'Driver thirteen UG (haftungsbeschraenkt)'||this.deal == 'American Express Credit Account Master Trust, Series 2017-2'||this.deal == 'Penarth Master Issuer plc'||this.deal == 'Navient Student Loan Trust 2014-1'||this.deal == 'SLM Student Loan Trust 2004-8'){
      widgetName = 'ABS Performance Report';
    }
    if(this.deal == 'Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1' || this.deal == 'MADRID RMBS IV, FTA'){
      widgetName = 'RMBS Performance Report';
    }
		if(chartTitleList[widgetName] != undefined){
			var titleTextInCsv = ('title' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['title'] : widgetName;
			var offsetX = ('offsetX' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetX']: 0;
			var offsetY = ('offsetY' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetY']: 0;
      var fileFirstKey = ('fileFirstKey' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['fileFirstKey']: '';
			var separator = ('separator' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['separator']: '';
			// var flag = true;
		}else{
			// var flag = false;
			var offsetX = 0;
			var offsetY = 0;
			var titleTextInCsv = undefined;
			var separator = '';
      var fileFirstKey = '';
		}
		console.log(titleTextInCsv);
		console.log(offsetX);
		console.log(offsetY);
    console.log(separator);
    console.log(fileFirstKey);
    this.fileFirstKey = fileFirstKey; // for compare data

    if(this.deal == "Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1" || this.deal == "Wachovia Bank Commercial Mortgage Trust 2007-C32" || this.deal == "MADRID RMBS IV, FTA"){
      // get X/T labels
      var xLabels = browser.getText(performancePage_xpath.xLabel);
      // (//*[@class="highcharts-axis-labels highcharts-xaxis-labels "])[1]/following-sibling::*[1]
      // var yLabels = browser.getText(performancePage_xpath.yLabel);
      var tooltip = performancePage_xpath.tooltip; 
      console.log(xLabels); 
      console.log(tooltip);
    }
  	// Portfolio-CLO-for-automation - Historical1- Historical_11-May-2018.csv
  	switch(mode){
  		case 'portfolio':
  			var filename = this.portfolio + ' - Historical__INDEX__- Historical_' + today + '.' + fileType.toLowerCase();
  			break;
  		case 'manager':
        // GSO _ Blackstone Debt Funds Management - HistoricalChart1- HistoricalChart_20-Jun-2018.csv
  			// var filename = this.manager.replace('/','_') + ' - Historical__INDEX__- Historical_' + today + '.' + fileType.toLowerCase();
        var filename = this.manager.replace('/','_') + ' - HistoricalChart__INDEX__- HistoricalChart_' + today + '.' + fileType.toLowerCase();
  			break;
  		case 'deal':
        var filename = this.deal.replace('/','_') + ' - HistoricalChart__INDEX__- HistoricalChart_' + today + '.' + fileType.toLowerCase();
  			break;
  	}
  	var filenameList = [];
  	var fileContentList = [];
  	var uiValues = [];
    // download file
  	for(var i=0;i < downloadValueList.length;i++){
      var index = i + 1;

      if( fileType == 'CSV' && (this.deal == "Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1" || this.deal == "Wachovia Bank Commercial Mortgage Trust 2007-C32" || this.deal == "MADRID RMBS IV, FTA")){
        // get current chart labels
        var xLabelText = xLabels[i].split('\n');
        // *[@class="highcharts-axis-labels highcharts-xaxis-labels "][2]/following-sibling::*[1]
        var yLabelText = browser.getText('(' + performancePage_xpath.xLabel + ')['+index+']/following-sibling::*[1]').split('\n')[0];
        console.log(yLabelText);
        var tmpIndex = [];
        // var yLabelXpath = '(' + performancePage_xpath.yLabel + ')['+ index +']//*[text()="'+ yLabelText +'"]';
        var yLabelXpath = '(' + performancePage_xpath.xLabel + ')['+index+']/following-sibling::*[1]//*[text()="'+yLabelText+'"]';
        // get the value by yLabel        
        browser.moveToObject(yLabelXpath,offsetX,offsetY);
        browser.pause(500);
        browser.moveToObject(yLabelXpath,offsetX,offsetY);
        var tooltipValue = browser.getText('(' + tooltip + ')[' + index + ']');
        console.log('-----' + tooltipValue);
        tmpIndex.push(tooltipValue);
        // get the value by xLabel
        // Oct 2017● REO %: 72.97● WA DSCR: 0.97
        for(var j=0;j<xLabelText.length;j++){
          var xLabelXpath = '(' + performancePage_xpath.xLabel + ')['+ index +']//*[text()="'+ xLabelText[j] +'"]';
          browser.moveToObject(xLabelXpath,offsetX,offsetY);
          tooltipValue = browser.getText('(' + tooltip + ')[' + index + ']');
          console.log('-----' + tooltipValue);
          tmpIndex.push(tooltipValue);
          browser.pause(500);
        }
        uiValues.push(tmpIndex);
      }

  		// var currentFileName = filename.replace('__INDEX__',i+1);
      console.log('this.deal:'+this.deal) 
      var currentFileName = 'HistoricalChart' 
  		this.file_session.deleteFiles(currentFileName);
			browser.pause(200);
      try{
        browser.elementIdClick(downloadValueList[i]['ELEMENT']);
        // browser.pause(1000);
        browser.waitForVisible(downloadIcon + '/following-sibling::*' + fileTextIcon, 20*1000);
      }catch(error){
        browser.elementIdClick(downloadValueList[i]['ELEMENT']);
        browser.waitForVisible(downloadIcon + '/following-sibling::*' + fileTextIcon, this.wait20);
      }
  		// browser.elementIdClick(downloadValueList[i]['ELEMENT']);
  		// browser.pause(500);

      // browser.elementIdClick(fileTextIconList[i]['ELEMENT']);

      console.log('(' + downloadIcon + '/following-sibling::*' + fileTextIcon + ')' + '['+ index +']');
      browser.click('(' + downloadIcon + '/following-sibling::*' + fileTextIcon + ')' + '['+ index +']');

      // For IE we need to click the save button
      if (process.env.BROWSER == 'IE11') {
        browser.pause(5*1000);
        this.robot_session.clickImage(null, 'IE11_DownloadSave.png');
        browser.pause(10*1000);
        this.robot_session.clickImage(null, 'IE11_DownloadDismissX.png');
        browser.pause(1000);
      }

      
  		browser.pause(5000);
      var currentFileName=this.file_session.getDownloadFileName(currentFileName,fileType.toLowerCase())['filePath'];
  		// currentFileName = this.file_session.waitForDownload(browser,currentFileName);
  		console.log('my download file: ' + currentFileName);
      filenameList.push(currentFileName); 
  		switch(fileType.toUpperCase()){
				case 'CSV':
					var file_content = fs.readFileSync(currentFileName,{encoding:'utf-8'});
					expect(file_content.toLowerCase().indexOf('undefined') == -1).toBe(true,currentFileName + ': This file contains undefined');
					break;
				case 'XLS':
					var file_content = this.file_session.readHtmlAsCsvString(currentFileName,true);
					expect(file_content.toLowerCase().indexOf('undefined') == -1).toBe(true,'This file contains undefined');
					break;
			}

			// get target table
			var file_array = file_content.replace(/\r/g,'').split('\n');
			// console.log(file_array);
			var tmp = {};
			var headerIndex = undefined;
			var lastIndex = undefined;
      var len = file_array.length;
			for(var j=0;j<len;j++){
        var t = file_array[j];
				if( t.replace(/"/g,'').startsWith(titleTextInCsv.replace(/"/g,'')) ){
					headerIndex = j;
					tmp['header'] = t.replace(/"/g,'');
				}
				// if( headerIndex && file_array[j].replace(/["\s]/g,'').length == 0){
				// 	lastIndex = j;
				// 	tmp['data'] = file_array.slice(headerIndex+1,lastIndex);
				// 	break;
				// }
			}
      tmp['data'] = file_array.slice(headerIndex + 1,len);
			fileContentList.push(tmp);
  	}
  	// console.log('****************');
  	// console.log(filenameList);
  	// console.log(fileContentList);
  	this.fileContentList = fileContentList;
    this.uiValues = uiValues;
    console.log(this.uiValues);
    console.log('****************');
    console.log(this.fileContentList);
  });
}