// When_I_#_the_vector_named_#.js
module.exports = function() {
this.When(/^I (delete|click) the vector named "([^"]*)"$/, function (method, vectorName) {
    // Write code here that turns the phrase above into concrete actions
    var cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
    this.browser_session.waitForResource(browser);

    var vectorTable = cashflow_xpath.vectorTable;
    console.log(vectorTable);
    var vectorTableRows = cashflow_xpath.vectorTable + "/td[1]";
    var tableContent = browser.getText(vectorTableRows);
    console.log(tableContent);
    console.log(tableContent.length);
    var vectorCount = tableContent.length;

    if(vectorCount != 0){
      for(var i=1; i<vectorCount+1; i++){
        var vectorRow = vectorTable + "[" + i + "]/td[1]";
        var vectorName1 = browser.getText(vectorRow);
        console.log(vectorName1);
        if(vectorName1 == vectorName){
            if(method == 'delete'){
                var deleteIcon = cashflow_xpath.vectorTable + "[" + i + "]/td//span";
                browser.click(deleteIcon);
                browser.pause(3000);
                var vectorTableRows1 = cashflow_xpath.vectorTable + "/td[1]";
                var tableContent1 = browser.getText(vectorTableRows1);
                var vectorCount1 = tableContent1.length;
                console.log(vectorCount);
                console.log(vectorCount1);
                expect(vectorCount1).toEqual(vectorCount-1);
            }
            else{
                browser.click(vectorRow);
            }
            
        }
      }
    }
  });
}