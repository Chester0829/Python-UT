// Recommended filename: When_I_click_on_the_#_dropdown_list.js
module.exports = function() {
  this.When(/^I click on the "([^"]*)" dropdown list$/,
    {timeout: process.env.StepTimeoutInMS}, function (listName) {
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      var my_dropdownList = content_xpath.labeled_mdSelect.replace('__LABEL__', listName);
      browser.click(my_dropdownList);
      browser.pause(500);
  });
}
