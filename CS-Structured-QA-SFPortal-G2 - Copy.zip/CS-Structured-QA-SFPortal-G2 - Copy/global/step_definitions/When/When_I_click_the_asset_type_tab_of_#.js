// Recommended filename: When_I_click_the_asset_type_tab_of_#.js
module.exports = function() {
  this.When(/^I click the asset type tab of "([^"]*)"$/, function (tabName) {
    // Write the automation code here
    const portfolioPage_xpath = this.xpath_lib.xpathRequire('portfolioPage_xpath');
    
    var assetClass_tab = portfolioPage_xpath.assetClassTab_xpath.replace('__TABNAME__', tabName);
    // this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    browser.waitForVisible(assetClass_tab,this.waitDefaukt);
    browser.click(assetClass_tab);
    this.browser_session.waitForResource(browser);

    // console.log(assetClassTab_xpath);
    // browser.click(assetClass_tab);
    //browser.pause(1000);
    //this.browser_session.waitForResource(browser);
    //this.browser_session.waitForLoading(browser);
  });
};
