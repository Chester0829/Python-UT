// When_I_created_new_rule_with_following_information_under_the_#_panel-heading.js
// only for Stratification
module.exports = function() {
  this.When(/^I created new rule with following information under the "([^"]*)" panel\-heading$/, function (arg1, table) {
    // Write code here that turns the phrase above into concrete actions
    var rule_item_list = table.hashes();
    // var add_new_rule = '//*[text()="Add New Rule"]';
    // browser.waitForVisible(add_new_rule,this.waitDefault);
    // browser.click(add_new_rule);
    var cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
    var table_xpath = cashflow_xpath.StratificationTable;
    var ruleIDs = table_xpath + '//tbody//tr//td[@style="text-align: center; vertical-align: middle"]';
    var new_ruleLen = browser.getText(ruleIDs).length;
    console.log(new_ruleLen);
    

    for(var i=0;i<rule_item_list.length;i++){
      var column = rule_item_list[i]['row_item'];
      var value = rule_item_list[i]['value'];
      // console.log('column: ' + column + ', value: ' + value);
      switch(column){
        case 'watch.type1':
        case 'watch.type2':
        case 'watch.type3':
        case 'watch.prepaytype':
        case 'watch.defaulttype':
        case 'watch.NOI_growth_rate_type':
        case 'watch.cap_rate_growth_rate_type':
        case 'watch.term_triggers_select_priority':
        case 'watch.lossType':
        case 'watch.maturity_trigger_select_priority': 
          var mdSelect = cashflow_xpath.mdSelect.replace('__NAME__',column);
          var tmp = browser.isVisible(mdSelect);
          // need to filter true in tmp list ?
          var mdSelectLen = Array.isArray(tmp) ? tmp.length : 1; 
          browser.click( '(' + mdSelect +')[' + mdSelectLen + ']');
          browser.pause(200);
          try {
            var textXpath = cashflow_xpath.mdSelectMenu + '//*[text()="'+ value +'"]';
            var t = browser.isVisible(textXpath);
            var textXpathLen = Array.isArray(t) ? t.length : 1;
            browser.click('(' + textXpath + ')[' + textXpathLen + ']');  
          } catch (error) {
            var textXpath = cashflow_xpath.mdSelectMenu2 + '//*[text()="'+ value +'"]';
            console.log('try more one time: ' + textXpath);
            var t = browser.isVisible(textXpath);
            var textXpathLen = Array.isArray(t) ? t.length : 1;
            browser.click('(' + textXpath + ')[' + textXpathLen + ']');
          }
          break;
        case 'watch.min1':
          // var uiSelectMatch = '//div[@ng-model="'+ column +'"]//div[@class="ui-select-match"]';
          // var tmp = browser.isVisible(uiSelectMatch);
          // var uiSelectMatchLen = Array.isArray(tmp) ? tmp.length : 1;
          // console.log('(' + uiSelectMatch + ')[' + uiSelectMatchLen +']');
          // try {
          //   browser.click('(' + uiSelectMatch + ')[' + uiSelectMatchLen +']');  
          // } catch (error) {
          //   console.log('try to click: ' + '(' + divSelectMatch + ')[' + uiSelectMatchLen + ']' );
          //   browser.click('(' + divSelectMatch + ')[' + uiSelectMatchLen + ']');
          // }
          var divSelectMatch = '//div[@ng-model="'+ column +'"]';
          var tmp = browser.isVisible(divSelectMatch);
          console.log(tmp);
          var divSelectMatchLen = Array.isArray(tmp) ? tmp.length : 1;
          browser.click('(' + divSelectMatch + ')[' + divSelectMatchLen + ']');
          browser.pause(200);
          var input = '//div[@ng-model="watch.min1"]//input[contains(@placeholder,"Select or search")]';
          var t = browser.isVisible(input);
          console.log(t);
          var inputLen =  Array.isArray(t) ? t.length : 1;
          console.log(inputLen);
          browser.click('(' + input + ')[' + inputLen + ']');
          console.log('(' + input + ')[' + inputLen + ']');
          browser.pause(1000);
          browser.setValue('(' + input + ')[' + inputLen + ']',value);
          browser.waitForVisible('//div[@ng-model="watch.min1"]//ul[not (contains(@class,"ng-hide"))]//*[text()="'+ value +'"]',this.waitDefault);
          this.robot_session.keyTap();
          if(this.portfolio && browser.isVisible('(' + input + ')[' + inputLen + ']')){
            browser.pause(500);
            browser.click('(' + input + ')[' + inputLen + ']');
            browser.waitForVisible('//div[@ng-model="watch.min1"]//ul[not (contains(@class,"ng-hide"))]//*[text()="'+ value +'"]',this.waitDefault);
            this.robot_session.keyTap();
          }
          break;
        case 'watch.max1':
        case 'watch.min2':
        case 'watch.max2':
        case 'watch.min3':
        case 'watch.max3':
        case 'watch.NOI_growth_rate':
        case 'watch.cap_rate_growth_rate':
        case 'watch.term_triggers_LTV_liquidate':
        case 'watch.term_triggers_LTV_months':
        case 'watch.term_triggers_LTV_loss':
        case 'watch.term_triggers_DSCR_liquidate':
        case 'watch.term_triggers_DSCR_months':
        case 'watch.term_triggers_DSCR_loss':
        case 'watch.maturity_trigger_LTV_payoff':
        case 'watch.maturity_trigger_LTV_liquidate':
        case 'watch.maturity_trigger_LTV_loss':
        case 'watch.maturity_trigger_LTV_extension':
        case 'watch.maturity_trigger_LTV_end_of_extension_liq_or_payoff':
        case 'watch.maturity_trigger_LTV_end_of_extension_loss':
        case 'watch.maturity_trigger_DY_payoff':
        case 'watch.maturity_trigger_DY_liquidate':
        case 'watch.maturity_trigger_DY_loss':
        case 'watch.maturity_trigger_DY_extension':
        case 'watch.maturity_trigger_DY_end_of_extension_liq_or_payoff':
        case 'watch.maturity_trigger_DY_end_of_extension_loss':
        case 'watch.prepayrate':
        case 'watch.defaultrate':
        case 'watch.lossrate':
        case 'watch.lagmonths':
          var sfpTextInput = cashflow_xpath.sfpTextInput.replace('__NAME__',column) + '//input';
          // var sfpTextInput = '//sfp-text-input[@ng-model="'+ column +'"]//input';
          var tmp = browser.isVisible(sfpTextInput);
          if(!tmp){
            sfpTextInput = '//input[@ng-model="'+ column +'"]';
            tmp = browser.isVisible(sfpTextInput); 
          }
          var sfpTextInputLen = Array.isArray(tmp) ? tmp.length : 1;
          // console.log('(' + sfpTextInput + ')[' + sfpTextInputLen + ']');
          if(value == 'disabled'){
            var isDisable = browser.getAttribute('(' + sfpTextInput + ')[' + sfpTextInputLen + ']','disabled');
            // console.log(isDisable);
          }else{
            browser.setValue('(' + sfpTextInput + ')[' + sfpTextInputLen + ']',value);
          }
          break;
        // case 'watch.NOI_growth_rate_type':
        // case 'watch.cap_rate_growth_rate_type':
        // case 'watch.term_triggers_select_priority':
        // case 'watch.lossType':
        // case 'watch.maturity_trigger_select_priority':
        //   // var mdSelect = '//md-select[@ng-model="'+ column +'"]';
        //   var mdSelect = cashflow_xpath.mdSelect.replace('__NAME__',column);
        //   var tmp = browser.isVisible(mdSelect);
        //   var mdSelectLen = Array.isArray(tmp) ? tmp.length : 1;
        //   console.log('(' + mdSelect + ')[' + mdSelectLen + ']');
        //   browser.click('(' + mdSelect + ')[' + mdSelectLen + ']');
        //   browser.pause(200);
        //   var textXpath = cashflow_xpath.mdSelectMenu2 + '//*[text()="'+ value +'"]';
        //   // var textXpath = '//md-select-menu[@class="_md"]//md-option[@aria-selected="false"]//*[text()="'+ value +'"]';
        //   var t = browser.isVisible(textXpath);
        //   var textXpathLen = Array.isArray(t) ? t.length : 1;
        //   console.log('(' + textXpath + ')[' + textXpathLen + ']');
        //   browser.click('(' + textXpath + ')[' + textXpathLen + ']');
        //   break;
        case 'watch.term_triggers_activate_LTV_trigger':
        case 'watch.term_triggers_activate_DSCR_trigger':
        case 'watch.maturity_trigger_activate_LTV_trigger':
        case 'watch.maturity_trigger_activate_DY_trigger':
          var sfpCheckbox = cashflow_xpath.sfpCheckbox.replace('__NAME__',column);
          // var sfpCheckbox = '//sfp-checkbox[@ng-model="'+ column +'"]';
          var tmp = browser.isVisible(sfpCheckbox);
          var sfpCheckboxLen = Array.isArray(tmp) ? tmp.length : 1;
          // console.log('(' + sfpCheckbox + ')[' + sfpCheckboxLen + ']');
          var checkedStatus = browser.getAttribute('(' + sfpCheckbox + ')[' + sfpCheckboxLen + ']','aria-checked');
          if(value == 'checked'){
            if(checkedStatus != 'true'){
              browser.click('(' + sfpCheckbox + ')[' + sfpCheckboxLen + ']');
            }
          }else if(value == 'unchecked'){
            if(checkedStatus != 'false'){
              browser.click('(' + sfpCheckbox + ')[' + sfpCheckboxLen + ']');
            }
          }
          break;
        
      }



    }




    });
}

