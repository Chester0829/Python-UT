// Recommended filename: When_I_fill_the_performance_charts_with_the_following_metrics.js
module.exports = function() {
  this.When(/^I fill the performance charts with the following (metrics|metrics for specified charts)$/, {timeout: process.env.StepTimeoutInMS}, function(type,table) {
    var expected_list = table.hashes();
    const performancePage_xpath = this.xpath_lib.xpathRequire('performancePage_xpath');
    var metricInput_xpath = performancePage_xpath.metricInput;
    var self = this;
    if(type == 'metrics for specified charts'){
      expected_list.forEach(function(expected_item){
        var chartMetricInput = '(' + metricInput_xpath + ')[' + expected_item['charts'] + ']';
        console.log(chartMetricInput)
        browser.waitForExist(chartMetricInput,self.waitMax)
        browser.waitForVisible(chartMetricInput,self.waitMax) 
        // browser.waitForEnabled(chartMetricInput,self.waitDefault)
        console.log(chartMetricInput,expected_item['dropdown_item'])
        browser.setValue(chartMetricInput,expected_item['dropdown_item'])
        browser.pause(100)
        browser.waitForExist('//*[@class="ui-select-highlight"]',self.waitDefault)
        browser.keys('Enter');
        // try{
        //   var metricText_xpath = content_xpath.charts_fields;
        //   browser.waitForVisible(metricText_xpath,self.waitMax) 
        //   var metricsText=browser.getText(metricText_xpath) 
        //   console.log(metricsText)
        //   expect(metricsText).toContain(expected_item['dropdown_item'])
        // }catch(e){
        //   console.log('set again')
        //   browser.waitForExist(chartMetricInput,self.waitMax)
        //   browser.waitForVisible(chartMetricInput,self.waitMax) 
        //   browser.setValue(chartMetricInput,expected_item['dropdown_item'])
        //   browser.pause(100)
        //   browser.waitForExist('//*[@class="ui-select-highlight"]',self.waitDefault)
        //   browser.keys('Enter');
        // }
        // var expected_item['dropdown_item']
      })

    }else{
      expected_list.forEach(function(expected_item, index) {
        var chartIndex = index % 4;
        var chartMetricInput = '(' + metricInput_xpath + ')[' + (chartIndex + 1) + ']';
        browser.waitForVisible(chartMetricInput,self.waitDefault)
        browser.setValue(chartMetricInput, expected_item['dropdown_item']);
        browser.pause(100);
      // CMBS Deal: Performing Loan Number % and Non-Performing Loan Number %
      if(expected_item['dropdown_item'] == 'Performing Loan Number %'){
        var liXpath = '//li[@class="ui-select-choices-group"]';
        var allList = browser.getText(liXpath + '//a');
        var indexItem = allList.indexOf(expected_item['dropdown_item']);
        // console.log(allList);
        // console.log('(' + liXpath + '//a' + ')[' + (indexItem+1) + ')');
        browser.click('(' + liXpath + '//a' + ')[' + (indexItem+1) + ']');
        browser.pause(100);
      }else{
        browser.keys('Enter');
        browser.pause(100);
      }
      
    });
    }
      browser.pause(1000);
      self.expected_list = expected_list

  });
};
