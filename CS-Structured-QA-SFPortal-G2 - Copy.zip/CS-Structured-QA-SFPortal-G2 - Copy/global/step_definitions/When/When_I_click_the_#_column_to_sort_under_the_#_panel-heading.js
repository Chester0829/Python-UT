// Recommended filename: When_I_click_the_#_column_to_sort_under_the_#_panel-heading.js
module.exports = function() {
  this.When(/^I click the (first|second|third|fourth|fifth|sixth|seventh|eighth|nineth|tenth|eleventh|twelveth|thirteenth|eighteenth) column to sort under the "([^"]*)" panel-heading$/, {timeout: 6000*1000}, function (numOfCol, widgetName) {
    // Write the automation code here
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const bwic_xpath = this.xpath_lib.xpathRequire('bwic_xpath');
    
    var nth_index;
    switch (numOfCol) {
        case "first":
            nth_index = 1;
            break;
        case "second":
            nth_index = 2;
            break; 
        case "third":
            nth_index = 3;
            break;
         case "fourth":
            nth_index = 4;
            break;
        case "fifth":
            nth_index = 5;
            break;
        case "sixth":
            nth_index = 6;
            break;
        case "seventh":
            nth_index = 7;
            break;
        case "eighth":
            nth_index = 8;
            break;
        case "nineth":
            nth_index = 9;
            break;
        case "tenth":
            nth_index = 10;
            break;
        case "eleventh":
            nth_index = 11;
            break;
        case "twelveth":
            nth_index = 12;
            break;
        case "thirteenth":
            nth_index = 13;
            break;
        case "eighteenth":
            nth_index = 18;
            break;
        default: 
            nth_index = 1;
            break;
    };

    var column_xpath = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase()) + '//table/thead/tr/th[' + nth_index + ']/a';
    if(widgetName == 'BWIC Analyzer:'){
        column_xpath = '//table/thead/tr/th[' + nth_index + ']/a';
    }
    if(widgetName == 'Tranche Level Universe: CLO'||widgetName == 'Tranche Level Universe: AUTO'||widgetName == 'Key Stats: Portfolio-CLO-for-automation'
        ||widgetName == 'Key Stats: Portfolio-All-for-automation'||widgetName == 'Key Stats: Portfolio-RMBS-for-automation'
        ||widgetName == 'Dealer Inventory: ALL'||widgetName == 'BWIC List: CLO/ CBO'||widgetName == 'BWIC List: User Input BWIC List' ||widgetName == 'BWIC List: User Input BWIC List for CMBS' ||widgetName == 'BWIC List: User Input BWIC List for Mix'||widgetName == 'Comparables'){
        column_xpath = content_xpath.titledSectionLowercaseBWIC.replace('__TITLE__', widgetName.toLowerCase()) + bwic_xpath.enhancedBWICTable + '/thead/tr[2]/th[' + nth_index + ']/a';
    }
    console.log(column_xpath);
    browser.click(column_xpath); 
    // browser.pause(1000);
    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
  });
};
