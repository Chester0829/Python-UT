// Recommended filename: When_I_click_menu_to_logout_of_the_application.js
module.exports = function() {
  this.When(/^I click menu to logout of the application$/,
    {timeout: process.env.StepTimeoutInMS*5}, function () {
    // Write code here that turns the phrase above into concrete actions
    const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
    const loginPage_xpath = this.xpath_lib.xpathRequire('loginPage_xpath');
    
    var myLogout_button = header_xpath.named_MenuOption_link.replace('__NAME__', 'Logout');
    if (browser.isExisting(header_xpath.user_pull)) {
      browser.waitForExist(header_xpath.user_pull);
      browser.click(header_xpath.user_pull);
      browser.waitForExist(header_xpath.user_pull);
      browser.waitForVisible(myLogout_button, this.waitDefault*2);
      browser.click(myLogout_button);
      this.browser_session.waitForLoading(browser);
    }
    browser.waitForExist(loginPage_xpath.signIn_form, this.waitDefault*2);
  });
}
