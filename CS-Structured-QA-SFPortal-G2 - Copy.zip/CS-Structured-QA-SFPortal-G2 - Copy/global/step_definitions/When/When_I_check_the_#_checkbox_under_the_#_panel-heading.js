// Recommended filename: When_I_check_the_#_checkbox_under_the_#_panel-heading.js
module.exports = function() {
	this.When(/^I check the "([^"]*)" checkbox under the "([^"]*)" panel-heading$/, 
		{timeout: process.env.StepTimeoutInMS*5},
		function(checkboxValue,widgetName){
			// return 'pending';
			// browser.pause(2*1000);	
			this.browser_session.waitForResource(browser);
			const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
			var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());
			var checkBox_xpath = this.xpath_lib.xpathRequire('checkBox_xpath');
			var checkBoxTitle_xpath = checkBox_xpath.checkBoxTitle_xpath1.replace('__CHECKBOXTITLE__',checkboxValue);
			var label_xpath = myPanel + checkBoxTitle_xpath;

			if(widgetName=='Capital Structure'){
				label_xpath = myPanel + '//md-checkbox';
			}
			if(widgetName =='Filter Settings'){
				browser.pause(10*1000);	
			}
			try{
				browser.waitForVisible(label_xpath,this.waitDefault*2);
			}
			catch(error){
				console.log('try again...');
				label_xpath = myPanel + checkBox_xpath.checkBoxTitle_xpath.replace('__CHECKBOXTITLE__',checkboxValue);;
				// browser.refresh();
				// this.browser_session.waitForResource(browser);
				browser.waitForVisible(label_xpath,this.waitDefault*2);

			}
			// // sometimes it will display the search result pop-up.
	  //   var search_result_end = '//div/*[contains(text(), "* Note: There are more records in the system, please refine your search to get more accurate results.")]';
	  //   if(browser.isVisible(search_result_end)){
	  //     browser.refresh();
	  //     //browser.pause(3000);
	  //     this.browser_session.waitForResource(browser);
	  //     browser.waitForVisible(label_xpath,this.waitDefault);
	  //   }
	    this.browser_session.clickNoWhere(browser);
			//var label_xpath = myPanel + checkBoxTitle_xpath;
			console.log(label_xpath);
			browser.click(label_xpath);
			browser.pause(1000);
		})
}

