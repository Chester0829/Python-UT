// Recommended filename: When_I_add_below_items_for_the_#_FieldsPlus_option_in_the_#_panel-heading.js
module.exports = function() {
	this.When(/^I add below items for the "([^"]*)" FieldsPlus option in the "([^"]*)" panel-heading$/, 
		{timeout:process.env.StepTimeoutInMS*5},
		function (optionText, panelName, table) {
		// Write code here that turns the phrase above into concrete actions
		this.browser_session.waitForLoading(browser);
    this.browser_session.waitForResource(browser);
    var table_json = table.hashes();
    var addItemList = [];
    for(var i=0;i<table_json.length;i++){
    	addItemList.push(table_json[i]['row_data']);
    }
    this.selected_count=this.browser_session.setFieldsPlus(browser, panelName, optionText, addItemList);
    this.browser_session.waitForLoading(browser);
    this.browser_session.waitForResource(browser);


		// return 'pending';
	});
};