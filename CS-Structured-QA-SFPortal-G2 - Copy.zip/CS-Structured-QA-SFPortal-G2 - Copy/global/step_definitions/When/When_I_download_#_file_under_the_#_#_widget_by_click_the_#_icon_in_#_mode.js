// Recommended filename: When_I_download_#_file_under_the_#_#_widget_by_click_the_#_icon_in_#_mode.js
module.exports = function() {
	this.When(/^I download "([^"]*)" file under the "([^"]*)" (table|charts|pie chart|bar chart|area chart) widget by click the "([^"]*)" icon in (deal|manager|stored deal) (mode|clickwrap mode)$/, 
		{timeout: process.env.StepTimeoutInMS*5},
		function(filetype, widgetName, widgetType, button,mode,isClickwrap){
			// Write code here that turns the phrase above into concrete actions
			this.browser_session.waitForResource(browser);
			const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
			const download_xpath = this.xpath_lib.xpathRequire('portfolioModeDownload_xpath');
			const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
			const bwic_xpath = this.xpath_lib.xpathRequire('bwic_xpath');
			const fs = require('fs');
			const path = require('path');

			var chartTtile = this.xpath_lib.xpathRequire('chartTitle');
			if(widgetName == 'BWIC Analyzer:'){
				const bwic_xpath = this.xpath_lib.xpathRequire('bwic_xpath');
				var myPanel = bwic_xpath.nameTitle;
			}else if(widgetName == 'Edit Deal'){
				var myPanel = cashflow_xpath.editDealFrame;
			}else if(widgetName == 'Tranche Level Universe: CLO'||widgetName == 'Tranche Level Universe: AUTO'||widgetName == 'Key Stats: Portfolio-CLO-for-automation'
				||widgetName == 'Key Stats: Portfolio-All-for-automation'||widgetName == 'Key Stats: Portfolio-RMBS-for-automation'
				||widgetName == 'Dealer Inventory: ALL'||widgetName == 'BWIC List: CLO/ CBO'||widgetName == 'BWIC List: User Input BWIC List' ||widgetName == 'BWIC List: User Input BWIC List for CMBS' ||widgetName == 'BWIC List: User Input BWIC List for Mix'){
				var myPanel = content_xpath.titledSectionLowercaseBWIC.replace('__TITLE__', widgetName.toLowerCase());
			}
			else{
				var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());	
			}
			// var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());
			switch(button){
				case 'download':
					// var download_icon_xpath = myPanel + download_xpath.download_icon;
					var icon_xpath = download_xpath.download_icon;
					if(widgetName == 'Tranche Level Universe: CLO'||widgetName == 'Tranche Level Universe: AUTO'||widgetName == 'Key Stats: Portfolio-CLO-for-automation'
						||widgetName == 'Key Stats: Portfolio-All-for-automation'||widgetName == 'Key Stats: Portfolio-RMBS-for-automation'
						||widgetName == 'Dealer Inventory: ALL'||widgetName == 'BWIC List: CLO/ CBO'||widgetName == 'BWIC List: User Input BWIC List' ||widgetName == 'BWIC List: User Input BWIC List for CMBS' ||widgetName == 'BWIC List: User Input BWIC List for Mix'){
						var icon_xpath = download_xpath.download_iconforBWIC;
					}
					break;
				case 'Current':
				case 'Export All':
					var icon_xpath = download_xpath.currentOrExportAll_download_icon.replace('__CURRENTTYPE__',button);
					break;
				case 'Export Template':
					var icon_xpath = cashflow_xpath.editDealExport;
					break;
			}

			var download_icon_xpath = myPanel + icon_xpath;
			this.no_data_text_list = download_xpath.no_data_text_list;
			console.log(this.no_data_text_list);

			switch(widgetName){
				case 'Asset Type':
				case 'APR of Receivables':
				case 'Delinquency Experience':
					download_icon_xpath = '(' + download_icon_xpath + ')[1]';	
					myPanel = '(' + myPanel + ')[1]';
					break;
				case 'Current Balance':
				case 'FICO Score':
					download_icon_xpath = '(' + download_icon_xpath + ')[2]';
					myPanel = '(' + myPanel + ')[2]';
					break;
				case 'Geography':
					download_icon_xpath = '(' + download_icon_xpath + ')[3]';
					myPanel = '(' + myPanel + ')[3]';
					break;
				case 'Industry':
				case 'Loan To Value':
					download_icon_xpath = '(' + download_icon_xpath + ')[4]';
					myPanel = '(' + myPanel + ')[4]';
					break;
				case 'Obligor Concentration':
					download_icon_xpath = '(' + download_icon_xpath + ')[5]';
					myPanel = '(' + myPanel + ')[5]';
					break;
				case 'Vehicle Type':
					download_icon_xpath = '(' + download_icon_xpath + ')[6]';
					myPanel = '(' + myPanel + ')[6]';
					break;
				case 'Scheduled Termination Date':
					download_icon_xpath = '(' + download_icon_xpath + ')[6]';
					myPanel = '(' + myPanel + ')[6]';
					break;
				case 'Vehicle Model':
					download_icon_xpath = '(' + download_icon_xpath + ')[7]';
					myPanel = '(' + myPanel + ')[7]';
					break;
				case 'Original Term':
					if(this.deal=='Mercedes-Benz Auto Lease Trust 2017-A'){
						download_icon_xpath = '(' + download_icon_xpath + ')[4]';
						myPanel = '(' + myPanel + ')[4]';
					}
					else{
						download_icon_xpath = '(' + download_icon_xpath + ')[6]';
						myPanel = '(' + myPanel + ')[6]';
					}
					break;
				case 'Remaining Term':
					if(this.deal=='Mercedes-Benz Auto Lease Trust 2017-A'){
						download_icon_xpath = '(' + download_icon_xpath + ')[5]';
						myPanel = '(' + myPanel + ')[5]';
					}
					else{
					download_icon_xpath = '(' + download_icon_xpath + ')[7]';
					myPanel = '(' + myPanel + ')[7]';
				  }
					break;
				default:
					break;
			}
			console.log(download_icon_xpath);

			if(widgetType != 'table'){
				// var chartTitleList = chartTtile['deal'];
				
				var chartTitleList = chartTtile[mode];
				if(chartTitleList[widgetName] != undefined){
					if(this.page=="Tranches" && widgetName=="Key Differentiators"){
						widgetName = "Key Differentiators for tranche";
						var titleTextInCsv = ('title' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['title'] : chartTitleList[widgetName];
						var offsetX = ('offsetX' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetX']: 0;
						var offsetY = ('offsetY' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetY']: 0;
						var separator = ('separator' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['separator']: '';
						var fileFirstKey = ('fileFirstKey' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['fileFirstKey']: '';
						var flag = true;
						widgetName = "Key Differentiators";
						console.log("rename widget name");
					}else{
						var titleTextInCsv = ('title' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['title'] : chartTitleList[widgetName];
						var offsetX = ('offsetX' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetX']: 0;
						var offsetY = ('offsetY' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetY']: 0;
						var separator = ('separator' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['separator']: '';
						var fileFirstKey = ('fileFirstKey' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['fileFirstKey']: '';
						var flag = true;
					}	
				}else if(chartTitleList[this.chartName] != undefined){
					var titleTextInCsv = 'title' in chartTitleList[this.chartName] ? chartTitleList[this.chartName]['title'] : chartTitleList[this.chartName];
					var offsetX = ('offsetX' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetX']: 0;
					var offsetY = ('offsetY' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetY']: 0;
					var separator = ('separator' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['separator']: '';
					var fileFirstKey = ('fileFirstKey' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['fileFirstKey']: '';
					var flag = true;
				}else{
					var flag = false;
					var offsetX = 0;
					var offsetY = 0;
					var separator = '';
					var fileFirstKey = '';
					var titleTextInCsv = this.chartName;
				}
				console.log(titleTextInCsv);
				console.log(offsetX);
				console.log(offsetY);
				this.fileFirstKey = fileFirstKey;
			}
			


			// donot delete the annotation code
			switch(widgetType){
				case 'table':
					var flag = false;
					var table_xpath = myPanel + content_xpath.descendantDataTable;
					if(widgetName == 'Tranche Level Universe: CLO'||widgetName == 'Tranche Level Universe: AUTO'||widgetName == 'Key Stats: Portfolio-CLO-for-automation'
						||widgetName == 'Key Stats: Portfolio-All-for-automation'||widgetName == 'Key Stats: Portfolio-RMBS-for-automation'
						||widgetName == 'Dealer Inventory: ALL'||widgetName == 'BWIC List: CLO/ CBO'||widgetName == 'BWIC List: User Input BWIC List' ||widgetName == 'BWIC List: User Input BWIC List for CMBS' ||widgetName == 'BWIC List: User Input BWIC List for Mix'){
						var table_xpath = myPanel + bwic_xpath.enhancedBWICTable;
					}
					console.log(table_xpath);
					if(browser.isVisible(table_xpath + '//thead//th')){
						var htmls = browser.getHTML(table_xpath);
						// console.log(htmls);
						// console.log('*******************')
						// console.log(htmls.length);
						// console.log(htmls[2]);
						// console.log(this.tabletojson.convert(htmls));
						// console.log('----------------------');
						// console.log(this.tabletojson.convert(htmls)[2]);
						// console.log('*********************');
						// console.log(this.tabletojson.convert(htmls[2])[0]);
						// console.log(this.tabletojson.convert(htmls[2])[1]);
						if(widgetName == 'Results'){
							// cashflows
							this.table_json = this.tabletojson.convert(htmls[2])[0];
						}else{
							this.table_json = this.tabletojson.convert(htmls)[0];	
						}
						if(this.name == 'Enhanced BWIC'&& (widgetName.indexOf('Key Stats')>-1||widgetName.indexOf('Tranche Level Universe')>-1
							||widgetName.indexOf('BWIC List') != -1 ||widgetName.indexOf('Dealer Inventory') != -1)){
							console.log('handle enhanced bwic data')
							this.table_json.splice(0,1)
						}
						// this.table_json = this.tabletojson.convert(htmls)[0];
						// console.log('*******************htmls:',htmls)
						console.log('**********this.table_json:',this.table_json);
						var lastItem = this.table_json[this.table_json.length-1];
						for(var key in lastItem){
							var reg = new RegExp(this.no_data_text_list.join('|'),'g'); 
							if(reg.test(lastItem[key])){
								flag = true;
							}
							break;
						}
						var table_length = flag ? (this.table_json.length-1) : this.table_json.length;
						console.log(table_xpath + '//thead//th');
						// console.log('table_length: ' + table_length);
						var thead = browser.getText(table_xpath + '//thead//th').join(',');
						console.log(thead);
					}else{
						// Notable Metrics and Weighted Average Financial Ratios
						this.text_list = browser.getText(table_xpath + '//tr');
						var lastItem = this.text_list[this.text_list.length-1];
						var reg = new RegExp(this.no_data_text_list.join('|'),'g'); 
						var table_length = reg.test(lastItem) == true ? this.text_list.length -1 : this.text_list.length;
						// tr[1]->td[1]
						if(widgetName == 'Deal Overview'){
							var allThead = browser.getText(table_xpath + '//tr[1]//td[1]');
							console.log('allThead: ' + allThead);
							thead = allThead[0];
							var uiResult = browser.getText(table_xpath + '//tr');
							uiResult.splice(0,0,'Deal Parties');
							uiResult.splice(4,0,'Deal Characteristics');
							// console.log(uiResult);
							this.uiResult = uiResult;
						}else if(widgetName == 'Tickers' || widgetName == 'Characteristics'){
							var thead = browser.getText(table_xpath + '//tr[1]//td[1]');
							var uiResult = browser.getText(table_xpath + '//tr');
							console.log(uiResult);
							this.uiResult = uiResult;
						}else if(browser.isVisible(table_xpath + '//tr[1]//td[1]')){
							var thead = browser.getText(table_xpath + '//tr[1]//td[1]');
						}else if(widgetName == 'Collateral Summary'){
							var thead = browser.getText(table_xpath + '//tr[1]//th').join(',');
							var uiResult = browser.getText(table_xpath + '//tr');
							console.log(uiResult);
							this.uiResult = uiResult;
						}
						else{
							var thead = browser.getText(table_xpath + '//tr[1]//th[1]');
							//The first cell may be null
							if(thead.replace(/\s/g,'').length == 0){
								thead = browser.getText(table_xpath + '//tr[1]');
							}
						}
						console.log(thead);
					}
					break;
				case 'pie chart':
					if(filetype == 'CSV' && widgetName == 'Key Differentiators'){
						// annotation as result is no used, but may be use in feature
						var result = this.browser_session.getTooltipValueForKeyDiff(browser)
						console.log(result);
						this.uiResult = result;
						this.pie_charts_value_length = result.length;
						break;
					}
					// manager
					if(mode == 'manager'){ // only for Concentration Report
						// charts_all_values no used for the moment, but may be use in feature
						// var myChart = myPanel + content_xpath.titledChart.replace('__TITLE__', this.chartName);
						// var myChart_drilldown = myChart + '//a[text()]';
						// var charts_all_values = browser.getText(myChart_drilldown);
					}else if(widgetName == 'Concentration Report Chart Builder'){
						this.pie_charts_value_length = this.concentrationReportList.length;
						// charts_all_values = this.concentrationReportList;
					}else{
						// charts_all_values no used for the moment,but may be use in feature
						// var pie_charts_value_xpath = myPanel + content_xpath.pie_chart_value3;
						// browser.waitForVisible(pie_charts_value_xpath,this.wait10);
						// var charts_all_values = browser.getText(pie_charts_value_xpath);
					}
					// this.chartName and this.pie_charts_value_length come form pie-charts steps
					// Then_I_should_see_the_chart_with_#_#_under_the_#_section_to_#_the_following_chart_data.js
					console.log(this.chartName);
					// console.log(charts_all_values);
					console.log(this.pie_charts_value_length);
					// if(widgetName == 'Concentration Report Chart Builder'){
					// 	// the sum should be 100%
					// 	var total = 0;
					// 	var listValue = Array.isArray(charts_all_values) ? charts_all_values : [charts_all_values];
					// 	for(var i=0;i<listValue.length;i++){
					// 		var tmp = listValue[i].split(':')
					// 		total = total + parseFloat(tmp[tmp.length-1].trim());
					// 		console.log(total);
					// 	}
					// 	expect(parseInt(Math.abs(parseInt(total)-100))).toBeLessThanOrEqual(1);
					// }
					break;
					// break;
				case 'bar chart': // for manager
					// Then_I_should_see_the_chart_with_#_#_under_the_#_section_to_#_the_following_chart_data.js
					// var myChart = myPanel + content_xpath.namedChart.replace('__NAME__', this.chartName);
					if(mode == 'manager'){
						var myChart_legend = myPanel + content_xpath.chartLegend;
						console.log(myChart_legend);
						var myChart_legendText = browser.getText(myChart_legend);
						// console.log(myChart_legendText);
						myChart_legendText = myChart_legendText.filter(function(item){ return item.length != 0});
						this.pie_charts_value_length = myChart_legendText[0].split('\n').length;
						// console.log(this.pie_charts_value_length);
					}else{
						// deal
						var bar_charts_labels_xpath = myPanel + content_xpath.bar_chart_labels;
						browser.waitForVisible(bar_charts_labels_xpath, this.waitDefault);
						var bar_charts_all_labels = browser.getText(bar_charts_labels_xpath).split('\n');
						this.pie_charts_value_length = bar_charts_all_labels.length;
						// console.log(bar_charts_all_labels);
						console.log(this.pie_charts_value_length);
						console.log(this.portfolio)
						// // get tooltip value 
						// // charts_all_values is no used,but may be use in feature
						if(filetype == 'CSV' && this.deal == "Wachovia Bank Commercial Mortgage Trust 2007-C32" || this.portfolio == "Portfolio-CMBS_-for-automation" ){
							// only for CMBS
							var charts_all_values = [];
							for(var i=0;i<bar_charts_all_labels.length;i++){
								var item_xpath = bar_charts_labels_xpath + '//span[contains(text(),"'+ bar_charts_all_labels[i] +'")]';
								console.log(item_xpath);
								// sometimes it will not get the value
								if(i == 0 || i == bar_charts_all_labels.length-1){
									browser.moveToObject(item_xpath,offsetX,offsetY);	
								}
								browser.moveToObject(item_xpath,offsetX,offsetY);
								browser.pause(1000);
								var tooltip_xpath = myPanel + content_xpath.bar_chart_tooltip;
								var tooltip_xpath2 = myPanel + content_xpath.bar_chart_tooltip2;
								if(browser.isVisible(tooltip_xpath)){
									var tooltip_value = browser.getText(tooltip_xpath);
								}else if(browser.isVisible(tooltip_xpath2)){
									var tooltip_value = browser.getText(tooltip_xpath2);
								}else{
									var tooltip_value = undefined;
								}

								charts_all_values.push(tooltip_value);
							}
							console.log(charts_all_values);
							this.charts_all_values = charts_all_values;
						}
					}
					break;
				case 'area chart': // manager -> Assets Under Management
					if(mode == 'manager'){
						var myChart_legend = myPanel + content_xpath.chartXLabel;
						console.log(myChart_legend);
						var myChart_legendText = browser.getText(myChart_legend);
						console.log(myChart_legendText);
						this.pie_charts_value_length = myChart_legendText.length;
						console.log(this.pie_charts_value_length);
					}else if(widgetName == 'Simplified Supervisory Formula Approach (SSFA)'){
						var chart = '(//*[contains(@class,"highcharts-markers") and contains(@class,"highcharts-series-")])[1]';
						var isVisible = browser.isVisible(chart);
						console.log("isVisible: " + isVisible);
						if(isVisible){
						 	var allValue = browser.elements(chart + '//*[@class]')['value'];
						 	// console.log(allValue);
						 	this.pie_charts_value_length = allValue.length;
						}else{
							this.pie_charts_value_length = 0;	
						}
					}
					break;
				case 'charts':
					break;
			}

			var filetype_list = [];
			switch(filetype){
				case 'XLS/CSV':
					filetype_list = ['CSV','XLS'];
					break;
				case 'CSV':
					filetype_list.push('CSV');
					break;
				case 'XLS':
					filetype_list.push('XLS');
					break;
				default:
					filetype_list.push('CSV');
			}
      if (!process.env.BROWSER.startsWith('IE')) {
        browser.touchScroll(browser.element(myPanel).value['ELEMENT'],0,200);
      }
			browser.pause(500);
			browser.click(download_icon_xpath);
			this.file_target_data = [];
			var today = this.time_lib.getTime();
			// var moment = require('moment');
			// var today = moment().local().format('DD-MMM-YYYY');
			for(var i=0;i<filetype_list.length;i++){
				var myExportTextIcon = download_icon_xpath + download_xpath.file_type_text.replace('__FILETYPENAME__',filetype_list[i]);
				switch(widgetName){
					case 'Collateral Summary':
					case 'Deal Overview':
						// cmbs deal summary
						var fileName = this.deal + '_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					// case 'Pool(s)':
					// 	var fileName = this.deal + '_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
					// 	break;
					case 'Capital Structure':
						if(this.deal == 'Dell Equipment Finance Trust 2016-1'||this.deal == 'Flexi ABS Trust 2017-1'
							||this.deal == 'Mercedes-Benz Auto Lease Trust 2017-A'||this.deal == 'SC Germany Auto 2018-1 UG (haftungsbeschraenkt)'
							||this.deal == 'American Express Credit Account Master Trust, Series 2017-2'||this.deal == 'Penarth Master Issuer plc'
							||this.deal == 'Navient Student Loan Trust 2014-1'||this.deal == 'SLM Student Loan Trust 2004-8'
							||this.deal == 'SC GERMANY AUTO 2019-1 UG (haftungsbeschraenkt)'){
							var fileName = this.deal + '_' + widgetName + ' ABS_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Wachovia Bank Commercial Mortgage Trust 2007-C32'){
							// Wachovia Bank Commercial Mortgage Trust 2007-C32_Capital Structure CMBS_05-Aug-2018
							var fileName = this.deal + '_' + widgetName + ' CMBS_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == 'Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1' || this.deal == 'MADRID RMBS IV, FTA'){
							var fileName = this.deal + '_' + widgetName + ' ABS_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else{
							var fileName = this.deal + '_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						break;
					case 'Key Differentiators':
						if(this.page == 'Tranches' && this.deal == 'Madison Park Funding XI, Ltd.'){
							var fileName = this.deal + ' - PS_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.page == 'Tranches' && (this.deal == 'Dell Equipment Finance Trust 2016-1'
							||this.deal == 'Flexi ABS Trust 2017-1'||this.deal == 'Navient Student Loan Trust 2014-1')){
							var fileName = this.deal + ' - A1_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.page == 'Tranches' && this.deal == 'Dryden 48 Euro CLO 2016 B.V.'){
							var fileName = this.deal + ' - XR_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.page == 'Tranches' && this.deal == 'Mercedes-Benz Auto Lease Trust 2017-A'){
							var fileName = this.deal + ' - A4_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.page == 'Tranches' && this.deal == 'SC Germany Auto 2018-1 UG (haftungsbeschraenkt)'){
							var fileName = this.deal + ' - A_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.page == 'Tranches' && this.deal == 'SLM Student Loan Trust 2004-8'){
							var fileName = this.deal + ' - A5_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.page == 'Tranches' && this.deal == 'American Express Credit Account Master Trust, Series 2017-2'){
							var fileName = this.deal + ' - 20172A_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.page == 'Tranches' && this.deal == 'Penarth Master Issuer plc'){
							var fileName = this.deal + ' - A1-1601_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.page == 'Tranches' && this.deal == 'Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1'){
							// Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1 - M-1_Key Differentiators_05-Sep-2018
							var fileName = this.deal + ' - M-1_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.page == 'Tranches' && this.deal == 'MADRID RMBS IV, FTA'){
							// Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1 - M-1_Key Differentiators_05-Sep-2018
							var fileName = this.deal + ' - C_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.tab == 'Tranche' && this.page == 'Enhanced BWIC'){
							// Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1 - M-1_Key Differentiators_05-Sep-2018
							var fileName = 'Avery Point V CLO, Limited - AR_Key Differentiators' + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else{
							var fileName = this.deal + '_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						break;
					case 'Market Color and Estimated Valuation':
						if(this.deal == 'Madison Park Funding XI, Ltd.'){
							var fileName = 'Madison Park Funding XI, Ltd. - PS_MARKET COLOR AND ESTIMATED VALUATION_'+ today + '.' + filetype_list[i].toLowerCase();
							//var fileName = this.deal + ' - PS_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Dell Equipment Finance Trust 2016-1'
							||this.deal == 'Flexi ABS Trust 2017-1'||this.deal == 'Navient Student Loan Trust 2014-1'){
							var fileName = this.deal + ' - A1_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Dryden 48 Euro CLO 2016 B.V.'){
							var fileName = this.deal + ' - XR_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Mercedes-Benz Auto Lease Trust 2017-A'){
							var fileName = this.deal + ' - A4_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'SC Germany Auto 2018-1 UG (haftungsbeschraenkt)'){
							var fileName = this.deal + ' - A_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'SLM Student Loan Trust 2004-8'){
							var fileName = this.deal + ' - A5_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'American Express Credit Account Master Trust, Series 2017-2'){
							var fileName = this.deal + ' - 20172A_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Penarth Master Issuer plc'){
							var fileName = this.deal + ' - A1-1601_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == 'Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1'){
							var fileName = this.deal + ' - M-1_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == 'MADRID RMBS IV, FTA'){
							var fileName = this.deal + ' - C_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						break;
					case 'Simplified Supervisory Formula Approach (SSFA)':
						if(this.deal == 'Madison Park Funding XI, Ltd.'){
							var fileName = this.deal + ' - PS_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Dell Equipment Finance Trust 2016-1'
							||this.deal == 'Flexi ABS Trust 2017-1'||this.deal == 'Navient Student Loan Trust 2014-1'){
							var fileName = this.deal + ' - A1_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Dryden 48 Euro CLO 2016 B.V.'){
							var fileName = this.deal + ' - XR_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Mercedes-Benz Auto Lease Trust 2017-A'){
							var fileName = this.deal + ' - A4_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'SC Germany Auto 2018-1 UG (haftungsbeschraenkt)'){
							var fileName = this.deal + ' - A_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'SLM Student Loan Trust 2004-8'){
							var fileName = this.deal + ' - A5_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'American Express Credit Account Master Trust, Series 2017-2'){
							var fileName = this.deal + ' - 20172A_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Penarth Master Issuer plc'){
							var fileName = this.deal + ' - A1-1601_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == 'Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1'){
							var fileName = this.deal + ' - M-1_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == 'MADRID RMBS IV, FTA'){
							var fileName = this.deal + ' - C_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						break;
					case 'Test Summary':
						var fileName = this.deal + '_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Asset Level':
						// var url = browser.getUrl();
						// console.log('url: ' + url);
						var fileName = this.deal + '_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Market Value Metrics (Biz Rules)':
						if(this.deal == 'Dell Equipment Finance Trust 2016-1'
							||this.deal == 'Flexi ABS Trust 2017-1'||this.deal == 'Navient Student Loan Trust 2014-1'){
							var fileName = this.deal + ' - A1_MARKET VALUE METRICS (Biz Rules)' + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Dryden 48 Euro CLO 2016 B.V.'){
							var fileName = this.deal + ' - XR_MARKET VALUE METRICS (Biz Rules)' + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Mercedes-Benz Auto Lease Trust 2017-A'){
							var fileName = this.deal + ' - A4_MARKET VALUE METRICS (Biz Rules)' + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'SC Germany Auto 2018-1 UG (haftungsbeschraenkt)'){
							var fileName = this.deal + ' - A_MARKET VALUE METRICS (Biz Rules)' + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'SLM Student Loan Trust 2004-8'){
							var fileName = this.deal + ' - A5_MARKET VALUE METRICS (Biz Rules)' + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'American Express Credit Account Master Trust, Series 2017-2'){
							var fileName = this.deal + ' - 20172A_MARKET VALUE METRICS (Biz Rules)' + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Penarth Master Issuer plc'){
							var fileName = this.deal + ' - A1-1601_MARKET VALUE METRICS (Biz Rules)' + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Madison Park Funding XI, Ltd.'){
							//PS is the class of the tranche
							var fileName = this.deal + ' - PS_MARKET VALUE METRICS (Biz Rules)' + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == 'Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1'){
							// Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1 - M-1_MARKET VALUE METRICS (Biz Rules)_05-Sep-2018
							var fileName = this.deal + ' - M-1_MARKET VALUE METRICS (Biz Rules)' + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == 'MADRID RMBS IV, FTA'){
							// MADRID RMBS IV, FTA - C_SIMPLIFIED SUPERVISORY FORMULA APPROACH (SSFA)_09-Nov-2018.csv
							var fileName = this.deal + ' - C_MARKET VALUE METRICS (Biz Rules)' + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						break;
					case 'Tickers':
						if(this.deal == 'Dell Equipment Finance Trust 2016-1'
							||this.deal == 'Flexi ABS Trust 2017-1'||this.deal == 'Navient Student Loan Trust 2014-1'){
							var fileName = this.deal + ' - A1_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Dryden 48 Euro CLO 2016 B.V.'){
							var fileName = this.deal + ' - XR_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Mercedes-Benz Auto Lease Trust 2017-A'){
							var fileName = this.deal + ' - A4_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Madison Park Funding XI, Ltd.'){
							var fileName = this.deal + ' - PS_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'SC Germany Auto 2018-1 UG (haftungsbeschraenkt)'){
							var fileName = this.deal + ' - A_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}	
						else if(this.deal == 'SLM Student Loan Trust 2004-8'){
							var fileName = this.deal + ' - A5_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'American Express Credit Account Master Trust, Series 2017-2'){
							var fileName = this.deal + ' - 20172A_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Penarth Master Issuer plc'){
							var fileName = this.deal + ' - A1-1601_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == 'Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1'){
							var fileName = this.deal + ' - M-1_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == 'MADRID RMBS IV, FTA'){
							var fileName = this.deal + ' - C_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						break;
					case 'News/Alerts':
						if(this.page == 'Tranches' && (this.deal == 'Dell Equipment Finance Trust 2016-1'
							||this.deal == 'Flexi ABS Trust 2017-1'||this.deal == 'Navient Student Loan Trust 2014-1'||this.deal == 'SLM Student Loan Trust 2004-8')){
							var fileName = this.deal + ' - A1_' + widgetName.replace('/','_').toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
							console.log(fileName);
						}
						else if(this.page == 'Tranches' && this.deal == 'Dryden 48 Euro CLO 2016 B.V.'){
							var fileName = this.deal + ' - XR_' + widgetName.replace('/','_').toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.page == 'Tranches' && this.deal == 'SC Germany Auto 2018-1 UG (haftungsbeschraenkt)'){
							var fileName = this.deal + ' - A_' + widgetName.replace('/','_').toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.page == 'Tranches' && this.deal == 'Mercedes-Benz Auto Lease Trust 2017-A'){
							var fileName = this.deal + ' - A4_' + widgetName.replace('/','_').toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.page == 'Tranches' && this.deal == 'American Express Credit Account Master Trust, Series 2017-2'){
							var fileName = this.deal + ' - 20172A_' + widgetName.replace('/','_').toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.page == 'Tranches' && this.deal == 'Penarth Master Issuer plc'){
							var fileName = this.deal + ' - A1-1601_' + widgetName.replace('/','_').toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.page == 'Tranches' && this.deal == 'Madison Park Funding XI, Ltd.'){
							var fileName = this.deal + ' - A1A_' + widgetName.replace('/','_').toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.page == 'Tranches' && this.deal == 'MADRID RMBS IV, FTA'){
							var fileName = this.deal + ' - A1_' + widgetName.replace('/','_').toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.page == 'Tranches' && this.deal == 'Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1'){
							var fileName = this.deal + ' - A-H_' + widgetName.replace('/','_').toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else{
							var fileName = this.deal + '_' + widgetName.replace('/','_').toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						break;
					case 'Characteristics':
						if(this.deal == 'Dell Equipment Finance Trust 2016-1'
							||this.deal == 'Flexi ABS Trust 2017-1'||this.deal == 'Navient Student Loan Trust 2014-1'){
							var fileName = this.deal + ' - A1_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Dryden 48 Euro CLO 2016 B.V.'){
							var fileName = this.deal + ' - XR_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Mercedes-Benz Auto Lease Trust 2017-A'){
							var fileName = this.deal + ' - A4_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'SC Germany Auto 2018-1 UG (haftungsbeschraenkt)'){
							var fileName = this.deal + ' - A_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'SLM Student Loan Trust 2004-8'){
							var fileName = this.deal + ' - A5_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'American Express Credit Account Master Trust, Series 2017-2'){
							var fileName = this.deal + ' - 20172A_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Penarth Master Issuer plc'){
							var fileName = this.deal + ' - A1-1601_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Madison Park Funding XI, Ltd.'){
							var fileName = this.deal + ' - PS_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.pagetype == 'loan'){
							//var fileName = 'W001NL013TB01_LX169662_' + this.loan.replace(/\//g,'_') + '_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
							var fileName = 'W001NL013TB01_LX169662_Weight Watchers International, Inc. Initial Term Loan_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == 'Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1'){
							// Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1 - M-1_CHARACTERISTICS_05-Sep-2018
							var fileName = this.deal + ' - M-1_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == 'MADRID RMBS IV, FTA'){
							var fileName = this.deal + ' - C_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						break;
					case 'Solely for payments of Principal and Interest (SPPI) Metrics':
						if(this.deal == 'Dell Equipment Finance Trust 2016-1'){
							var fileName = this.deal + ' - A1_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						if(this.deal == 'Dryden 48 Euro CLO 2016 B.V.'){
							var fileName = this.deal + ' - XR_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						if(this.deal == 'Flexi ABS Trust 2017-1'){
							var fileName = this.deal + ' - D_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						if(this.deal == 'Navient Student Loan Trust 2014-1'){
							var fileName = this.deal + ' - A2_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Mercedes-Benz Auto Lease Trust 2017-A'){
							var fileName = this.deal + ' - A4_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'SC Germany Auto 2018-1 UG (haftungsbeschraenkt)'){
							var fileName = this.deal + ' - A_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'SLM Student Loan Trust 2004-8'){
							var fileName = this.deal + ' - A5_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'American Express Credit Account Master Trust, Series 2017-2'){
							var fileName = this.deal + ' - 20172A_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Penarth Master Issuer plc'){
							var fileName = this.deal + ' - A1-1601_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Madison Park Funding XI, Ltd.'){
							var fileName = this.deal + ' - PS_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == 'Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1'){
							// Structured Agency Credit Risk (STACR) Debt Notes, Series 2016-DNA1 - M-1_CHARACTERISTICS_05-Sep-2018
							var fileName = this.deal + ' - M-1_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == 'MADRID RMBS IV, FTA'){
							var fileName = this.deal + ' - C_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == 'Halcyon Loan Advisors Funding 2014-2 Ltd.'){
							var fileName = this.deal + ' - A1AR_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						break;
					case 'Overlap Matrix':
						if(this.deal == 'Dryden 48 Euro CLO 2016 B.V.'){
							var fileName = this.deal + '_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Madison Park Funding XI, Ltd.'){
							var fileName = this.deal + '_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}	
						break;
					case 'Overlap Results':
						if(this.deal == 'Dryden 48 Euro CLO 2016 B.V.'){
							var fileName = this.deal + '_OVERLAP GRID' + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Madison Park Funding XI, Ltd.'){
							var fileName = this.deal + '_OVERLAP GRID' + '_' + today + '.' + filetype_list[i].toLowerCase();
						}	
						break;				
					case 'Comparison Results': 
						var selectedTab = browser.getText(content_xpath.selectedComparisonTab1);
						console.log(selectedTab)
						var fileName = 'Deal - Deal Comparison Results - Category_ ' + selectedTab.replace(/\//g,'_') + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Concentration Report Chart Builder': // deal and manager mode
						var selected_value_xpath = download_xpath.selected_value_xpath;
						browser.waitForVisible(selected_value_xpath,this.waitDefault);
						var selected_value = browser.getText(selected_value_xpath);
						console.log(selected_value);
						// GSO _ Blackstone Debt Funds Management_Concentration Report Chart Builder-Asset Type_21-Jun-2018.csv
						var fileName = this[mode].replace('/','_') + '_' + widgetName + '-' + selected_value.trim() + '_' + today + '.' + filetype_list[i].toLowerCase();
						// var fileName = this[mode].replace('/','_') + '_' + widgetName.toUpperCase() + '-' + selected_value.trim() + '_' + today + '.' + filetype_list[i].toLowerCase();
						// if (this.deal == 'Madison Park Funding XI, Ltd.'){
						// 	fileName = 'MADPK11_' + widgetName + '-' + selected_value.trim() + '_' + today + '.' + filetype_list[i].toLowerCase();
						// }
						break;
					case 'Asset Price Distribution': // manager chart
					case 'Rating Distribution':
					case 'Assets Under Management':
						var fileName = this[mode].replace('/','_') + '_' + widgetName.replace('/','_').toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'biggest defaulted assets':
					case 'highest priced performing assets':
					case 'lowest priced performing assets':
					case 'Collateral DM/Yield Distribution': // for deal and manager
						// for manager
						//GSO _ Blackstone Debt Funds Management_Collateral DM Distribution_20-Apr-2018.csv
						if(mode == 'manager'){
							const selectOption_xpath = this.xpath_lib.xpathRequire('selectOption_xpath');
							var selectedTab_xpath = myPanel + selectOption_xpath.md_selectXpath + '//*[contains(@class,"md-select-value")]'
							console.log(selectedTab_xpath);
							var selectText = browser.getText(selectedTab_xpath);
							var fileName = this[mode].replace('/','_') + '_Collateral ' + selectText + ' Distribution_' + today+ '.' + filetype_list[i].toLowerCase();
							break;
						}
						// for deal
						var widgetArr = widgetName.toLowerCase().split(' ');
						var filewidget = '';
						for(var index in widgetArr){
								filewidget += widgetArr[index].substring(0,1).toUpperCase()+widgetArr[index].substring(1)+' ';
						}
						console.log("filewidget:",filewidget);
						var fileName = this.deal + '_' + filewidget.substring(0,filewidget.length-1) +'_'+ today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Asset Type':
					case 'Current Balance':
					case 'Geography':
					case 'Industry':
					case 'Obligor Concentration':
					case 'Original Term':
					case 'Remaining Term':
					case 'APR of Receivables':
					case 'Delinquency Experience':
					case 'Scheduled Termination Date':
					case 'FICO Score':
					case 'Loan To Value':
					case 'Vehicle Type':
					case 'Vehicle Model':
					case 'Market Spreads':
						var fileName = widgetName +'_'+ today +'.' + filetype_list[i].toLowerCase();
						break;
					case 'biggest caa/ccc assets':
						var fileName = this.deal + '_' + 'Biggest Caa_CCC Assets_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Deal Documents':
						var fileName = this.deal + '_' + widgetName.replace('/','_').toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						var title = chartTtile['deal']['Deal Documents'].split(' :: ');
						if(this.tabName == 'All'){
							var thead = title[0];
						}
						else if(this.tabName == 'Trustee Reports'){
							var thead = title[1];
						}
						else if(this.tabName == 'Notices'){
							var thead = title[2];
						}
						else if(this.tabName == 'Closing Documents'){
							var thead = title[3];
						}
						else if(this.tabName == 'Research'){
							var thead = title[4];
						}
						console.log(this.tabName);
						console.log(thead);
						break;
					case 'Deals with Largest Exposure to This Asset':
					  console.log('this.loan : ' + this.loan);					  
						var fileName = 'W001NL013TB01_LX169662_Weight Watchers International, Inc. Weight Watchers T_L B 1L 11_17_DEALS WITH LARGEST EXPOSURE TO THIS ASSET' +  '_' +  today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Managers with Largest Exposure to This Asset':
						//This is for CLO loan page table download.
						console.log('this.loan : ' + this.loan);
						var fileName = 'W001NL013TB01_LX169662_Weight Watchers International, Inc. Weight Watchers T_L B 1L 11_17_MANAGERS WITH LARGEST EXPOSURE TO THIS ASSET' + '_' + today+ '.' + filetype_list[i].toLowerCase();
						break;
					case 'Asset Price History':
					case 'EDF History':
					case 'Financial Ratio History':
						//This is for CLO loan page chart download.
						var fileName = 'W001NL013TB01_LX169662_Weight Watchers International, Inc. Weight Watchers T_L B 1L 11_17' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'BWIC Analyzer:':
						// BWIC_04-May-2018
						var fileName = 'BWIC_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case "SSFA Projections":
						if (button == "Current") {
							// For SSFA Porjection, must run step When_I_set_the_#_under_the_#_panel-heading_to_#_in_SSFA_page.js
							var tranchename = this.selected_tranche;
							var scenarioname = this.selected_scenario;
							var fileName = tranchename + '_' + scenarioname + '_' + today + '.' + filetype_list[i].toLowerCase();
							if(this.deal == 'Merrill Lynch Mortgage Trust 2008-C1'){
								fileName =  this.deal + '_SSFA PROJECTIONS RESULTS_' + fileName;
							}
						}
						break;
						case "Cashflows":
						if (button == "Current") {
							// For SSFA Porjection, must run step When_I_set_the_#_under_the_#_panel-heading_to_#_in_SSFA_page.js
							var tranchename = this.selected_tranche;
							var fileName = this.deal + '_SCENARIO CASHFLOWS_' + tranchename + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						break;
					case "Tranche/Collateral Summary":
						var fileName = this.deal + '_SCENARIO CASHFLOWS_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case "OTTI Analysis Results":
						var fileName = this.deal + '_OTTI ANALYSIS RESULTS FOR  OTTI TYPE_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Delinquencies Distribution':
					case 'Loan Balance Distribution':
					case 'LTV Distribution':
					case 'NOI Distribution':
					case 'DSCR Distribution':
					case 'Top Ten Largest Loans':
					case 'Top Ten Delinquent Loans':
					case 'Top Ten Specially Serviced Loans':
					case 'Top Ten State Concentrations':
					case 'Top Ten Property Types':
					case 'Top Ten MSA Concentrations':
					case 'Top Ten Appraisal Reduction Loans':
						var fileName = this.deal + '_' + widgetName.replace('/','_') + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Loan Level Summary':
						var url = browser.getUrl();
						console.log('url: ' + url);
						// 820349351_Asset Level_08-Jun-2018.csv
						var fileName = url.substr(url.lastIndexOf('/') + 1)+ '_' + 'Asset Level' + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'New Deals':
					case 'Ratings Transitions':
						var fileName = widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'CLO Key Differentiators 25/50/75 Percentile Vintage Analysis':
						var fileName = widgetName.replace('/','_').replace('/','_').toUpperCase() + '_Date_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Universal Alerts':
						var fileName = 'Dashboard_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Performance Report Chart Builder':
						var fileName = 'PERFORMANCE REPORT_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Deals':
						var fileName = 'List of Pre-pricing Deals_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Results':
						console.log('this.deal:',this.deal)
						if(this.deal == 'Dell Equipment Finance Trust 2016-1'){
							var fileName = 'DEFT16-1' + '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Flexi ABS Trust 2017-1'){
							var fileName = 'FLEXIABS171' + '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'SLM Student Loan Trust 2004-8'){
							var fileName = '' + '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'American Express Credit Account Master Trust, Series 2017-2'){ 
							var fileName = '' + '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Penarth Master Issuer plc'){
							var fileName = '' + '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else if(this.deal == 'Madison Park Funding XI, Ltd.'){
							var fileName = '' + '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == 'Merrill Lynch Mortgage Trust 2008-C1'){
							// CMBS_MLM080C1-Cashflow_19-Jul-2018.xls
							var fileName = 'CMBS_MLM080C1' + '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == '830818196'){
							var fileName = 'DEFT2019-1' + '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == '824673751'){
							var fileName = 'FD2015-C' + '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == '820349351'){
							var fileName = 'CMBS_WBC07C32' + '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.deal == '822051530'){
							var fileName = 'MADRMBS0IV' + '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase(); 
						}else if(this.deal == '823889570'){
							var fileName = 'NAVIENT2014-1' + '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase(); 
						}else {
							var fileName = this.deal+ '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase();
						}
						// else if(this.deal == 'Neuberger Berman Loan Advisers CLO 30, Ltd.'){
						// 	var fileName = 'NB_30' + '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase();
						// }else if(this.deal == 'NovaStar ABS CDO I, Ltd.'){
						// 	var fileName = 'NOVASTAR' + '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase();
						// }else if(this.deal == 'GSC ABS CDO 2006-4u, Ltd.'){
						// 	var fileName = 'GSC064U' + '-Cashflow_' + today + '.' + filetype_list[i].toLowerCase();
						// }
						break;
					case 'Edit Deal':
						console.log(this.deal);
						if(this.deal == 'Madison Park Funding XI, Ltd.'){
								var today = this.settleDate;
								console.log('today: '+today);
								var fileName = 'collateral_MADPK11_'+today+'.'+  filetype_list[i].toLowerCase();
						}
						break;
					case 'Tranche Level Universe: CLO':
					case 'Tranche Level Universe: AUTO':
					case 'BWIC List: User Input BWIC List':
					case 'BWIC List: User Input BWIC List for CMBS':
					case 'BWIC List: User Input BWIC List for Mix':
						var fileName = widgetName.replace(':','').replace('/','_') + ' - Enhanced BWIC_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Key Stats: Portfolio-CLO-for-automation':
						var fileName = 'Portfolio Portfolio-CLO-for-automation - Enhanced BWIC_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Key Stats: Portfolio-All-for-automation':
						var fileName = 'Portfolio Portfolio-All-for-automation - Enhanced BWIC_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Key Stats: Portfolio-RMBS-for-automation':
					  var fileName = 'Portfolio Portfolio-RMBS-for-automation - Enhanced BWIC_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Total Collateral Balance (millions)':
					  var fileName = 'Portfolio-CLO-for-automation_ Collateral Balance (millions)- Drilldown_' + today + '.' + filetype_list[i].toLowerCase()
					case 'BWIC List: CLO/ CBO':
					case 'Dealer Inventory: ALL':
					  browser.pause(10000);
						var fileName = widgetName.replace(':','').replace('/','_') + ' - Enhanced BWIC_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Historical Payments':
					  browser.pause(100);
					  // if(this.deal==undefined){
					  // 	var fileName = 'Mountain View CLO 2017-2 Ltd._'+widgetName.replace('/','_').toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
					  // }
					  var fileName = this.deal + '_' + widgetName.replace('/','_').toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
					  break;
					case 'Country Distribution':
					  var fileName = this.deal + '_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					default:
						var fileName = this.deal + '_' + widgetName.replace('/','_').toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
				}
				console.log('fileName: ' + fileName);
				this.file_session.deleteFiles(fileName);
				try{
					browser.waitForVisible(myExportTextIcon,this.wait10);
				}catch(error){
					browser.click(download_icon_xpath);
					browser.waitForVisible(myExportTextIcon,this.wait10);
				} 
				console.log(myExportTextIcon);
				browser.click(myExportTextIcon);
				// browser.pause(1*1000);
				// For IE we need to click the save button
	      if (process.env.BROWSER == 'IE11') {
	        browser.pause(5*1000);
	        this.robot_session.clickImage(null, 'IE11_DownloadSave.png');
	        browser.pause(10*1000);
	        this.robot_session.clickImage(null, 'IE11_DownloadDismissX.png');
	        browser.pause(1000);
	      }
			 var my_download_file = this.file_session.waitForDownload(browser,fileName);
			 //update by Chester on 3/18/2020, for above method will lock the process
			 //update by Chester on 3/27/2020, below method failed in AT, use the origial method and comment out below
			 //var my_download_file = this.file_session.getDownloadFileName(fileName,filetype_list[i].toLowerCase())['filePath'];
		 	if(mode == 'stored deal'){
				console.log('my download file: ' + my_download_file);
				var save_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res',fileName);
				console.log('save_path',save_path)
				console.log('copy file...');
				this.file_session.copyFile(my_download_file,save_path);
				// fs.copyFile(my_download_file,save_path)
				return
		  }
			console.log('my download file: ' + my_download_file);
			switch(filetype_list[i]){
				case 'CSV':
					// var fs = require('fs');
					var file_content = fs.readFileSync(my_download_file,{encoding:'utf-8'});
					// console.log('thead:' + thead);
					// if(thead){
					// 	var thead_str = thead.join('","').trim();
					// 	console.log(thead_str);
					// }
					// if(widgetName != 'Deal Documents'){
					// 	var ui_header = thead_str;
					// }
					if(isClickwrap !='clickwrap mode'&&this.deal != 'Papier Union and PMF'&&this.deal != 'CMA CGM S.A.'&&this.deal != 'Flint Group Finance B.V'&&this.deal != 'Hapag-Lloyd'
						&&this.deal != 'MSC Treasury Limited'&&this.deal != 'X-Press Feeders Funding S.A.R.L'){
						expect(file_content.toLowerCase().indexOf('undefined') == -1).toBe(true,my_download_file + ': This file contains undefined');
					}
					//expect(file_content.toLowerCase().indexOf('undefined') == -1).toBe(true,my_download_file + ': This file contains undefined');
					break;
				case 'XLS':
					// var file_content = this.file_session.readHtmlAsCsvString(my_download_file,true);
					console.log()
					var file_content = this.file_session.parseHtmlToCsv(my_download_file);
					// if(thead){
					// 	console.log(thead);
					// 	var thead_str = thead.join(',').trim();
					// 	console.log(thead_str);
					// }
					// if(widgetName != 'Deal Documents'){
					// 	var ui_header = thead_str;
					// }
					if(isClickwrap !='clickwrap mode'&&this.deal != 'Papier Union and PMF'&&this.deal != 'CMA CGM S.A.'&&this.deal != 'Flint Group Finance B.V'&&this.deal != 'Hapag-Lloyd'
						&&this.deal != 'MSC Treasury Limited'&&this.deal != 'X-Press Feeders Funding S.A.R.L'){
						expect(file_content.toLowerCase().indexOf('undefined') == -1).toBe(true,my_download_file + ': This file contains undefined');
					}
					//expect(file_content.toLowerCase().indexOf('undefined') == -1).toBe(true,'This file contains undefined');
					break;
			}
			console.log('file_content: ' + file_content);
			switch(widgetType){
				case 'table':
					this.file_target_data = [];
					var header_index_infile = undefined;
					var table_array = file_content.replace(/\r/g,'').split('\n');
					// if(widgetName == 'Deal Overview'){
					// 	this.file_target_data.push(table_array);
					// 	break;
					// }
					// console.log('table_array: ' + table_array);
					// console.log('thead : ' + thead.replace(/["\s,]/g,''));
					// console.log(table_array);
					var len = table_array.length;
					// console.log('len:' + len);
					for(var i=0;i<len;i++){
						var item = table_array[i];
						if(item.replace(/[",\s]/g,'').indexOf(thead.replace(/["\s,]/g,'')) != -1){
							header_index_infile = i;
							break;
						}
					}
					console.log('header_index_infile: '+header_index_infile);
					if(widgetName == 'Notable Metrics'||widgetName == 'Tickers'||widgetName == 'Characteristics'){
						header_index_infile = header_index_infile - 1;
					}
					if(widgetName == 'Deal Documents'){
						header_index_infile = header_index_infile + 1;
					}
					if(widgetName == 'Deal Overview'){
						header_index_infile = header_index_infile - 2;
						table_length = table_length + 3;
					}
					var target_data = table_array.slice(header_index_infile,header_index_infile + 1+ table_length);
					// console.log('filetype_list[i]: ' + filetype_list[i] );
					// console.log("fileName.endsWith('csv'): " + fileName.endsWith('csv'));
					if(target_data[0]!= undefined && fileName.endsWith('csv')){
						// remove the space before and after for header
						// console.log('*****************');
						target_data[0] = target_data[0].split('","').map(function(curValue){return curValue.trim()}).join('","');
					}
					console.log('target_data[0]: ' + target_data[0]);
					this.file_target_data.push(target_data);
					break;
				case 'pie chart':
					var table_array = file_content.replace(/\r/g,'').split('\n');
					console.log(table_array);
					console.log("111111");
					if(filetype_list[i] == 'XLS'){
						var chart_name_index = table_array.indexOf( titleTextInCsv.replace(/"/g,'') ); //XLS
						if(chart_name_index == -1){
							chart_name_index = table_array.indexOf('"' + titleTextInCsv + '"');
						}
					}else{
						var chart_name_index = table_array.indexOf('"' + titleTextInCsv + '"');
						if(chart_name_index == -1){
							chart_name_index = table_array.indexOf('"' + titleTextInCsv + '",');
						}
					}
					console.log(chart_name_index);
					console.log(this.pie_charts_value_length);
					if(flag == true){
						var target_data = table_array.slice(chart_name_index, chart_name_index + 1 + this.pie_charts_value_length);
					}else{
						var target_data = table_array.slice(chart_name_index + 1,chart_name_index + 2 + this.pie_charts_value_length);	
					}
					// var target_data = table_array.slice(chart_name_index + 1,chart_name_index + 2 + this.pie_charts_value_length);
					console.log(target_data);
					break;
				case 'bar chart':
				case 'area chart':
					// for manager/deal
					var table_array = file_content.replace(/\r/g,'').split('\n');
					// console.log(table_array);
					var chart_name_index = undefined;
					console.log(titleTextInCsv.replace(/"/g,''));
					for(var i=0;i<table_array.length;i++){
						console.log(table_array[i].replace(/"/g,''));
						if(table_array[i].replace(/"/g,'').indexOf(titleTextInCsv.replace(/"/g,'')) != -1){
							chart_name_index = i;
							break;
						}
					}
					var target_data = table_array.slice(chart_name_index, chart_name_index + 1 + this.pie_charts_value_length);
					break;
				default:
					break;
			}
			this.file_target_data.push(target_data);
		  }	
		  
			console.log(this.file_target_data); 

		})
}
