// When_I_enter_the_following_data_in_the_#_tab.js
// CMBS portfolio cashflow 
module.exports = function() {
this.When(/^I enter the following data in the "([^"]*)" tab$/, function (tabName, table) {
		// Write code here that turns the phrase above into concrete actions
		var cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
		this.browser_session.waitForResource(browser);
		var root_path = cashflow_xpath.vectors;
		// cmbs cashflow xpath
		var xpathInfo = {
			'Prepayment':{
				'name':'//sfp-text-input[@ng-model="vectorCtrl.currPrePayVec[\'name\']"]//input',
				'name1':'//input[@ng-model="vectorCtrl.currPrePayVec[\'name\']"]',
				'assumption':'//md-select[@ng-model="vectorCtrl.currPrePayVec.vectorDetail.ppydefTypeCode"]',
				'apply_seasoning':'//md-select[@ng-model="vectorCtrl.currPrePayVec.vectorDetail.ppydefVector[\'vectorSeasoning\']"]',
				'month': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.prepay_periods_data[$index].month"]',
				'rate': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.prepay_periods_data[$index].rate"]',
			},
			'Default':{
				'name':'//sfp-text-input[@ng-model="vectorCtrl.currDefaultVec[\'name\']"]//input',
				'name1':'//input[@ng-model="vectorCtrl.currDefaultVec[\'name\']"]',
				'assumption':'//md-select[@ng-model="vectorCtrl.currDefaultVec.vectorDetail.ppydefTypeCode"]',
				'apply_seasoning':'//md-select[@ng-model="vectorCtrl.currDefaultVec.vectorDetail.ppydefVector[\'vectorSeasoning\']"]',
				'month': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.def_periods_data[$index].month"]',
				'rate': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.def_periods_data[$index].rate"]',
			},
			'Loss Vectors':{
				'name':'//sfp-text-input[@ng-model="vectorCtrl.currLossVec[\'name\']"]//input',
				'name1':'//input[@ng-model="vectorCtrl.currLossVec[\'name\']"]',
				'apply_seasoning':'//md-select[@ng-model="vectorCtrl.currLossVec.vectorDetail[\'vectorSeasoning\']"]',
				'month': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.loss_periods_data[$index].month"]',
				'rate': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.loss_periods_data[$index].rate"]',
			},
			'Asset Class Vectors':{
				'name':'//sfp-text-input[@ng-model="vectorCtrl.currAssetVec[\'name\']"]//input',
				'name1':'//input[@ng-model="vectorCtrl.currAssetVec[\'name\']"]',
				'apply_seasoning':'//md-select[@ng-model="vectorCtrl.currAssetVec.vectorDetail[\'vectorSeasoning\']"]',
				'vector_type':'//md-select[@ng-model="vectorCtrl.vectorType"]',
				'asset_class':'//*[@ng-model="vectorCtrl.assetClass"]',
				'month': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.asset_periods_data[$index].month"]',
				'rate': root_path + '//table[@class="table cftable vector-data"]//tr[__INDEX__]//*[@ng-model="vectorCtrl.asset_periods_data[$index].rate"]',
			}
		};

		var targetXpath = xpathInfo[tabName];
		console.log(targetXpath);

		var tableList = table.hashes();
		var name = tableList[0]['name'];
		var assumption = tableList[0]['assumption'];
		var apply_seasoning = tableList[0]['apply_seasoning'];
		var month = tableList[0]['month'].split(',');
		var rate = tableList[0]['rate'].split(',');
		var vector_type = tableList[0]['vector_type'];
		var asset_class = tableList[0]['asset_class'];

		// var moment = this.moment;
		// var postfixName = moment().format('Y-MM-DD');
		// var recordName = name + '_' + postfixName;
		var recordName = name;

		// delete same name entry
		var recordTable = root_path + '//table[@class="table table-striped"]';
		var deleteIcon = '//*[contains(@class,"glyphicon glyphicon-remove")]';
		var trXpath = recordTable + '//tbody/tr';
		var isExists = false;
		if(browser.isVisible(trXpath)){
			var trTmp = browser.getText(trXpath);
			console.log(trTmp);
			var trList = Array.isArray(trTmp)? trTmp : [trTmp];
			for(var i=0;i<trList.length;i++){
				if(trList[i].indexOf(recordName) != -1){
					// delete
					// console.log(trXpath + '['+ (i+1) +']' + deleteIcon);
					browser.click(trXpath + '['+ (i+1) +']' + deleteIcon);
					isExists = true;
					break;
				}
			}
		}

		if(isExists){
			// click create new button
			var content_xpath = this.xpath_lib.xpathRequire('content_xpath');
			var button_xpath = content_xpath.namedButton.replace('__NAME__', 'Create New');
			browser.click(button_xpath);
			try{
				browser.waitForVisible(targetXpath['name'],3*1000);
			}catch(e){
				browser.waitForVisible(targetXpath['name1'],3*1000);
			}
			
		}
		// input name for all
		try{
			browser.setValue(targetXpath['name'],recordName);
		}catch(e){
			console.log('try again: ' + targetXpath['name1']);
			browser.setValue(targetXpath['name1'],recordName);
		}
		browser.pause(100);

		// input month and rate for all
		for(var i=0;i<month.length;i++){
			var tmonth = month[i];
			var trate = rate[i];
			browser.setValue(targetXpath['month'].replace('__INDEX__',i+1),tmonth);
			browser.pause(100);
			browser.setValue(targetXpath['rate'].replace('__INDEX__',i+1),trate);
			browser.pause(100);
		}

		var menu = '//*[contains(@class,"md-clickable") and @aria-hidden="false"]';
		// set Apply Seasoning for all
		try{
			browser.click(targetXpath['apply_seasoning']);
			var target_apply_seasoning = menu+'//*[text()="' + apply_seasoning + '"]';
			browser.waitForVisible(target_apply_seasoning,this.waitDefault);
			console.log(browser.getText(menu));
			browser.click(target_apply_seasoning);
			browser.pause(500);
		}catch(e){}		

		// assumption
		if(assumption){
			browser.click(targetXpath['assumption']);
			var targetAssumption = menu+'//*[text()="' + assumption + '"]';
			browser.waitForVisible(targetAssumption,this.waitDefault);
			browser.click(targetAssumption);
			browser.pause(500);
		}

		if(vector_type){
			browser.click(targetXpath['vector_type']);
			var target_vector_type = menu + '//*[text()="'+ vector_type +'"]';
			browser.waitForVisible(target_vector_type,this.waitDefault);
			browser.click(target_vector_type);
			browser.pause(500);
			console.log(browser.getText(targetXpath['asset_class']));
		}
	});
}