// Recommended filename: When_I_create_a_new_#_tab_in_the_#_page.js
module.exports = function() {
  this.When(/^I create a new "([^"]*)" dashboard in the "([^"]*)" page$/, {timeout: process.env.StepTimeoutInMS}, function (dashBoardName, pageName) {
    // Write code here that turns the phrase above into concrete actions
    const dataViewerPage_xpath = this.xpath_lib.xpathRequire('dataViewerPage_xpath');

    var myDashBoardName = dashBoardName.replace('%%', process.env.DISPLAY);
    var myDataViewer_section = dataViewerPage_xpath.titled_Application_page.replace('__TITLE__', pageName);
    var myDashboard_tab = dataViewerPage_xpath.titled_Dashboard_tab.replace('__TITLE__', myDashBoardName);
    var myCreateDashboardIcon = dataViewerPage_xpath.createDashboard_icon;
    var myEditDashboardIcon = dataViewerPage_xpath.titled_actionIcon.replace('__TITLE__', 'Edit Current Dashboard Settings');
    var mydeleteButton = dataViewerPage_xpath.deleteButton;
    var mysaveButton = dataViewerPage_xpath.saveButton;
    var myDashBoardName_input = dataViewerPage_xpath.dashboardSettingsName_input;
    var myUINotification = dataViewerPage_xpath.actionMessage;

    // if action bar is collasped let's expand it
    var myCollaspedActionBar_xpath = dataViewerPage_xpath.actionBar_collasped;
    var myExpandActionBar_icon = dataViewerPage_xpath.titled_actionIcon.replace('__TITLE__', 'Expand Action Bar');
    if (browser.isVisible(myCollaspedActionBar_xpath)) {
      browser.click(myExpandActionBar_icon);
    }
    
    browser.waitForVisible(myCreateDashboardIcon, this.waitDefault*2);
    browser.pause(1000);
    try {
      browser.waitForVisible(myDashboard_tab, this.waitDefault);
    } catch(e) {}
    
    if (browser.isExisting(myDashboard_tab)) {
      browser.click(myDataViewer_section);
      browser.pause(1000);
      browser.click(myDashboard_tab);
      browser.pause(3000);
      browser.click(myEditDashboardIcon);
      browser.pause(1000);
      this.robot_session.clickAndEnter(browser, mydeleteButton);
      browser.waitForVisible(myUINotification, this.waitDefault);
      browser.waitForVisible(myUINotification, this.waitDefault, true);
    }
    browser.pause(1000);
    this.browser_session.waitForLoading(browser);
    browser.waitForVisible(myCreateDashboardIcon, this.waitDefault);
    browser.click(myCreateDashboardIcon);
    browser.pause(1000);
    browser.waitForVisible(myDashBoardName_input, this.waitDefault);
    browser.setValue(myDashBoardName_input, myDashBoardName);
    browser.pause(1000);
    browser.click(mysaveButton);
    browser.waitForVisible(myUINotification, this.waitDefault);
    browser.waitForVisible(myUINotification, this.waitDefault, true);
    this.browser_session.waitForLoading(browser);
    this.Dashboard = myDashBoardName;
  });
}