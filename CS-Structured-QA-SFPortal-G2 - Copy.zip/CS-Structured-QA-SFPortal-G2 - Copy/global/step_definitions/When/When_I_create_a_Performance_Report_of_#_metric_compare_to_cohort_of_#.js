// Recommended filename: When_I_create_a_Performance_Report_of_#_metric_compare_to_cohort_of_#.js
module.exports = function() {
  this.When(/^I create a (Portfolio Performance|Performance) Report of "([^"]*)" metric compare to cohort of "([^"]*)"$/, {timeout: process.env.StepTimeoutInMS}, function(requestType,metric, cohort) {
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const performancePage_xpath = this.xpath_lib.xpathRequire('performancePage_xpath');
    var metricSelect_xpath;

    if(requestType == "Portfolio Performance"){
      if (cohort != null && cohort != '') {
        metricSelect_xpath = content_xpath.labeled_mdSelect.replace('__LABEL__', 'Choose A Report');
      } else {
        metricSelect_xpath = content_xpath.labeled_mdSelect.replace('__LABEL__', 'Choose A Report');
      }
    }else{
      if (cohort != null && cohort != '') {
      metricSelect_xpath = content_xpath.labeled_mdSelect.replace('__LABEL__', 'Choose Report');
      } else {
        metricSelect_xpath = content_xpath.labeled_mdSelect.replace('__LABEL__', 'Choose Report');
      }
    }    
    var selectOption_path = content_xpath.named_mdOption.replace('__NAME__', metric);
    console.log(metricSelect_xpath)
    browser.click(metricSelect_xpath);
    browser.pause(100);
    console.log(selectOption_path);
    browser.getLocationInView(selectOption_path);
    browser.click(selectOption_path);
    if (cohort != null && cohort != '') {
      var cohortRadioButton_xpath = performancePage_xpath.labeledRadioButton.replace('__LABEL__', cohort);
      var loadReportButton_xpath = content_xpath.namedButton.replace('__NAME__', 'Load Report');
      browser.click(cohortRadioButton_xpath);
      browser.click(loadReportButton_xpath);
    }
  });
};
