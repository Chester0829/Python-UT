// Recommended filename: When_I_apply_the_following_settings_under_the_#_panel-heading.js
module.exports = function() {
  this.When(/^I apply the following settings under the "([^"]*)" panel-heading$/, 
    {timeout:process.env.StepTimeoutInMS*5},
    function (widgetName, table) {
    // Write code here that turns the phrase above into concrete actions
    const settingsPage_xpath = this.xpath_lib.xpathRequire('settingsPage_xpath');
    var expected_row_list = table.hashes();

    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    
    console.log(expected_row_list.length);
    expected_row_list.forEach(function(setting_list, rowIndex){
        if(setting_list['Watchlist (Custom)']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[2]//span//input";
            console.log(xpath);
            var attribute = browser.getAttribute(xpath,'class');
            console.log(attribute);
            if (attribute.indexOf('ng-not-empty') > -1 && setting_list['Watchlist (Custom)']=='unchecked'){
              browser.click(xpath);
              browser.pause(1000);
            }
            else if(attribute.indexOf('ng-empty') > -1 && setting_list['Watchlist (Custom)']=='checked'){
              browser.click(xpath);
              browser.pause(1000);
            }
        }
        if(setting_list['Watchlist Status (Custom)']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[3]//span/select";
            console.log(xpath);
            browser.click(xpath);
            var option = "//table/tbody/tr["+(rowIndex+1)+"]/td[3]//option[text()=\""+ setting_list['Watchlist Status (Custom)'] + "\"]";
            console.log(option);
            browser.click(option);
        }
        if(setting_list['Defaulted (Custom)']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[4]//span//input";
            console.log(xpath);
            var attribute = browser.getAttribute(xpath,'class');
            if (attribute.indexOf('ng-not-empty') > -1 && setting_list['Defaulted (Custom)']=='unchecked'){
              browser.click(xpath);
              browser.pause(1000);
            }
            else if(attribute.indexOf('ng-empty') > -1 && setting_list['Defaulted (Custom)']=='checked'){
              browser.click(xpath);
              browser.pause(1000);
            }
        }
        if(setting_list['Rating (Custom)']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[5]//span//input";
            console.log(xpath);
            browser.setValue(xpath, setting_list['Rating (Custom)']);
        }
        if(setting_list['Custom 1']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[6]//span//input";
            console.log(xpath);
            browser.setValue(xpath, setting_list['Custom 1']);
        }
        if(setting_list['Custom 2']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[7]//span//input";
            console.log(xpath);
            browser.setValue(xpath, setting_list['Custom 2']);
        }
        if(setting_list['Custom 3']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[8]//span//input";
            console.log(xpath);
            browser.setValue(xpath, setting_list['Custom 3']);
        }
        if(setting_list['Custom 4']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[9]//span//input";
            console.log(xpath);
            browser.setValue(xpath, setting_list['Custom 4']);
        }
        if(setting_list['Custom 5']){
            var xpath = "//table/tbody/tr["+(rowIndex+1)+"]/td[10]//span//input";
            console.log(xpath);
            browser.setValue(xpath, setting_list['Custom 5']);
        }
    })
  });
}