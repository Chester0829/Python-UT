// Recommended filename: When_I_click_a_button_with_the_text_#.js
module.exports = function () {
  this.When(/^I click a button with the text "([^"]*)" (under iframe|on page)$/, function (buttonText, inIframe) {
    // Write the automation code here
    // pending();

    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const bwic_xpath = this.xpath_lib.xpathRequire('bwic_xpath');
    const reg_xpath = this.xpath_lib.xpathRequire('regulatory_xpath');

    if (inIframe == "under iframe") {
      browser.frame(); //jump out of the iframe before clicking the button.
      var button_xpath = content_xpath.namedButton.replace('__NAME__', buttonText);
      console.log('under iframe');
      console.log(button_xpath);
      browser.waitForVisible(button_xpath, this.waitDefault);
      browser.click(button_xpath);
    } else if (buttonText == '+') {
      // for BWIC Analyzer on dashboard
      var button_xpath = bwic_xpath.plusIcon_xpath;
      browser.waitForVisible(button_xpath, this.wait30);
      browser.click(button_xpath);
      this.browser_session.waitForResource(browser);
    } else if (buttonText == 'Create New BWIC') {
      var button_xpath = bwic_xpath.bwicLink_xpath;
      browser.waitForVisible(button_xpath, this.wait30);
      browser.click(button_xpath);
      this.browser_session.waitForResource(browser);
    } else if (buttonText == 'Create New BWICs') {
      var button_xpath = bwic_xpath.bwicCreate;
      browser.waitForVisible(button_xpath, this.wait30);
      browser.click(button_xpath);
      this.browser_session.waitForResource(browser);
    } else if (buttonText == '(+) Assumptions') {
      // RegModule IFRS9
      var button_xpath = content_xpath.namedSpanText.replace('__NAME__', buttonText);
      browser.waitForVisible(button_xpath, this.wait30);
      browser.click(button_xpath);
      this.browser_session.waitForResource(browser);
    } else if (buttonText == 'Save Assumptions') {
      var warningMessageXpath = '//ng-message[contains(@when,"required || pattern")]';
      console.log(browser.isVisible(warningMessageXpath));
      // expect(browser.isVisible(warningMessageXpath)).toBe(false);
      var button_xpath = content_xpath.namedButton.replace('__NAME__', buttonText);
      browser.waitForVisible(button_xpath, this.wait30);
      browser.click(button_xpath);
    } else if (buttonText == 'Create New Reinvestment') {
      var createReinves_xpath = '//div[@ng-if="assumpCtrl.showReinvestPool"]//button[contains(@class,"create")]';
      browser.waitForVisible(createReinves_xpath, this.waitDefault);
      browser.click(createReinves_xpath);
    } else if (buttonText == 'Save Vector') {
      var saveVector_xpath = '//div[@class="vector-container"]//button[contains(@ng-click,"save")]';
      browser.waitForVisible(saveVector_xpath, this.waitDefault);
      browser.click(saveVector_xpath);
    } else if (buttonText == 'Save Reinvestment') {
      var saveReinvestment_xpath = '//div[@class="reinv"]//button[contains(@ng-click,"save")]';
      browser.waitForVisible(saveReinvestment_xpath, this.waitDefault);
      browser.click(saveReinvestment_xpath);
    } else if (buttonText == 'Apply Stratification' || buttonText == 'Apply Custom Rates') {
      // var stratification_xpath = '//a[text()="Apply Stratification"]';
      var stratification_xpath = '//a[text()="' + buttonText + '"]';
      browser.waitForVisible(stratification_xpath, this.wait10);
      browser.click(stratification_xpath);
      // some times the Stratification will not display
      if (this.deal) {
        var cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
        var cmbsStratification = cashflow_xpath.cmbsStratification;
        try {
          console.log(cmbsStratification + '//*[text()="Stratification"]');
          browser.waitForVisible(cmbsStratification + '//*[text()="Stratification"]', this.wait10);
        } catch (error) {
          console.log('try click "Apply Stratification" again');
          browser.click(stratification_xpath);
          browser.waitForVisible(cmbsStratification + '//*[text()="Stratification"]', this.waitDefault);
        }
      } else if (this.portfolio.indexOf('CMBS') != -1) {
        if (buttonText.indexOf('Stratification') != -1) {
          var tmpXpath = '//*[@class="sfp-card-content"]//*[text()="Stratification"]';
        } else if (buttonText.indexOf('Custom Rates') != -1) {
          var tmpXpath = '//*[@class="sfp-card-content"]//*[text()="Custom Rates"]';
        }
        browser.click(tmpXpath);
      }
      this.browser_session.waitForResource(browser);
    } else if (buttonText == 'Save Stratifications') {
      var button_xpath = content_xpath.namedButton.replace('__NAME__', 'Save Stratifications');
      browser.waitForVisible(button_xpath, this.wait30);
      console.log(button_xpath);
      browser.click(button_xpath);
    } else if (buttonText == 'Loan Level Assumptions' || buttonText == 'Forward Curve') {
      var linkText_xpath = '//a[text()="' + buttonText + '"]';
      browser.waitForVisible(linkText_xpath, this.wait10);
      browser.click(linkText_xpath);
      this.browser_session.waitForResource(browser);
    } else if (buttonText == 'Save') {
      if (this.page == "Dynamic CFs New") {
        var button_xpath = '//button/span[text()="Save"]';
      } else {
        var button_xpath = content_xpath.namedButton.replace('__NAME__', buttonText);
      }
      browser.waitForVisible(button_xpath, this.waitDefault);
      browser.waitForEnabled(button_xpath, this.waitDefault);
      console.log(button_xpath);
      browser.click(button_xpath);
    } else if (buttonText == 'Clear') {
      var button_xpath = content_xpath.ClearButton.replace('__NAME__', buttonText);
      browser.waitForVisible(button_xpath, this.waitDefault);
      browser.waitForEnabled(button_xpath, this.waitDefault);
      console.log(button_xpath);
      browser.click(button_xpath);
    } else if (buttonText == 'BANK 2017-BNK4x' || buttonText == 'MADRID RMBS IV, FTAx') {
      // Portfolio compare
      var tmp = buttonText.slice(0, -1);
      const portfolioPage_xpath = this.xpath_lib.xpathRequire('portfolioPage_xpath');
      var search = portfolioPage_xpath.sfpSearch.replace('__NAME__', 'compareCtrl.searchFactory');
      // var deleteIcon = search + '//span[text()="BANK 2017-BNK4"]/*[@class="fa fa-times deleteIcon"]';
      var deleteIcon = search + '//span[text()="' + tmp + '"]/*[@class="fa fa-times deleteIcon"]';
      browser.click(deleteIcon);
      browser.pause(500);
    } else if (buttonText == 'Edit icon') {
      // screen
      var button_xpath = '//button[contains(@ng-click,"vm.initEditState")]';
      browser.click(button_xpath);
      this.browser_session.waitForResource(browser);

      // reg cus scen
    } else if (buttonText == 'Add a Basic Scenario' || buttonText == 'Add a Custom Scenario' || buttonText == 'Add a Basic Scenario') {
      var button_xpath = '//span[translate(normalize-space(), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz")="__NAME__"]/parent :: button'.replace('__NAME__', buttonText.toLowerCase());
      console.log(button_xpath);
      browser.waitForVisible(button_xpath, this.waitDefault);
      browser.click(button_xpath);
      this.browser_session.waitForResource(browser);
    } else if (buttonText == 'Save Scenario') {
      var button_xpath = reg_xpath.Button_xpath.replace('__NAME__', buttonText);
      console.log(button_xpath);
      browser.click(button_xpath);
      browser.waitForVisible('//*[contains(text(),"Scenario Added Successfully") or contains(text(),"Successfully saved assumptions")]', this.waitMax);
      browser.pause(2000);

    } else if (buttonText == 'Save Rating Assumption') {
      var button_xpath = '(' + reg_xpath.Button_xpath.replace('__NAME__', buttonText) + ')[2]';
      console.log(button_xpath);
      browser.click(button_xpath);
      browser.waitForVisible('//*[contains(text(),"Changes to rating assumptions are successfully applied to database")]', this.waitMax);
      browser.pause(1000);
    } else if (['Bold', 'Italic', 'Strikethrough'].indexOf(buttonText) != -1) {


    } else if (['Bold', 'Italic', 'Strikethrough', 'Link'].indexOf(buttonText) != -1) {

      // Journal
      // console.log(browser.windowHandles());
      this.browser_session.waitForResource(browser);
      this.browser_session.waitForLoading(browser);
      var editArea = content_xpath.editArea;
      browser.waitForVisible(editArea, this.waitDefault);
      browser.pause(1000);
      browser.setValue(editArea, ' ');
      var button_xpath = content_xpath.namedButton.replace('__NAME__', buttonText);
      browser.click(button_xpath);
    } else if (buttonText == '1Y' || buttonText == '3M' || buttonText == '6M') {
      // performance
      this.browser_session.waitForResource(browser);
      // var button_xpath = '//*[contains(@class,"btn-group historical-date-range-nav")]//label[text()="' + buttonText + '"]';
      var performancePage_xpath = this.xpath_lib.xpathRequire('performancePage_xpath');
      var button_xpath = performancePage_xpath.dateButton.replace('__VALUE__', buttonText);
      var buttonList = browser.elements(button_xpath).value;
      for (var i = 0; i < buttonList.length; i++) {
        browser.elementIdClick(buttonList[i]['ELEMENT']);
      }
      // check the date range
      // var date_ranges = browser.getValue('//*[contains(@class,"sfp-date-picker")]//input');
      var date_ranges = browser.getValue(performancePage_xpath.dateRange);
      console.log(date_ranges);
      var expectValue = undefined;
      switch (buttonText) {
        case '1Y':
          expectValue = 1;
          break;
        case '3M':
          expectValue = 0.25;
          break;
        case '6M':
          expectValue = 0.5;
          break;
      }
      for (var i = 0; i < date_ranges.length; i += 2) {
        var begin = date_ranges[i];
        var end = date_ranges[i + 1];
        expect(this.moment(end).diff(this.moment(begin), 'years', true)).toEqual(expectValue);
      }

    } else if (buttonText == 'CMBS') {
      // for CMBS Portfolio cashflow
      var button_xpath = '//*[@ng-if="assumpCtrl.showStratificationNav"]//md-tab-item//*[text()="CMBS"]';
      try {
        browser.waitForVisible(button_xpath, this.waitDefault);
        browser.click(button_xpath);
      } catch (e) {
      }
      this.browser_session.waitForResource(browser);
    }
    else if (buttonText == 'Apply Customized') {
      var button_xpath = '//div[@class="sfp-card-actions"]//button[contains(.,"Apply")]';
      browser.waitForVisible(button_xpath);
      browser.click(button_xpath);
    }
    else if (buttonText == 'Edit BWIC') {
      var button_xpath = bwic_xpath.bwicEdit;
      browser.waitForVisible(button_xpath);
      browser.click(button_xpath);
    }
    else if (buttonText == 'Delete BWIC') {
      var button_xpath = bwic_xpath.bwicDelete;
      browser.waitForVisible(button_xpath);
      this.robot_session.clickAndEnter(browser, button_xpath);
    }
    else if (buttonText == 'Save This Screen') {
      var button_xpath = '//button[contains(@ng-click,"saveScreener")]';
      browser.waitForVisible(button_xpath);
      browser.waitForEnabled(button_xpath);
      browser.pause(1000);
      browser.click(button_xpath);
      browser.waitForVisible('//*[contains(., "Saved successfully")]', this.waitDefault);
      browser.pause(1000);
      // browser.element(button_xpath);
      // browser.keys('Enter');    
    }
    else if (buttonText == 'ScreenTest5_10' || buttonText == 'archive_clo_test' || buttonText == 'archive_clo_deal' || buttonText == 'archive_abs_test' || buttonText == 'archive_abs_deal') {
      if (buttonText == 'ScreenTest5_10') {
        var button_xpath = '//a[contains(.,"ScreenTest5_10")]';
      } else {
        var button_xpath = '//a[contains(.,"' + this.alertsName + '")]';
      }
      browser.waitForVisible(button_xpath);
      browser.waitForEnabled(button_xpath);
      console.log(button_xpath);
      browser.click(button_xpath);
      browser.waitForVisible('//span[contains(.,"Edit")]');
    }
    else {
      browser.pause(2000);
      if (buttonText == 'Load Asset Data') {
        // For clo asset-level
        browser.pause(25 * 1000);
      }
      if (buttonText == 'Back to My Screens') {
        browser.pause(5 * 1000);
        var button_xpath = '(' + content_xpath.namedButton.replace('__NAME__', buttonText) + ')[2]';
        if (!browser.isVisible(button_xpath)) {
          // for cmbs screen
          var button_xpath = content_xpath.namedButton.replace('__NAME__', buttonText);
        }
        if (!browser.isVisible(button_xpath)) {
          //for screen create
          var button_xpath = '(' + content_xpath.namedButton.replace('__NAME__', buttonText) + ')[1]';
        }
      }
      else {
        var button_xpath = content_xpath.namedButton.replace('__NAME__', buttonText);
      }
      // if(buttonText == 'Export XLSX'){
      //   this.file_session.deleteFiles('testing.xlsx');
      //   browser.pause(1000);
      // }
      console.log(button_xpath);
      browser.waitForVisible(button_xpath, this.wait30);
      browser.click(button_xpath);
      if (buttonText == 'Read File') {

        const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
        this.browser_session.waitForResource(browser, cashflow_xpath.editDealFrame);
      }
      this.browser_session.waitForResource(browser);
      //browser.pause(2000);
    }
  });
};