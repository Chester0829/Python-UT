// Recommended filename: When_I_download_#_file_under_the_#_widget_that_contains_the_#_#_by_click_the_#_icon_in_manager_mode.js
module.exports = function() {
	this.When(/^I download "([^"]*)" file under the "([^"]*)" widget that contains the (regular|irregular) (table|charts) by click the "([^"]*)" icon in manager mode$/, 
		{timeout: process.env.StepTimeoutInMS*5},
		function (filetype,widgetName,describeText,widgetType,button){
			// browser.pause(30*1000);
			this.browser_session.waitForResource(browser);
			const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
			const download_xpath = this.xpath_lib.xpathRequire('managerModeDownload_xpath');
			const path = require('path');
			var chartTtile = this.xpath_lib.xpathRequire('chartTitle');
			var widget_xpath = download_xpath.widget_xpath.replace('__WIDGETNAME__',widgetName);
			var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());

			// var download_icon_xpath = widget_xpath + '/parent::*/parent::*' + download_xpath.download_icon;
			var download_icon_xpath = myPanel + download_xpath.download_icon;
			this.no_data_text_list = download_xpath.no_data_text_list;
			console.log(this.no_data_text_list);
			console.log('this.manager',this.manager) 

			// if(widgetType != 'table'){
			// 	if(this.manager != undefined){
			// 		var chartTitleList = chartTtile['manager'];
			// 	}
			// 	if(chartTitleList[widgetName] != undefined){
			// 		var titleTextInCsv = ('title' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['title'] : chartTitleList[widgetName];
			// 		var offsetX = ('offsetX' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetX']: 0;
			// 		var offsetY = ('offsetY' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetY']: 0;
			// 		var separator = ('separator' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['separator']: '';
			// 		var flag = true;
			// 	}else if(chartTitleList[this.chartName] != undefined){
			// 		var titleTextInCsv = 'title' in chartTitleList[this.chartName] ? chartTitleList[this.chartName]['title'] : chartTitleList[this.chartName];
			// 		var offsetX = ('offsetX' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetX']: 0;
			// 		var offsetY = ('offsetY' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetY']: 0;
			// 		var separator = ('separator' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['separator']: '';
			// 		var flag = true;
			// 	}else{
			// 		var flag = false;
			// 		var offsetX = 0;
			// 		var offsetY = 0;
			// 		var separator = '';
			// 		var titleTextInCsv = this.chartName;
			// 	}
			// 	console.log(titleTextInCsv);
			// 	console.log(offsetX);
			// 	console.log(offsetY);
			// }

			switch(widgetType){
				case 'table':
					// var table_xpath = widget_xpath + '/parent::*/parent::*' + download_xpath.sfp_data_table;
					var table_xpath = myPanel + content_xpath.descendantDataTable;
					var managerTitleList = chartTtile['manager'];
					var table_length = [];
					switch(describeText){
						case 'irregular':
							var titleInCsvList = managerTitleList[widgetName];
							// may be Array or string.
							var tableText = browser.getText(table_xpath + '/tbody/tr');
							// this.table_json = Array.isArray(tableText) ? tableText : [ tableText ];
							this.tableText = Array.isArray(tableText) ? tableText : [ tableText ];
							table_length.push(this.tableText.length);
							// console.log(titleInCsvList);
							// console.log(this.tableText);
							break;
						case 'regular': // can use this.tabletojson.convert to get correct data, only contains one thead
							var htmls = browser.getHTML(table_xpath);
							var htmlsList = Array.isArray(htmls) ? htmls : [ htmls ];
							var table_json = [];
							var titleInCsvList = [];
							for(var i=0;i<htmlsList.length;i++){
								var tmp = this.tabletojson.convert(htmlsList[i])[0];
								table_json.push(tmp);
								// need to be check if last item contain 'No matching records found'
								var flag = false;
								var lastItem = tmp[tmp.length-1];
								for(var key in lastItem){
									var reg = new RegExp(this.no_data_text_list.join('|'),'g'); 
									if(reg.test(lastItem[key])){
										flag = true;
									}
									break;
								}
								table_length.push(flag ? (tmp.length-1) : tmp.length );
							}
							if(widgetName == 'Comparison Results'){
								var titleInCsv = 'Region' + browser.getText(content_xpath.selectedTab);
								titleInCsvList = [ titleInCsv ];
							}else{
								var titleInCsv = browser.getText(table_xpath + '/thead');
								titleInCsvList = Array.isArray(titleInCsv) ? titleInCsv : [ titleInCsv ];	
							}
							// var titleInCsv = browser.getText(table_xpath + '/thead');
							// titleInCsvList = Array.isArray(titleInCsv) ? titleInCsv : [ titleInCsv ];
							this.table_json = table_json;
							// this.titleInCsvList = titleInCsvList;
							// console.log(titleInCsvList);
							// console.log(this.table_json);
							break;
						case 'only':
							var htmls = browser.getHTML(table_xpath);
							this.table_json = this.tabletojson.convert(htmls)[0];
							this.titleInCsvList = [ browser.getText(table_xpath + '/thead') ];
							break;
						case 'two':
							var htmls = browser.getHTML(table_xpath);
							this.table_json = [this.tabletojson.convert(htmls[0])[0], this.tabletojson.convert(htmls[1])[0] ];
							this.titleInCsvList = browser.getText(table_xpath + '/thead');
							break;
					}
					break;
				case 'charts':
					break;
			}

			var filetype_list = [];
			switch(filetype){
				case 'XLS/CSV':
					filetype_list = ['CSV','XLS'];
					break;
				case 'CSV':
					filetype_list.push('CSV');
					break;
				case 'XLS':
					filetype_list.push('XLS');
					break;
				default:
					filetype_list.push('CSV');
			}

			if (!process.env.BROWSER.startsWith('IE')) {
        // browser.touchScroll(browser.element(widget_xpath).value['ELEMENT'],0,200);
        browser.touchScroll(browser.element(myPanel).value['ELEMENT'],0,200);
      }
			browser.pause(1*1000);
			browser.click(download_icon_xpath);
			this.file_target_data = [];
			var today = this.time_lib.getTime();
			// var moment = require('moment');
			// var today = moment().local().format('DD-MMM-YYYY');

			for(var i=0;i<filetype_list.length;i++){
				var myExportTextIcon = download_icon_xpath + download_xpath.file_type_text.replace('__FILETYPENAME__',filetype_list[i]);
				// may be need to classification

				switch(widgetName){
					case 'Managed Deals':
						var fileName = this.manager.replace('/','_') + '_' + 'CURRENTLY' + '-' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Asset Level':
					  var fileName = this.manager.replace('/','_') + '_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Trade Behavior':
						var fileName = this.manager.replace('/','_') + '_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Comparison Results':
						const pillGroup_xpath = this.xpath_lib.xpathRequire('pillGroup_xpath');
						var pillGroupValue = browser.getText(pillGroup_xpath.pillGroup + '//span').join(',').replace('/','_');
						// console.log(pillGroupValue);
						// Compare_GSO _ Blackstone Debt Funds Management,PGIM_Manager - Manager Comparison Results_03-Apr-2018.csv
						// GSO _ Blackstone Debt Funds Management,PGIM_03-Jun-2018.csv
						// var fileName = 'Compare_' + pillGroupValue + '_Manager - Manager ' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						var fileName = pillGroupValue + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Market Sentiment (Avg 3-Mo Market Color)':
						var fileName = this.manager.replace('/','_') + '_MARKET SENTIMENT_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Annualized Default Rate (%): U.S. Manager':
						var fileName = 'Compare - ' + this.manager.replace('/','_') + ' - Manager _ Annualized Default Rate (%) Drilldown' + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Average loan purchase price (12-mo trailing): U.S. Manager':
						var fileName = 'Compare - ' + this.manager.replace('/','_') + ' - Manager _ Average loan purchase price (12-mo trailing) Drilldown' + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Senior Management Fee (bps): U.S. Manager':
						var fileName = 'Compare - ' + this.manager.replace('/','_') + ' - Manager _ Senior Management Fee (bps) Drilldown' + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'WA Collateral Price: Cohort':
						// Compare - Cohort - Europe Cohort _ WA Collateral Price Drilldown_12-Apr-2018.csv
						// Compare - GSO _ Blackstone Debt Funds Management - Manager _ WA Collateral Price Drilldown_03-Apr-2018.csv
						// var fileName = 'Compare - ' + this.manager.replace('/','_') + ' - Manager _ WA Collateral Price Drilldown_' + today + '.' + filetype_list[i].toLowerCase();
						var fileName = 'Compare - Cohort - ' + this.tabName + ' Cohort _ WA Collateral Price Drilldown_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Biggest Caa/CCC Concentration Deals':
					case 'Biggest Caa/CCC Issuers':
						var fileName = this.manager.replace('/','_')+'_'+widgetName.toUpperCase().replace('/','_').replace('AA','aa')+'_'+today+'.'+filetype_list[i].toLowerCase();
						break;
					// case 'Biggest Caa/CCC Issuers':
					// 	var fileName = this.manager.replace('/','_')+'_BIGGEST Caa_CCC ISSUERS_'+today+'.'+filetype_list[i].toLowerCase();
					// 	break;
					default:
						if(widgetName.includes("Alerts for")){
							var fileName = this.manager.replace('/','_') + '_ALERTS FOR ' + this.manager.replace('/','_') + ' S DEALS_' + today + '.' + filetype_list[i].toLowerCase();
						}
						else{
							var fileName = this.manager.replace('/','_') + '_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
				}

				console.log('fileName: ' + fileName);
				this.file_session.deleteFiles(fileName);
				try{
					browser.waitForVisible(myExportTextIcon,this.wait10);
				}catch(error){
					browser.click(download_icon_xpath);
					browser.waitForVisible(myExportTextIcon,this.wait10);
				}
				browser.click(myExportTextIcon);
				// browser.pause(1*1000);

				// For IE we need to click the save button
	      if (process.env.BROWSER == 'IE11') {
	        browser.pause(5*1000);
	        this.robot_session.clickImage(null, 'IE11_DownloadSave.png');
	        browser.pause(10*1000);
	        this.robot_session.clickImage(null, 'IE11_DownloadDismissX.png');
	        browser.pause(1000);
	      }
	      var my_download_file = this.file_session.waitForDownload(browser,fileName);
				console.log('my download file: ' + my_download_file);
				// copy download file
				// console.log('copy file...');
				// this.file_session.copyFile(my_download_file,path.join(this.newestReportDit,fileName));

	      // check undefined
	      switch(filetype_list[i]){
	      	case 'CSV':
	      		var fs = require('fs');
						var file_content = fs.readFileSync(my_download_file,{encoding:'utf-8'});
						expect(file_content.toLowerCase().indexOf('undefined') == -1).toBe(true,my_download_file + ': This file contains undefined');
	      		break;
	      	case 'XLS':
	      		// <70 --> 0.740.570.87
	      		var file_content = this.file_session.readHtmlAsCsvString(my_download_file,true);
	      		// console.log(file_content);
	      		expect(file_content.toLowerCase().indexOf('undefined') == -1).toBe(true,my_download_file + ': This file contains undefined');
	      		break
	      }

	      switch(widgetType){
	      	case 'table':
	      		var header_index_infile_list = [];
	      		var table_array = file_content.replace(/\r/g,'').split('\n');
	      		// console.log(table_array);
	      		// get title form CSV array
	      		for(var i=0;i<table_array.length;i++){
	      			if(describeText == 'irregular'){
	      				// console.log('--------------')
	      				if(table_array[i].replace(/["\s]/g,'').indexOf(titleInCsvList[0].replace(/[\n\s"]/g,'')) != -1 && table_array[i+1].replace(/["\s]/g,'').indexOf(titleInCsvList[1].replace(/[\n\s"]/g,'')) != -1){
	      					header_index_infile_list.push(i+1);
	      					break;
	      				}
	      			}else{
	      				for(var j=0;j<titleInCsvList.length;j++){
	      					if(table_array[i].replace(/[",\s]/g,'').indexOf(titleInCsvList[j].replace(/[\n\s]/g,'')) != -1){
	      						header_index_infile_list.push(i);
	      						titleInCsvList.splice(j,1);
	      					}
	      				}
	      			}
	      		}
	      		// console.log(header_index_infile_list);
	      		var other_data = table_array.slice(0,header_index_infile_list[0]);
	      		// console.log(other_data);

	      		for(var i=0;i<header_index_infile_list.length;i++){
	      			if(widgetName == 'Comparison Results'){
	      				header_index_infile_list[i]  = header_index_infile_list[i] + 1;
	      			}
	      			this.file_target_data.push(table_array.slice(header_index_infile_list[i],header_index_infile_list[i] + table_length[i] + 1 ));
	      		}
	      		console.log(this.file_target_data);
	      		break;
	      	case 'charts':
	      		break;
	      }
			}
			// browser.pause(500*1000);
		})
}