// Recommended filename: When_I_click_menu_to_open_the_#_menu_item.js
module.exports = function() {
  this.When(/^I click menu to open the "([^"]*)" menu item$/, {timeout: process.env.StepTimeoutInMS}, function (menuItem) {
    // Write code here that turns the phrase above into concrete actions
    
    const portfolioPage_xpath = this.xpath_lib.xpathRequire('header_xpath');
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    browser.pause(1000);
    var menu = content_xpath.namedTopMenuButton.replace('__NAME__', 'Menu');
    var click_link = content_xpath.namedSubMenuButton.replace('__SECTION__', 'General').replace('__LINK__', menuItem)
    browser.waitForVisible(menu, this.waitDefault);
    browser.moveToObject(menu, 0, 0);
    browser.pause(1000);
    browser.waitForVisible(click_link, this.waitDefault);
    browser.click(click_link)

    this.browser_session.waitForLoading(browser);
    browser.click(portfolioPage_xpath.globalSearch_input);
    switch (menuItem) {
      case "DataViewer":
        try {
          // wait for progress bar to settle and last updated to show up
          browser.waitForVisible(dataViewerPage_xpath.progressBar, (this.waitDefault));
          browser.waitForVisible(dataViewerPage_xpath.progressBar, this.waitDefault, true);
          browser.waitForVisible(dataViewerPage_xpath.lastUpdated, this.waitDefault);
        } catch (e) {
          // ignore, we might have login once already.
          console.log("Waiting for Progress Bar and Last Updated failed");
        }
        // check DataViewer card
        var myDataViewer_section = dataViewerPage_xpath.titled_Application_page.replace('__TITLE__', 'DataViewer');
        browser.waitForVisible(myDataViewer_section, this.waitDefault);
        break;
      case "BWIC":
        try {
          // TODO: not implemented
          console.log("BWIC option NOT IMPLEMENTED");
        } catch (e) {
        }
        break;
        default:
          console.log("Menu option: " + menuItem + "NOT IMPLEMENTED");
    }
  });
}
