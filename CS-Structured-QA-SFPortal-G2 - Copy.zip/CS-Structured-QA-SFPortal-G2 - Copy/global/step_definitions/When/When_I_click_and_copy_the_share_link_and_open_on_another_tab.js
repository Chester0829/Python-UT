module.exports = function () {
    this.When(/^I click and copy the (share|new share|historical date share|history share) link and open on another tab$/,
        {timeout: process.env.StepTimeoutInMS * 10},
        function (linkType) {
            const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
            const dealPage_xpath = this.xpath_lib.xpathRequire('dealPage_xpath');            
            const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
            const dashboardPage_xpath = this.xpath_lib.xpathRequire('dashboardPage_xpath');
            const clickwrap_xpath = this.xpath_lib.xpathRequire('clickwrap_xpath');
            var agreeframe='//form[@name="agreementForm"]';

            var closingDate=this.closingDate;
            console.log(closingDate);
            var currentDate = new Date();
            var closing_date = new Date(closingDate.split('-')[0],parseInt(closingDate.split('-')[1])-1,closingDate.split('-')[2]);
            if(currentDate>=closing_date){
                throw new Error('No pre-closing deal for this asset class');
            }

            //use historical share link first, if fail then use a new share link
            if(linkType == 'share'){
                  try{
                        var wrapperHistoryTable = clickwrap_xpath.wrapperHistoryTable;
                        browser.waitForVisible(wrapperHistoryTable,this.waitDefault);
                        var linkNumber = browser.elements(wrapperHistoryTable+'//tbody//tr').value.length -1;
                        var shareLinkLocation = wrapperHistoryTable + '//tr['+ linkNumber+']//td[6]//span[@ng-bind-html]';
                        console.log('share link location:',shareLinkLocation);
                        var historicalLink = browser.getText(shareLinkLocation);                  
                        console.log('share link:',historicalLink);
                        this.browser_session.openUrlInNewTab(browser,historicalLink);
                        this.browser_session.waitForLoading(browser); 
                        //sometimes no need to login when use a historical share link                  
                        try{
                              browser.waitForVisible(agreeframe,this.waitDefault);
                        }catch(e){
                              // if(!browser.isVisible(agreeframe)){
                              //       //close clickwrap side when share link expired 
                              //       // browser.click('//button[contains(.,"Close")]');
                              //       //browser.switchTab();
                              //       browser.close();
                              //       //browser.close(browser.windowHandle());
                              //       //var window_handles = browser.windowHandles(); 
                              //       //console.log("handle 0:",browser.window(window_handles.value[0]).getTitle()); 
                              //       //console.log("handle 1:",browser.window(window_handles.value[1]).getTitle()); 
                              //       //browser.close(window_handles.value[1]); 
                              //       //browser.window(browser.windowHandle());                               
                              //       //console.log('handles:',browser.windowHandles()); 
                              //       //console.log('handle:',browser.windowHandle());
                              //       expect(true).toBe(false); 
                              // }
                              browser.waitForVisible(dealPage_xpath.nameOfDeal,this.waitDefault);
                              console.log(dealPage_xpath.nameOfDeal);                                              
                        }
                  }
                  catch(error){
                        console.log(error);
                        //copy share link
                        var button_xpath = content_xpath.namedButton.replace('__NAME__', 'Share Link');
                        console.log(button_xpath);
                        browser.waitForVisible(button_xpath,this.wait30);
                        browser.click(button_xpath);
                        var copyButton='//div[@class="shared-dialog"]//button';
                        browser.waitForVisible(copyButton,this.waitDefault);
                        browser.click(copyButton);
                        browser.pause(2000);
                        console.log("------share link copied!------");

                        //open share link on a new tab
                        const robot = require('robotjs');
                        robot.keyTap('t','control');
                        browser.pause(1000);
                        robot.keyTap('v','control');
                        browser.pause(1000);
                        robot.keyTap('enter');
                        browser.pause(1000);

                        //transfer the window
                        var windowHandles=browser.windowHandles();
                        var handle=browser.windowHandle();
                        // console.log('current window:'+ handle);
                        // console.log('all handles:'+ windowHandles);
                        var window1=windowHandles.value[0];
                        var window2=windowHandles.value[1];
                        // console.log(window2);
                        browser.window(window2);
                        console.log(browser.windowHandle());

                        // var agreement="//div[contains(text(),'ACCESS AGREEMENT')]";                  
                        browser.waitForVisible(agreeframe,this.waitDefault);
                        console.log("------agreement form show!------");
                        this.browser_session.waitForResource(browser);
                        //expect(true).toBe(false);
                        
                  }
            }
            else if(linkType == 'new share'){
                  //copy share link
                  var button_xpath = content_xpath.namedButton.replace('__NAME__', 'Share Link');
                  console.log(button_xpath);
                  browser.waitForVisible(button_xpath,this.wait30); 
                  //check for button tip message                 
                  var tipMessage = '//button[@title="Share this deal with prosective investors for up to two weeks"]';
                  browser.waitForVisible(tipMessage,this.wait30);
                  browser.click(button_xpath);
                  var copyButton='//div[@class="shared-dialog"]//button';
                  browser.waitForVisible(copyButton,this.waitDefault);
                  browser.click(copyButton);
                  browser.pause(2000);
                  console.log("------share link copied!------");

                  //open share link on a new tab
                  const robot = require('robotjs');
                  robot.keyTap('t','control');
                  browser.pause(1000);
                  robot.keyTap('v','control');
                  browser.pause(1000);
                  robot.keyTap('enter');
                  browser.pause(1000);

                  //transfer the window
                  var windowHandles=browser.windowHandles();
                  var handle=browser.windowHandle();
                  // console.log('current window:'+ handle);
                  // console.log('all handles:'+ windowHandles);
                  var window1=windowHandles.value[0];
                  var window2=windowHandles.value[1];
                  // console.log(window2);
                  browser.window(window2);
                  console.log(browser.windowHandle());

                  // var agreement="//div[contains(text(),'ACCESS AGREEMENT')]";                  
                  browser.waitForVisible(agreeframe,this.waitDefault);
                  console.log("------agreement form show!------");
                  this.browser_session.waitForResource(browser);                  
            }else if(linkType == 'history share'){
                  var wrapperHistoryTable = clickwrap_xpath.wrapperHistoryTable;
                  browser.waitForVisible(wrapperHistoryTable,this.waitDefault);
                  var linkNumber = browser.elements(wrapperHistoryTable+'//tbody//tr').value.length -1;
                  var shareLinkLocation = wrapperHistoryTable + '//tr['+ linkNumber+']//td[6]//span[@ng-bind-html]';
                  console.log('share link location:',shareLinkLocation);
                  var historicalLink = browser.getText(shareLinkLocation);                  
                  console.log('share link:',historicalLink);
                  this.browser_session.openUrlInNewTab(browser,historicalLink);
                  this.browser_session.waitForLoading(browser); 
                  //sometimes no need to login when use a historical share link                  
                  try{
                        browser.waitForVisible(agreeframe,this.waitDefault);
                  }catch(e){                             
                        browser.waitForVisible(dealPage_xpath.nameOfDeal,this.waitDefault);
                        console.log(dealPage_xpath.nameOfDeal);                                              
                  }
            }else{
                  var wrapperHistoryTable = clickwrap_xpath.wrapperHistoryTable;
                  browser.waitForVisible(wrapperHistoryTable,this.waitDefault);
                  var linkNumber = browser.elements(wrapperHistoryTable+'//tbody//tr').value.length -1;
                  var currentRow;
                  for(var i=0;i<linkNumber;i++){
                        currentRow = linkNumber - i;
                        var dateLocation = wrapperHistoryTable + '//tr['+ currentRow +']//td[5]//span[@ng-bind-html]';
                        var dateDisplay = browser.getText(dateLocation);
                        var myDate = new Date(); 
                        var currentDate = myDate.getFullYear()+'-'+('0'+(myDate.getMonth()+1)).slice(-2)+'-'+ ('0'+myDate.getDate()).slice(-2);
                        if(dateDisplay!=currentDate){
                              console.log('currentDate:',currentDate);
                              console.log('dateDisplay:',dateDisplay);
                              break;
                        }
                  }
                  var shareLinkLocation = wrapperHistoryTable + '//tr['+ currentRow+']//td[6]//span[@ng-bind-html]';
                  console.log('share link location:',shareLinkLocation);
                  var historicalLink = browser.getText(shareLinkLocation);
                  var arrMes = new Array();
                  //get historical login message
                  for(var j=1;j<7;j++){
                        var mesLocation= wrapperHistoryTable + '//tr['+ currentRow+']//td['+ j +']//span[@ng-bind-html]';
                        var mesItem=browser.getText(mesLocation);
                        arrMes.push(mesItem);
                  } 
                  console.log('message array:',arrMes);
                  this.arrMes = arrMes; 
                  this.currentRow = currentRow;

                  console.log('share link:',historicalLink);
                  this.browser_session.openUrlInNewTab(browser,historicalLink);
                  this.browser_session.waitForLoading(browser); 
                  //sometimes no need to login when use a historical share link                  
                  try{
                        browser.waitForVisible(agreeframe,this.waitDefault);
                  }catch(e){                        
                        browser.waitForVisible(dealPage_xpath.nameOfDeal,this.waitDefault);
                        console.log(dealPage_xpath.nameOfDeal);                                              
                  } 
            }
            
        });
};