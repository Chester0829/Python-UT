  // Recommended filename: When_I_apply_the_portfolio_cashflow_assumptions_for_the_first_#_#_tranches_for_the_following_assumptions.js
  module.exports = function() {
    this.When(/^I apply the portfolio cashflow assumptions for the first (.*) "([^"]*)" tranches for the following assumptions$/, {timeout: 300*1000}, function (batchSize, assetType, table) {
      // Write the automation code here
      var assumption_list = table.hashes();
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
      // var cashflow_div = '//div[@id="cashflows"]';
      var settings_div = content_xpath.settingPanel;
      var assumption_div = content_xpath.assumptionsPanel;
      var run_cashflow_button = cashflow_xpath.cashflowButton;
      var cash_assetClasses = content_xpath.tabList.replace('__TYPE__','cash.assetClassTypes');
      console.log(cash_assetClasses);
      //browser.waitForVisible(cash_assetClasses,this.waitDefault);
      this.browser_session.waitForResource(browser,cash_assetClasses);
      if(browser.isVisible(cash_assetClasses)==false)
      {
        cash_assetClasses = content_xpath.tabList1.replace('__TYPE__','cash.assetClassTypes');
      }
      var numOf_assetClasses = browser.elements(cash_assetClasses).value.length;
      var cash_assetClassTabs = [];
      var assetClasee_table;
      var set_size;
      var set_offset;
      var self = this;
      this.isCustom='MR';
      
      // filed cash_assetClassTabs array from page
      for (var i=0; i<numOf_assetClasses; i++){
        var tab = {};
        tab.selector = '('+cash_assetClasses+')['+(i+1)+']';
        tab.text = browser.getText(tab.selector).split(' ');
        tab.name = tab.text[0];
        tab.itemCount = Number(tab.text[1].replace(/[{()}]/g, ''));
        cash_assetClassTabs[i] = tab;
        // console.log('tab.itemCount:'+tab.itemCount);
      }
      cash_assetClassTabs.forEach(function(tab) {
        if (tab.name === 'All') {
          set_size = parseInt(tab.itemCount);
          console.log('set_size：'+set_size);
        }
      });
      //this.browser_session.waitForResource(browser,cashflow_xpath.dealCfsAssumptions);
      //browser.getLocationInView(content_xpath.assumptionsContent);
      // console.log(assumption_list);
     assumption_list.forEach(function(list_row) {
      console.log(list_row['name']);
      switch (list_row['name']) {
          case "cash.output_type":
            var selectPicker_select = content_xpath.selectPicker.replace('__SELECTNAME__','Output Type');
            console.log(selectPicker_select);
            //self.browser_session.waitForResource(browser, selectPicker_select);
            browser.click(selectPicker_select);
            //browser.waitForVisible(content_xpath.selectBox2,self.waitDefault);
            // this.browser_session.waitForResource(browser,content_xpath.selectBox2);
            if (browser.isVisible(content_xpath.selectBox2)) {
              browser.click(content_xpath.selectOption.replace('__OPTION__',list_row['value']));
             }
             browser.pause(500);
            break;
          case "cash.cashflowOutputType":
            var selectPicker_select = content_xpath.selectPicker.replace('__SELECTNAME__','Cashflow Output');
            console.log(selectPicker_select);
            //self.browser_session.waitForResource(browser, selectPicker_select);
            browser.click(selectPicker_select);
            //browser.waitForVisible(content_xpath.selectBox2,self.waitDefault);
            // this.browser_session.waitForResource(browser,content_xpath.selectBox2);
            if (browser.isVisible(content_xpath.selectBox2)) {
             if(list_row['value']=='ENV_OUTPUT'){
               var cfs_output_type = process.env.output_type
               if (cfs_output_type==undefined) {
                cfs_output_type="Monthly"; 
              }
              if (cfs_output_type == 'Payment'){
                cfs_output_type = 'Payment Dates'
              }
              console.log('Cashflow output type:',cfs_output_type);
              browser.click(content_xpath.selectOption.replace('__OPTION__',cfs_output_type));
            }else{
              browser.click(content_xpath.selectOption.replace('__OPTION__',list_row['value']));
            }
              // browser.click(content_xpath.selectOption.replace('__OPTION__',list_row['value']));
            }
             browser.pause(500);
            break;
          case "cash.settles_date":
            var settleDateInput = cashflow_xpath.cashflowPortfolioInput.replace('__NAME__',list_row['name']);
            console.log(settleDateInput);
            //browser.click(selectPicker_select);
            browser.setValue(settleDateInput, list_row['value']);
            break;
          case "cash.apply_watch":
            var check_box = cashflow_xpath.mdCheckbox.replace('__NAME__',list_row['name']);
            //var target_item = check_box + '//div[@class="md-icon"]'
            var target_attribute = browser.getAttribute(check_box, 'class');
            if ((list_row['value']=='checked' && target_attribute.indexOf('ng-empty') > -1) || (list_row['value']=='unchecked' && target_attribute.indexOf('ng-not-empty') > -1)){
                  console.log(check_box);
                  browser.click(check_box);
                  browser.pause(100);
                 }  
            break;
          case "cash.isCustomRates":
            var check_box = cashflow_xpath.mdCheckbox.replace('__NAME__',list_row['name']);
            //var target_item = check_box + '//div[@class="md-icon"]'
            var target_attribute = browser.getAttribute(check_box, 'class');
            if ((list_row['value']=='checked' && target_attribute.indexOf('ng-empty') > -1) || (list_row['value']=='unchecked' && target_attribute.indexOf('ng-not-empty') > -1)){
                  console.log(check_box);
                  browser.click(check_box);
                  browser.pause(100);
                 }
            if(list_row['value']=='checked'){
              self.isCustom = "CR";              
            }
            break;
          case "cash.selectedAssetClass":
              var target_item = cash_assetClasses + cashflow_xpath.cfnamedDescendantTab.replace('__NAME__',list_row['value']);
              console.log(target_item);
              browser.waitForVisible(target_item,self.waitDefault);
              browser.click(target_item);              
              // browser.waitForVisible(assetClasee_table,self.waitDefault);
              // self.browser_session.waitForResource(browser,assetClasee_table);
              break;
            case "tranche.run_flag":
              var run_flag = assumption_div + cashflow_xpath.cashflow_runflag;
              self.browser_session.waitForResource(browser,assumption_div,this.waitDefault);
              self.browser_session.clickNoWhere(browser);
              if (list_row['value'] == 'checked') {
                console.log(set_size);
                console.log(batchSize);
                // if(set_size=='undefined'){set_size=batchSize}
                for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
                  var target_item = '(' + run_flag + ')[' + (i) + ']';
                  var target_attribute = browser.getAttribute(target_item, 'class');
                  while (target_attribute.indexOf('ng-empty') > -1) {
                    // only exit when target is not empty
                    browser.waitForVisible(target_item,self.waitDefault);
                    browser.click(target_item);
                    browser.pause(100);
                    target_attribute = browser.getAttribute(target_item, 'class');
                  }           
                }
              } else {
                for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
                  var target_item = '(' + run_flag + ')[' + (set_offset + i) + ']';
                  var target_attribute = browser.getAttribute(target_item, 'class');
                  while (target_attribute.indexOf('ng-not-empty') > -1) {
                    // only exit when target is empty
                    browser.click(target_item);
                    browser.pause(100);
                    target_attribute = browser.getAttribute(target_item, 'class');
                  }           
                }
              }
              break; 
            case "tranche.seed_default":
            case "tranche.ignore_input_nonpayment_term":
            case "tranche.calc_curve_off_static_bal":
              var target_set = assumption_div + content_xpath.inputoption.replace('__NAME__',list_row['name']);
              console.log(target_set);
              for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
                var target_item = '(' + target_set + ')[' + i + ']';
                console.log(target_item);
                var target_attribute = browser.getAttribute(target_item, 'class');
                console.log(target_attribute);
                if ((list_row['value']=='checked' && target_attribute.indexOf('ng-empty') > -1) || (list_row['value']=='unchecked' && target_attribute.indexOf('ng-not-empty') > -1)){
                  console.log(target_item);
                  browser.click(target_item);
                  browser.pause(100);
                 }  
                // else {
                //   //var target_item = '(' + target_set + ')[' + (set_offset + i) + ']';
                //   while (target_attribute.indexOf('ng-not-empty') > -1) {
                //     // only exit when target is empty
                //     browser.click(target_item);
                //     browser.pause(100);
                //     //target_attribute = browser.getAttribute(target_item, 'class');
                //   }           
                // }
              }
              break;   
            case "tranche.repay_rate":
            case "tranche.price":
            case "tranche.reinvest_price":
            case "tranche.loss_rate":
            case "tranche.purchase_rate":
            case "tranche.portfolio_yield_rate":
            case "tranche.prepay_rate":
            case "tranche.buy_price":
            case "tranche.buy_date":
            case "tranche.default_rate":
            case "tranche.prinLossSeverityPctNonPerf":
            case "tranche.rec_lag":
            case "tranche.reinvDefaultLockout":
            case "tranche.reinvest_spread":
            case "tranche.reinvest_term":
            case "tranche.call_date":
            case "tranche.call_price":    
            case "tranche.alloc_mon":
            case "tranche.call_date":
            case "tranche.delinquency_rate":
            case "tranche.adv_loss_rate":
            case "tranche.adv_lag_mon":
            case "tranche.portfolio_loss_rate":
            case "tranche.deferment_rate":
            case "tranche.grace_rate":
            case "tranche.forbear_rate":
            case "tranche.subsidy_payment_delay":
            case "tranche.SAP_payment_delay":
            case "tranche.BB_utilization_rate":
            case "tranche.servicer_rate":
              var target_set = assumption_div + content_xpath.inputoption.replace('__NAME__',list_row['name']);
              console.log(target_set);
              for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
                var target_item = '(' + target_set + ')[' + i + ']';
                console.log(target_item);
                browser.setValue(target_item, list_row['value']);
              }
              break;
            case "tranche.dm":
            case "tranche.yield_pct":
              var target_set = assumption_div + content_xpath.inputoption.replace('__NAME__',list_row['name']);
              console.log(target_set);
              for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
                var target_item = '(' + target_set + ')[' + i + ']';
                console.log(target_item);
                var target_attribute = browser.getAttribute(target_item, 'disabled');
                console.log(target_attribute);
                if(target_attribute == null){
                  browser.setValue(target_item, list_row['value']);
                }  
              }
              break;
            case "tranche.solve_for":
            case "tranche.benchmark":
            case "tranche.repay_type":
            case "tranche.purchase_type":
            case "tranche.portfolio_yield_type":
            case "tranche.prepay_type":
            // case "tranche.first_loss_threshold":
            case "tranche.default_type":
            // case "tranche.benchmark":
            case "tranche.loss_type":
            case "tranche.reinvest_price_type":
            case "tranche.reinvest_pool":
            case "tranche.reinvest_rules":
            case "tranche.first_loss_threshold":
            case "tranche.call_price_type":
            case "tranche.call_option":
            case "tranche.force_call":
            case "tranche.delinquency_type":
            case "tranche.portfolio_loss_type":
            case "tranche.deferment_type":
            case "tranche.grace_type":
            case "tranche.forbear_type":
            case "tranche.interest_cap_freq":
            case "tranche.servicer_basis":
              if (list_row['name'] =='tranche.benchmark' && process.env.NODE_ENV.indexOf('SPS')==-1){
                 list_row['value']=list_row['value'].replace('TSY','LIBOR')
              }
              if (list_row['name'] =='tranche.benchmark' && process.env.NODE_ENV.indexOf('SPS')>-1){
                 list_row['value']=list_row['value'].replace('LIBOR','TSY')
              }
              var target_set = assumption_div + cashflow_xpath.selectButton.replace('__NAME__',list_row['name']);
                for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
                  var target_item = '(' + target_set + ')[' + i + ']';
                  console.log(target_item);
                  console.log(list_row['value']);
                  browser.waitForVisible(target_item,self.waitDefault);
                  browser.selectByVisibleText(target_item,list_row['value']);
                  console.log(browser.getText(target_item));
                }
                // if(list_row['name']=='tranche.first_loss_threshold'){
                //   self.portfolio_fistloss_type=list_row['value']
                // }
              break;
          }
        self.browser_session.clickNoWhere(browser);
        });
      // browser.click(run_cashflow_button);
      browser.pause(1000);
    });
  };
