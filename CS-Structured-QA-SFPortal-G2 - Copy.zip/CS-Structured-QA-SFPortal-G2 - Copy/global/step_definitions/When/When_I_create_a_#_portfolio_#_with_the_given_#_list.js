// Recommended filename: When_I_create_a_#_portfolio_#_with_the_given_#_list.js
module.exports = function() {
  this.When(/^I create a (regular|share) portfolio "([^"]*)" with the given (cusip|isin|cusip and isin|deal name|deal ticker|BBSecurityTicker|bb tranche|bb deal) list$/, function (shareType, portfolioName, listType) {
    const createPortfolioPage_xpath = this.xpath_lib.xpathRequire('createPortfolioPage_xpath');
    var portfolioName_input = createPortfolioPage_xpath.portfolioName_input;
    var cusipInputTable_xpath = createPortfolioPage_xpath.cusipIdentifierSearch_inputTable;
    var bbidentifierInputTable_xpath = createPortfolioPage_xpath.BBIdentifierSearch_inputTable;
    var dealNameInput_xpath = createPortfolioPage_xpath.dealNameInput_textArea;
    var dealTickerInput_xpath = createPortfolioPage_xpath.dealTickerSearch_textArea;
    var searchResults_table = createPortfolioPage_xpath.searchResults_table;
    var yourPortfolio_table = createPortfolioPage_xpath.yourPortfolio_table;
    var create_success_message = createPortfolioPage_xpath.successfullyCreatedPortfolio_message;
    var my_testList = this.test_list;
    var self = this;
    var myPortfolioName;
    var checkTableHeader = '';  
    
    // if portfolio name has %% we use a preseted name in global variable
    if (portfolioName.indexOf('%%') >= 0) {
        myPortfolioName = this.portfolio;
    } else {
        myPortfolioName = portfolioName;
    }

    console.log('create portfolio name: ' + myPortfolioName);

    this.browser_session.waitForResource(browser);

    // set portfolio name
    browser.waitForVisible(portfolioName_input, this.waitDefault);
    browser.setValue(portfolioName_input, myPortfolioName);
    // set share type
    if (shareType == 'share') { browser.click(createPortfolioPage_xpath.sharePortfolio_checkbox) }

    // click then use arrow key action to set md-select value for find by method
    browser.click(createPortfolioPage_xpath.findTranchBy_caret);
    try {
      browser.waitForVisible('//*[@value="id"]', this.waitDefault);
    } catch (error) {
      console.log("click again.");
      browser.click(createPortfolioPage_xpath.findTranchBy_caret);
    }

    switch (listType) {
      case 'cusip':
      case 'isin':
      case 'cusip and isin':
        browser.keys(['Enter']);
        // fill cusip search table
        checkTableHeader = this.browser_session.getTableHeaderText(browser, cusipInputTable_xpath);
        my_testList.forEach(function(list_item, index) {
          list_item['item'] = list_item['item'].replace(/;/g, '\t');
          self.browser_session.getTableCellText(browser, cusipInputTable_xpath, (index + 1), 1, 0, true, list_item['item']);
        });
        break;
      case 'deal name':
        browser.keys(['Down', 'Enter']);
        var insert_str = '';
        my_testList.forEach(function(list_item) {
          insert_str += list_item['item'] + '\n';
        });
        console.log('Insert Deal Name:' + insert_str);
        browser.setValue(dealNameInput_xpath, insert_str);
        break;
      case 'BBSecurityTicker':
        browser.click(createPortfolioPage_xpath.bloombergTranche_option);
        my_testList.forEach(function(list_item, index) {
          self.browser_session.getTableCellText(browser, bbidentifierInputTable_xpath, (index + 1), 1, 0, true, list_item['item']);
        });
        break;
      case 'deal ticker':
        browser.click(createPortfolioPage_xpath.bbDealTicker_option);
        var insert_str = '';
        my_testList.forEach(function(list_item) {
          insert_str += list_item['item'] + '\n';
        });
        console.log('Insert Deal Ticker:' + insert_str);
        browser.setValue(dealTickerInput_xpath, insert_str);
        break;
      default:
    }
    browser.click(createPortfolioPage_xpath.idSearch_button);
    // wait for search result and add selected
    browser.waitForVisible(searchResults_table, this.waitDefault);
    browser.click(createPortfolioPage_xpath.addSelectedToPortfolio_button);
    // create portfolio
    browser.waitForVisible(yourPortfolio_table, this.waitDefault);
    browser.click(createPortfolioPage_xpath.saveChanges_button);
    // wait for success message to show and disappear
    console.log(create_success_message);
    browser.pause(2000);
    browser.waitForVisible(create_success_message, this.waitDefault*2);
    browser.waitForVisible(create_success_message, this.waitDefault, true);

  });
}
