// Recommended filename: When_I_click_a_button_with_the_text_#.js
module.exports = function() {
  this.When(/^I click a drilldown link in row "([^"]*)" and column "([^"]*)" in "([^"]*)" panel-heading table$/, function (rowNum, columnNum, panelName) {
    // Write the automation code here
    // pending();
    this.browser_session.waitForResource(browser);
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    this.panelName = panelName;

    var drillDownLink = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase()) + '//table/tbody/tr[' + rowNum + ']/td[' + columnNum + ']/span';
    if (panelName == 'Summary Statistics-1'){
        drillDownLink = content_xpath.titledPanelLowercase.replace('__TITLE__','summary statistics') + '//table/tbody/tr/td[1]/table/tbody/tr[' + rowNum + ']/td[' + columnNum + ']//a';
    }
    if (panelName == 'Summary Statistics-2'){
        drillDownLink = content_xpath.titledPanelLowercase.replace('__TITLE__','summary statistics') + '//table/tbody/tr/td[2]/table/tbody/tr[' + rowNum + ']/td[' + columnNum + ']//a';
    }
    if (panelName == 'Summary Statistics-3'){
        drillDownLink = content_xpath.titledPanelLowercase.replace('__TITLE__','summary statistics') + '//table/tbody/tr/td[3]/table/tbody/tr[' + rowNum + ']/td[' + columnNum + ']//a';
    }
    if (panelName == 'Summary Statistics-4'){
        drillDownLink = content_xpath.titledPanelLowercase.replace('__TITLE__','summary statistics') + '//table/tbody/tr/td[4]/table/tbody/tr[' + rowNum + ']/td[' + columnNum + ']//a';
    }
    if (panelName == "My Company's Private Files"){
      var panelXpath = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase())
      var footerStr = browser.getText(panelXpath + '//*[@class="footer"]//div');
      drillDownLink = panelXpath + '//table/tbody/tr['+ parseInt(footerStr.split(' ').slice(-2,-1)[0]) +']/td['+ columnNum +']//a';
      this.downloadFileName = browser.getText(drillDownLink);
    }
    console.log(drillDownLink);
    browser.click(drillDownLink);
    if(panelName.indexOf('Comparison Results') != -1){
    	browser.pause(10*1000);
    	this.browser_session.waitForResource(browser);
    }
    this.browser_session.waitForResource(browser);
  });
};