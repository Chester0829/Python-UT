//When_I_change_the_setting_of_charts_as_below.js
module.exports = function() {
  this.When(/^I change the setting of charts as below$/, function (table) {
         // Write code here that turns the phrase above into concrete actions 
         const content_xpath = this.xpath_lib.xpathRequire('content_xpath');    
         var setting_table = table.hashes()
         setting_table.forEach(function(list_row){
           switch(list_row['settings']){
             case "ctrl.applyCohort":
             case "ctrl.combineY":
               var setting_field = '('+content_xpath.modeCheckbox.replace('__NAME__',list_row['settings'])+')['+list_row['charts']+']'
               console.log(setting_field)
               var flag = browser.getAttribute(setting_field,'aria-checked')
               if(flag=='true'&&list_row['value']=='unchecked'){
                 browser.click(setting_field)
               }else if(flag=='false'&&list_row['value']=='checked'){
                 browser.click(setting_field)
               }
               break;
              case "ctrl.dateRange":
                var setting_field = '('+content_xpath.labelCheckbox.replace('__MODEL__',list_row['settings']).replace('__VALUE__',list_row['value'])+')['+list_row['charts']+']'
                browser.click(setting_field)
                break;
              case "ctrl.startDate":
              case "ctrl.endDate":
                var setting_field = '('+ content_xpath.inputoption.replace('__NAME__',list_row['settings'])+')['+list_row['charts']+']'
                browser.setValue(setting_field,list_row['value'])
                break;
           }
           
         });
        
       })
};
