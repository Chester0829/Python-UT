// Recommended filename: When_I_choose_#_in_the_dropdown_input_list_under_the_#_panel-heading.js
module.exports = function () {
  this.When(/^I choose "([^"]*)" in the dropdown input list under the "([^"]*)" panel-heading$/,
    { timeout: process.env.StepTimeoutInMS * 5 },
    function (optionText, panelName) {
      // Write the automation code here

      this.browser_session.waitForResource(browser);
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      const selectOption_xpath = this.xpath_lib.xpathRequire('selectOption_xpath');

      var myPanel_xpath;
      var mySelectDropdown_xpath;
      var mySelectCaret_xpath;
      var mySelectInput_xpath;
      var mySelectMatched_xpath;
      this.optionText = optionText;
      switch (panelName) {
        case "main":
          break;
        default:
          myPanel_xpath = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase());
          mySelectDropdown_xpath = myPanel_xpath + selectOption_xpath.selectDropdown;
          mySelectCaret_xpath = '(' + myPanel_xpath + selectOption_xpath.selectCaret + ')[1]';
          mySelectInput_xpath = myPanel_xpath + selectOption_xpath.selectInput;
          mySelectMatched_xpath = myPanel_xpath + selectOption_xpath.selectMatched;
          break;
      }
      browser.waitForVisible(myPanel_xpath, this.waitMax);
      browser.getLocationInView(myPanel_xpath);
      console.log('Clicking: ' + mySelectCaret_xpath);
      browser.click(mySelectCaret_xpath);
      var ul_xpath = content_xpath.namedMenuSection_ul.replace("__TYPE__", "@class").replace('__VALUE__', "ui-select-choices ui-select-choices-content ui-select-dropdown");
      var dealList = browser.getText(myPanel_xpath + ul_xpath + '//a');

      // try to click the select caret, if not clickable (md-select) click the main md-select
      this.browser_session.waitForLoading(browser);
      try {
        console.log('click try: ' + mySelectCaret_xpath);
        browser.click(mySelectCaret_xpath);
      } catch (e) {
        if (mySelectCaret_xpath.includes('md-select')) {
          console.log('click: select container');
          browser.click(mySelectCaret_xpath + '/ancestor::*[contains(@class, "ui-select-container") or name()="md-select"][1]');
        } else {
          console.log(e);
        }
      }

      browser.keys(optionText);
      browser.keys('Enter');
      var selectMatched_text = browser.getText(mySelectMatched_xpath);
      if (panelName == "Historical Payments") {
        console.log(dealList);
        var tmp = Array.isArray(dealList) ? dealList : [dealList];
        expect(tmp.join(' :: ').indexOf('undefined') == -1).toBe(true);
        // check cusip and isin in deal mode
        if (this.deal_result) {
          // come from Then_I_can_get_below_value_under_the_#_panel-heading_in_deal_mode.js
          var len = this.deal_result[this.deal_result.length - 1].join().indexOf('No matching') != -1 ? this.deal_result.length - 1 : this.deal_result.length;
          expect(len).toEqual(tmp.length);
          for (var i = 0; i < len; i++) {
            var entry = this.deal_result[i].join(' ( ') + ' )';
            expect(tmp.join(' :: ').replace(/\s/g, '')).toContain(entry.replace(/\s/g, ''));
          }
        }
      }
      // normalize double spaces into single when we compare
      // expect(selectMatched_text.replace(/  /g, ' ')).toContain(optionText.replace(/  /g, ' '));
    });
};
