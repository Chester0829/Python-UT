module.exports = function() {
  this.When(/^I fill the performance charts with pool "([^"]*)"$/, {timeout: process.env.StepTimeoutInMS}, function(poolName) {
    const performancePage_xpath = this.xpath_lib.xpathRequire('performancePage_xpath');
    var poolInput_xpath = performancePage_xpath.poolInput;
    var poolNumber = browser.elements(poolInput_xpath).value.length;
    console.log(poolNumber)
    for(var i = 1; i <= poolNumber; i++){
      var chartPoolInput = '(' + poolInput_xpath + ')[' + i + ']';
      browser.setValue(chartPoolInput, poolName);
      browser.pause(100);
      browser.keys('Enter');
      browser.pause(100);
    }
    this.pool = poolName; 
    browser.pause(1000);
  });
};
 