// Recommended filename: When_I_click_on_#_link
// Example Show Deal Details, Hide Deal Details
module.exports = function() {
  this.When(/^I click on "([^"]*)" link$/, {timeout: process.env.StepTimeoutInMS}, function (linkNamed) {

    const dealPage_xpath = this.xpath_lib.xpathRequire('dealPage_xpath');

    var link_xpath = dealPage_xpath.linkedNamePath.replace('__NAME__',linkNamed);
    console.log("Link xpath: " + link_xpath);

    browser.waitForVisible(link_xpath);
    browser.click(link_xpath);

  });

};
