// When_I_delete_all_the_items_in_#_widget.js
module.exports = function() {
this.When(/^I delete all the items in "([^"]*)" widget/, function (widgetName) {
    // Write code here that turns the phrase above into concrete actions
    var content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    this.browser_session.waitForResource(browser);

    if(widgetName == 'BWIC Analyzer'){
       var targetTable = content_xpath.titledPanelLowercase.replace('__TITLE__', widgetName.toLowerCase());
        console.log(targetTable);
        var targetTableRows = targetTable + "//sfp-data-table//table/tbody/tr";
        
        var tableContent = browser.getText(targetTableRows);
        console.log(tableContent);
        console.log(tableContent.length);
        var rowCount = tableContent.length;

        if(rowCount != 1 && rowCount != 26){
          for(var i=rowCount-1; i>0; i--){
            var targetRow = targetTableRows + "[" + i + "]";
            // var vectorName1 = browser.getText(targetRow);
            console.log(targetRow);
            var deleteIcon = targetRow + "/td[6]/span";
            console.log(deleteIcon);
            this.browser_session.waitForResource(browser);
            //browser.click(deleteIcon);
            this.robot_session.clickAndEnter(browser, deleteIcon);             
            }
          var alertXpath = '//div[contains(@class,"growl-item alert alert-success")]';
          var alertXpath1 = '//div[contains(@class,"alert alert-success")]';
          try{
            browser.waitForVisible(alertXpath,this.waitDefault);
            console.log(browser.getText(alertXpath));
           }catch(e){
            console.log('try again...');
            var button_xpath = content_xpath.namedButton.replace('__NAME__', "Save");
            browser.click(button_xpath);
            browser.waitForVisible(alertXpath1,this.waitDefault);
            console.log(browser.getText(alertXpath1));
           }  
          browser.pause(2*1000);

          browser.refresh();
          this.browser_session.waitForLoading(browser);
          this.browser_session.waitForResource(browser);
        }     
    } 
  });
}