module.exports = function () {
    this.When(/^I close the clickwrap portal page and (reload|not reload) normal portal page for (CDO|ABS) deal$/,
        {timeout: process.env.StepTimeoutInMS * 10},
        function (isReload,type) {
            const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
            const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
            const dashboardPage_xpath = this.xpath_lib.xpathRequire('dashboardPage_xpath');

            var dashboard_button = header_xpath.mainDashboard_button;
            var newDealsTable = dashboardPage_xpath.newDealTable;
            var newDealsPanel = content_xpath.titledPanelLowercase.replace("__TITLE__","new deals");

            //close clickwrap side             
            console.log('handle:',browser.windowHandle());            
            browser.close(browser.windowHandle());            
            console.log('handle:',browser.windowHandle());             

            if(isReload == 'reload'){                
                browser.refresh();
                var userName = this.test_user;
                var password = this.user_login_config.getPassword(userName);
                var myLoginUserButton = header_xpath.named_LoginUser_button.replace('__NAME__', userName);
                try {
                    console.log('first try if already login as: ' + myLoginUserButton);
                    browser.waitForVisible(myLoginUserButton, this.waitDefault/5);
                } catch(e) {
                      console.log('logout anyway');
                      this.browser_session.userLogout(browser);
                      browser.pause(500);
                      browser.refresh();
                      this.browser_session.userLogin(browser, this.test_url, userName, password);                      
                      browser.waitForVisible(myLoginUserButton, this.waitDefault*4);

                      //choose the first preclosing deal
                      var searchArea = newDealsPanel+'//input';
                      browser.waitForVisible(searchArea,this.waitDefault);
                      browser.setValue(searchArea,type);
                      var dealName= '('+newDealsTable+'//tbody//a)[' + this.dealIndex + ']';
                      console.log(dealName);
                      try{
                            browser.click(dealName);
                            this.browser_session.waitForResource(browser);
                            browser.waitForVisible('//div[@class="banner-container"]',this.waitDefault);
                      }catch(e){
                            browser.click(dealName);
                            this.browser_session.waitForResource(browser);
                            browser.waitForVisible('//div[@class="banner-container"]',this.waitDefault);
                      }                  
                }                 
              }
            });
};