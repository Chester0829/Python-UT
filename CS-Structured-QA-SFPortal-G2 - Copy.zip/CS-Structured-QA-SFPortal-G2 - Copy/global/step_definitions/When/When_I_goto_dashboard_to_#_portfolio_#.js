// Recommended filename: When_I_goto_dashboard_to_#_portfolio_#.js
module.exports = function() {
  this.When(/^I goto dashboard to (search|search and open|search and delete) portfolio "([^"]*)"$/,
    {timeout: process.env.StepTimeoutInMS*10},
    function (action, portfolioName) {
    // Write the automation code here
    const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const dashboardPage_xpath = this.xpath_lib.xpathRequire('dashboardPage_xpath');
    const portfolioPage_xpath = this.xpath_lib.xpathRequire('portfolioPage_xpath');

    var dashboard_button = header_xpath.mainDashboard_button;
    var container_div = content_xpath.uiViewContent;
    var portfolio_table = dashboardPage_xpath.portfolioTable;
    var portfolio_search_window = dashboardPage_xpath.portfolioTableSearch_input;
    var portfoliosSection = content_xpath.titledSection.replace('__TITLE__', 'Portfolios');

    var myPortfolioName;
    this.pagetype = 'portfolio';
    
 
    // if portfolio name has %% we use a preseted name in global variable
    if (portfolioName.indexOf('%%') >= 0) {
        myPortfolioName = this.portfolio;
    } else {
        myPortfolioName = portfolioName;
    }
    this.portfolio = myPortfolioName;
    
    // go to dashboard
    if (!browser.getUrl().includes('/dashboard')) {
      try {
        this.browser_session.waitForLoadingSection(browser, portfoliosSection);
        browser.waitForVisible(content_xpath.maskOff, this.waitDefault);
        browser.waitForVisible(dashboard_button, this.waitDefault);
        browser.click(dashboard_button);
      } catch (e) {
        // go to dashboard directly
        var dashboard_url = this.test_url + '/dashboard';
        browser.url(dashboard_url);
      }
      this.browser_session.waitForLoadingSection(browser, portfoliosSection);
      this.browser_session.waitForResource(browser);        
    }
    
    // try twice due to portfolio table may not load at once
    try {
      browser.waitForVisible(portfolio_search_window, this.waitDefault);
    } catch(e) {
      browser.refresh();
    }
    try {
      browser.waitForVisible(portfolio_search_window, this.waitDefault);
    } catch(e) {
      browser.refresh();
    }
    browser.waitForVisible(portfolio_search_window, this.waitDefault*2);
    browser.click(portfolio_search_window);
    browser.waitForExist(portfolio_search_window, this.waitDefault);
    browser.setValue(portfolio_search_window, myPortfolioName);
    var searched_portfolio = dashboardPage_xpath.named_portfolioTableSearchResult.replace('__NAME__', myPortfolioName);

    browser.waitForExist(searched_portfolio, this.waitDefault);
    browser.waitForVisible(searched_portfolio, this.waitDefault);

    var result_portfolio = this.browser_session.getTableCellText(browser, portfolio_table, myPortfolioName, 'Name', -2);
    var result_tranche_count = this.browser_session.getTableCellText(browser, portfolio_table, myPortfolioName, '# of Tranches', -2);
    var result_notional_amount = this.browser_session.getTableCellText(browser, portfolio_table, myPortfolioName, 'Notional', -2);

    console.log('Portfolio Search Result: ' + result_portfolio + ' :: ' + result_tranche_count + ' :: ' + result_notional_amount);

    this.portfolio_tranche_count = parseInt(result_tranche_count);
    this.portfolio_notional_amount = this.accounting.unformat(result_notional_amount);
    this.portfolio = myPortfolioName;
    console.log(this.portfolio);
    expect(result_portfolio).toEqual(myPortfolioName);
    if (action.includes('and open')) {
        browser.click(searched_portfolio);
        var myPortfolioHeader_xpath = portfolioPage_xpath.portfolioHeader;
        var myPortfolioName_xpath = portfolioPage_xpath.namedPortfolioName.replace('__NAME__', myPortfolioName)
        //try twice due to portfolio page may not load at once
        try {
          browser.waitForVisible(myPortfolioName_xpath, this.waitDefault);
        } catch(e) {
          browser.refresh();
        }
        try {
          browser.waitForVisible(myPortfolioName_xpath, this.waitDefault);
        } catch(e) {
          browser.refresh();
        }
        browser.waitForVisible(myPortfolioName_xpath, this.waitDefault*2);
         // get portfolio information by api
      // try {
      //   this.license = this.api_session.getLicense(this.test_user);
      //   console.log(this.license);
      //   var portfolioInfo = this.api_session.getPortfolioInfo(portfolioName, this.license);
      //   this.portfolio_tranche_count = parseInt(portfolioInfo.numOfInvest);
      //   this.portfolio_notional_amount = portfolioInfo.notionalValue;
      //   this.portfolio_id = portfolioInfo.portfolioId;
      // }
      // catch (err) {
      //   console.log(err.stack)
      // }
    }
    if (action.includes('and delete')) {
      const dashboardPage_xpath = this.xpath_lib.xpathRequire('dashboardPage_xpath');
      var portfolio_delete_icon = dashboardPage_xpath.portfolioDelete_icon;
      var first_portfolio_delete_icon = '(' + portfolio_delete_icon + ')[1]';
      var delete_success_message = dashboardPage_xpath.successfullyDeletedPortfolio_message;
      browser.waitForExist(first_portfolio_delete_icon, this.waitDefault);
      if (browser.isExisting(first_portfolio_delete_icon)) {
        this.robot_session.clickAndEnter(browser, first_portfolio_delete_icon);
        // wait for message to appear...
        browser.waitForVisible(delete_success_message, this.waitDefault);
        // wait for message to vanish...
        browser.waitForVisible(delete_success_message, this.waitDefault, true);
      }
    }
    this.browser_session.waitForLoadingSection(browser, portfoliosSection);
  });
};
