// Recommended filename: When_I_apply_#_settings_for_#_panel-heading_as_below.js
module.exports = function () {
    this.When(/^I apply "([^"]*)" settings for "([^"]*)" panel-heading as below$/,
        { timeout: process.env.StepTimeoutInMS * 5 },
        function (type, widgetName, table) {
            // Write code here that turns the phrase above into concrete actions
            const settingsPage_xpath = this.xpath_lib.xpathRequire('settingsPage_xpath');
            const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
            var setting_list = table.hashes();
            var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());
            var self = this;
            this.browser_session.waitForResource(browser);
            this.browser_session.waitForLoading(browser);

            if (type == 'OTTI' || type == 'General') {
                setting_list.forEach(function (list_row) {
                    switch (list_row['name']) {
                        //checkbox items
                        case "Use Book Price Average":
                        case "Asset-Level Page Show Maximum by Default":
                        case "Deal":
                        case "Tranche":
                        case "Manager":
                        case "Issuer":
                        case "Loan":
                            var check_box = myPanel + settingsPage_xpath.settingsCheckBoxItems.replace('__CHECKBOXLABEL__', list_row['name']);
                            console.log(check_box);
                            var target_attribute = browser.getAttribute(check_box, 'aria-checked');
                            console.log(target_attribute);
                            if (list_row['value'] == 'checked' && target_attribute == 'false') {
                                browser.click(check_box);
                                browser.pause(100);
                            }
                            if (list_row['value'] == 'unchecked' && target_attribute == 'true') {
                                browser.click(check_box);
                                browser.pause(100);
                            }
                            break;
                        case "Asset-Level Page Show Maximum by Default":
                        case "Deal":
                        case "Tranche":
                        case "Manager":
                        case "Issuer":
                        case "Loan":
                            var check_box = myPanel + settingsPage_xpath.settingsCheckBoxItems.replace('__CHECKBOXLABEL__', list_row['name']);
                            console.log(check_box);
                            var target_attribute = browser.getAttribute(check_box, 'aria-checked');
                            console.log(target_attribute);
                            if (list_row['value'] == 'checked' && target_attribute == 'false') {
                                browser.click(check_box);
                                browser.pause(100);
                            }
                            if (list_row['value'] == 'unchecked' && target_attribute == 'true') {
                                browser.click(check_box);
                                browser.pause(100);
                            }
                            break;
                        //select items
                        case "OTTI Calculation":
                        case "Notional Loss Type":
                        case "OCI Calculation":
                        case "Book Price Average":
                        case "Fair Value Calculation Approach:":
                        case "Implied Yield Calculation:":
                        case "Fair Value Credit Calculation:":
                        case "Base Currency":
                        case "Pricing Options":
                        case "Preferred Language":
                        case "Ribbon Detail":
                            var selectIcon = myPanel + settingsPage_xpath.settingsSelectIcon.replace('__SELECTLABEL__', list_row['name']);
                            console.log(selectIcon);
                            browser.click(selectIcon);
                            var selectValue = settingsPage_xpath.settingsSelectOption.replace('__OPTIONTEXT__', list_row['value']);
                            console.log(selectValue);
                            var selectMenu = settingsPage_xpath.settingsSelectMenu;
                            browser.waitForVisible(selectMenu, self.waitDefault);
                            console.log(selectMenu);
                            browser.click(selectValue);
                            break;
                        //input items
                        case "Notional Loss Threshold":
                        case "Recently Viewed Options in Workspace":
                            var inputItem = myPanel + settingsPage_xpath.settingsInputItems.replace('__INPUTLABEL__', list_row['name']);
                            if (!browser.isVisible(inputItem)) {
                                inputItem = myPanel + settingsPage_xpath.settingsInputItems1.replace('__INPUTLABEL__', list_row['name']);
                            }
                            console.log(inputItem);
                            browser.setValue(inputItem, list_row['value']);
                            console.log(browser.getValue(inputItem));
                            break;
                    }
                })
            }
        });
}