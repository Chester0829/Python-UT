// Recommended filename: When_I_click_the_#_radio_button_under_the_#_panel-heading.js
module.exports = function() {
  this.When(/^I click the "([^"]*)" radio button under the "([^"]*)" panel-heading$/, { 
    timeout: process.env.StepTimeoutInMS*5}, 
    function (radiobuttonName, panelName) {
    // Write the automation code here
    
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    var myPanel_xpath = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase());
    var radioButton_xpath = myPanel_xpath + content_xpath.valuedRadioButton.replace('__VALUE__', radiobuttonName);

    console.log("radioButton_xpath: " + radioButton_xpath);
    browser.click(radioButton_xpath);

    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);

  });
};
