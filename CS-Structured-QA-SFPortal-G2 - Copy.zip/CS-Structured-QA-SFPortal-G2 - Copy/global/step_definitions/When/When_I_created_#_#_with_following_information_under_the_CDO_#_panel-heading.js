// When_I_created_new_rule_with_following_information_under_the_CDO_#_panel-heading.js
// only for Stratification
module.exports = function() {
  this.When(/^I created (new|first|second) (rule|reinvestments) with following information under the CDO "([^"]*)" panel\-heading$/, function (tableIndex,typeName,penelName,table) {
    // Write code here that turns the phrase above into concrete actions
    var rule_item_list = table.hashes();
    // var add_new_rule = '//*[text()="Add New Rule"]';
    // browser.waitForVisible(add_new_rule,this.waitDefault);
    // browser.click(add_new_rule);
    var cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
    var nIndex = 1;
    // if (typeName=='rule') {

    // }else if (typeName=='reinvestments'){

    // }
    // var table_xpath = cashflow_xpath.StratificationTable;
    // var ruleIDs = table_xpath + '//tbody//tr//td[@style="text-align: center; vertical-align: middle"]';
    // var new_ruleLen = browser.getText(ruleIDs).length;
    // console.log(new_ruleLen);

    for(var i=0;i<rule_item_list.length;i++){
      var column = rule_item_list[i]['row_item'];
      var value = rule_item_list[i]['value'];
      console.log('column: ' + column + ', value: ' + value);
      switch(column){
        case 'watch.min2':
        case 'watch.max2':
        case 'watch.type1':
        case 'watch.type2':
        case 'watch.type3':
        case 'watch.prepaytype':
        case 'watch.defaulttype':
        case 'watch.lossType':
        case 'item.adjustable':
        case 'item.bankLoans':
        case 'item.juniorSenior':
        case 'item.country':
        case 'item.rating':
        case 'assumpCtrl.postReinv.autoReinvEnd':
        case 'assumpCtrl.postReinv.reinvestOverride':
          var mdSelect = cashflow_xpath.mdSelect.replace('__NAME__',column);
          var tmp = browser.isVisible(mdSelect);
          // need to filter true in tmp list ?
          var mdSelectLen = Array.isArray(tmp) ? tmp.length : 1; 
          browser.pause(200);
           if(value == 'disabled'){
            var isDisable = browser.getAttribute('(' + mdSelect +')[' + mdSelectLen + ']','disabled');
            console.log(isDisable);
            expect(isDisable).toEqual(value);
          }else{
            browser.click('(' + mdSelect +')[' + mdSelectLen + ']');
            try {
              var textXpath = cashflow_xpath.mdSelectMenu + '//*[text()="'+ value +'"]';
              var t = browser.isVisible(textXpath);
              var textXpathLen = Array.isArray(t) ? t.length : 1;
              browser.click('(' + textXpath + ')[' + textXpathLen + ']');  
            } catch (error) {
              var textXpath = cashflow_xpath.mdSelectMenu2 + '//*[text()="'+ value +'"]';
              console.log('try more one time: ' + textXpath);
              var t = browser.isVisible(textXpath);
              var textXpathLen = Array.isArray(t) ? t.length : 1;
              browser.click('(' + textXpath + ')[' + textXpathLen + ']');
            }
          }
          break;
        case 'watch.min1':
          // var uiSelectMatch = '//div[@ng-model="'+ column +'"]//div[@class="ui-select-match"]';
          // var tmp = browser.isVisible(uiSelectMatch);
          // var uiSelectMatchLen = Array.isArray(tmp) ? tmp.length : 1;
          // console.log('(' + uiSelectMatch + ')[' + uiSelectMatchLen +']');
          // try {
          //   browser.click('(' + uiSelectMatch + ')[' + uiSelectMatchLen +']');  
          // } catch (error) {
          //   console.log('try to click: ' + '(' + divSelectMatch + ')[' + uiSelectMatchLen + ']' );
          //   browser.click('(' + divSelectMatch + ')[' + uiSelectMatchLen + ']');
          // }
          var divSelectMatch = '//div[@ng-model="'+ column +'"]';
          var tmp = browser.isVisible(divSelectMatch);
          console.log(tmp);
          var divSelectMatchLen = Array.isArray(tmp) ? tmp.length : 1;
          browser.click('(' + divSelectMatch + ')[' + divSelectMatchLen + ']');
          browser.pause(200);
          var input = '//div[@ng-model="watch.min1"]//input[contains(@placeholder,"Select or search")]';
          var t = browser.isVisible(input);
          console.log(t);
          var inputLen =  Array.isArray(t) ? t.length : 1;
          console.log(inputLen);
          browser.click('(' + input + ')[' + inputLen + ']');
          console.log('(' + input + ')[' + inputLen + ']');
          browser.pause(1000);
          browser.setValue('(' + input + ')[' + inputLen + ']',value);
          browser.waitForVisible('//div[@ng-model="watch.min1"]//ul[not (contains(@class,"ng-hide"))]//*[text()="'+ value +'"]',this.waitDefault);
          this.robot_session.keyTap();
          if(this.portfolio && browser.isVisible('(' + input + ')[' + inputLen + ']')){
            browser.pause(500);
            browser.click('(' + input + ')[' + inputLen + ']');
            browser.waitForVisible('//div[@ng-model="watch.min1"]//ul[not (contains(@class,"ng-hide"))]//*[text()="'+ value +'"]',this.waitDefault);
            this.robot_session.keyTap();
          }
          break;
        case 'watch.max1':
        case 'watch.max3':
        case 'watch.min3':
        case 'watch.prepayrate':
        case 'watch.defaultrate':
        case 'watch.lossrate':
        case 'watch.lagmonths':
        case 'watch.defaultDate':
        case 'watch.cccDateIn':
        case 'watch.cccDateOut':
        case 'watch.lossRate':
        case 'item.companyName':
        case 'item.term':
        case 'item.coupon':
        case 'item.margin':
        case 'item.recoveryRate':
        case 'item.floor':
        case 'item.price':
        case 'item.mktprice':
        case 'row.months':
        case 'item.value':
        case 'item.value1':
        case 'item.value2':
        case 'item.value3':
        case 'item.value4':
        case 'item.value5':
        case 'item.value6':
        case 'item.value7':
        case 'item.value8':
        case 'item.value9':
        case 'item.value10':
        case 'item.value11':
        case 'item.value12':
        case 'item.value13':
        case 'item.value14':
        case 'item.value15':
        case 'item.value16':
        case 'item.value17':
        case 'item.value18':
        case 'item.value19':
        case 'item.value20':
        case 'item.value21':
        case 'item.value22':
        case 'item.value23':
        case 'item.value24':
        case 'assumpCtrl.postReinv.customDate':
        case 'assumpCtrl.postReinv.period':
        case 'assumpCtrl.postReinv.autoReinvEndval':
        case 'assumpCtrl.postReinv.intraPeriod':
          var sfpTextInput = cashflow_xpath.sfpTextInput.replace('__NAME__',column) + '//input';
          var tmp = browser.isVisible(sfpTextInput);
          if(!tmp){
            sfpTextInput = '//input[@ng-model="'+ column +'"]';
            tmp = browser.isVisible(sfpTextInput); 
          }
          var sfpTextInputLen = Array.isArray(tmp) ? tmp.length : 1;
          // console.log('(' + sfpTextInput + ')[' + sfpTextInputLen + ']');
          if(column=="item.value1" || column == "item.value2"||column=="item.value3" || column == "item.value4" || column == "item.value5" || column == "item.value6" || column == "item.value7" || column == "item.value8" || column == "item.value9" || column == "item.value10" || column == "item.value11" || column == "item.value12" || column == "item.value13" || column == "item.value14" || column == "item.value15" || column == "item.value16" || column == "item.value17" || column == "item.value18" || column == "item.value19" || column == "item.value20" || column == "item.value21" || column == "item.value22" || column == "item.value23" || column == "item.value24"){
            sfpTextInput = '(//input[@ng-model="item.value"])['+column.substr(10)+']';
            console.log(sfpTextInput);
            tmp = browser.isVisible(sfpTextInput); 
            sfpTextInputLen = 1;
          }
          if(value == 'disabled'){
            var isDisable = browser.getAttribute('(' + sfpTextInput + ')[' + sfpTextInputLen + ']','disabled');
            console.log(isDisable);
          }else{
            browser.setValue('(' + sfpTextInput + ')[' + sfpTextInputLen + ']',value);
          }
          break;    
        case 'assumpCtrl.postReinv.prepayment':
        case 'assumpCtrl.postReinv.scheduled':
        case 'assumpCtrl.postReinv.recoveries':
        case 'assumpCtrl.postReinv.prepayment2':
        case 'assumpCtrl.postReinv.scheduled2':
        case 'assumpCtrl.postReinv.scheduled2':
        case 'assumpCtrl.postReinv.recoveries2':
          var mdCheckBox = cashflow_xpath.mdCheckbox.replace('__NAME__',column); 
          var checkStatus = browser.getAttribute(mdCheckBox,'aria-checked');
          console.log(checkStatus);
          if(value == 'checked' && checkStatus == "false"){
            browser.click(mdCheckBox);
            console.log('checked');
          }else if(value == 'unchecked' && checkStatus == "true"){
            browser.click(mdCheckbox);
          }
          break;
      }



    }




    });
}


