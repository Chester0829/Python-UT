module.exports = function () {
    this.When(/^I create a new screen with following information$/, function (table) {
        var information_list = table.hashes();
        var screenerPage_xpath = this.xpath_lib.xpathRequire('screenerPage_xpath');
        var content_xpath = this.xpath_lib.xpathRequire('content_xpath');
        var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', 'create screens');
        var self = this;

        information_list.forEach(function (list_row) {
            switch (list_row['name']) {
                case 'Asset Class':
                    var selectIcon = screenerPage_xpath.assetClass;
                    browser.click(selectIcon);
                    var selectMenu = screenerPage_xpath.assetCalssMenu;
                    browser.waitForVisible(selectMenu);
                    var selectValue = screenerPage_xpath.assetClassValue.replace('__VALUE__', list_row['value']);
                    console.log(selectValue);
                    browser.click(selectValue);
                    break;
                case 'Deal Characteristics':
                case 'Tranche Characteristics':
                case 'Asset Characteristics':
                case 'Pool Characteristics':                    
                    var selectIcon = screenerPage_xpath.selectIcons.replace('__SELECTLABEL__', list_row['name']);
                    browser.waitForVisible(selectIcon, self.waitDefault);
                    if(browser.getText(selectIcon).indexOf(list_row['value'])== -1){
                        browser.click(selectIcon);
                        var selectMenu = screenerPage_xpath.selectMenus.replace('__SELECTLABEL__', list_row['name']);
                        browser.waitForVisible(selectMenu);
                        var selectValue = screenerPage_xpath.selectOption.replace('__SELECTLABEL__', list_row['name']).replace('__VALUE__', list_row['value']);
                        console.log(selectValue);
                        browser.click(selectValue);
                        var selectCheck= screenerPage_xpath.selectCheck.replace('__SELECTLABEL__',list_row['name']).replace('__VALUE__',list_row['value']);
                        browser.waitForVisible(selectCheck,self.waitDefault)
                        browser.pause(1000);
                        console.log(list_row['min']);
                        console.log(list_row['max']);
                        if (list_row['min'] !=''&&list_row['max'] !='') {
                            var inputMin ='('+ screenerPage_xpath.selectIcons1.replace('__SELECTLABEL__',list_row['value'])+')[2]';
                            browser.setValue(inputMin, list_row['min']);
                            var inputMax = '('+ screenerPage_xpath.selectIcons1.replace('__SELECTLABEL__',list_row['value'])+')[3]';
                            browser.setValue(inputMax, list_row['max']);
                        }
                        else{
                            var selectIcon1 = screenerPage_xpath.selectIcons1.replace('__SELECTLABEL__', list_row['value']);
                            try{                           
                                browser.click(selectIcon1);
                                var selectMenu1 = screenerPage_xpath.selectMenu1.replace('__SELECTLABEL__', list_row['value']);
                                browser.waitForVisible(selectMenu1);
                                var selectValue1 = screenerPage_xpath.selectOption1.replace('__SELECTLABEL__', list_row['value']).replace('__VALUE__', list_row['min']);
                                console.log(selectValue1);
                                try {
                                    browser.waitForVisible(selectValue1, self.waitDefault);
                                    browser.click(selectValue1);
                                }
                                catch (e) {
                                    console.log(e);
                                    browser.click(selectIcon1);
                                    browser.waitForVisible(selectValue1, self.waitDefault);
                                    browser.click(selectValue1);
                                }
                            }catch(err){
                                browser.setValue(selectIcon1, list_row['min']);                        
                            }
                        }                  
                    }                     
                    break;
                case 'Screen Name':
                case 'Email alerts to':                    
                    var inputItem = screenerPage_xpath.inputItems.replace('__INPUTLABEL__', list_row['name']);
                    var inputValue = list_row['value'];
                    if(inputValue=='archive_clo_test'||inputValue=='archive_abs_test'||inputValue=='archive_clo_deal'||inputValue=='archive_abs_deal'){
                        inputValue=inputValue+'_'+self.time_lib.getTime()+Math.floor(Math.random()*1000);
                        console.log(inputValue);
                        self.alertsName=inputValue;                        
                    }
                    browser.setValue(inputItem, inputValue);
                    console.log(browser.getValue(inputItem));
                    break;
                case 'Apply screen as alerts to portfolios':
                    var applyScreenInput = screenerPage_xpath.applyScreenInput;
                    browser.waitForVisible(applyScreenInput);
                    browser.click(applyScreenInput);
                    var applyScreenMenu = screenerPage_xpath.applyScreenMenu;
                    browser.waitForVisible(applyScreenMenu);
                    var selectValue = screenerPage_xpath.applyScreenValue.replace('__VALUE__',list_row['value']);
                    console.log(selectValue);
                    browser.click(selectValue);
                    var applyScreenCheck=screenerPage_xpath.applyScreenCheck.replace('__VALUE__',list_row['value']);
                    browser.waitForVisible(applyScreenCheck,self.waitDefault);
                    break;
                case 'Evaluate multiple characteristics as':
                case 'Search for':
                    var searchForIcon = screenerPage_xpath.searchFor.replace('__SELECTLABEL__', list_row['name'])+'/div';
                    browser.waitForVisible(searchForIcon);
                    browser.click(searchForIcon);
                    var searchForMenu = screenerPage_xpath.searchFor.replace('__SELECTLABEL__', list_row['name'])+'/ul';
                    browser.waitForVisible(searchForMenu);
                    var selectValue = screenerPage_xpath.searchForOption.replace('__SELECTLABEL__', list_row['name']).replace('__VALUE__', list_row['value']);
                    browser.click(selectValue);
                    break;
            }
        })
    });
};