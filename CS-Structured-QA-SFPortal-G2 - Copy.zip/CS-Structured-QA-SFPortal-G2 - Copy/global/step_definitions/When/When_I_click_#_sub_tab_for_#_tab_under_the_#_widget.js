//When_I_click_#_sub_tab_for_#_tab_under_the_#_widget.js
module.exports = function() {
       this.When(/^I click "([^"]*)" sub tab for "([^"]*)" tab under the "([^"]*)" widget$/, function (subTab, tab, widgetName) {
         // Write code here that turns the phrase above into concrete actions
         const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
         var widget_element = content_xpath.titledPanel.replace('__TITLE__',widgetName);
         this.tab = tab;
         browser.waitForVisible(widget_element,this.waitMax);
         var tab_element = content_xpath.namedTab3.replace(/__NAME__/g,tab);
         browser.waitForVisible(tab_element,this.waitDefault);
         browser.waitForEnabled(tab_element,this.waitDefault);
         console.log(tab_element);
         browser.click(tab_element);
         if(subTab != 'null'){
            var subTab_element = content_xpath.namedTab3.replace(/__NAME__/g,subTab);
            console.log(subTab_element);
            browser.click(subTab_element);
         }
         this.browser_session.waitForResource(browser);
       });
}