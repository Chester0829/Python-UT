module.exports = function() {
    this.When(/^I click the add icon on My Screens panel$/,  function() {
      const screenerPage_xpath = this.xpath_lib.xpathRequire('screenerPage_xpath');

      var create_element=screenerPage_xpath.createIcon;
      var create_screens=screenerPage_xpath.createScreensLable;
      browser.waitForVisible(create_element,this.waitDefault);
      browser.click(create_element);

    });
  };