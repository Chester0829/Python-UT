// When_I_click_row_#_on_#_table.js
module.exports = function() {
       this.When(/^I click row "([^"]*)" on "([^"]*)" (Enhanced BWIC table|table)$/, function (rowIndex, widgetName,tableType) {
           // Write code here that turns the phrase above into concrete actions
           const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
           var table_element = content_xpath.titled_Panel_Table2.replace("__NAME__",widgetName);
           var row_element = table_element + '/tbody/tr[' + rowIndex + ']';
           browser.waitForVisible(row_element,this.waitDefault)
           browser.click(row_element);
           if(tableType=='Enhanced BWIC table'){
             var nameField=row_element+'//td[1]//span[@ng-bind-html]';
             console.log(nameField);
             browser.waitForText(nameField,500);
             var dealName=browser.getText(nameField);
             console.log(dealName);
             this.deal=dealName;
           }
       });
}