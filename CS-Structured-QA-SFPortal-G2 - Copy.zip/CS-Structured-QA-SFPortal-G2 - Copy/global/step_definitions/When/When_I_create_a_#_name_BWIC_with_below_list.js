//// Recommended filename: When_I_create_a_#_name_BWIC_with_below_list.js
module.exports = function() {
	this.When(/^I create a "([^"]*)" name BWIC with below list$/, function (name,table) {
	 	// Write code here that turns the phrase above into concrete actions
	 	// return 'pending';
	 	// browser.pause(5*1000);
	 	this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    const bwic_xpath = this.xpath_lib.xpathRequire('bwic_xpath');

    var bwic_textarea = bwic_xpath.bwic_textarea;
    var submit_button = bwic_xpath.submit_button;
    this.BWIC_cusip_list = table.hashes();

    // paste in the list of cusips from the test case
	 	var BWIC_list_text = "";
    this.BWIC_cusip_list.forEach(function(list_row) {
    	BWIC_list_text += list_row['cusipisin'] + "\n";
  	});
    browser.setValue(bwic_textarea, BWIC_list_text);
    var BWIC_name_xpath = '//label[contains(text(),"BWIC Name")]//parent :: div//descendant :: input'

    if(name=="AAA"){
       this.bwicName = name;
    }
	 	else{
       this.bwicName = 'automation_' + this.moment().format('YYYYMMDD_HH_mm_ss');
     }
	 	console.log(this.BWIC_cusip_list);
	 	console.log(this.bwicName);
	  browser.setValue(BWIC_name_xpath,this.bwicName);
	 	browser.click(submit_button);
    this.browser_session.waitForResource(browser);
    browser.pause(5*1000);
	});
}