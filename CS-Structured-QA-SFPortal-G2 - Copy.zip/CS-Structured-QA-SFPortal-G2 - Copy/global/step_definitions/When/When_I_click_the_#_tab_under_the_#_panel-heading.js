// Recommended filename: When_I_click_the_#_tab_under_the_#_panel-heading.js
module.exports = function() {
  this.When(/^I click the "([^"]*)" tab under the "([^"]*)" panel-heading$/, 
    {timeout: process.env.StepTimeoutInMS*5}, function (tabName, panelName) {
    // Write the automation code here
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const scenarioManager_xpath = this.xpath_lib.xpathRequire('scenarioManager_xpath');
    var cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath'); 
    this.tabName = tabName;
    var myPanel_xpath = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase());;
    
    this.browser_session.waitForLoading(browser);

    switch(panelName) {
      case "Alerts for":
      case "Alerts for GSO / BLACKSTONE DEBT FUNDS MANAGEMENT 's deal":
        myPanel_xpath = content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase()); 
        break;
      case "uiViewContent":
        myPanel_xpath = content_xpath.uiViewContent;
        break;
      case "Regulatory":
        myPanel_xpath = '';
        break;
      case "OTTI Analysis Results":
        this.browser_session.waitForResource(browser);
        this.browser_session.waitForResource(browser, myPanel_xpath);
        break;
      case 'Settings':
        myPanel_xpath = cashflow_xpath.cashflow_tab.replace('__NAME__',panelName) + '/following-sibling::*';
        break;
      case 'Tranche Level Universe: AUTO':
        myPanel_xpath = content_xpath.titledSectionLowercaseDiv.replace('__TITLE__', panelName.toLowerCase())+'/ancestor::div[@class="sfp-card-title bwic-table"]/parent::div[@class="sfp-card"]';
      case 'All Saved Scenarios':
        myPanel_xpath = scenarioManager_xpath.scenarioManagerPanel.replace('__NAME__', panelName);
      default:   
        break;
    }

    console.log(myPanel_xpath);
    // split the tab name by the first space into 2 parts
    var tabStarting = tabName.replace(/ .*/,'');
    var tabRemaining = tabName.substr(tabName.indexOf(" ") + 1);
    this.tabName = tabName;
    // process tab xpath
    var myPanelTab_xpath = myPanel_xpath + content_xpath.namedTab3;
    myPanelTab_xpath = myPanelTab_xpath.replace('__NAME__', tabStarting);
    myPanelTab_xpath = myPanelTab_xpath.replace(/__NAME__/g, tabRemaining); 
    // ---just for Reg Custom Scen
    if(tabName == 'Basic Vectors' || tabName == 'Custom Forward Rates'){
      myPanelTab_xpath = '//span[translate(normalize-space(), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz")="__NAME__" and contains(@class ,"ng-binding ng-scope")]'.replace('__NAME__',tabName.toLowerCase());
    }else if(tabName == 'Reinvestments' || tabName == 'Intra/Post Reinvestment Assumptions'){
      myPanelTab_xpath = cashflow_xpath.cashflowReinvestmentsTab.replace('__NAME__',tabName);
    }
    else if(tabName == 'Vectors' || tabName == 'Custom Rates' || tabName == 'Settings' || tabName == 'CDO Reinvestments' 
      || tabName == 'Stratification'){
      myPanelTab_xpath = myPanel_xpath + cashflow_xpath.cashflow_tab1.replace('__NAME__',tabName);
    }
    if(panelName == 'Assumptions'){
      //var cash_assetClasses = content_xpath.tabList.replace('__TYPE__','cash.assetClassTypes');
      myPanelTab_xpath = cashflow_xpath.cfnamedDescendantTab.replace('__NAME__',tabName);
      console.log(myPanelTab_xpath);
    }
    if(panelName == 'All Saved Scenarios'){
      myPanelTab_xpath = myPanel_xpath + scenarioManager_xpath.scenarioManagerTab.replace('__NAME__',tabName);
    }
    this.browser_session.waitForLoadingSection(browser, myPanel_xpath);
    try{
      browser.waitForVisible(myPanelTab_xpath, this.waitDefault*2);
    }catch(e){
      var myPanelTab_xpath = myPanel_xpath + content_xpath.namedTab2;
      myPanelTab_xpath = myPanelTab_xpath.replace('__NAME__', tabStarting);
      myPanelTab_xpath = myPanelTab_xpath.replace(/__NAME__/g, tabRemaining);
      browser.waitForVisible(myPanelTab_xpath, this.waitDefault*2);
    }
    // browser.waitForVisible(myPanelTab_xpath, this.waitDefault*8);
    browser.getLocationInView(myPanelTab_xpath);
    console.log(myPanelTab_xpath);
    browser.click(myPanelTab_xpath);
    if(this.portfolio && this.portfolio.indexOf('CMBS') != -1 && panelName == 'List of Tranches'){
      browser.pause(2*1000);
    }
    //browser.pause(3*1000);
    this.browser_session.waitForLoadingSection(browser, myPanel_xpath);
  });
};
