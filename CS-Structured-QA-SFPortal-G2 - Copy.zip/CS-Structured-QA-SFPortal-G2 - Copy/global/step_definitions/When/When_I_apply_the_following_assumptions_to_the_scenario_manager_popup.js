//When_I_apply_the_following_assumptions_to_the_scenario_manager_popup.js
module.exports = function() {
this.When(/^I apply the following assumptions to the scenario manager popup$/, function (table) {
         // Write code here that turns the phrase above into concrete actions
      var assumption_list = table.hashes();
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      const scenarioManager_xpath = this.xpath_lib.xpathRequire('scenarioManager_xpath');
      this.browser_session.waitForResource(browser,scenarioManager_xpath.scenarioManagerAssumptions);
      console.log(scenarioManager_xpath.scenarioManagerAssumptions)
      browser.getLocationInView(scenarioManager_xpath.scenarioManagerAssumptions);
      browser.pause(500);
      var self = this;

      assumption_list.forEach(function(list_row)
      {
        switch(list_row['name']){
          case "scen.cal_first_loss":
          case "scen.seed_default":
          case "scen.ignore_input_nonpayment_term":
          case "scen.calc_curve_off_static_bal":
          case "scen.useACHVector":
          case "scen.apply_watch":
          case "scen.apply_loan_level_assumps":
          case 'scen.term_triggers_activate_LTV_trigger':
          case 'scen.term_triggers_activate_DSCR_trigger':
          case 'scen.maturity_trigger_activate_LTV_trigger':
          case 'scen.maturity_trigger_activate_DY_trigger':
            console.log(list_row['name']);
            var check_box = scenarioManager_xpath.scenarioManagerCheckBox.replace('__NAME__',list_row['name']);
            var check_flag = scenarioManager_xpath.scenarioManagerCheckBox.replace('__NAME__',list_row['name']);
            var target_attribute = browser.getAttribute(check_flag, 'class');
            if (list_row['value']=='checked'&&target_attribute.indexOf('ng-empty') > -1 ){
              console.log(check_box)
              browser.click(check_box);
              browser.pause(100); 
             }
            if (list_row['value']=='unchecked' && target_attribute.indexOf('ng-not-empty')>-1) {
              browser.click(check_box);
              browser.pause(100);
            }
            break;
          case "scenarioManagerCtrl.assestClass_selected":
          case "scen.solve_for":
          case "scen.forward_curve":
          case "scen.loss_type":
          case "scen.delinquency_type":
          case "scen.repay_type":
          case "scen.purchase_type":
          case "scen.portfolio_yield_type":
          case "scen.portfolio_loss_type":
          case "scen.deferment_type":
          case "scen.grace_type":
          case "scen.forbear_type":
          case "scen.interest_cap_freq":
          case "scen.BB_type":
          case "scen.reinvest_price_type":
          case "scen.reinvest_pool":
          case "scen.reinvest_rules":    
          case "scen.call_option":
          case "scen.force_call":
          case "scen.call_price_type":
          case "scen.prepay_type":
          case "scen.default_type":
          case "scen.NOI_growth_rate_type":
          case "scen.cap_rate_growth_rate_type":
          case "scen.term_triggers_select_priority":
          case "scen.maturity_trigger_select_priority":
          case 'scen.servicer_basis':
          case 'scen.servicer_type':
            console.log(list_row['name']);
            var deal_CfSfpSelect = scenarioManager_xpath.scenarioManagerfpSelect.replace('__NAME__',list_row['name']);
            console.log(deal_CfSfpSelect);
            browser.getLocationInView(deal_CfSfpSelect);
            browser.click(deal_CfSfpSelect);
            browser.waitForVisible(scenarioManager_xpath.scenarioManagerSelDropDown.replace('__NAME__',list_row['name']),self.waitDefault);
            browser.click(scenarioManager_xpath.scenarioManagerDropDSelItem.replace('__NAME__',list_row['name']).replace('__ITEM__',list_row['value']));
            console.log(browser.getValue(deal_CfSfpSelect));
            // console.log(browser.getHTML(scenarioManager_xpath.scenarioManagerSelDropDown.replace('__NAME__',list_row['name'])));
            break;
          case "scenarioManagerCtrl.outputType":
          case "scenarioManagerCtrl.scenarioMethod":
          case "scenarioManagerCtrl.scenarioInput":
            console.log(list_row['name']);
            var deal_CfSfpSelect = scenarioManager_xpath.scenarioManagerfpSelect.replace('__NAME__',list_row['name']);
            console.log(deal_CfSfpSelect);
            browser.click(deal_CfSfpSelect);
            try{
              browser.waitForVisible(scenarioManager_xpath.scenarioManagerSelDropDown.replace('__NAME__',list_row['name']),self.waitDefault);
            }catch(e){
              console.log('try again...');
              browser.click(deal_CfSfpSelect);
              browser.waitForVisible(scenarioManager_xpath.scenarioManagerSelDropDown.replace('__NAME__',list_row['name']),self.waitDefault);
            }
            
            browser.click(scenarioManager_xpath.scenarioManagerDropDSelItem.replace('__NAME__',list_row['name']).replace('__ITEM__',list_row['value']));
            break;
          case "scenarioManagerCtrl.scenarioMidPoint":
          case "scenarioManagerCtrl.scenarioStepSize":
            console.log(list_row['name']);
            var assumptions_input = scenarioManager_xpath.scenarioManagerInput.replace('__NAME__',list_row['name']);
            browser.setValue(assumptions_input,list_row['value']);
            console.log(browser.getValue(assumptions_input));
            break;
          case "scen.scenTypeSelected": 
            console.log(list_row['name']);
            var sentypeSelect = scenarioManager_xpath.scenarioManagerfpSelect.replace('__NAME__',list_row['name']);
            browser.waitForVisible(sentypeSelect);
            console.log(sentypeSelect);
            // browser.setValue(sentypeSelect,list_row['value']);
            browser.click(sentypeSelect); 
            var select_item = scenarioManager_xpath.scenarioManagerDropDSelItem.replace('__NAME__', list_row['name']).replace('__ITEM__', list_row['value']);
            // content_xpath.namedSelectItem.replace('__NAME__', list_row['value']);
            console.log(select_item);
            browser.waitForVisible(select_item,self.waitDefault);
            browser.click(select_item);
            break; 
          case "scenarioManagerCtrl.scenario_name":     
          // case "scen.settle_date":
          case "scen.prepay_rate":
          case "scen.default_rate":
          case "scen.loss_rate":
          case "scen.delinquency_rate":
          case "scen.adv_loss_rate":
          case "scen.adv_lag_mon":
          case "scen.repay_rate":
          case "scen.purchase_rate":
          case "scen.portfolio_yield_rate":
          case "scen.portfolio_loss_rate":
          case "scen.deferment_rate":
          case "scen.grace_rate":
          case "scen.forbear_rate":
          case "scen.BB_utilization_rate":
          case "scen.subsidy_payment_delay":
          case "scen.SAP_payment_delay":
          case "scen.prinLossSeverityPctNonPerf":
          case "scen.rec_lag":
          case "scen.alloc_mon":
          case "scen.reinvest_price":
          case "scen.reinvDefaultLockout":
          case "scen.NOI_growth_rate":
          case "scen.cap_rate_growth_rate":
          case "scen.term_triggers_LTV_liquidate":
          case "scen.term_triggers_LTV_months":
          case "scen.term_triggers_LTV_loss":
          case "scen.term_triggers_DSCR_liquidate":
          case "scen.term_triggers_DSCR_months":
          case "scen.term_triggers_DSCR_loss":
          case "scen.maturity_trigger_LTV_payoff":
          case "scen.maturity_trigger_LTV_liquidate":
          case "scen.maturity_trigger_LTV_loss":
          case "scen.maturity_trigger_LTV_extension":
          case "scen.maturity_trigger_LTV_end_of_extension_liq_or_payoff":
          case "scen.maturity_trigger_LTV_end_of_extension_loss":
          case "scen.maturity_trigger_DY_payoff":
          case "scen.maturity_trigger_DY_liquidate":
          case "scen.maturity_trigger_DY_loss":
          case "scen.maturity_trigger_DY_extension":
          case "scen.maturity_trigger_DY_end_of_extension_liq_or_payoff":
          case "scen.maturity_trigger_DY_end_of_extension_loss":
          case "scen.servicer_rate":
          case "scen.call_date":
          case "scen.plus_minus_months":
          case "scen.reinvest_spread":
          case "scen.reinvest_term":
          case "scen.call_price":
          //Input field with ng-model  
            console.log(list_row['name']);
            if(list_row['value'] == 'current date'){
                var assumptions_input = scenarioManager_xpath.scenarioManagerInput.replace('__NAME__',list_row['name']);
                browser.click(assumptions_input);
                var today = scenarioManager_xpath.settleDateToday;
                browser.click(today);
                console.log("has set " + list_row['name'] + " to " + list_row['value']);
                console.log(browser.getValue(assumptions_input));
                break;
            }       
            var assumptions_input = scenarioManager_xpath.scenarioManagerInput.replace('__NAME__',list_row['name']);
            browser.setValue(assumptions_input,list_row['value']);
            console.log(browser.getValue(assumptions_input));
            break;
        }
      });
  });
}