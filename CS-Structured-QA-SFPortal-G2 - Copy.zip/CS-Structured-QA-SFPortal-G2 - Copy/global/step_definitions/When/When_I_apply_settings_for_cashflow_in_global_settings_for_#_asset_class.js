// Recommended filename: When_I_apply_settings_for_cashflow_in_global_settings_for_#_asset_class_as_below.js
module.exports = function() {
  this.When(/^I apply (settings|Economy001|Economy002|Economy003) for cashflow in global settings for "([^"]*)" asset class as below$/, 
    {timeout:process.env.StepTimeoutInMS*5},
    function (economy_num, assetType, table) {
    // Write code here that turns the phrase above into concrete actions
    const settingsPage_xpath = this.xpath_lib.xpathRequire('settingsPage_xpath');
    var setting_list = table.hashes();

    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    var self = this;
    
    this.economyNum='';
    switch(economy_num){
        case 'Economy001':
            self.economyNum='Ec01';
            break;
        case 'Economy002':
            self.economyNum='Ec02';
            break;
        case 'Economy003':
            self.economyNum='Ec03';
            break;
    }
    var assetTab = settingsPage_xpath.cashflowSettingsAssetTypeTab.replace('__TABNAME__',assetType);
    console.log(assetTab);
    try{
      browser.waitForEnabled(assetTab,this.wait5);
      browser.click(assetTab);
    }catch(e){
      console.log('try again...');
      assetTab = settingsPage_xpath.cashflowSettingsAssetTypeTab1.replace('__TABNAME__',assetType);
      browser.click(assetTab);
    }

    if(assetType == 'CDO'){
        setting_list.forEach(function(list_row)
        {
        switch(list_row['name']){
            //checkbox items
            case "Default Until End":
            case "Default Before Amort":
            case "Non Performing Bonds Default":
            case "Recover Defaults at Maturity/Call":
            case "Liq NonPerf @ Market":
            case "Use Asset-Level Recovery Rate":
            case "Use Asset-Level Recovery Rate for NonPerf":
            case "Use Recovery Schedule (Periods)":
                var check_box = settingsPage_xpath.cashflowSettingsCheckBoxItems.replace('__CHECKBOXLABEL__',list_row['name']);
                console.log(check_box);
                var target_attribute = browser.getAttribute(check_box, 'aria-checked');
                console.log(target_attribute);
                if (list_row['value']=='checked' && target_attribute=='false'){
                    browser.click(check_box);
                    browser.pause(100); 
                }
                if (list_row['value']=='unchecked' && target_attribute=='true') {
                    browser.click(check_box);
                    browser.pause(100);
                }
                break;
            //select items
            case "Default Bond Rating Moody's":
            case "Default Bond Rating S&P":
            case "Default Bond Rating Fitch":
                var selectIcon = settingsPage_xpath.cashflowSettingsSelectIcon.replace('__SELECTLABEL__',list_row['name']);
                console.log(selectIcon);
                browser.click(selectIcon);
                if (list_row['value'] == "NR"){
                    var selectValue = settingsPage_xpath.cashflowSettingsSelectOption11;
                }else{
                    var selectValue = settingsPage_xpath.cashflowSettingsSelectOption.replace('__OPTIONTEXT__',list_row['value']);
                }
                console.log(selectValue);
                var selectMenu = settingsPage_xpath.cashflowSettingsSelectMenu;
                browser.waitForVisible(selectMenu);
                console.log(selectMenu);
                browser.click(selectValue);
                break;
            //input items
            case "Default Bond below Market Price":
            case "Custom Flags Default Rate":
            case "Custom Flags Loss Rate":
            case "Interest Loss Severity":
                var inputItem = settingsPage_xpath.cashflowSettingsInputItems.replace('__INPUTLABEL__',list_row['name']);
                if(!browser.isVisible(inputItem)){
                  inputItem = settingsPage_xpath.cashflowSettingsInputItems1.replace('__INPUTLABEL__',list_row['name']);
                }
                console.log(inputItem);
                browser.setValue(inputItem,list_row['value']);
                console.log(browser.getValue(inputItem));
                break;
            }
        })
    }
    else{
        setting_list.forEach(function(list_row)
        {
        switch(list_row['name']){
            //checkbox items
            case "Default Until End":
            case "REO":
            case "Foreclosed":
            case "Delinquent":
            case "Bankrupt":
            case "Interest Calculated Before Defaults":
            case "Reimburse Advance P&I":
            case "Prepays Only On Pay Dates":
                var check_box = settingsPage_xpath.cashflowSettingsCheckBoxItemsforABS.replace('__CHECKBOXLABEL__',list_row['name']);
                console.log(check_box);
                var target_attribute = browser.getAttribute(check_box, 'aria-checked');
                console.log(target_attribute);
                if (list_row['value']=='checked' && target_attribute=='false'){
                    browser.click(check_box);
                    browser.pause(100); 
                }
                if (list_row['value']=='unchecked' && target_attribute=='true') {
                    browser.click(check_box);
                    browser.pause(100);
                }
                break;
            //select items
            case "Calculation Method":
            case "Servicer Advances P&I":
                var selectIcon = settingsPage_xpath.cashflowSettingsSelectIconforABS.replace('__SELECTLABEL__',list_row['name']);
                console.log(selectIcon);
                browser.click(selectIcon);
                browser.pause(200);
                var selectValue = settingsPage_xpath.cashflowSettingsSelectOption.replace('__OPTIONTEXT__',list_row['value']); 
                try{
                  browser.click(selectValue);
                }catch(e){
                  selectValue = settingsPage_xpath.cashflowSettingsSelectOption1.replace('__OPTIONTEXT__',list_row['value']); 
                  browser.click(selectValue);
                }
                break;
            //input items
            case "Interest Loss Severity":
                var inputItem = settingsPage_xpath.cashflowSettingsInputItemsforABS.replace('__INPUTLABEL__',list_row['name']);
                if(!browser.isVisible(inputItem)){
                  inputItem = settingsPage_xpath.cashflowSettingsInputItemsforABS2.replace('__INPUTLABEL__',list_row['name']);
                }
                console.log(inputItem);
                browser.setValue(inputItem,list_row['value']);
                console.log(browser.getValue(inputItem));
                break;
            case "Delinquent Min Months":
                var inputItem = settingsPage_xpath.cashflowDelinquentMinMonthsInput;
                console.log(inputItem);
                browser.setValue(inputItem,list_row['value']);
                console.log(browser.getValue(inputItem));
                break;
            case "Bankrupt Min Months":
                var inputItem = settingsPage_xpath.cashflowBankruptMinMonthsInput;
                console.log(inputItem);
                browser.setValue(inputItem,list_row['value']);
                console.log(browser.getValue(inputItem));
                break;
            case "Max Prepay Rate":
                var inputItem = settingsPage_xpath.cashflowSettingsInputItemsforABS3.replace('__INPUTLABEL__',"Max Prepay");
                console.log(inputItem);
                browser.setValue(inputItem,list_row['value']);
                console.log(browser.getValue(inputItem));
                break;
            case "Max Prepay Type":
                var selectItem = settingsPage_xpath.cashflowMaxPrepayType.replace('__INPUTLABEL__',"Max Prepay");
                browser.click(selectItem);
                browser.pause(200);
                var selectValue = settingsPage_xpath.cashflowSettingsSelectOption.replace('__OPTIONTEXT__',list_row['value']);
                browser.click(selectValue);
                break;
            }
        })
    };
  });
}