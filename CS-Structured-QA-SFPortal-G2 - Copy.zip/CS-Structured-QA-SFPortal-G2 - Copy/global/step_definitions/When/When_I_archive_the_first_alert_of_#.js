// When_I_#_the_vector_named_#.js
module.exports = function() {
this.When(/^I archive the (first|second) alert of "([^"]*)"$/, function (num,alertName) {
    // Write code here that turns the phrase above into concrete actions
    this.browser_session.waitForResource(browser);

    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const portfolioPage_xpath = this.xpath_lib.xpathRequire('portfolioPage_xpath');
    var alertsPanel = content_xpath.titledPanel.replace('__TITLE__','Alerts');
    var alertsPanelDeal = content_xpath.titledPanel.replace('__TITLE__','News/Alerts');
    var alertsPanelAll = content_xpath.titledPanelContains.replace('__TITLE__','Alerts');

    var inputValue = alertName;
    var archiveNum;
    switch(num){
        case 'first':
            archiveNum = 1;
            break;
        case 'second':
            archiveNum = 2;
            break;
    }

    if(alertName=='archive_clo_test'||alertName=='archive_abs_test'||alertName=='archive_clo_deal'||alertName=='archive_abs_deal'){
        inputValue= this.alertsName;
    }
    console.log(inputValue);
    if(alertName=='archive_clo_test'||alertName=='archive_abs_test'){
        browser.setValue(alertsPanel+'//input',inputValue);
    }else if(alertName=='any screener'){
    }else{
        browser.setValue(alertsPanelDeal+'//input',inputValue);
    }
    browser.pause(500);

    var archiveArray = new Object();
    for(var i=2; i<13; i++){        
        var keys = browser.getText(alertsPanelAll+'//table[contains(@class,"alertsTable")]//th['+ i +']//span[@class="text"]');
        var alertValue_xpath = alertsPanelAll+'//table[contains(@class,"alertsTable")]//tbody//tr['+archiveNum+']//td[' + i + ']//span[@ng-bind-html]';
        if(i==2){
            alertValue_xpath = alertValue_xpath + '//a';
        }
        var alertValue = browser.getText(alertValue_xpath); 
        archiveArray[keys]=alertValue;           
    }
    console.log(archiveArray);
    this.archiveArray=archiveArray;
    
    var archiveRow = browser.getText(alertsPanelAll+'//table[contains(@class,"alertsTable")]//tbody//tr['+archiveNum+']');
    console.log(archiveRow);
    this.archiveRow=archiveRow;

    // if(alertName=='archive_clo_deal'||alertName=='archive_abs_deal'){
    var archiveBtn = alertsPanelAll+portfolioPage_xpath.archiveBtn.replace('__NUM__',archiveNum);
    // }else{
    //     var archiveBtn = portfolioPage_xpath.archiveBtn.replace('__NUM__',archiveNum);
    // }
    browser.click(archiveBtn);
    browser.pause(2000);
    
  });
}