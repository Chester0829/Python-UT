module.exports=function(){
  this.When(/^I (exclude|include) owned notional amount weightings and get UI data on "([^"]*)" page$/, function (excludeFlag,pageName) {
         // Write code here that turns the phrase above into concrete actions
         const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
         const performancePage_xpath = this.xpath_lib.xpathRequire('performancePage_xpath');
         var ptCheckbox = content_xpath.modeCheckbox.replace('__NAME__','ptFlag');
         var weightingsCheckbox = content_xpath.modeCheckbox.replace('__NAME__','isOwnNotional');
         var applyButton = content_xpath.applyButton;

         var customize = "//a[contains(text(),'Customize')]";
         if(!browser.isVisible(content_xpath.customizeDropDown)){
            browser.waitForVisible(customize,this.waitDefault);
            browser.click(customize);
            browser.waitForVisible(content_xpath.customizeDropDown,this.waitMax);
         }
         
         var ptAttribute = browser.getAttribute(ptCheckbox,'class');
         var weightingsAttribute = browser.getAttribute(weightingsCheckbox,'class');         
         if(ptAttribute.indexOf('ng-empty')!=-1){
           browser.click(ptCheckbox);
         }
         if((excludeFlag=='exclude'&&weightingsAttribute.indexOf('ng-empty')!=-1)||
           (excludeFlag=='include'&&weightingsAttribute.indexOf('ng-not-empty')!=-1)){
           browser.click(weightingsCheckbox);         
           browser.pause(50);
           browser.click(applyButton);
           this.browser_session.waitForLoading(browser);
         }

         var self=this;
         browser.pause(5*1000);         

         var getTableData = function(tableList){
           var uiValues = [];
           for(var i=0;i<4;i++){
             var index = i + 1;
             var xLabels = browser.getText(performancePage_xpath.xLabel);
             var tooltip = performancePage_xpath.tooltip; 
             var xLabelText = xLabels[i].split('\n');
             var yLabelText = browser.getText('(' + performancePage_xpath.xLabel + ')['+index+']/following-sibling::*[1]').split('\n')[0];
             var tmpIndex = [];
             var yLabelXpath = '(' + performancePage_xpath.xLabel + ')['+index+']/following-sibling::*[1]//*[text()="'+yLabelText+'"]';
             browser.moveToObject(yLabelXpath,50,-12);
             browser.pause(500);
             browser.moveToObject(yLabelXpath,50,-12);
             var tooltipValue = browser.getText('(' + tooltip + ')[' + index + ']');
             tmpIndex.push(tooltipValue);
             for(var j=0;j<xLabelText.length;j++){
              var xLabelXpath = '(' + performancePage_xpath.xLabel + ')['+ index +']//*[text()="'+ xLabelText[j] +'"]';
              browser.moveToObject(xLabelXpath,50,-12);
              tooltipValue = browser.getText('(' + tooltip + ')[' + index + ']');
              console.log('-----' + tooltipValue);
              tmpIndex.push(tooltipValue);
              browser.pause(500);
             }
             uiValues.push(tmpIndex);
           }           
           return uiValues;
         }

         var performanceData = getTableData();         
         console.log(performanceData);

         browser.click(weightingsCheckbox);
         browser.pause(50);
         browser.click(applyButton);
         this.browser_session.waitForLoading(browser);
         browser.refresh();

         if(excludeFlag=='exclude'){
           this.excludeWeightingsData=performanceData;
         }else{
           this.weightingsData=performanceData;
         }    

       });
}