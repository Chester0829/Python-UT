//Then_I_apply_the_Deal_cashflow_assumptions_of_the_following_table_to_the_scenario_#.js
module.exports = function () {
  this.When(/^I apply the Deal cashflow assumptions of the following table to the scenario "([^"]*)"$/, function (arg1, table) {
    // Write code here that turns the phrase above into concrete actions
    var assumption_list = table.hashes();
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
    var scenario_num = arg1;
    this.browser_session.waitForResource(browser, cashflow_xpath.dealCfsAssumptions);
    console.log(cashflow_xpath.dealCfsAssumptions)
    //browser.getLocationInView('//*[normalize-space()="Assumptions"]/ancestor::md-card-title');
    // browser.click('//*[normalize-space()="Assumptions"]/ancestor::md-card-title');
    browser.pause(500);
    var self = this;
    this.firstloss=false
    this.currentdate = false
    this.isCustom = "MR"
    const dateFormat = require('dateformat');
    // come form Then_I_should_see_#_widget.js
    // this.assumptionsList.push(assumption_list);
    assumption_list.forEach(function (list_row) {
      switch (list_row['name']) {
        case "scen.run_flag":
        case "scen.cal_first_loss":
        case "scen.seed_default":
        case "scen.ignore_input_nonpayment_term":
        case "scen.calc_curve_off_static_bal":
        case "scen.useACHVector":
        case "scen.apply_watch":
        case "scen.apply_loan_level_assumps":
        case 'scen.term_triggers_activate_LTV_trigger':
        case 'scen.term_triggers_activate_DSCR_trigger':
        case 'scen.maturity_trigger_activate_LTV_trigger':
        case 'scen.maturity_trigger_activate_DY_trigger':
          var check_box = '(' + cashflow_xpath.dealcfsCheckBox.replace('__NAME__', list_row['name']) + ')[' + arg1 + ']';
          var check_flag = '(' + cashflow_xpath.dealcfsCheckBox.replace('__NAME__', list_row['name']) + ')[' + arg1 + ']';
          var target_attribute = browser.getAttribute(check_flag, 'class');
          if (list_row['value'] == 'checked' && target_attribute.indexOf('ng-empty') > -1) {
            console.log(check_box)
            browser.click(check_box);
            browser.pause(100);
          }
          if (list_row['value'] == 'unchecked' && target_attribute.indexOf('ng-not-empty') > -1) {
            browser.click(check_box);
            browser.pause(100);
          }
          if(list_row['value'] == 'checked' && list_row['name']=='scen.cal_first_loss'){
            self.firstloss = true;
          }
          break;
        case "scen.solve_for":        
        case "scen.loss_type":
        case "scen.delinquency_type":
        case "scen.repay_type":
        case "scen.purchase_type":
        case "scen.portfolio_yield_type":
        case "scen.portfolio_loss_type":
        case "scen.deferment_type":
        case "scen.grace_type":
        case "scen.forbear_type":
        case "scen.interest_cap_freq":
        case "scen.BB_type":
        case "scen.reinvest_price_type":
        case "scen.reinvest_pool":
        case "scen.reinvest_rules":
        case "scen.call_option":
        case "scen.force_call":
        case "scen.call_price_type":
        case "scen.prepay_type":
        case "scen.default_type":
        case "scen.NOI_growth_rate_type":
        case "scen.cap_rate_growth_rate_type":
        case "scen.term_triggers_select_priority":
        case "scen.maturity_trigger_select_priority":
        case 'scen.servicer_basis':
        case 'scen.servicer_type':
          var deal_CfSfpSelect = '(' + cashflow_xpath.dealCfSfpSelect.replace('__NAME__', list_row['name']) + ')[' + arg1 + ']';
          console.log(deal_CfSfpSelect);
          browser.click(deal_CfSfpSelect);
          browser.waitForVisible(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__', list_row['name']), self.waitDefault);
          browser.click(cashflow_xpath.dealCfsDropDSelItem.replace('__NAME__', list_row['name']).replace('__ITEM__', list_row['value']));
          console.log(browser.getValue(deal_CfSfpSelect));
          // console.log(browser.getHTML(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__',list_row['name'])));
          break;
        case "scen.forward_curve":
          var deal_CfSfpSelect = '(' + cashflow_xpath.dealCfSfpSelect.replace('__NAME__', list_row['name']) + ')[' + arg1 + ']';
          console.log(deal_CfSfpSelect);
          browser.click(deal_CfSfpSelect);
          browser.waitForVisible(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__', list_row['name']), self.waitDefault);
          browser.click(cashflow_xpath.dealCfsDropDSelItem.replace('__NAME__', list_row['name']).replace('__ITEM__', list_row['value']));
          console.log(browser.getValue(deal_CfSfpSelect));
          if(list_row['value']=="Custom"){
            self.isCustom='CR'
          }
          // console.log(browser.getHTML(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__',list_row['name'])));
          break;
        case "analyticsCtrl.outputType":
        case "analyticsCtrl.scenarioMethod":
        case "analyticsCtrl.scenarioInput":
          var deal_CfSfpSelect = cashflow_xpath.dealCfSfpSelect.replace('__NAME__', list_row['name']);
          console.log(deal_CfSfpSelect);
          browser.click(deal_CfSfpSelect);
          try {
            browser.waitForVisible(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__', list_row['name']), self.waitDefault);
          } catch (e) {
            console.log('try again...');
            browser.click(deal_CfSfpSelect);
            browser.waitForVisible(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__', list_row['name']), self.waitDefault);
          }

          browser.click(cashflow_xpath.dealCfsDropDSelItem.replace('__NAME__', list_row['name']).replace('__ITEM__', list_row['value']));
          break;
        case "analyticsCtrl.scenarioMidPoint":
        case "analyticsCtrl.scenarioStepSize":
          var assumptions_input = cashflow_xpath.dealCfsInput.replace('__NAME__', list_row['name']);
          browser.setValue(assumptions_input, list_row['value']);
          console.log(browser.getValue(assumptions_input));
          break;
        case "scen.scenType":
          var sentypeSelect = '(' + cashflow_xpath.mdSelect.replace('__NAME__', list_row['name']) + ')[' + arg1 + ']';
          browser.waitForVisible(sentypeSelect);
          console.log(sentypeSelect);
          browser.click(sentypeSelect);
          var select_item = content_xpath.namedSelectItem.replace('__NAME__', list_row['value']);
          console.log(select_item);
          browser.waitForVisible(select_item, self.waitDefault);
          browser.click(select_item);
          break;
        case "scen.scenarioNameSelected":
          var scenName_div = '(//div[@ng-model="' + list_row['name'] + '"])[' + arg1 + ']';
          var scenName_i = scenName_div + '//i[@role="button"]';
          browser.waitForVisible(scenName_i);
          browser.click(scenName_i);
          var select_item = scenName_div + '/ul/li/div[@role="option"]/a/div[contains(normalize-space(), "' + list_row['value'] + '")]';
          browser.waitForVisible(select_item, self.waitDefault);
          browser.click(select_item);
          break;
        // // case "scen.NOI_growth_rate_type":
        // // case "scen.cap_rate_growth_rate_type":
        // // case "scen.term_triggers_select_priority":
        // // case "scen.maturity_trigger_select_priority":
        // // case "scen.servicer_basis":
        // case "scen.servicer_type":
        // // case "scen.apply_loan_level_assumps":
        //   // Select field of select ng-model
        //   var assumptions_select = '(' + cashflow_xpath.dealCfsSelect.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
        //   console.log(assumptions_select);
        //   browser.selectByVisibleText(assumptions_select, list_row['value']);
        //   console.log(browser.getText(assumptions_select));
        // break;
        case "scen.settle_date":
        case "scen.prepay_rate":
        case "scen.default_rate":
        case "scen.loss_rate":
        case "scen.delinquency_rate":
        case "scen.adv_loss_rate":
        case "scen.adv_lag_mon":
        case "scen.repay_rate":
        case "scen.purchase_rate":
        case "scen.portfolio_yield_rate":
        case "scen.portfolio_loss_rate":
        case "scen.deferment_rate":
        case "scen.grace_rate":
        case "scen.forbear_rate":
        case "scen.BB_utilization_rate":
        case "scen.subsidy_payment_delay":
        case "scen.SAP_payment_delay":
        case "scen.prinLossSeverityPctNonPerf":
        case "scen.rec_lag":
        case "scen.alloc_mon":
        case "scen.reinvest_price":
        case "scen.reinvDefaultLockout":
        case "scen.NOI_growth_rate":
        case "scen.cap_rate_growth_rate":
        case "scen.term_triggers_LTV_liquidate":
        case "scen.term_triggers_LTV_months":
        case "scen.term_triggers_LTV_loss":
        case "scen.term_triggers_DSCR_liquidate":
        case "scen.term_triggers_DSCR_months":
        case "scen.term_triggers_DSCR_loss":
        case "scen.maturity_trigger_LTV_payoff":
        case "scen.maturity_trigger_LTV_liquidate":
        case "scen.maturity_trigger_LTV_loss":
        case "scen.maturity_trigger_LTV_extension":
        case "scen.maturity_trigger_LTV_end_of_extension_liq_or_payoff":
        case "scen.maturity_trigger_LTV_end_of_extension_loss":
        case "scen.maturity_trigger_DY_payoff":
        case "scen.maturity_trigger_DY_liquidate":
        case "scen.maturity_trigger_DY_loss":
        case "scen.maturity_trigger_DY_extension":
        case "scen.maturity_trigger_DY_end_of_extension_liq_or_payoff":
        case "scen.maturity_trigger_DY_end_of_extension_loss":
        case "scen.servicer_rate":
        case "scen.call_date":
        case "scen.plus_minus_months":
        case "scen.reinvest_spread":
        case "scen.reinvest_term":
        case "scen.call_price":
          //Input field with ng-model  
          if (list_row['value'] == 'current date' || list_row['value']=='Current Date') {
            var assumptions_input = '(' + cashflow_xpath.dealCfsInput.replace('__NAME__', list_row['name']) + ')[' + arg1 + ']';
            browser.click(assumptions_input);
            var today = cashflow_xpath.settleDateToday;
            browser.click(today);
            console.log(browser.getValue(assumptions_input));
             console.log(browser.getValue(assumptions_input));
             var date = browser.getValue(assumptions_input);
             date = date.replace(/-/g,'/');
             var date = new Date(date);
             date.setDate(date.getDate() - 2);
             var new_date = dateFormat(date,"yyyy-mm-dd");
             console.log(new_date);
             browser.setValue(assumptions_input,new_date);
             console.log("has set " + list_row['name'] + " to " + new_date);
            self.isCurrentdate = true
            break;
          }
          var assumptions_input = '(' + cashflow_xpath.dealCfsInput.replace('__NAME__', list_row['name']) + ')[' + arg1 + ']';
          browser.setValue(assumptions_input, list_row['value']);
          console.log(browser.getValue(assumptions_input));
          break;
      }
    });
  });
}