// Recommended filename: When_I_download_PDF_file_by_click_the_Export_PDF_icon_in_#_mode.js
// When I download PDF file by click the Export PDF icon in portfolio mode
module.exports = function() {
	this.When(/^I download PDF file by click the Export PDF icon in (portfolio|manager) mode$/,
	{timeout: process.env.StepTimeoutInMS*5},
	function(mode){
		// check download pdf and check widget name exists in pdf.
		this.browser_session.waitForResource(browser);
		const execSync = require('child_process').execSync;
		const pdfDownload_xpath = this.xpath_lib.xpathRequire('pdfDownload_xpath');
		var exportPDF_xpath = pdfDownload_xpath.exportPDF_xpath;
		var active_page_item = browser.getText(pdfDownload_xpath.active_page_item).trim();
		var select_xpath = pdfDownload_xpath.pdf_sfp_xpath + pdfDownload_xpath.select_xpath;
		var selectedText_xpath = pdfDownload_xpath.pdf_sfp_xpath + pdfDownload_xpath.selectedText_xpath;
		var export_xpath = pdfDownload_xpath.pdf_sfp_xpath + pdfDownload_xpath.export_xpath;

		var pdfName = mode[0].toUpperCase() + mode.slice(1).toLowerCase() + ' ' + active_page_item + '.pdf';
		console.log(pdfName);
		this.file_session.deleteFiles(pdfName);

		browser.waitForVisible(exportPDF_xpath,this.waitDefault);
		browser.click(exportPDF_xpath);
		browser.waitForVisible(select_xpath,this.waitDefault);
		browser.selectByValue(select_xpath,'General');
		browser.pause(1000);
		// get selectedText
		this.selectedTextList = browser.getText(selectedText_xpath).split('\n');
		console.log(this.selectedTextList);
		// click export button
		browser.click(export_xpath);
		var my_download_file = this.file_session.waitForDownload(browser,pdfName);
		console.log('my download file: ' + my_download_file);
		// check export pdf button
		browser.waitForVisible(exportPDF_xpath,this.waitDefault);

		var downloadDir = my_download_file.substring(0, my_download_file.lastIndexOf('/'));
		console.log(downloadDir);
		var tmp_file = downloadDir + '/' + pdfName.replace('.pdf','.log').replace(/\s/g,'_');
		this.file_session.deleteFiles(tmp_file);
		
		var script_path = process.env.ProjectFullPath + '/scripts/readPDF.js';
		var cmd = 'node ' + script_path + ' "' + my_download_file + '" > ' + tmp_file;
		console.log(cmd);
		execSync(cmd);
		var fs = require('fs');
		var pdfTextInfo = fs.readFileSync(tmp_file,{encoding:'utf-8'}).replace(/[\r\s]/g,'');
		console.log(pdfTextInfo);

	})
}