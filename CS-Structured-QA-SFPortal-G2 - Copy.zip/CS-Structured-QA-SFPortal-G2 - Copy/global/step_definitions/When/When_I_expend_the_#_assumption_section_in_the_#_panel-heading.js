//When_I_expend_the_#_assumption_section_in_the_#_panel-heading.js
module.exports = function() {
  this.When(/^I expend the "([^"]*)" assumption section in the "([^"]*)" panel-heading$/, function (labelName, panelName) {
    // Write the automation code here
    // pending();
    this.browser_session.waitForResource(browser);
    const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
    const scenarioManager_xpath = this.xpath_lib.xpathRequire('scenarioManager_xpath');

    if(labelName == "Deal Overrides"){
        var assumptionLabel = cashflow_xpath.cashflowDealOverridesLabel.replace('__LABEL__',labelName);
        browser.click(assumptionLabel);
        var dealOverridesTable = cashflow_xpath.cashflowDealOverridesTable;
        console.log(dealOverridesTable);
        console.log(browser.isVisible(dealOverridesTable));
        if(browser.isVisible(dealOverridesTable) == false){
          browser.click(assumptionLabel);
        }
        browser.waitForVisible(dealOverridesTable);
    }else if(labelName == "Term Triggers" || labelName == "Maturity Trigger"){
        var assumptionLabel = scenarioManager_xpath.scenarioManagerLabel.replace('__LABEL__',labelName);
        browser.click(assumptionLabel);
    }else if(labelName == "Prepay Type"||labelName == "Grace Type"){
        var assumptionLabel = scenarioManager_xpath.scenarioManagerLabelLink.replace('__LABEL__',labelName);
        browser.click(assumptionLabel);
    }
  });
};
