// Recommended filename: When_I_download_#_file_under_the_#_#_widget_by_click_the_#_icon_in_portfolio_mode.js
module.exports = function() {
	this.When(/^I download "([^"]*)" file under the "([^"]*)" (table|charts|pie chart|bar chart|multi table) widget by click the "([^"]*)" icon in (portfolio|stored portfolio) mode$/, 
		{timeout: process.env.StepTimeoutInMS*5},
		function (filetype, widgetName, widgetType, button,mode ) {
			// Write code here that turns the phrase above into concrete actions
			this.browser_session.waitForResource(browser);
			const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
			const download_xpath = this.xpath_lib.xpathRequire('portfolioModeDownload_xpath');
			const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
			var chartTtile = this.xpath_lib.xpathRequire('chartTitle');
			var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());
			const fs = require('fs');
			const path = require('path');
			if (widgetName == 'Results' && this.page == 'Cashflows'){
				myPanel = cashflow_xpath.portfolioCfsAllresultwidget;
			}
			switch(button){
				case 'download':
					// var download_icon_xpath = myPanel + download_xpath.download_icon;
					var icon_xpath = download_xpath.download_icon;
					break;
				case 'Current':
				case 'Export All':
					var icon_xpath = download_xpath.currentOrExportAll_download_icon.replace('__CURRENTTYPE__',button);
					break;
			}
			var download_icon_xpath = myPanel + icon_xpath;
			this.no_data_text_list = download_xpath.no_data_text_list;
			// console.log(this.no_data_text_list);
			console.log(download_icon_xpath)
			if(widgetType != 'table'){
				if(this.portfolio != undefined){
					var chartTitleList = chartTtile['portfolio'];
				}else if(this.manager != undefined){
					var chartTitleList = chartTtile['manager'];
				}
				if(chartTitleList[widgetName] != undefined){
					var titleTextInCsv = ('title' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['title'] : chartTitleList[widgetName];
					var offsetX = ('offsetX' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetX']: 0;
					var offsetY = ('offsetY' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetY']: 0;
					var separator = ('separator' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['separator']: '';
					var flag = true;
				}else if(chartTitleList[this.chartName] != undefined){
					var titleTextInCsv = 'title' in chartTitleList[this.chartName] ? chartTitleList[this.chartName]['title'] : chartTitleList[this.chartName];
					var offsetX = ('offsetX' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetX']: 0;
					var offsetY = ('offsetY' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['offsetY']: 0;
					var separator = ('separator' in chartTitleList[widgetName]) ? chartTitleList[widgetName]['separator']: '';
					var flag = true;
				}else{
					var flag = false;
					var offsetX = 0;
					var offsetY = 0;
					var separator = '';
					var titleTextInCsv = this.chartName;
				}
				console.log(titleTextInCsv);
				console.log(offsetX);
				console.log(offsetY);
			}

			switch(widgetType){
				case 'table':
					if(widgetName == 'Overlap Matrix'){
						var table_xpath = myPanel + content_xpath.descendantDataTable;
						var htmls = browser.getHTML(table_xpath);
						this.table_json = this.tabletojson.convert(htmls)[0];
						// get table thead
						var thead = browser.getText(table_xpath + '/tbody/tr[1]/th');
						console.log(thead);
						//console.log(this.table_json);
						//console.log(this.ui_header);
					}else if(widgetName == 'Summary Statistics'){
						var table_xpath = myPanel + '//*[@id="summaryTable"]/tbody//tbody';
						var table_text = browser.getText(table_xpath);
						console.log(table_text);
						var table_list = table_text.join(' :: ');
						var thead = [table_text[0].split('\n')[0]];
						console.log(thead);
					}
					else{
						console.log('this.page: '+this.page);
						var table_xpath = myPanel + content_xpath.descendantDataTable;
						if(widgetName == 'All Positions'){
							const regulatory_xpath = this.xpath_lib.xpathRequire('regulatory_xpath');
							table_xpath = regulatory_xpath.unhiddenSummaryctrl_xpath + table_xpath;
						}else if(this.page == 'Composition'){ 
							table_xpath = myPanel + '//*[@ng-show="ctrl.model.data"]//table';
						}
						var htmls = browser.getHTML(table_xpath);
						this.table_json = this.tabletojson.convert(htmls)[0];
						// get table thead
						try{
						var thead = browser.getText(table_xpath + '/thead//th');
					  }catch(error){
						// if no thead, will use the first tr [td or th]
						var thead = browser.getText(table_xpath + '/tbody/tr[1]//th');
					  }
					  console.log(thead);
					  console.log('table_xpath: ' + table_xpath);
					  console.log('table_json: ' + this.table_json);
					}
					break;
				case 'multi table':
					var table_xpath = myPanel + content_xpath.descendantDataTable;
					// var table_length = [];
					var table_num = browser.elements(table_xpath).value.length;
					console.log(table_num);
					var tableListText = []; 
					for(var i = 0;i<table_num;i++){
						var tableText = browser.getText(table_xpath +'['+(i+1)+']' + '//tr');
						console.log('tableText:'+tableText);
						// tableListText[i] = [];
						tableListText[i] = Array.isArray(tableText) ? tableText : [ tableText ];
						// console.log('tableListText['+i+']:'+tableListText[i])
						// console.log('table_length:'+tableListText[i].length);
					}
					this.tableAllText = tableListText;
					console.log('this.tableAllText:'+this.tableAllText);
					 // table_length.push(this.tableAllText.length);
					break;
				case 'pie chart':
					// charts_all_values is no used,but may be use in feature
					if(this.portfolio == 'Portfolio-CMBS_-for-automation'){
						var pie_charts_value_xpath = myPanel + content_xpath.pie_chart_value;
						var pie_charts_value_xpath2 = myPanel + content_xpath.pie_chart_value2;
						if(browser.isVisible(pie_charts_value_xpath)){
							var charts_all_values = browser.getText(pie_charts_value_xpath);
						}else if(browser.isVisible(pie_charts_value_xpath2)){
							// for CLO Concentration
							var charts_all_values = browser.getText(pie_charts_value_xpath2);
						}
						this.charts_all_values = charts_all_values;
						console.log(charts_all_values);
					}
					// this.chartName and this.pie_charts_value_length come form pie-charts steps
					console.log(this.chartName);
					console.log(this.pie_charts_value_length);
					break;
				case 'bar chart': //Delinquencies Distribution
					// this.chartName and this.pie_charts_value_length come form pie-charts steps
					console.log(this.chartName);
					console.log(this.pie_charts_value_length);
					// get tooltip value
					// charts_all_values is no used,but may be use in feature
					if(this.deal == "Wachovia Bank Commercial Mortgage Trust 2007-C32" || this.portfolio == "Portfolio-CMBS_-for-automation"){
						var bar_charts_labels_xpath = myPanel + content_xpath.bar_chart_labels;
						browser.waitForVisible(bar_charts_labels_xpath, this.waitDefault);
						var bar_charts_all_labels = browser.getText(bar_charts_labels_xpath).split('\n');
						var charts_all_values = [];
						for(var i=0;i<bar_charts_all_labels.length;i++){
							var item_xpath = bar_charts_labels_xpath + '//span[contains(text(),"'+ bar_charts_all_labels[i] +'")]';
							console.log(item_xpath);
							if(i == 0 || i == bar_charts_all_labels.length-1){
								browser.moveToObject(item_xpath,offsetX,offsetY);	
							}
							browser.moveToObject(item_xpath,offsetX,offsetY);
							browser.pause(1000);
							var tooltip_xpath = myPanel + content_xpath.bar_chart_tooltip;
							var tooltip_xpath2 = myPanel + content_xpath.bar_chart_tooltip2;
							if(browser.isVisible(tooltip_xpath)){
								var tooltip_value = browser.getText(tooltip_xpath);
							}else if(browser.isVisible(tooltip_xpath2)){
								var tooltip_value = browser.getText(tooltip_xpath2);
							}else{
								var tooltip_value = undefined;
							}

							charts_all_values.push(tooltip_value);
						}
						console.log(charts_all_values);
						this.charts_all_values = charts_all_values;
					}
					break;
				case 'charts':
					break;
			}
			
			var filetype_list = [];
			switch(filetype){
				case 'XLS/CSV':
					filetype_list = ['CSV','XLS'];
					break;
				case 'CSV':
					filetype_list.push('CSV');
					break;
				case 'XLS':
					filetype_list.push('XLS');
					break;
				default:
					filetype_list.push('CSV');
			}
      if (!process.env.BROWSER.startsWith('IE')) {
        browser.touchScroll(browser.element(myPanel).value['ELEMENT'],0,200);
      }
			browser.pause(500);
			browser.click(download_icon_xpath);
			this.file_target_data = [];
			var today = this.time_lib.getTime();
			
			// var moment = require('moment');
			// var today = moment().local().format('DD-MMM-YYYY'); 

			for(var i=0;i<filetype_list.length;i++){
				var myExportTextIcon = download_icon_xpath + download_xpath.file_type_text.replace('__FILETYPENAME__',filetype_list[i]);
				// Mix Portfolio Position --> OK
					switch(widgetName){
					case 'Trade History':
						var fileName = 'Dashboard' + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Deal Documents':
					  var fileName = this.test_deal_name + '_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						var title = chartTtile['portfolio']['Deal Documents'].split(' :: ');
						// var ui_header = (this.tabName == 'All') ? title[0] : title[1];
						if(this.tabName == 'All'){
							var ui_header = title[0];
						}
						else if(this.tabName == 'Trustee Reports'){
							var ui_header = title[1];
						}
						else if(this.tabName == 'Notices'){
							var ui_header = title[2];
						}
						else if(this.tabName == 'Closing Documents'){
							var ui_header = title[3];
						}
						else if(this.tabName == 'Research'){
							var thead = title[4];
						}
						console.log(ui_header);
						break;
					case 'Overlap Results':
						var fileName = this.portfolio + '_' + 'OVERLAP GRID' + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Comparison Results':
						var selectedTab = browser.getText(content_xpath.selectedTab);
						if(this.portfolio == 'Portfolio-CLO-for-automation'){
							// var selectedTab = browser.getText(content_xpath.selectedTab);
							var fileName = 'Portfolio - ' + widgetName + ' - Asset Class_ CDO' + ' - Category_ ' + selectedTab + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.portfolio == 'Portfolio-CMBS_-for-automation'){
							// Portfolio - Comparison Results - Asset Class_ CMBS - Category_ DQ and Performing Special Servicer_06-Aug-2018
							// var selectedTab = browser.getText(content_xpath.selectedTab); 
							var fileName = 'Portfolio - ' + widgetName + ' - Asset Class_ CMBS' + ' - Category_ ' + selectedTab + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else if(this.portfolio == 'Portfolio-RMBS-for-automation'){
							// Portfolio - Comparison Results - Asset Class_ RMBS - Category_ Delinquencies_18-Oct-2018.csv
							var fileName = 'Portfolio - ' + widgetName + ' - Asset Class_ RMBS' + ' - Category_ ' + selectedTab.replace(/\//g,'_') + '_' + today + '.' + filetype_list[i].toLowerCase();							
						}
						else{
							var selectedTab = browser.getText(content_xpath.selectedTab);
							var assertName = selectedTab[0];
							var tabName = selectedTab[1].replace(/\//g, '_');
							var fileName = 'Portfolio - ' + widgetName + ' - Asset Class_ ' + assertName + ' - Category_ ' + tabName + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						break;
					case 'Concentration Report': // for CLO Concentration
						var selected_value_xpath = download_xpath.selected_value_xpath;
						browser.waitForVisible(selected_value_xpath,this.waitDefault);
						var selected_value = browser.getText(selected_value_xpath)[0];
						var fileName = this.portfolio + '_' + widgetName.toUpperCase() + '-' + selected_value.trim() + today + '.' + filetype_list[i].toLowerCase()
						break;
					case 'Asset Level': //CLO
						var fileName = this.portfolio + '_' + 'ASSET LEVEL' + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'ALTICE NV': //CLO
					  // if(filetype_list[i].toLowerCase()=='xls'){
					  	var fileName = this.portfolio + '_' + 'BIGGEST CAA_CCC ISSUERS- Drilldown' + '_' + today + '.' + filetype_list[i].toLowerCase();
						// }else{
						// 	var fileName = this.portfolio + '_' + 'BIGGEST Caa_CCC ISSUERS' + '_' + today + '.' + filetype_list[i].toLowerCase();
						// }
						break;
					// CMBS Portfolio
					case 'Loan Level Summary':
						var fileName = this.portfolio + '_' + 'Asset Level' + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Delinquencies Distribution':
					case 'Loan Balance Distribution':
					case 'LTV Distribution':
					case 'NOI Distribution':
					case 'DSCR Distribution':
					case 'Top Ten Property Types':
					case 'Top Ten State Concentrations':
					case 'Top Ten MSA Concentrations':
					case 'Top Ten Appraisal Reduction Loans':
					case 'Top Ten Largest Loans':
					case 'Top Ten Delinquent Loans':
					case 'Top Ten Specially Serviced Loans':
					case 'Asset Price Distribution':
					case 'Biggest Industries':
						// FOR CMBS portfolio composition
						var fileName = this.portfolio + '_' + widgetName + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Biggest Caa/Ccc Issuers':
						// FOR CMBS portfolio composition
						var fileName = this.portfolio + '_BIGGEST Caa_CCC ISSUERS_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Collateral DM/Yield Distribution':
						var fileName = this.portfolio + '_Collateral Yield Distribution_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Deal Exposures':
						//This is for CLO industry page table download. As there is only one table, so add it here.
						var fileName = this.industry + '_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Deals with Largest Exposure to This Issuer':
					case 'Managers with Largest Exposure to This Issuer':
						//This is for CLO issuer page table download.
						var fileName = widgetName.toUpperCase() + ' ' + this.issuer.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'All Positions':
						var fileName = this.portfolio + '_REGULATORY SUMMARY All POSITIONS RESULTS_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Tranche/Collateral Summary':
						var fileName = this.portfolio + '_SCENARIO CASHFLOWS_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Cashflows':
						var fileName = this.portfolio + '_SCENARIO CASHFLOWS_' + this.selected_tranche + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Results for : cdo_screen':
						var fileName = 'CDO_SCREEN_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Results for : CMBS_Auto':
						var fileName = 'CMBS_AUTO_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Results for : RMBS_AUTO':
						var fileName = 'RMBS_AUTO_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Results for : ABS Tranches':
						var fileName = 'ABS TRANCHES_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Results for : AUTO Screener':
						var fileName = 'AUTO SCREENER_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Results for : CARDS Screener':
						var fileName = 'CARDS SCREENER_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Results for : SLABS Screener':
						var fileName = 'SLABS SCREENER_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Risk Weight Calculator':
						// This is for RegModule SEC-SA
						var fileName = widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case "SSFA Projections":
						if (button == "Current") {
							// For SSFA Porjection, must run step When_I_set_the_#_under_the_#_panel-heading_to_#_in_SSFA_page.js
							var tranchename = this.selected_tranche;
							var scenarioname = this.selected_scenario;
							var fileName = this.portfolio + '_' + widgetName.toUpperCase() + ' RESULTS_'+ tranchename + '_' + scenarioname + '_' + today + '.' + filetype_list[i].toLowerCase();
						}
						break;
					case "OTTI Analysis Results":
						var fileName = this.portfolio + '_OTTI ANALYSIS RESULTS FOR  OTTI TYPE_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case "Total Collateral Balance (millions)":
						var fileName = this.portfolio + '_ Collateral Balance (millions)- Drilldown_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case "WAC - Collateral":
					case "WAM - Collateral":
					case "Cumulative Losses":
					case "Cumulative Defaults":
					case "Delinquencies 30D":
					case "Delinquencies 60D":
					case "Delinquencies 90D+":
					case "Total Collateral Balance (millions)":
					case "% in Cash":
					case "WAC":
					case "Second Lien Loans":
					case "Bonds":
						var fileName = this.portfolio + '_' + widgetName + '- Drilldown_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case "BOXER PARENT COMPANY INC. (BMC)":
						var fileName = this.portfolio+'_'+this.panelName.toUpperCase().replace(/\//g,'_')+'- '+'Drilldown_'+today+'.'+filetype_list[i].toLowerCase();
						break;
					// drill down page
					case 'Three month EURIBOR':
					case 'CPR1MTH':
					case 'MADRID RMBS IV, FTA':
					case 'Yes':
					case '0.00-0.49 Delinquency Rate':
					case 'SR':
					case '2016':
					case 'MBS - Prime':
					case 'CMBS - Conduit / Fusion':
					case 'US':
					case 'Floating':
					case 'EUR':
					case 'UNITED STATES':
					case 'CPR_SINCEISSUE':
					case 'SPAIN':
					case 'CPR 1 month 8.00-9.99':
					case '0.50-0.99 Delinquency Rate':
					case 'CPR 1 month 5.00-5.99':
					case 'CPR 1 month 6.00-6.99':
						var fileName = this.portfolio + '_Drilldown_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					case 'Results':
						var fileName = this.portfolio+ '_Analytics_Portfolio Cashflow_' + today + '.' + filetype_list[i].toLowerCase();
						break;
					default:
						if(widgetName.includes("Assets issued by")){
						//This is for CLO issuer page table download.
						var fileName = widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();
						}else{
							var fileName = this.portfolio + '_' + widgetName.toUpperCase() + '_' + today + '.' + filetype_list[i].toLowerCase();			
						}				
				}

				
				console.log('fileName: ' + fileName);
				this.file_session.deleteFiles(fileName);
				try{
					browser.waitForVisible(myExportTextIcon,this.wait10);
				}catch(error){
					browser.click(download_icon_xpath);
					browser.waitForVisible(myExportTextIcon,this.wait10);
				}
				browser.click(myExportTextIcon);
				console.log('myExportTextIcon:--------------------------------',myExportTextIcon);
				// browser.pause(1*1000);
				// For IE we need to click the save button
	      if (process.env.BROWSER == 'IE11') {
	        browser.pause(5*1000);
	        this.robot_session.clickImage(null, 'IE11_DownloadSave.png');
	        browser.pause(10*1000);
	        this.robot_session.clickImage(null, 'IE11_DownloadDismissX.png');
	        browser.pause(1000);
	      }
				var my_download_file = this.file_session.waitForDownload(browser,fileName);
				console.log('my download file: ' + my_download_file);
				if(mode == 'stored portfolio'){
					console.log('my download file: ' + my_download_file);
					var save_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res',fileName);
					console.log('save_path',save_path)
					console.log('copy file...');
					this.file_session.copyFile(my_download_file,save_path);
				// fs.copyFile(my_download_file,save_path)
				return
			}

				// check undefined
				switch(filetype_list[i]){
					case 'CSV':
						// var fs = require('fs');
						var file_content = fs.readFileSync(my_download_file,{encoding:'utf-8'});
						if(thead){
							var thead_str = thead.join('","').trim();
							console.log(thead_str);
						}
						if(widgetName != 'Deal Documents'){
							var ui_header = thead_str;
						}

						// if(widgetName != 'Deal Documents' && this.ui_header != undefined){
						// 	var tmp = this.ui_header.replace(/ :: /g,'","').trim();
						// 	var ui_header = tmp;

						// 	// if( tmp.endsWith(' ::') ){
						// 	// 	var ui_header = '"' + tmp.replace(' ::','","')+ '",';
						// 	// }else{
						// 	// 	var ui_header = '"' + tmp + '",';
						// 	// }
							
						// 	console.log(ui_header);
						// }
						
						expect(file_content.toLowerCase().indexOf('undefined') == -1).toBe(true,my_download_file + ': This file contains undefined');
						break;
					case 'XLS':
						var file_content = this.file_session.readHtmlAsCsvString(my_download_file,true);
						if(thead){
							var thead_str = thead.join(',').trim();
							console.log(thead_str);
						}
						if(widgetName != 'Deal Documents'){
							var ui_header = thead_str;
						}
						

						// if(widgetName != 'Deal Documents' && this.ui_header != undefined){
						// 	var tmp = this.ui_header.replace(/ :: /g,',').trim();
						// 	var ui_header = tmp;
							
						// 	// if( tmp.endsWith(' ::') ){ // for Trade History
						// 	// 	var ui_header = tmp.replace(' ::',',');
						// 	// }else{
						// 	// 	var ui_header = tmp;
						// 	// }

						// 	console.log(ui_header);
						// }

						expect(file_content.toLowerCase().indexOf('undefined') == -1).toBe(true,'This file contains undefined');
						break;
				}
				// console.log('file_content: ' + file_content);
				
				// get header and target data from file for table widget
				switch(widgetType){
					case 'table':
						var table_array = file_content.replace(/\r/g,'').split('\n');
						console.log("table_array:"+table_array);

						for(var i=0;i<table_array.length;i++){
							if(widgetName == 'Loan Level Summary'){
								if( table_array[i].replace(/\s*/g,'').indexOf(ui_header.replace(/\s*/g,'')) != -1){
									var header_index_infile = i;
								}
							}else{
								if( table_array[i].indexOf(ui_header) != -1){
									var header_index_infile = i;
								}
							}
							
						}
						// var header_index_infile = table_array.indexOf(ui_header);
						if(widgetName == 'Deal Documents'){
							header_index_infile = header_index_infile + 1;
						}
						if(widgetName == 'Summary Statistics'){
							var target_data = table_array.slice(header_index_infile-1);
							break;
						}
						console.log('this.table_json :-----------'+this.table_json);
						var ui_table_length = this.table_json.length;
						var target_data = table_array.slice(header_index_infile,header_index_infile + ui_table_length + 1);
						// console.log('target_data: ' + target_data);
						break;
					case 'multi table':
						var header_index_infile_list = [];
						var titleInCsvList = chartTitleList[widgetName];
	      		var table_array = file_content.replace(/\r/g,'').split('\n');
							console.log(table_array);
							console.log(titleInCsvList.length);
						var file_target_start = 0;
							//this.tableAllText
						for(var i=0;i<titleInCsvList.length;i++){
							for(var j = 0;j<table_array.length;j++){
								// console.log('--------------');
	      				// console.log('table_array['+j+']:'+table_array[j]);
	      				// console.log('titleInCsvList['+i+']:'+titleInCsvList[i]);
	      				if(table_array[j].replace(/["\s]/g,'').indexOf(titleInCsvList[i].replace(/[\n\s"]/g,'')) != -1){
	      					file_target_start = j;
							}
						}
						var table_tmp = table_array.slice(file_target_start,file_target_start + this.tableAllText[i].length);
						console.log('table_tmp: '+table_tmp);
	      		this.file_target_data.push(table_tmp);
	      		// console.log('this.file_target_data length : ' + this.file_target_data.length);
	      		// }
	      		
					 }
					 	console.log('---------------------------------------------------------');
					 // console.log('this.file_target_data[0]:'+this.file_target_data[0]);
					 // console.log('this.file_target_data[1]:'+this.file_target_data[1]);
					 console.log('this.file_target_data.length:'+ this.file_target_data.length);
	      	 break;
					case 'pie chart':
					case 'bar chart':
						var table_array = file_content.replace(/\r/g,'').split('\n');
						// console.log(table_array);
						if(filetype_list[i] == 'XLS'){
							var chart_name_index = table_array.indexOf( titleTextInCsv.replace(/"/g,'') ); //XLS
						}else{
							var chart_name_index = table_array.indexOf('"' + titleTextInCsv + '",');
						}
						// console.log(chart_name_index);
						if(flag == true){
							var target_data = table_array.slice(chart_name_index, chart_name_index + 1 + this.pie_charts_value_length);
						}else{
							var target_data = table_array.slice(chart_name_index + 1,chart_name_index + 2 + this.pie_charts_value_length);	
						}
						// var target_data = table_array.slice(chart_name_index + 1,chart_name_index + 2 + this.pie_charts_value_length);
						// console.log(target_data);
						break;
					case 'charts':
						break;
				}
				if(widgetType!='multi table'){
					this.file_target_data.push(target_data);
				}
			}

			// when file_target_data length is bigger than 1, those data in it should be equal.
			console.log( 'this.file_target_data:'+this.file_target_data);



			// return 'pending';
	});
};