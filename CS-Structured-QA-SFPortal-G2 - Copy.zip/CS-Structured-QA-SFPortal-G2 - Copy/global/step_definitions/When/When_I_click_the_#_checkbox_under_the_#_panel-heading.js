// Recommended filename: When_I_click_the_#_checkbox_under_the_#_panel-heading.js
module.exports = function() {
  this.When(/^I click the "([^"]*)" checkbox under the "([^"]*)" panel-heading$/, { 
    timeout: process.env.StepTimeoutInMS*5}, 
    function (checkboxName, panelName) {
    // Write the automation code here
    
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    var myPanel_xpath = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase());
    var checkbox_xpath = myPanel_xpath + content_xpath.valuedCheckbox.replace('__VALUE__', checkboxName);

    if (checkboxName == "Outstanding Tranches Only")
    {
        checkbox_xpath = myPanel_xpath + content_xpath.sfp_valuedCheckbox.replace('__VALUE__', checkboxName);
    }
    
    if (!process.env.BROWSER.startsWith('IE')) {
        browser.touchScroll(browser.element(myPanel_xpath).value['ELEMENT'],0,200);
    }

    if(checkboxName == 'U.S.' && (panelName == 'Performance Report Chart Builder'||panelName == 'Ratings Transitions')){
        checkbox_xpath = myPanel_xpath + '//md-checkbox[1]' 
    }

    if(checkboxName == 'Europe' && (panelName == 'Performance Report Chart Builder'||panelName == 'Ratings Transitions')){
        checkbox_xpath = myPanel_xpath + '//md-checkbox[2]' 
    }

    console.log("checkbox_xpath: " + checkbox_xpath);
    browser.click(checkbox_xpath);

    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);

  });
};
