module.exports = function() {
  this.When(/^I click the "([^"]*)" icon in "([^"]*)" table for row "([^"]*)"$/, function (icontype, tableName, record) {
    // Write the automation code here
 
  const portfolioPage_xpath = this.xpath_lib.xpathRequire('portfolioPage_xpath');
  const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
  const settingsPage_xpath = this.xpath_lib.xpathRequire('settingsPage_xpath');
  const dashboardPage_xpath = this.xpath_lib.xpathRequire('dashboardPage_xpath');
  const scenarioManager_xpath = this.xpath_lib.xpathRequire('scenarioManager_xpath');

  if(icontype == 'edit'){
    switch(tableName){
      case 'Trade History':
        var edit_icon = content_xpath.titledPanelLowercase.replace('__TITLE__', tableName.toLowerCase()) + portfolioPage_xpath.editIcon.replace('__ROWNUM__', record);
        break;
      case 'All Saved Scenarios':
        var edit_icon = scenarioManager_xpath.scenarioManagerPanel.replace('__NAME__',tableName)+'//table/tbody/tr['+record+']/td[3]/span//a/span';
        console.log(edit_icon);
        break;
      default:
        var edit_icon = content_xpath.titledPanelLowercase.replace('__TITLE__', tableName.toLowerCase()) + portfolioPage_xpath.editIcon.replace('__ROWNUM__', record);
        break;
    }
    console.log(edit_icon);
    this.browser_session.waitForResource(browser);
    if(tableName == 'All Saved Scenarios'){
      browser.click(edit_icon);
      console.log('first click');
      try{
        var popup_visible = browser.waitForVisible(scenarioManager_xpath.scenarioManagerAssumptions,this.wait10);
        console.log('1. popup_visible->'+popup_visible);
      } catch (error){
        //console.log('second click, user doubleclick method');
        //browser.doubleClick(edit_icon);
        console.log('second click!!!');
        browser.click(edit_icon);
        var popup_visible = browser.waitForVisible(scenarioManager_xpath.scenarioManagerAssumptions,this.wait10);
        console.log('2. popup_visible->'+popup_visible);
      }
      console.log('3. popup_visible->'+popup_visible);
      /*try{
        this.browser_session.waitForResource(browser,scenarioManager_xpath.scenarioManagerAssumptions);
      } catch (error){
        browser.click(edit_icon);
      }*/
    }else{
      this.robot_session.clickAndEnter(browser, edit_icon);
    }
  }
  else if(icontype == 'copy'){
    var copy_icon = scenarioManager_xpath.scenarioManagerPanel.replace('__NAME__',tableName)+'//table/tbody/tr['+record+']/td[4]/span//a/span';
    console.log(copy_icon);
    browser.click(copy_icon);
    browser.pause(3000);
  }
  else if(icontype == 'restore portfolio'){
    var restoreIcon = content_xpath.titledPanelLowercase.replace('__TITLE__', tableName.toLowerCase()) + settingsPage_xpath.restoreIcon;
    console.log(restoreIcon);
    browser.click(restoreIcon);
    browser.pause(3000);  
  }
  else if(icontype == 'delete portfolio'){
    var deleteIcon = content_xpath.titledPanelLowercase.replace('__TITLE__', tableName.toLowerCase()) + dashboardPage_xpath.deletePortfolioIcon;
    console.log(deleteIcon);
    try{
        browser.waitForVisible(deleteIcon,this.waitDefault*2);
        this.robot_session.clickAndEnter(browser, deleteIcon);
        browser.pause(3000);
      }
      catch(error){
      }
    // if(browser.waitForVisible(deleteIcon,this.waitDefault*2)){
    //   this.robot_session.clickAndEnter(browser, deleteIcon);
    //   browser.pause(3000);
    // }
  }

  //icontype == 'delete'
  else{
    switch(tableName){
      case 'Trade History':
        var delete_icon = content_xpath.titledPanelLowercase.replace('__TITLE__', tableName.toLowerCase()) + portfolioPage_xpath.deleteIcon.replace('__ROWNUM__', record);
        break;
      case 'All Saved Scenarios':
        var delete_icon = scenarioManager_xpath.scenarioManagerPanel.replace('__NAME__',tableName)+'//table/tbody/tr['+record+']/td[5]/span//a/span';
        break;
      default:
        var delete_icon = content_xpath.titledPanelLowercase.replace('__TITLE__', tableName.toLowerCase()) + portfolioPage_xpath.deleteIcon.replace('__ROWNUM__', record);
        break;
    }
    console.log(delete_icon);
    this.browser_session.waitForResource(browser);
    this.robot_session.clickAndEnter(browser, delete_icon);
    }
  });
};
