  // Recommended filename: When_I_cleaned_the_metrics_in_the_first_graph_and_check_the_drop-down_list.js
  module.exports = function() {
   this.When(/^I clear all metrics in all graphs$/, {timeout: process.env.StepTimeoutInMS*5}, function() {
    const performancePage_xpath = this.xpath_lib.xpathRequire('performancePage_xpath');
    this.browser_session.waitForLoading(browser,'//md-progress-linear')
    var metricClose_xpath = performancePage_xpath.metricClose1;
    try{
     browser.waitForVisible(metricClose_xpath, 60*1000);
    }catch(e){
     metricClose_xpath = performancePage_xpath.metricClose1;
    }
    console.log(metricClose_xpath)
    this.browser_session.waitForResource(browser,metricClose_xpath)
    var close_length= browser.elements(metricClose_xpath).value.length;
    console.log('close_length:'+close_length)
    for(var item=0;item<close_length;item++){
     browser.waitForVisible('('+metricClose_xpath+')[1]',60*1000)
     browser.click('('+metricClose_xpath+')[1]')
     browser.pause(500);
    }
    try{
     expect(browser.isVisible(metricClose_xpath)).toBe(false)
    }catch(e){
     console.log('try again')
     console.log(close_length)
     for(var item=0;item<close_length;item++){
      browser.waitForVisible('('+metricClose_xpath+')[1]',60*1000)
      browser.click('('+metricClose_xpath+')[1]')
      browser.pause(500);
     }
     expect(browser.isVisible(metricClose_xpath)).toBe(false)
    }
    // var displayed_metricClose_list = browser.elements(metricClose_xpath).value;
    // console.log(displayed_metricClose_list);
    // displayed_metricClose_list.forEach(function(metricClose_element,index) {
    //   console.log('metricClose_element.ELEMENT: '+metricClose_element.ELEMENT)
    //   // console.log('('+metricClose_xpath+')[1]')
    //   // browser.waitForVisible('('+metricClose_xpath+')[1]',60*1000)
    //   if(browser.elementIdEnabled(metricClose_element.ELEMENT)){ 
    //      // browser.touchScroll(metricClose_element.ELEMENT,0,200);
    //      browser.elementIdClick(metricClose_element.ELEMENT);
    //   }else{
    //     console.log(elementIdNotEnabled)
    //     browser.pause(5*1000)
    //     browser.elementIdClick(metricClose_element.ELEMENT);
    //   }
    //   browser.pause(100);
    //   try{
    //     expect(browser.elementIdDisplayed(metricClose_element.ELEMENT).toBe(false))
    //   }catch(e){
    //     console.log('try again')
    //     browser.elementIdClick(metricClose_element.ELEMENT);
    //     browser.pause(100);
    //   }
    // }) 
  });
};
 