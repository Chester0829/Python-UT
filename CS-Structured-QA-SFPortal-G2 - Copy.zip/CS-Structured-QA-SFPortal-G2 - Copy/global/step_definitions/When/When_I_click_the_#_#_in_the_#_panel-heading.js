module.exports = function() {
  this.When(/^I click the "([^"]*)" (icon|link) in the "([^"]*)" panel-heading$/, function (icon, type, panelName) {
    // Write the automation code here
    // pending();
    this.browser_session.waitForResource(browser);
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const issuerPage_xpath = this.xpath_lib.xpathRequire('issuerPage_xpath');
    const loanPage_xpath = this.xpath_lib.xpathRequire('loanPage_xpath');
    const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');

    if(panelName == 'Deals with Largest Exposure to This Issuer'||panelName == 'Managers with Largest Exposure to This Issuer'){
      var zoomIn_icon = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase()) + issuerPage_xpath.zoomIn_button;
    }else if(panelName == 'Assumptions' || panelName=="Scenarios"){
      var zoomIn_icon = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase()) + cashflow_xpath.assumption_link.replace('__LABEL__',icon);
    }
    else if(panelName == 'Deals with Largest Exposure to This Asset'||panelName == 'Managers with Largest Exposure to This Asset'){
      var zoomIn_icon = content_xpath.titledPanelLowercase.replace('__TITLE__', panelName.toLowerCase()) + loanPage_xpath.zoomIn_button;
    }
    console.log(zoomIn_icon);
    browser.click(zoomIn_icon);
    browser.pause(5000);
    if(browser.isVisible('//iframe')){
      browser.pause(10000);
      browser.frame(0);
    }
  });
};

