//Then_I_copy_scen_#_to_scen_#_in_cashflow_assumptions.js
module.exports=function(){
 this.Then(/^I copy scen "([^"]*)" to scen "([^"]*)" in cashflow assumptions$/, function (arg1, arg2) {
         // Write code here that turns the phrase above into concrete actions
         const content_xpath = this.xpath_lib.xpathRequire("content_xpath");
         const cashflow_xpath = this.xpath_lib.xpathRequire("cashflow_xpath");
         var template = arg1;
         var target = arg2;
         var option_path = '/descendant::md-content';
         console.log("In Copy Scen: " + cashflow_xpath.dealcfsfromScen );
         // browser.getLocationInView(cashflow_xpath.dealcfsfromScen);
         browser.getLocationInView('//*[normalize-space()="Assumptions"]/ancestor::md-card-title');
         console.log("Selecting FROM Scenario value");
         //From select box
         browser.click('//md-select[@ng-model="analyticsCtrl.fromScen"]//*[@class="md-select-icon"]');
         browser.pause(500);
         // browser.click('//md-select[@ng-model="analyticsCtrl.fromScen"]//*[@class="md-select-icon"]');
         for (var i = 10; i >= 0; i--) {
            browser.keys('\uE013');
         }
         for (var i = 1; i < parseInt(template); i++) {
            browser.keys('\uE015');
         }
         browser.keys('\uE006');

         console.log("Selecting TO Scenario value");
         //To select box
         browser.click('//md-select[@ng-model="analyticsCtrl.toScen"]//*[@class="md-select-icon"]');
         browser.pause(500);
         // browser.click('//md-select[@ng-model="analyticsCtrl.fromScen"]//*[@class="md-select-icon"]');
         // for (var i = 10; i >= 0; i--) {
         //    browser.keys('\uE013');
         // }

         for (var i = 10; i >= 0; i--) {
            browser.keys('\uE013');
         }
         for (var i = 1; i < parseInt(target); i++) {
            browser.keys('\uE015');
         }
         browser.keys('\uE006');

         // browser.selectByVisibleText(cashflow_xpath.dealcfsfromScen + option_path , template);
         // console.log("From Scen already selected. To scen xpath: " + cashflow_xpath.dealcfstoScen);
         // browser.selectByVisibleText(cashflow_xpath.dealcfstoScen + option_path , target);
         console.log("To Scen selected. Duplicate Button xpath: " + cashflow_xpath.dealcfsdupliScen );
         browser.click(cashflow_xpath.dealcfsdupliScen);
         browser.click('//*[normalize-space()="Call Assumptions"]');
         browser.pause(500);
       });
}

