// Recommended filename: When_I_enter_the_correct_username_and_password_and_login.js
module.exports = function() {
  this.When(/^I enter the correct username and password and login$/,
    {timeout: process.env.StepTimeoutInMS*5},
    function () {
  // Write code here that turns the phrase above into concrete actions
    const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
    const loginPage_xpath = this.xpath_lib.xpathRequire('loginPage_xpath');

    var userName = this.test_user;
    var password = this.user_login_config.getPassword(userName);

    // login
    browser.waitForExist(loginPage_xpath.signIn_form, this.waitDefault);
    browser.setValue(loginPage_xpath.userName_input, userName);
    browser.setValue(loginPage_xpath.password_input, password);
    browser.waitForExist(loginPage_xpath.signIn_button, this.waitDefault);
    browser.click(loginPage_xpath.signIn_button);
    try {
        browser.waitForExist(loginPage_xpath.NotYou_link, this.waitDefault);
        browser.waitForExist(loginPage_xpath.NotYou_link, this.waitDefault, true);
    } catch (e) {
    }
    this.browser_session.waitForLoading(browser);
    browser.waitForExist(header_xpath.mainDashboard_button, this.waitDefault);
  });
}