// Recommended filename: When_I_goto_global_search_box_to_#_#_#.js
module.exports = function() {
  this.setDefaultTimeout(360*1000);
  this.When(/^I goto global search box to (search|search and open) (tenant|deal|tranche|cusip|isin|bloomberg_id|manager|loan|issuer|industry|text) "([^"]*)"$/, {timeout: process.env.StepTimeoutInMS*3}, function (searchAction, searchType, searchName) {
    // Write the automation code here
    // console.log(action);
     const dealPage_xpath = this.xpath_lib.xpathRequire('dealPage_xpath');
    if(searchType == 'tenant'){
      browser.pause(2*1000);
    }
    var search_action = (searchAction.includes('search and open'));
    this.browser_session.waitForLoading(browser);
    browser.pause(5000);
    this.browser_session.globalSearchItem(browser, searchType, searchName, search_action, 300*1000, searchName);
    // this.browser_session.setFieldsPlus(browser);
    this.browser_session.waitForResource(browser);
    this.browser_session.waitForLoading(browser);
    //   if(searchType == 'deal'){
    //    browser.waitForVisible(dealPage_xpath.nameOfDeal,this.waitDefault);
    //    console.log(dealPage_xpath.nameOfDeal);
    // }
    // this.browser_session.waitForRender(browser,null,null,this.stepTimeoutMore,null);
    this[searchType] = searchName;
  });
};
