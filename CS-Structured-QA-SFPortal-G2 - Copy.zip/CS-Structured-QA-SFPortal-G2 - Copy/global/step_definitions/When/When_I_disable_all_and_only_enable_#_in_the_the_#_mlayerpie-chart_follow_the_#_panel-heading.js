// Recommended filename: I_disable_all_and_only_enable_#_in_the_the_#_mlayerpie-chart_follow_the_#_panel-heading.js
module.exports = function() {
  this.When(/^I disable all and only enable "([^"]*)" in the the "([^"]*)" mlayerpie\-chart follow the "([^"]*)" panel-heading$/, 
    {timeout: process.env.StepTimeoutInMS*5},
    function (selection, chartName, panelName) {
    // Write the automation code here  
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', panelName.toLowerCase());
    var myChart = content_xpath.namedPieChar.replace(/__NAME__/g, chartName);
    browser.getLocationInView(myChart);
    var myChart_legend = myChart + content_xpath.chartLegend;
    var myChard_legend_shown = myChart_legend + content_xpath.chartLegendNotHided;
    var myChard_legend_toEnable = myChart_legend + content_xpath.chartLegendHided + '//*[contains(text(), "' + selection + '")]';
    var myChard_legend_enabled = myChard_legend_shown + '//*[contains(text(), "' + selection + '")]';
    var displayed_legend;
    while (browser.isVisible(myChard_legend_shown)) {
      browser.click(myChard_legend_shown);
      browser.pause(100);
    }
    browser.waitForExist(myChard_legend_toEnable);
    browser.click(myChard_legend_toEnable);
    browser.waitForExist(myChard_legend_enabled);
  });
}
