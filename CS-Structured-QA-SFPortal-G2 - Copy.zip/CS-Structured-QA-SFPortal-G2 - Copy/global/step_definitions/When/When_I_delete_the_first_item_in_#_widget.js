module.exports = function () {
    this.When(/^I delete the first item in "([^"]*)" widget/, function (widgetName) {
        var content_xpath = this.xpath_lib.xpathRequire('content_xpath');
        this.browser_session.waitForResource(browser);
        if (widgetName == 'My Screens') {
            var targetTable = content_xpath.titledPanelLowercase.replace('__TITLE__', widgetName.toLowerCase());
            console.log(targetTable);
            var targetTableRows = targetTable + "//sfp-data-table//table/tbody/tr";

            var tableContent = browser.getText(targetTableRows);
            console.log(tableContent);
            console.log(tableContent.length);
            var targetRow = targetTableRows + "[1]";
            console.log(targetRow);
            var deleteIcon = targetRow + "/td[7]/span";
            console.log(deleteIcon);
            this.browser_session.waitForResource(browser);
            this.robot_session.clickAndEnter(browser, deleteIcon);

            // var alertXpath1 = '//div[contains(@class,"growl-item alert alert-success")]';
            // var alertXpath = '//div[contains(@class,"alert alert-success")]';
            // try {
            //     browser.waitForVisible(alertXpath, this.waitDefault);
            //     console.log(alertXpath);
            //     console.log(browser.getText(alertXpath));
            // } catch (e) {
            //     browser.waitForVisible(alertXpath1, this.waitDefault);
            //     console.log(alertXpath);
            //     console.log(browser.getText(alertXpath1));
            // }
            browser.pause(2 * 1000);
            browser.refresh();
            this.browser_session.waitForLoading(browser);
            this.browser_session.waitForResource(browser);
        }
    });
}