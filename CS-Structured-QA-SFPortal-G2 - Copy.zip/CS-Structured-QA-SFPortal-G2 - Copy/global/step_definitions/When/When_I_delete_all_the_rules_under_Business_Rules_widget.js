// When_I_delete_all_the_rules_under_Business_Rules_widget.js
module.exports = function() {
  this.When(/^I delete all the rules under Business Rules widget$/, function() {
    const settingsPage_xpath = this.xpath_lib.xpathRequire('settingsPage_xpath');
    this.browser_session.waitForResource(browser);

    var removeIcon = settingsPage_xpath.removeIcon;
    // var row = removeIcon.length;
    // console.log(row);
    
    for(var i=10;i--;i>0){
      console.log(i);
      var deleteIcon = "(" + removeIcon + ")["+i+"]";
      console.log(deleteIcon);
      var tmp = browser.isVisible(deleteIcon);
      console.log(tmp);
      if(tmp==false){
        continue;
      }
      else{
        browser.click(deleteIcon);
      }

    expect(browser.isVisible(deleteIcon)).toBe(false);

    }
  });
}