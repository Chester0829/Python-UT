// When_I_delete_the_rule_that_before_created_under_the_#_panel-heading.js
// only for Stratification
module.exports = function() {
  this.When(/^I delete the rule that before created under the "([^"]*)" panel\-heading$/, function (arg1) {
    // Write code here that turns the phrase above into concrete actions
    var deleteRule = '//a[contains(@ng-click,"assumpCtrl.deleteRule")]';
    var tmp = browser.isVisible(deleteRule);
    var deleteRuleLen =  Array.isArray(tmp) ? tmp.length : 1;
    browser.click('(' + deleteRule + ')[' + deleteRuleLen + ']');

  });
}