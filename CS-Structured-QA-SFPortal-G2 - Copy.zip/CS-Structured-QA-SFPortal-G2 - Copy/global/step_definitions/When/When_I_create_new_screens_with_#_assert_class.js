// When_I_create_new_screens_with_#_assert_class.js
module.exports = function() {
	this.When(/^I create new screens with "([^"]*)" assert class$/, function (arg1) {
		// Write code here that turns the phrase above into concrete actions
		this.browser_session.waitForResource(browser);
		const screenerPage_xpath = this.xpath_lib.xpathRequire('screenerPage_xpath');
		// click create icon
		var createIcon = screenerPage_xpath.createIcon;
		browser.click(createIcon);
		this.browser_session.waitForResource(browser);
		// input asset class
		var assetClass = '//*[@ng-model="vm.selectedAssetClass"]';
		browser.click(assetClass);
		var input = assetClass + '//input[@ng-model]';
		browser.waitForVisible(input,this.wait5);
		browser.click(input);
		browser.pause(500);
		browser.setValue(input,arg1);
		this.robot_session.keyTap();
		this.browser_session.waitForResource(browser);

	});
}