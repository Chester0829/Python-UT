//When_I_clear_all_Cohort_in_Selection.js
module.exports = function() {
  this.When(/^I clear all Cohort in Selection$/, function () {
         // Write code here that turns the phrase above into concrete actions 
         const content_xpath = this.xpath_lib.xpathRequire('content_xpath');    
         const performancePage_xpath = this.xpath_lib.xpathRequire('performancePage_xpath');
         console.log(performancePage_xpath.cohortDeleteElement)
         browser.waitForVisible(performancePage_xpath.cohortDeleteElement,this.waitDefault)
         var cohort_length= browser.elements(performancePage_xpath.cohortDeleteElement).value.length;
         console.log(cohort_length)
         for(var item=0;item<cohort_length;item++){
            browser.click('('+performancePage_xpath.cohortDeleteElement+')[1]')
            browser.pause(500);
         }
         try{
            expect(browser.isVisible(performancePage_xpath.cohortDeleteElement)).toBe(false)
         }catch(e){
             var cohort_length= browser.elements(performancePage_xpath.cohortDeleteElement).value.length;
             console.log(cohort_length)
             for(var item=0;item<cohort_length;item++){
                 browser.click('('+performancePage_xpath.cohortDeleteElement+')[1]')
                 browser.pause(500);
             }
             expect(browser.isVisible(performancePage_xpath.cohortDeleteElement)).toBe(false)
         }
       })
};
 