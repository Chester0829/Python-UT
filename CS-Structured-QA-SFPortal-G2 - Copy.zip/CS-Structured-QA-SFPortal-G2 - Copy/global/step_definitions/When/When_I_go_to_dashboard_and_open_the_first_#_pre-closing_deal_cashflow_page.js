module.exports = function () {
    this.When(/^I go to dashboard and open the (first|second) (CDO|ABS) pre\-closing deal (cashflow|summary|default) page$/,
        { timeout: process.env.StepTimeoutInMS * 10 },
        function (number, type, page) {
            const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
            const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
            const dashboardPage_xpath = this.xpath_lib.xpathRequire('dashboardPage_xpath');

            var dashboard_button = header_xpath.mainDashboard_button;
            var newDealsTable = dashboardPage_xpath.newDealTable;
            var newDealsPanel = content_xpath.titledPanelLowercase.replace("__TITLE__", "new deals");

            // go to dashboard
            browser.click(dashboard_button);
            this.browser_session.waitForResource(browser);

            //choose the first preclosing deal
            var searchArea = newDealsPanel + '//input';
            browser.waitForVisible(searchArea, this.waitDefault);
            browser.setValue(searchArea, type);
            var dealIndex;
            switch (number) {
                case 'first':
                    if(type=='CDO'){
                        // dealIndex = 2;
                        dealIndex = 1;
                    }else{
                        dealIndex = 1;
                    }
                    break;
                case 'second':
                    if(type=='CDO'){
                        // dealIndex = 3;
                        dealIndex = 2;
                    }else{
                        dealIndex = 2;
                    }
                    break;
            }
            var dealName = '(' + newDealsTable + '//tbody//a)[' + dealIndex + ']';
            console.log(dealName);
            var closingDate = browser.getText(newDealsTable + '//tbody//tr[' + dealIndex + ']//td[2]//span[@ng-bind-html]');
            console.log('----------->closingDate:', closingDate);
            this.closingDate = closingDate;
            var currentDate = new Date();
            if (currentDate.getFullYear() < closingDate.split('-')[0]) {
                this.preclosingFlag = false;
            }
            try {
                browser.click(dealName);
                this.browser_session.waitForResource(browser);
                browser.waitForVisible('//div[@class="banner-container"]', this.waitDefault);
            } catch (e) {
                browser.click(dealName);
                this.browser_session.waitForResource(browser);
                browser.waitForVisible('//div[@class="banner-container"]', this.waitDefault);
            }

            var menuButton = content_xpath.namedTopMenuButton.replace('__NAME__', 'Menu');
            if (page == 'cashflow') {
                //compatible new cashflow page
                console.log("process.env.NEW_CF------->" + process.env.NEW_CF);
                if (process.env.NEW_CF == "Y") {
                    var click_link = content_xpath.namedSubMenuButton.replace('__SECTION__', 'Analytics').replace('__LINK__', 'Dynamic CFs New');
                } else {
                    var click_link = content_xpath.namedSubMenuButton.replace('__SECTION__', 'Analytics').replace('__LINK__', 'Dynamic CFs');
                }
                browser.waitForVisible(menuButton, this.waitMax);
                browser.moveToObject(menuButton);
                browser.waitForVisible(click_link, this.waitMax);
                browser.click(click_link);
            }
            else if (page == 'summary') {
                var click_link = content_xpath.namedSubMenuButton.replace('__SECTION__', 'Analytics').replace('__LINK__', 'Summary');
                browser.waitForVisible(menuButton, this.waitMax);
                browser.moveToObject(menuButton);
                browser.waitForVisible(click_link, this.waitMax);
                browser.click(click_link);
            }
            browser.pause(1000);
            this.browser_session.clickNoWhere(browser);
            browser.pause(1000);
            this.browser_session.waitForLoading(browser);
            this.dealIndex = dealIndex;


        });
};