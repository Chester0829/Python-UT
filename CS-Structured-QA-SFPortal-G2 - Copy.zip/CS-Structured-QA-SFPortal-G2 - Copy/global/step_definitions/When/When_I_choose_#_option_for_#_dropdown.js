// Recommended filename: When_I_choose_#_in_the_dropdown_input_list_under_the_#_panel-heading.js
module.exports = function () {
  this.When(/^I (choose|verify) "([^"]*)" option for "([^"]*)" dropdown$/,
    { timeout: process.env.StepTimeoutInMS * 5 },
    function (method, optionText, dropdownName) {
      // Write the automation code here

      this.browser_session.waitForResource(browser);
      const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
      const selectOption_xpath = this.xpath_lib.xpathRequire('selectOption_xpath');
      browser.pause(5000);

      console.log(process.env.NODE_ENV);
      if(dropdownName == 'Assumptions'&&process.env.NODE_ENV=='Staging'&&process.env.NODE_ENV=='Prod'){
        var mySelectDropdown_xpath = cashflow_xpath.mdSelect.replace('__NAME__', "analyticsCtrl.selectedAssumptions");
        console.log(mySelectDropdown_xpath);
        var mySelectCaret_xpath = '//md-select[@aria-expanded="true"]';
        var mySelectOption = selectOption_xpath.valuedOption1.replace('__VALUE__', optionText);
        console.log(mySelectOption);
        browser.waitForVisible(mySelectDropdown_xpath, this.waitMax);
        var Value = cashflow_xpath.assumptionSettingValue;
        console.log(browser.getText(Value));

        switch(method){
          case 'choose':
            console.log('Clicking: ' + mySelectDropdown_xpath);
            browser.click(mySelectDropdown_xpath);
            browser.waitForVisible(mySelectCaret_xpath, this.waitMax);
            browser.click(mySelectOption);
            break;
          case 'verify':
            try{
              expect(browser.getText(Value)).toEqual(optionText);
            }
            catch(e){
              console.log("Get wrong setting");
              browser.click(mySelectDropdown_xpath);
              browser.waitForVisible(mySelectCaret_xpath, this.waitMax);
              browser.click(mySelectOption);
            }
            expect(browser.getText(Value)).toEqual(optionText);
            break;
        }    
      }
    });
};
