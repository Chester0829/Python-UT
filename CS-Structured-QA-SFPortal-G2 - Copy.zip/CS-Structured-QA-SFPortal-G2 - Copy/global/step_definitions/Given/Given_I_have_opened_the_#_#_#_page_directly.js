// Recommended filename: Given_I_have_opened_the_#_#_#_page_directly.js
module.exports = function () {
  this.Given(/^I have opened the (portfolio|deal|tranche|manager|loan|issuer|industry|tenant|screener|settings|home|documents|market|customflag|enhancedBWIC|scenarioManager) "([^"]*)" "([^"]*)" page (directly)$/,
    { timeout: process.env.StepTimeoutInMS * 2 },
    function (type, name, target, method) {
      const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
      const dealPage_xpath = this.xpath_lib.xpathRequire('dealPage_xpath');
      // set some global vars
      this.page = target;
      this.pagetype = type;

      console.log(this.page);
      var tmp = type;
      // certain itme we need to go to the main page first
      switch (type) {
        case 'deal':
        case 'tranche':
        case 'manager':
          var targetSummaryUrl = this.test_url + this.url_lib.getTargetURL(type, 'Summary', name);
          browser.url(targetSummaryUrl);
          this.browser_session.waitForLoading(browser);
          break;
        case 'portfolio':
          // if (process.env.NODE_ENV.indexOf('Dev') != -1){
          //   type = 'Dev_Portfolio';
          // }
          tmp = (process.env.NODE_ENV.indexOf('Dev') != -1 || process.env.NODE_ENV.indexOf('SPSDEV') != -1) ? "Dev_Portfolio" : 'portfolio';
          // var portfolioPositionUrl = this.test_url + this.url_lib.getTargetURL(type, 'Positions', name);
          var portfolioPositionUrl = this.test_url + this.url_lib.getTargetURL(tmp, 'Positions', name);
          browser.url(portfolioPositionUrl);
          this.browser_session.waitForLoading(browser);
          break;
      }


      // below we open target directly
      var targetUrl = this.test_url + this.url_lib.getTargetURL(tmp, target, name);
      console.log(targetUrl);
      browser.url(targetUrl);
      this.browser_session.waitForLoading(browser);
      browser.waitForVisible(header_xpath.mainDashboard_button, this.waitDefault * 2);

      this[type] = name;
      // this.dealName = name;
      console.log(type + ' name is :' + name);

      if (type == 'portfolio') {
        // Sometimes scenarios keep running and cannot continue because of getFxRates. So I think I should delete them
        // get portfolio information by api
        // try {
        //   this.license = this.api_session.getLicense(this.test_user);
        //   var portfolioInfo = this.api_session.getPortfolioInfo(name, this.license);
        //   this.portfolio_tranche_count = parseInt(portfolioInfo.numOfInvest);
        //   this.portfolio_notional_amount = portfolioInfo.notionalValue;
        //   this.portfolio_id = portfolioInfo.portfolioId;
        // }
        // catch (err) {
        //   console.log(err.stack)
        // }
      }
      else if (type == 'loan') {
        browser.waitForVisible(dealPage_xpath.nameOfDeal1, this.waitMax);
        console.log(dealPage_xpath.nameOfDeal1);
        this.browser_session.waitForResource(browser, dealPage_xpath.nameOfDeal1);
        var loanName = browser.getText(dealPage_xpath.nameOfDeal1);
        var loan_url = browser.getUrl();
        console.log('loanName: ' + loanName);
        this.loan = loanName;
        this.pagetype = type;
        console.log('this.loan:' + this.loan);
        console.log(this.pagetype);
      } else if (type == 'deal') {
        browser.waitForVisible(dealPage_xpath.nameOfDeal, this.waitMax);
        console.log(dealPage_xpath.nameOfDeal);
        this.browser_session.waitForResource(browser, dealPage_xpath.nameOfDeal);
      }
      this.browser_session.waitForResource(browser);
      this.name = name;
      console.log(this.name);
      // Sometimes scenarios keep running and cannot continue because of getFxRates. So I think I should delete them
      // var token = this.api_session.getLicense(this.test_user);
      // this.token = token;
      // var fxRates = this.api_session.getFxRates(token);
      // this.fxRates = fxRates;
      // console.log('this.manager',this.manager)
      // 
      var coronavirus_close = '//input[@name="closeBanner"]'
      if (browser.isExisting(coronavirus_close)) {
        console.log('close coronavirus tips')
        browser.click(coronavirus_close)
      }
      if (process.env.NODE_ENV.indexOf('SPS') == -1) {
        var token = this.api_session.getLicense(this.test_user);
        this.token = token;
        var fxRates = this.api_session.getFxRates(token);
        this.fxRates = fxRates;
      }
      // var results = this.api_session.getNewDealsNode(this.token, this.fxRates);
      // var api_result = results['Response']['Deal'];
      // var arrayforCLONewDeals = [];
      // var dealkey = {};
      // var j = 0;
      // for(var i=0;i<api_result.length;i++){
      //   dealkey = {};
      //   if(api_result[i]["$"]["asset_class"] == "CDO"){
      //     dealkey["index"] = j;
      //     j++;
      //     dealkey["deal_key"] = api_result[i]["$"]["deal_key"];
      //     arrayforCLONewDeals.push(dealkey);
      //   }
      // }
      // this.arrayforCLONewDeals = arrayforCLONewDeals;
      // console.log(arrayforCLONewDeals);
      // console.log(arrayforCLONewDeals.length);
    });
}