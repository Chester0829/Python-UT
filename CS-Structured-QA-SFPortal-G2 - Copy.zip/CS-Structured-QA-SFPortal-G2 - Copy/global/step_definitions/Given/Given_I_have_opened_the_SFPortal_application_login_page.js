// Recommended filename: Given_I_have_opened_the_SFPortal_application_login_page.js
module.exports = function() {
  this.Given(/^I have opened the SFPortal application login page$/,
    {timeout: process.env.StepTimeoutInMS*5},
    function () {
    // Write code here that turns the phrase above into concrete actions
    const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
    const loginPage_xpath = this.xpath_lib.xpathRequire('loginPage_xpath');
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    var myUser_Button = header_xpath.named_LoginUser_button.replace('__NAME__', this.test_user);
    var myLogout_button = header_xpath.named_MenuOption_link.replace('__NAME__', 'Logout');
    browser.url(this.test_url);
    this.browser_session.waitForLoading(browser);
    console.log('really exited waitForLoading');
    browser.pause(1000);
    if (browser.isExisting(myUser_Button)) {
      try{
        console.log(myUser_Button);
        browser.waitForVisible(myUser_Button, this.waitDefault*2);
        browser.click(myUser_Button);
        console.log(myLogout_button);
        browser.waitForVisible(myLogout_button, this.waitDefault*2);
        browser.click(myLogout_button);
        this.browser_session.waitForLoading(browser);
      }catch(e){}
    }
    console.log(content_xpath.uiViewContent);
    browser.waitForVisible(content_xpath.uiViewContent, this.waitDefault*4);
    console.log(loginPage_xpath.signIn_form);
    browser.waitForExist(loginPage_xpath.signIn_form, this.waitDefault*4);
  });
}