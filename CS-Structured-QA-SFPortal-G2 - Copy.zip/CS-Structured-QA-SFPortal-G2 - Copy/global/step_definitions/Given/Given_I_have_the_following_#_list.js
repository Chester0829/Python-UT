// Recommended filename: Given_I_have_the_following_#_list.js
module.exports = function() {
  this.Given(/^I have the following (cusip|isin|cusip and isin|deal name|deal ticker|BBSecurityTicker) list$/, function (listType, table) {
    var itemList = table.hashes();
    switch (listType) {
      case 'cusip':
        this.test_cusip_list = itemList;
        break;
      case 'isin':
        this.test_isin_list = itemList;
        break;
      case 'cusip and isin':
        this.test_cusip_and_isin_list = itemList;
        break;
      case 'deal name':
        this.test_deal_list = itemList;
        break;
      case 'deal ticker':
        this.test_deal_ticker_list = itemList;
        break;
        case 'BBSecurityTicker':
        this.test_BBSecurityTicker_list = itemList;
        break;
    }
    this.test_list = itemList;
  });
};

