//Given_I_set_Customize_items_as_following_table.js
module.exports = function() {
       this.Given(/^I set Customize items as following table$/, function (table) {
         // Write code here that turns the phrase above into concrete actions
          const content_xpath = this.xpath_lib.xpathRequire('content_xpath'); 
          var expect_row_list = table.hashes();
          // var customize = '//*[@ng-if="!managerCtrl.customize.visible"]';
          this.browser_session.waitForResource(browser);
          var customize = "//a[contains(text(),'Customize')]";
          if(browser.isVisible(content_xpath.customizeDropDown)!=true){
            browser.waitForVisible(customize,this.waitDefault);
            browser.click(customize);
            console.log(customize);
            browser.waitForVisible(content_xpath.customizeDropDown,this.waitMax);
          }
          expect_row_list.forEach(function(expect_row){
            switch(expect_row['item']){
            case "exclude_amortizing_deals":
            case "exclude_acquired_deals":
            case "exclude_terminated_deals":
            case "include_affiliate":
            case "include_sub_advisor":
              var checkbox = content_xpath.modeCheckbox.replace('__NAME__',expect_row['item']);
              var attribute = browser.getAttribute(checkbox,'class');
              console.log(attribute);
              if(expect_row['value']=='false' && attribute.indexOf('ng-not-empty')!=-1){
                browser.click(checkbox);
              }
              if(expect_row['value']=='true' && attribute.indexOf('ng-empty')!=-1){
                browser.click(checkbox);
              }
              break;
            case "BSL":
            case "SME":
            case "CBO":
            case "CDO":
              var checkbox = content_xpath.labelMdcheck.replace('__LABEL__',expect_row['item']);
              var attribute = browser.getAttribute(checkbox,'class');
              console.log(attribute);
              if(expect_row['value']=='false' && attribute.indexOf('ng-not-empty')!=-1){
                browser.click(checkbox);
              }
              if(expect_row['value']=='true' && attribute.indexOf('ng-empty')!=-1){
                browser.click(checkbox);
              }
              break;
            case "vintage_start":
            case "vintage_end":
              browser.setValue(content_xpath.inputoption.replace('__NAME__',expect_row['item']),expect_row['value']);
              break;
            default:
              break;
            }
          });
          browser.click("//*[text()='Apply']");
       });
};