// Recommended filename: Given_I_have_login_to_the_SFPortal_application.js
module.exports = function() {
  this.Given(/^I have login to the SFPortal application$/, {timeout: process.env.StepTimeoutInMS*5}, function () {
    // Write code here that turns the phrase above into concrete actions
    const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    
    var userName = this.test_user;
    var password = this.user_login_config.getPassword(userName);
    var myLoginUserButton = header_xpath.named_LoginUser_button.replace('__NAME__', userName);
    var portfoliosSection = content_xpath.titledSection.replace('__TITLE__', 'Portfolios');

    var self = this;
    function tryLogin() {
      console.log(self.test_url);
      browser.url(self.test_url);
      try {
        console.log('first try if already login as: ' + myLoginUserButton);
        browser.waitForVisible(myLoginUserButton, self.waitDefault/5);
      } catch(e) {
        try {
          console.log('second try to logout anyway');
          self.browser_session.userLogout(browser);
          browser.pause(500);
          browser.refresh();
        } catch(e) {}
        try {
          console.log('third try to login');
          self.browser_session.userLogin(browser, self.test_url, userName, password);
          self.browser_session.waitForLoadingSection(browser, portfoliosSection);
          browser.waitForVisible(myLoginUserButton, self.waitDefault*4);
        } catch(e) {}
      }
      self.browser_session.waitForLoadingSection(browser, portfoliosSection);
      // refresh page if no content is shown
      if (!browser.isExisting(content_xpath.uiViewContent)) {
        console.log("Have not seen " + content_xpath.uiViewContent + " . So perform browser refresh. " );
        browser.refresh();
        browser.waitForVisible(myLoginUserButton, self.waitDefault);
      }
    }


    tryLogin();
    const dashboardPage_xpath = this.xpath_lib.xpathRequire('dashboardPage_xpath');
    try{
      browser.waitForVisible(dashboardPage_xpath.dashboard,this.wait10);
    }catch(e){
      tryLogin();
    }
    // var coronavirus_close = '//input[@name="closeBanner"]'
    // if(browser.isExisting(coronavirus_close)){
    //   console.log('close coronavirus tips')
    //   browser.click(coronavirus_close)
    // }



    // browser.url(this.test_url);
  
    // try {
    //   console.log('first try if already login as: ' + myLoginUserButton);
    //   browser.waitForVisible(myLoginUserButton, this.waitDefault/5);
    // } catch(e) {
    //   try {
    //     console.log('second try to logout anyway');
    //     this.browser_session.userLogout(browser);
    //     browser.pause(500);
    //   } catch(e) {}
    //   try {
    //     console.log('third try to login');
    //     this.browser_session.userLogin(browser, this.test_url, userName, password);
    //     this.browser_session.waitForLoadingSection(browser, portfoliosSection);
    //     browser.waitForVisible(myLoginUserButton, this.waitDefault*4);
    //   } catch(e) {}
    // }
    
    // this.browser_session.waitForLoadingSection(browser, portfoliosSection);
    // // refresh page if no content is shown
    // if (!browser.isExisting(content_xpath.uiViewContent)) {
    //   console.log("Have not seen " + content_xpath.uiViewContent + " . So perform browser refresh. " );
    //   browser.refresh();
    //   browser.waitForVisible(myLoginUserButton, this.waitDefault);
    // }

  });
}