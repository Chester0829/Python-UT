// Recommended filename: Given_I_am_the_BA_named_#.js
module.exports = function() {
  this.Given(/^I am the BA named "([^"]*)"$/, {timeout: process.env.StepTimeoutInMS}, function (testUser) {
    // Write the automation code here
    var my_testUser = testUser;
    this.test_user = my_testUser;
  });
};
