// Recommended filename: Given_I_have_a_test_portfolio_#.js
module.exports = function() {
  this.Given(/^I have a test portfolio "([^"]*)"$/, function (testPortfolio) {
    // Write the automation code here
    this.portfolio = testPortfolio;
  });
};

