// Recommended filename: Given_I_have_opened_the_SFPortal_#_application_directly.js
module.exports = function() {
  this.Given(/^I have opened the SFPortal (Settings|BWIC|Market|Documents|DataViewer|Screener|Custom Flags) application directly$/, {timeout: process.env.StepTimeoutInMS*5}, function (appName) {
    // Write code here that turns the phrase above into concrete actions
    const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const loginPage_xpath = this.xpath_lib.xpathRequire('loginPage_xpath');
    var userName = this.test_user;
    var password = this.user_login_config.getPassword(userName);
    var target_url;
    var myLoginUserButton = header_xpath.named_LoginUser_button.replace('__NAME__', userName);

    var self = this;
    switch (appName) {
      case 'Settings':
        target_url = self.test_url + '/settings/businessrules';
        break;
      case 'BWIC':
        target_url = self.test_url + '/bwic';
        break;
      case 'Market':
        target_url = self.test_url + '/marketupdate/performance';
        break;
      case 'Documents':
        target_url = self.test_url + '/documentation';
        break;
      case 'DataViewer':
        target_url = self.test_url + '/dataviewer';
        break;
      case 'Screen':
        target_url = self.test_url + '/screener';
        break;
      case 'Custom Flags':
        target_url = self.test_url + '/customflags';
        break;
      default:
        target_url = self.test_url;
    }
    
    function tryLogin(){
      console.log('url-------------:',target_url);
      browser.url(self.test_url);
      self.browser_session.waitForLoading(browser);
      // login of not yet
      try {
        console.log('first try if already login as: ' + myLoginUserButton);
        browser.waitForVisible(myLoginUserButton, self.waitDefault/5);
      } catch(e) {
        try {
          console.log('second try to logout anyway');
          self.browser_session.userLogout(browser);
          browser.refresh();
        } catch(e) {}
        try {
          console.log('third try to login');
          self.browser_session.userLogin(browser, self.test_url, userName, password);
          self.browser_session.waitForLoading(browser);
          browser.waitForVisible(myLoginUserButton, self.waitDefault*4);
        } catch(e) {}
      }
      browser.url(target_url);
      browser.pause(300);
      self.browser_session.waitForLoading(browser);

    }


    tryLogin(appName);
    const dashboardPage_xpath = this.xpath_lib.xpathRequire('dashboardPage_xpath');
    try{
      browser.waitForVisible(dashboardPage_xpath.dashboard,this.wait10);
    }catch(e){
      tryLogin(appName);
    }
    

    // browser.url(this.test_url);
    // this.browser_session.waitForLoading(browser);
    // // login of not yet
    // try {
    //   console.log('first try if already login as: ' + myLoginUserButton);
    //   browser.waitForVisible(myLoginUserButton, this.waitDefault/5);
    // } catch(e) {
    //   try {
    //     console.log('second try to logout anyway');
    //     this.browser_session.userLogout(browser);
    //   } catch(e) {}
    //   try {
    //     console.log('third try to login');
    //     this.browser_session.userLogin(browser, this.test_url, userName, password);
    //     this.browser_session.waitForLoading(browser);
    //     browser.waitForVisible(myLoginUserButton, this.waitDefault*4);
    //   } catch(e) {}
    // }

    // switch (appName) {
    //   case 'Settings':
    //     target_url = this.test_url + '/settings/businessrules';
    //     break;
    //   case 'BWIC':
    //     target_url = this.test_url + '/bwic';
    //     break;
    //   case 'Market':
    //     target_url = this.test_url + '/marketupdate/performance';
    //     break;
    //   case 'Documents':
    //     target_url = this.test_url + '/documentation';
    //     break;
    //   case 'DataViewer':
    //     target_url = this.test_url + '/dataviewer';
    //     break;
    //   case 'Screen':
    //     target_url = this.test_url + '/screener';
    //     break;
    //   case 'Custom Flags':
    //     target_url = this.test_url + '/customflags';
    //     break;
    //   default:
    //     target_url = this.test_url;
    // }

    // browser.url(target_url);
    // browser.pause(300);
    // this.browser_session.waitForLoading(browser);



  });
}