module.exports = {
    call_path: "/api/getDealList",
    call_json: {
        "portfolioId": "",
        "fxRates": ""
      }
  }