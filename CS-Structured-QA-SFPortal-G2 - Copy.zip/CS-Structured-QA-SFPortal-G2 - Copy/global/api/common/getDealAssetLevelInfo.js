module.exports = {
    call_path: "/api/getDealAssetLevelInfo",
    call_json: {
        "reportType": "",
        "deals": [
          {
            "dealKey": ""
          }
        ],
        "moduleName": "",
        "ReportingDate": "",
        "PricingDate": ""
      }
  }