module.exports = {
    call_path: "/api/getKeyDiffAggregation",
    call_json: {
        "region": "US",
        "type": "median",
        "latestVintageCount": "6",
        "fxRates": ""
      }
  } 