module.exports = {
    call_path: "/api/getHistoryPoolPerformanceData",
    call_json: {
        "asset_class":"",
        "deals":"",
        "fxRates":"",
        "mode":""
      }
  }