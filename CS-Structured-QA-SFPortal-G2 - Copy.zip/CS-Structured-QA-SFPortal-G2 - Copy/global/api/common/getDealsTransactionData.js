module.exports = {
    call_path: "/api/getDealsTransactionData",
    call_json: {
        "numOfMonths": "3",
        "deals": "",
        "fxRates": ""
      }
  }