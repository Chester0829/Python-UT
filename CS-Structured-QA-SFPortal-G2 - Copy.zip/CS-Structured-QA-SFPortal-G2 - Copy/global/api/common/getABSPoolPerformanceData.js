module.exports = {
    call_path: "/api/getABSPoolPerformanceData",
    call_json: {
        "cache": false,
        "startDate": "",
        "endDate": "",
        "mode": "",
        "portfolioAssetclass": "",
        "deals":"",
        "isOwnNotionalAmt": false,
        "metrics": "",
        "metricsMv": [],
        "pools": "",
        "fxRates":""
      }
  }