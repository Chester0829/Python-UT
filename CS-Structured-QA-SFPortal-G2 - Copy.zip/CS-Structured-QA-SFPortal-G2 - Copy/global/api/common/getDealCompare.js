module.exports = {
    call_path: "/api/getDealCompare",
    call_json: {
        "isCDO":"",
        "dealKey":"",
        "fxRates":""
      }
  }