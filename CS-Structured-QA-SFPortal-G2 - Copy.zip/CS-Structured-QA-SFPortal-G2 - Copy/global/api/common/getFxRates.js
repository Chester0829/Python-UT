module.exports = {
    call_path: "/api/getFxRates",
    call_json: {
        "asOfDate":"",
        "selectedCurrency":""
      }
  }