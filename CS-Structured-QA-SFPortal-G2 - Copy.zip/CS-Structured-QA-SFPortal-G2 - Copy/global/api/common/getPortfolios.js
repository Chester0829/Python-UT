module.exports = {
  call_path: "/api/getPortfolios",
  call_json: {
      "projections": {
        "portfolioName": 1,
        "notionalValue": 1,
        "numOfInvest": 1,
        "companyId": 1,
        "isShared": 1,
        "investments.percentOwn": 1,
        "investments.WSATicker": 1,
        "investments.dealKey": 1,
        "investments.assetClass": 1
      },
      "isDashboard": true
    }
}
