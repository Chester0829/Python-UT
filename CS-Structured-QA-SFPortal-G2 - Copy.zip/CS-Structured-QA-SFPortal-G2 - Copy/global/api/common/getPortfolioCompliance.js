module.exports = {
    call_path: "/api/getPortfolioCompliance",
    call_json: []
  }