module.exports = {
    call_path: "/api/getTranchesSSFA",
    call_json: {
        "tranches": "",
        "fxRates": ""
      }
  } 