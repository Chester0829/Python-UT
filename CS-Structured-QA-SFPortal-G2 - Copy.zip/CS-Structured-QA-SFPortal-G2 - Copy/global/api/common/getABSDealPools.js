module.exports = {
    call_path: "/api/getABSDealPools",
    call_json: {
        "deals": [{
          "dealKey": "",
          "reportingDate": ""
        }],
        // "deals":"",
        "fxRates":""
      }
  }