module.exports = {
    call_path: "/api/getIndexRates",
    call_json: {
        "asOfDate": "",
        "fxRates": ""
      }
  } 