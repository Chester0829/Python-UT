module.exports = {
    call_path: "/api/getTranchesValuations",
    call_json: {
        "tranches": "",
        "fxRates": ""
      }
  }