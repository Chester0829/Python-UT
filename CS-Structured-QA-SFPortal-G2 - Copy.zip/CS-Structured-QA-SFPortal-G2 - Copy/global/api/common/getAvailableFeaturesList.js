module.exports = {
    call_path: "/api/getAvailableFeaturesList",
    call_json: {
        "features": "",
        "fxRates": ""
      }
  }