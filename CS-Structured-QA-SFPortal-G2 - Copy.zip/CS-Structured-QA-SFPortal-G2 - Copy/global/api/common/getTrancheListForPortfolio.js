module.exports = {
    call_path: "/api/getTrancheListForPortfolio",
    call_json: {
        fxRates: "",
        portfolioId: ""
      }
  }