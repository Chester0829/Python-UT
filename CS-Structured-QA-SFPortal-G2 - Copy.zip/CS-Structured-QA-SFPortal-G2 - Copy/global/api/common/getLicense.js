module.exports = {
  call_path: "/api/getLicense",
  call_json: {
  	  "login": {
    	"username": "",
    	"password": ""
    }
	}
}
