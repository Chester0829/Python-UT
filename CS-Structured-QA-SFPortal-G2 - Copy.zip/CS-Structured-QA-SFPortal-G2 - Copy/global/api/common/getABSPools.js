module.exports = {
    call_path: "/api/getABSPools",
    call_json: {
        "deals":"",
        "fxRates":""
      }
  }