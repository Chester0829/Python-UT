module.exports = {
    call_path: "/api/getDealPerformanceData",
    call_json: {
        "requestType": "",
        "targetType": "",
        "startDate": "",
        "endDate": "",
        "deals":"",
        "fxRates":""
      }
  }