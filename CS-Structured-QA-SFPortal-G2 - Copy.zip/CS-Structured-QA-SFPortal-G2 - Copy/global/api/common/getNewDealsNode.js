module.exports = {
    call_path: "/api/getNewDealsNode",
    call_json: {
        "fxRates": ""
      }
  } 