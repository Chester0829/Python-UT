module.exports = {
    call_path: "/api/getMacroEconomicData",
    call_json: {
        "fxRates":""
      }
  }