module.exports = {
    call_path: "/api/getCMBSPoolReportingDates",
    call_json: {
        "type":"",
        "deals":"",
        "fxRates":""
      }
  }