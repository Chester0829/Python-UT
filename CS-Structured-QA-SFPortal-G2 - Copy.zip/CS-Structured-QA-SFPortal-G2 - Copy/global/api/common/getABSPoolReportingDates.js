module.exports = {
    call_path: "/api/getABSPoolReportingDates",
    call_json: {
        "deals":"",
        "fxRates":""
      }
  }