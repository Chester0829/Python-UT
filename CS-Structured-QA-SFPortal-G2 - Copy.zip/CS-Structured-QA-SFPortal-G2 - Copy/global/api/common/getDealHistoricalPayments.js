module.exports = {
    call_path: "/api/getDealHistoricalPayments",
    call_json: {
        "reportType":"",
        "fxRates":""
      }
  }