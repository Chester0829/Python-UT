module.exports = {
    call_path: "/api/getABSHistTranchePaymentsInfo",
    call_json: {
        "reportType":"",
        "fxRates":""
      }
  }