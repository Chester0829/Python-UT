module.exports = {
    call_path: "/api/getManagersReport",
    call_json: {
        "forceNewReq": true,
        "reportType": "TRANCHE_HISTORICAL_PAYMENT",
        "criteriaList": "",
        "fxRates":""
      }
  }