module.exports = {
  call_path: "/content/html",
  call_json: {
    "type": "",
    "id": "",
    "cache": "false"
  }
}
