module.exports = {
  call_path: "/api/getManagerScreen",
  call_json: {
      "searchStr": "",
      "currency": "",
      "all_managers": "",
      "assetClasses": "",
      "is_terminated": "",
      "is_acquired": "",
      "in_reinvest": "",
      "vintageMin": "",
      "vintageMax": "",
      "include_sub_advisor": 0,
      "include_affiliate": 0,
      "fxRates":{}
    }
}
