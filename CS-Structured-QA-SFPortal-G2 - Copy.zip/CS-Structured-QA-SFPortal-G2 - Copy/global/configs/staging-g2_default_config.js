exports.test_config = {
  target: "Staging",
  test_url: 'https://staging.sfportal.com',
  api_url: 'https://api-g2-s.sfportal.com',
  test_user: 'SFPQA002',
  test_portfolio: 'Portfolio-ByAssetClass',
  sp_user: 'aChoi',
  browser_x_offset: 0,
  browser_y_offset: 70,
  stepTimeoutDefault: 60*1000,
  stepTimeoutMore: 120*1000,
  stepTimeoutLong: 300*1000,
  stepTimeoutMax: 600*1000,
  waitMax: 120*1000,
  waitDefault: 30*1000
};
