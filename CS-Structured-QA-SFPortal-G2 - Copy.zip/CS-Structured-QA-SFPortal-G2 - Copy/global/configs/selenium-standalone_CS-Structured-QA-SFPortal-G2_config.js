// This file is used by local Linux as well as remote selenium PCs.
// In both local Linux and remote PC:
//  * install selenium and drivers: selenium-standalone install --config=<paht to this file>
//  * run selenium-standalone server: selenium-standalone start --config=<paht to this file>
// On remote selenium PC the above 2 steps are configured in 2 scheduled tasks and will be triggered upon reboot
// Notes on IE: note that we picked selenium 3.4.0 and iedriver 3.4.0. DO NOT CHANGE until you have tested it.
//              we have tested 3.5.0 to 3.11.0, IE11 has issues with these versions.

module.exports = {
  baseURL: 'http://selenium-release.storage.googleapis.com',
  version: '3.4.0',
  drivers: {
    chrome: {
      version: '2.38',
      arch: process.arch,
      baseURL: 'http://chromedriver.storage.googleapis.com'
    },
    ie: {
      version: '3.4.0',
      arch: process.arch,
      baseURL: 'http://selenium-release.storage.googleapis.com'
    },
    firefox: {
      version: '0.20.0',
      arch: process.arch,
      baseURL: 'http://github.com/mozilla/geckodriver/releases/download'
    },
    edge: {
      version: '16299',
      arch: process.arch,
      url: 'https://download.microsoft.com/download/D/4/1/D417998A-58EE-4EFE-A7CC-39EF9E020768/MicrosoftWebDriver.exe',
      extension: 'exe'
    }
  }
};
