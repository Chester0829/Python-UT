//Then_I_should_see_the_#_value_display_under_the_#_panel-heading_should_be_#_in_file.js
module.exports = function() {
  this.Then(/^I should see the (table|performance chart|charts|pie chart|bar chart|area chart|abnormal table) value display under the "([^"]*)" panel-heading should be (included|same as) in file$/,
    {timeout: process.env.StepTimeoutInMS*10},
    function (typeValue,widgetName,method){
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      if(widgetName == 'BWIC Analyzer:'){
        const bwic_xpath = this.xpath_lib.xpathRequire('bwic_xpath');
        var myPanel = bwic_xpath.nameTitle;
      }else{
        var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());
      }
      var table_xpath = myPanel + content_xpath.descendantDataTable;
      console.log('table_xpath:'+table_xpath)

      // parse array to json only for csv file
      function tmp(fileData){ 
        var char = '","';
        var fileResult = [];
        var thead = fileData[0][0].split(char);
        var tdata = fileData[0].slice(1);
        for(var i=0;i<tdata.length;i++){
          var obj = {};
          if(tdata[i].trim() == ''){break;} // 
          var item = tdata[i].split(char);
          for(var j=0;j<thead.length;j++){
            if(j == 0){
              // remove the first '"' for thead
              thead[j] = thead[j][0] == '"' ? thead[j].slice(1) : thead[j];
            }
            if(j == thead.length-1){
              // remove the last '"' for thead
              // remove the last " and , for thead
              if(thead[j].endsWith('",')){
                thead[j] = thead[j].slice(0,-2);
              }else if(thead[j].endsWith('"')){
                thead[j] = thead[j].slice(0,-1);
              }
            }

            var itemValue = item[j].replace(/"/g,'').trim();
            // remove the last ',' for value and trim for thead
            obj[thead[j].trim()] = itemValue.endsWith(',') ? itemValue.slice(0,-1) : itemValue;
          }
          fileResult.push(obj);
        }
        return fileResult;
      }

      // parse charts value
      function chartTmp(chartsList,splitChar){
        var splitChar = splitChar || '●';
        var uiResult = [];
        for(var i=0;i<chartsList.length;i++){
          var item = chartsList[i].split(splitChar).map(function(item){return item.trim()});
          uiResult.push(item);
        }
        return uiResult;
      }

      // handle the negative value in UI from table_json
      var self = this;
      function getUiTableValue(table_json,table_xpath,key,format){
        var negativeValue = table_xpath + '//*[@class="negativeValue"]';
        var format = format || 'DD/MMM/YYYY';
        var flag = Array.isArray(key);
        if(self.browser_session.elementSomeVisible(browser,negativeValue)){
          console.log('exists negative value');
          var uiResult = [];
          var thead = browser.getText(table_xpath + '/thead//th');
          console.log(thead);
          var trElements = browser.elements(table_xpath + '/tbody//tr').value;
          for(var i=0;i<trElements.length-1;i++){
            var tmpItem = {};
            for(var j=0;j<thead.length;j++){
              var td = table_xpath + '/tbody/tr['+(i+1)+']/td['+(j+1)+']'; 
              var tdValue = browser.getText(td).trim();
              if(browser.getHTML(td).indexOf('class="negativeValue"') != -1){
                tdValue = '-' + tdValue;
              }

              if(flag){
                for(var k=0;k<key.length;k++){
                  if(thead[j] == key[k]){
                    tmpItem[thead[j]] = self.moment(tdValue).format(format);; 
                  }else{
                    tmpItem[thead[j]] = tdValue;  
                  }
                }
              }else{
                if(thead[j] == key){
                  tmpItem[thead[j]] = self.moment(tdValue).format(format);; 
                }else{
                  tmpItem[thead[j]] = tdValue;  
                }   
              }

              // if(key == thead[j]){
              //   tmpItem[thead[j]] = self.moment(tdValue).format(format);;
              // }else{
              //   tmpItem[thead[j]] = tdValue;  
              // }


            }
            uiResult.push(tmpItem);
          }
          return uiResult;
        }else if(key){
          // handle date format for table_json
          for(var i=0;i<table_json.length;i++){
            var item = table_json[i];
            if(flag){
              for(var n=0;n<key.length;n++){
                // console.log(key[n]);
                // console.log(item[key[n]]);
                if(item[key[n]] && item[key[n]].trim() != '-' && item[key[n]].trim() != ''){
                  item[key[n]] = self.moment(item[key[n]]).format(format);  
                }
              }
            }else{
              if(item[key] && (item[key].trim() != '-' && item[key].trim() != '')){
                item[key] = self.moment(item[key]).format(format);  
              }
            }
          }
          // handle date format for table_json
          // for(var i=0;i<table_json.length;i++){
          //   var item = table_json[i];
          //   item[key] = self.moment(item[key]).format(format);
          // }
        }
        return table_json;
      }

      // only for performance,change uiValue to obj
      // CMBS Deal
      function tmpPerformance(fileData,splitChar){
        var result = [];
        var splitChar = splitChar || ',';
        for(var i=0;i<fileData.length;i++){
          var item = fileData[i];
          var header = item['header'].split(splitChar);
          var value = item['data'];
          var tmpObj = [];
          for(var j=0;j<value.length;j++){
            var obj = {};
            var tmp = value[j];
            if(tmp.trim() == ""){break;}
            // console.log(tmp);
            tmp = tmp.split(splitChar);
            for(var k=0;k<tmp.length;k++){
              // console.log(header[k]);
              // console.log(tmp[k]);
              if(header[k].trim() == ""){continue;}
              // Date in header
              var tmpValue = tmp[k].trim().replace(/"/g,'');
              if(k == 0){
                tmpValue = tmpValue.split('/').slice(1).join(' ');
              }
              obj[header[k].trim()] = tmpValue;
            }
            // console.log(obj);
            tmpObj.push(obj);
          }
          // console.log('*************');
          // console.log(tmpObj);
          result.push(tmpObj);
        }
        return result;
      }
      // only for performance, change uiValue to obj
      // CMBS Deal
      function tmpUIPerformance(uiItem){
        var result = [];
        for(var i=0;i<uiItem.length;i++){
          var tmp = uiItem[i];
          var tmpObj = [];
          var obj = {};
          tmp[0] = self.fileFirstKey + ':' + tmp[0];
          for(var j=0;j<tmp.length;j++){
            var entry = tmp[j].split(':');
            obj[entry[0].trim()] = entry[1].trim();
          }
          tmpObj.push(obj);
          result.push(tmpObj);
        }
        return result;
      }

      switch(typeValue){
        case 'table':
          var fileResult = tmp(this.file_target_data)
          console.log('fileResult***************');
          console.log(fileResult);
          console.log('***************');
          var keyList = [];
          if(widgetName.indexOf('BWIC Analyzer') != -1 || widgetName.indexOf('Results for :') != -1 || widgetName.indexOf('Key Stats') != -1){
            // handle date format
            var uiResult = getUiTableValue(this.table_json,table_xpath,['Closing Date','Reinv End Date','Next Pay Date']); 
            keyList.push('Closing Date');
          }else if(widgetName == 'Trade History'){
            var uiResult = getUiTableValue(this.table_json,table_xpath,['Settlement Date','Trade Date']);
            keyList = ['Settlement Date','Trade Date'];
          }else if(widgetName == 'List of Tranches'){
            // Latest Update
            var uiResult = getUiTableValue(this.table_json,table_xpath,['Latest Update','Est MV Date']);
            keyList = ['Latest Update','Est MV Date'];
          }else{
            var uiResult = getUiTableValue(this.table_json,table_xpath);  
          }
          console.log('uiResult***************');
          console.log(uiResult);
          console.log('************')
          if(fileResult.length == 0){
            expect(uiResult.length).toEqual(1);
            var noRecord = ['no data', 'no matching'];
            for(var i=0;i<uiResult.length;i++){
              var uiItem = uiResult[i];
              for(var key in uiItem){
                var tmpcase = uiItem[key].toLowerCase();
                expect(tmpcase.startsWith('no data') || tmpcase.startsWith('no matching') ).toBe(true);
              }
            }
            break; // no data
          }
          for(var i=0;i<uiResult.length;i++){
            var uiItem = uiResult[i];
            var fileItem = fileResult[i];
            console.log('---------------');
            console.log('uiItem:'+uiItem);
            console.log('fileItem:'+fileItem);
            for(var key in uiItem){
              if(widgetName == 'Trade History' && parseInt(key)){
                continue;
              }
              if(uiItem[key].indexOf('No match') != -1){
                break;
              }
              if(uiItem[key].indexOf('No Pool Performance') != -1){
                break;
              }
              if(uiItem[key].indexOf('Invalid date') != -1){
                // for Trade History
                break;
              }
              if(uiItem[key] == '-'){
                // Ui display '-' ?
                uiItem[key] = '';
              }else if(key.indexOf('%') != -1 && uiItem[key].indexOf('%') == -1){
                // add '%' if thead have contains '%'
                uiItem[key] += '%';
              }
              console.log(key);
              // expect(uiItem[key]).toEqual(fileItem[key]);
              if(keyList.indexOf(key) == -1  && (parseFloat(uiItem[key]) || parseFloat(uiItem[key]) == 0) ){
                if(widgetName == 'Trade History' && fileItem[key].indexOf('%') != -1){
                  expect(parseFloat(uiItem[key].slice(0,-1))).toEqual(parseFloat(fileItem[key].slice(0,-1)));
                }else{
                  expect(parseFloat(uiItem[key])).toEqual(parseFloat(fileItem[key]));  
                }
              }else{
                expect(uiItem[key]).toEqual(fileItem[key]);
              }
            }
          }
          break;
        case 'pie chart':
          // for Key Differentiators
          if(widgetName == "Key Differentiators"){
            console.log(this.uiResult);
            console.log('*************');
            console.log(this.file_target_data);
            var fileData = tmp(this.file_target_data)
            console.log(fileData);
            var num = 0;
            for(var i=0;i<this.uiResult.length;i++){
              var uiItem = this.uiResult[i];
              var fileItem = "";
              // find in fileData
              for(var j=0;j<fileData.length;j++){
                if(fileData[j][this.fileFirstKey] == uiItem[this.fileFirstKey]){
                  fileItem = fileData[j];
                  num = num + 1;
                  break;
                }
                if(fileItem != ""){break;}
              }
              if(fileItem == ''){continue;}
              console.log('**************');
              console.log(uiItem);
              console.log(fileItem);
              console.log('**************');
              for(var key in uiItem){
                //expect(uiItem[key].trim()).toEqual(fileItem[key].trim());
                expect(uiItem[key].replace(/,/g,'').trim()).toEqual(fileItem[key].replace(/,/g,'').trim());
              }
            }
            expect(num).not.toEqual(0);
          }else if(widgetName == 'Concentrations'){
            console.log(this.file_target_data);
            var uiValues = this.file_target_data[0].slice(1);
            console.log(this.charts_all_values);
            // var chartsList = this.charts_all_values.join('_').replace(/\s*/g,'').replace(/"/g,'');
            for(var i=0;i<uiValues.length;i++){
              var expectValue = undefined;
              var item = uiValues[i].split('","').slice(0,2)
              for(var j=0;j<this.charts_all_values.length;j++){
                if(this.charts_all_values[j].replace(/\s*/g,'').replace(/"/g,'').indexOf(item[0].replace(/\s*/g,'').replace(/"/g,'') != -1)){
                  expectValue = this.charts_all_values[j].replace(/\s*/g,'').replace(/"/g,'');
                }
              }
              if(!expectValue){
                expect(false).toBe(true,'can not find the value in csv file ' + item);
              }
              expect(parseFloat(item[1].slice(-1))).toEqual(parseFloat(expectValue.slice(-1)))
            }
          }
          break;
        case 'performance chart':
          var fileResult = tmpPerformance(this.fileContentList);
          console.log(fileResult);
          console.log(this.uiValues);
          console.log('**************');

          for(var k=0;k<this.uiValues.length;k++){
            var uiItem = chartTmp(this.uiValues[k]);
            var fileItem = fileResult[k];
            var uiItemObj = tmpUIPerformance(uiItem);
            // console.log(fileItem);
            // console.log('=============');
            // console.log(uiItemObj);
            // console.log('-------------');
            for(var i=0;i<uiItemObj.length;i++){
              var tmpUi = uiItemObj[i][0];
              var keyValue = tmpUi[this.fileFirstKey];
              var expectFileValue = "";
              // find the same Date from fileItem and uiItemObj
              for(var j=0;j<fileItem.length;j++){
                for(var key in fileItem[j]){
                  if(fileItem[j][this.fileFirstKey] == keyValue){
                    expectFileValue = fileItem[j];
                    break;
                  }
                }
                if(expectFileValue != ''){break;}
              }
              console.log('+++++++++++++++')
              console.log(expectFileValue);
              console.log(tmpUi);
              console.log('+++++++++++++++')
              // compare
              for(var key in expectFileValue){
                if(tmpUi[key] == undefined){
                  expect(expectFileValue[key].trim()).toEqual('');
                }else{
                  expect(expectFileValue[key].trim()).toEqual(tmpUi[key].trim());
                }
              }
            }
          }
          break;
        case 'bar chart':
          // cmbs composition
          var fileResult = tmp(this.file_target_data);
          console.log(fileResult);
          console.log(this.charts_all_values);
          var uiResult = chartTmp(this.charts_all_values);
          console.log(uiResult);
          for(var i=0;i<uiResult.length;i++){
            var uiItem = uiResult[i];
            var value = uiItem[0];
            // find value in fileResult
            var fileItem = undefined;
            var flag = false;
            for(var k=0;k<fileResult.length;k++){
              var t = fileResult[k];
              for(var key in t){
                if(t[key].trim() == value.trim()){
                  fileItem = t;
                  flag = true;
                  break;
                }
              }
              if(flag){break;}
            }
            // compare data
            console.log(uiItem);
            console.log(fileItem);
            if(fileItem != undefined){
              for(var j=1;j<uiItem.length;j++){
                if( uiItem[j].indexOf(':') != -1 ){
                  var n = uiItem[j].split(':').map(function(item){return item.trim()});
                  expect(parseInt(fileItem[n[0]])).toEqual(parseInt(n[1]));
                }
              }
            }

          }
          break;
        case 'abnormal table':
          // Deal Overview in cmbs deal -> Summary
          // console.log(this.uiResult);
          // console.log('*****************');
          if(widgetName == 'Deal Overview'){
            var fileResult = this.file_target_data[0].filter(function(item){if(item != ''){return item}});
            // console.log(fileResult);
            for(var i=0;i<this.uiResult.length;i++){
              var uiItem = this.uiResult[i];
              var index = i;
              if(fileResult[i] == ' '){
                var index = i + 1;
              }
              var fileItem = fileResult[index].replace(/","/g,' ').replace(/",/,'').replace(/"/,'');
              expect(uiItem.replace(/ -/g,' ').trim()).toEqual(fileItem.trim());
            }  
          }else if(widgetName == 'Collateral Summary'){
            var fileResult = tmp(this.file_target_data);
            // console.log(fileResult);
            var fileKey = '';
            for(var i=1;i<this.uiResult.length;i++){
              if(this.uiResult[i] == ''){break;}
              var uiItem = this.uiResult[i] + '%';
              // console.log(uiItem);
              // console.log(uiItem.replace(/-/g,''));
              var fileItem = fileResult[i-1];
              var fileStr = '';
              for(var key in fileItem){
                 fileStr += fileItem[key] + ' ';
                 if(i == 1){
                  fileKey += key + ' '; 
                 }
              }
              expect(fileStr.replace(/-/g,'').trim()).toEqual(uiItem.replace(/-/g,'').trim());
              expect(fileKey.trim()).toEqual(this.uiResult[0].trim());
              // console.log(fileStr.replace(/-/g,''));
              // console.log(fileKey);
              // console.log('-----------');
            }
          }
          break;
      }


  })
}

