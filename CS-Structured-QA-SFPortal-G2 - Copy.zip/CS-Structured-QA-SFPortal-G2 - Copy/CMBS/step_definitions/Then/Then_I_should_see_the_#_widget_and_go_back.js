// Then_I_should_see_the_#_widget_and_go_back.js
module.exports = function() {
	this.Then(/^I should see the "([^"]*)" widget and go back$/,
    {timeout: process.env.StepTimeoutInMS},
    function(widgetName){
    	this.browser_session.waitForResource(browser);
      this.browser_session.waitForLoading(browser);
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());
      browser.waitForVisible(myPanel,this.wait60);
      expect(browser.isVisible(myPanel)).toBe(true);
      browser.back();
      browser.pause(2*1000);
    });
}