// Then_I_should_see_the_#_div-table_with_#_under_the_#_panel-heading_to_match_the_following_table_data_row.js
module.exports = function() {
  this.Then(/^I should see the (first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|eleventh|twelfth|thirteenth|max) div\-table with "([^"]*)" under the "([^"]*)" panel\-heading to match the following table data row$/,
    {timeout: process.env.StepTimeoutInMS},
    function(num,tableName,widgetName,table){
      this.browser_session.waitForResource(browser);
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());
      var divTableNameXpath = myPanel + content_xpath.divTableName;
      console.log('divTableNameXpath: ' + divTableNameXpath);
      console.log(browser.getText(divTableNameXpath));
      var tableNameList = browser.getText(divTableNameXpath);
      tableNameList = Array.isArray(tableNameList)? tableNameList.map(function(item){return item.trim()}).join(' :: ') : tableNameList;
      expect(tableNameList).toContain(tableName);

      var tmp =  (tableName == 'CMM') ? tableName : tableName.split(' ').map(function(item){return item[0] + item.slice(1).toLowerCase()}).join(' ');
      var divSwitchWhenXpath =  undefined;
      if(tableName == 'SPLIT LOAN / PARI-PASSU'){
        divSwitchWhenXpath = myPanel + content_xpath.divSwitchWhen.replace('__TABLENAME__','Split / Pari-Passu');
      }else{
        divSwitchWhenXpath = myPanel + content_xpath.divSwitchWhen.replace('__TABLENAME__',tmp);
      }
      console.log('divSwitchWhenXpath: ' + divSwitchWhenXpath);
      var divTableTitleXpath = divSwitchWhenXpath + content_xpath.divTableTitle;
      console.log('divTableTitleXpath: ' + divTableTitleXpath);
      var divTableRowXpath = divSwitchWhenXpath + content_xpath.divTableRow;
      console.log('divTableRowXpath: ' + divTableRowXpath);
      var divTableXpath = divSwitchWhenXpath + content_xpath.divTable;
      console.log('divTableXpath: ' + divTableXpath);

      var baseTableXpath = undefined;
      switch(tableName){
        case 'LOAN PERFORMANCE':
        case 'CMM':
        case 'FINANCIALS':
        case 'VALUATIONS':
        case 'SERVICER COMMENTARY':
        case 'SPLIT LOAN / PARI-PASSU':
          baseTableXpath = divTableXpath + '/div';
          break;
        // case 'FINANCIALS':
        // case 'VALUATIONS': //TODO
        // case 'SERVICER COMMENTARY':
        //   baseTableXpath = divTableRowXpath;
        //   break;
      }
      var targetTableRow = undefined;
      var flag=false;
      switch(num){
        case 'first':
          targetTableRow = '(' + baseTableXpath + ')[1]';
          flag=true;
          break;
        case 'second':
          targetTableRow = '(' + baseTableXpath + ')[2]';
          flag=true;
          break;
        case 'third':
          targetTableRow = '(' + baseTableXpath + ')[3]';
          flag=true;
          break;
        case 'fourth':
          targetTableRow = '(' + baseTableXpath + ')[4]';
          flag=true;
          break;
        case 'fifth':
          targetTableRow = '(' + baseTableXpath + ')[5]';
          break;
        case 'sixth':
          targetTableRow = '(' + baseTableXpath + ')[6]';
          break;
        case 'seventh':
          targetTableRow = '(' + baseTableXpath + ')[7]';
          break;
        case 'eighth':
          targetTableRow = '(' + baseTableXpath + ')[8]';
          break;
        case 'ninth':
          targetTableRow = '(' + baseTableXpath + ')[9]';
          break;
        case 'tenth':
          targetTableRow = '(' + baseTableXpath + ')[10]';
          break;
        case 'eleventh':
          targetTableRow = '(' + baseTableXpath + ')[11]';
          break;
        case 'twelfth':
          targetTableRow = '(' + baseTableXpath + ')[12]';
          break;
        case 'thirteenth':
          targetTableRow = '(' + baseTableXpath + ')[13]';
          break;
        case 'max':
        targetTableRow = baseTableXpath;
          break;
        
      }
      console.log('targetTableRow: ' + targetTableRow);
      var targetText = browser.getText(targetTableRow);
      targetText = Array.isArray(targetText) ? targetText.map(function(item){return item.replace(/\n/g,' :: ')}) : targetText.split('\n');
      if(widgetName == 'Loan Level Summary' && (tableName == 'SERVICER COMMENTARY' || tableName == 'SPLIT LOAN / PARI-PASSU') && num == 'max'){
        targetText = targetText.slice(1);
      }
      console.log(targetText);

      var expectedList = table.hashes();
      var expectedReg = [];
      console.log(expectedList);
      for(var i=0;i<expectedList.length;i++){
        console.log(this.regex_lib.replaceRegex(expectedList[i]['row_data']));
        var t = this.regex_lib.replaceRegex(expectedList[i]['row_data']);
        expectedReg.push(t);
      }
      console.log(expectedReg.join(' :: '));
      var value = targetText.map(function(item){return item.trim()}).join(' :: ');
      console.log(value);
      if(value.indexOf('::') == -1){
        // for CMM Cumulative EDF Annual LGD
        value += ' :: ';
      }
      if(tableName == 'LOAN PERFORMANCE' && flag){
        console.log('***********');
        var tmpValue = value.split(' :: ');
        var tmpExpect = expectedReg.join(' :: ').split(' :: ');
        console.log(tmpValue);
        console.log(tmpExpect);
        for(var j=0;j<tmpValue.length;j++){
          expect(tmpValue[j]).toMatch(tmpExpect[j]);
        }
      }else{
        expect(value).toMatch(expectedReg.join(' :: '));
      }
      

  })
}