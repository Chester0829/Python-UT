//Then_I_should_see_#_column_that_index_vaule_#_display_#_under_the_#_panel-heading.js
module.exports = function() {
  this.Then(/^I should see "([^"]*)" column that index vaule "([^"]*)" display "([^"]*)" under the "([^"]*)" panel\-heading$/,
    {timeout: process.env.StepTimeoutInMS},
    function (columnName,index,value,widgetName){
      this.browser_session.waitForResource(browser);
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());
      var table_xpath = myPanel + content_xpath.descendantDataTable;
      var htmls = browser.getHTML(table_xpath);
      var table_json = this.tabletojson.convert(htmls)[0];
      console.log(table_json);
      
      for(var i=0;i<table_json.length;i++){
        var item = table_json[i];
        var flag = false;
        for(var key in item){
          if(item[key].indexOf('No match') != -1){
            flag = true;
            break;
          }
        }
        if(flag){
          continue;
        }
        if (!(columnName in item)){
          expect(false).toBe(true,'not find the column: ' + columnName);
        }
        expect(item[columnName]).toEqual(value);
      }


  })
}