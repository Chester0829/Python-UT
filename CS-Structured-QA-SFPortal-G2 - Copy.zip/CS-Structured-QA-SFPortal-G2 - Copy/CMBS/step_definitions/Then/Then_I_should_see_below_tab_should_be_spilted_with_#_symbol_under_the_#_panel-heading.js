//Then_I_should_see_below_tab_should_be_spilted_with_#_symbol_under_the_#_panel-heading.js
module.exports = function() {
  this.Then(/^I should see below tab should be spilted with "([^"]*)" symbol under the "([^"]*)" panel\-heading$/,
    {timeout: process.env.StepTimeoutInMS},
    function (char,widgetName,table){
      this.browser_session.waitForResource(browser);
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());
      var tabXpath = undefined;
      switch(widgetName){
        case 'Loan Level Summary':
          // tabXpath = myPanel + '//*[@id="singleLoanSummary"]//*[contains(@ng-click,"llsCtrl.selectedTab")]';
          tabXpath = myPanel + '//sfp-data-table//*[@id="singleLoanSummary"]//ul//li';
          break;
      }
      var textTab = browser.getText(tabXpath);
      console.log(textTab);
      textTab = textTab.map(function(item){return item.trim()});
      textTab = textTab.join('').split(char).map(function(item){return item.trim()}).join(char);
      var expectList = table.hashes();
      for(var i=0;i<expectList.length;i++){
        expect(expectList[i]['row_data'].replace(/ :: /g,'||')).toEqual(textTab);
      }


  })
}