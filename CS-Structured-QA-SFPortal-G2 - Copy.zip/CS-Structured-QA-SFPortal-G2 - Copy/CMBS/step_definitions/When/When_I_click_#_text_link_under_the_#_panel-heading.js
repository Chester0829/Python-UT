// When_I_click_#_text_link_under_the_#_panel-heading.js
module.exports = function() {
  this.When(/^I click "([^"]*)" text link under the "([^"]*)" panel\-heading$/,
    {timeout: process.env.StepTimeoutInMS},
    function (linkText, widgetName){
      this.browser_session.waitForResource(browser);
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());
      var linkTextXpath = undefined;
      switch(widgetName){
        case 'Loan Level Summary':
          var linkText = content_xpath.linkText.replace('__LINKTEXT__',linkText);
          console.log(myPanel + linkText);
          linkTextXpath = myPanel + linkText;
          break;
        case 'My Company\'s Private Files':
          linkTextXpath = myPanel + '//a//span[contains(text(),"' + linkText + '")]';
          break;
      }
      console.log('linkTextXpath: ', linkTextXpath);
      browser.click(linkTextXpath);
      this.browser_session.waitForResource(browser);


  })
}