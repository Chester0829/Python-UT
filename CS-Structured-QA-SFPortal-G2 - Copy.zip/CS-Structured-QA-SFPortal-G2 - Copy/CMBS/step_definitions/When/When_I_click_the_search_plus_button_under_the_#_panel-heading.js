// When_I_click_the_search_plus_button_under_the_#_panel-heading.js
module.exports = function() {
	this.When(/^I click the search plus button under the "([^"]*)" panel\-heading$/,
    {timeout: process.env.StepTimeoutInMS},
    function(widgetName){
    	// this.browser_session.waitForResource(browser);
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', widgetName.toLowerCase());
      var searchPlus = myPanel + '//*[contains(@class,"fa fa-search-plus pull-right")]';
      browser.waitForVisible(searchPlus,this.waitDefault);
      browser.click(searchPlus);
      this.browser_session.waitForResource(browser);
      this.browser_session.waitForLoading(browser);
    });
}