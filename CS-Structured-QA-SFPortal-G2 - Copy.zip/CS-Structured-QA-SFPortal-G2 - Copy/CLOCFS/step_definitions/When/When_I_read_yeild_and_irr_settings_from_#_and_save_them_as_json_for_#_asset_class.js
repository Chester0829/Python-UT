module.exports = function() {
  this.When(/^I read yield and irr settings from "([^"]*)" and save them as json for "([^"]*)" asset class$/,
    {timeout: process.env.StepTimeoutInMS*10},
    function (filename,assetclass,table){
      
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
      var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', 'results');
      this.browser_session.waitForResource(browser,cashflow_xpath.dealCashflowsResult);
      browser.getLocationInView(cashflow_xpath.dealCashflowsResult);
      var self = this;
      var path = require('path');
      var filePath = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'CLOCFS', filename);

      var yield_irr_res={};
      var yieldTable=cashflow_xpath.yieldTable;
      var irrTable=cashflow_xpath.trancheStatisticsTable;
      var tranche_count = browser.selectorExecute(tranche_select_xpath, function (selects) {
        return selects.length;
      });

      switch(assetclass){
        case "CLO":
          var yield_content = this.file_session.readXlsxAsCsvString(filePath,7).split('\n');
          var irr_content = this.file_session.readXlsxAsCsvString(filePath,8).split('\n');
          break;
      }
      
      var setting_list = table.hashes();
      var setting_length=setting_list.length;
      var yield_dict = {};
      var irr_dict = {};
      var yieldcontent_length = yield_content.length;
      var irrcontent_length = irr_content.length;
      console.log(yieldcontent_length);
      console.log(irrcontent_length);
      var yield_setting;
      var irr_setting;

      if(assetclass=="CLO"){
        for(var i=4;i<yieldcontent_length;i++){
          yield_setting = yield_content[i].split(',');
          if(yield_setting[2] != ''){
              yield_dict[yield_setting[2]] = yield_setting;
          }
        }
        for(var i=4;i<irrcontent_length;i++){
          irr_setting = irr_content[i].split(',');
          if(irr_setting[2] != ''){
              irr_dict[irr_setting[2]] = irr_setting;
          }
        }
      }
      //  defined the write function
      var export_res = function (file_name, file_path, file_content, file_type) {
          var myDate = new Date();
          var month = myDate.getMonth() + 1;
          var day = myDate.getDate();
          var today = '0' + month + day;
          file_name = file_name + '_' + today + '.' + file_type;
          if (file_type == 'json') {
              var data_json = JSON.stringify(file_content);
          } else {
              var data_json = file_content;
          }

          if (fs.existsSync(file_path)) {
              console.log(file_path + ' exist!')
          } else {
              fs.mkdir(file_path, function (err) {
                  if (err) {
                      throw err;
                  }
                  console.log('make dir success.');
              });
          }
          // console.log("--------------------------cash flow---------------------------------",casgflow_json);
          fs.writeFile(file_path + '/' + file_name, data_json, {flag: "w"}, function (err) {
              if (err) {
                  console.log(file_name + " saved failed!");
                  return console.log(err);
              } else {
                  console.log(file_name + " saved successfully!");
              }

          })
      };    

      var yield_value_list;
      var irr_value_list;

      var item={"perfsummary":{},"tranche statistics":{},}; 
      item["perfsummary"]["tranche name"]="tranche_name";
      item["perfsummary"]["senario id"]="senario_id";
        

      for(var setting_num=0;setting_num<setting_length;setting_num++){


        //fill in yield and irr setting
        if(setting_list[setting_num]['yield_setting']!='null'){
          yield_value_list=yield_dict[setting_list[setting_num]['yield_setting']];
          console.log(yield_value_list);
          browser.click(cashflow_xpath.yieldTableSelectIcon1);
          browser.waitForVisible(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__",yield_value_list[3]));
          browser.click(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__",yield_value_list[3]));
          if(yield_value_list[4]=='Y'){
            browser.click(cashflow_xpath.yieldTableSelectIcon2);
            browser.waitForVisible(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__","Custom"));
            browser.click(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__","Custom"));
            for(var i=1;i<=7;i++){
              var input_xpath='(//table[contains(@class,"yieldTable")]//input)['+i+']';
              browser.setValue(input_xpath,yield_value_list[i+5]);
            }
          }
          else{
            browser.click(cashflow_xpath.yieldTableSelectIcon2);
            browser.waitForVisible(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__","Custom"));
            browser.click(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__","Step Size (bps)"));
            for(var i=1;i<=2;i++){
              var input_xpath='(//table[contains(@class,"yieldTable")]//input)['+i+']';
              browser.setValue(input_xpath,yield_value_list[7-i]);
            }
          }
        }
        if(setting_list[setting_num]['irr_setting']!='null'){
          irr_value_list=irr_dict[setting_list[setting_num]['irr_setting']];
          console.log(irr_value_list);
          if (irr_value_list[3]!='default value') {
            var irr_input_xpath1='(//table[contains(@class,"trancheStatsTable")]//tr[13]//input)[1]';
            browser.setValue(irr_input_xpath1,irr_value_list[3]);
          }
          var irr_input_xpath2='(//table[contains(@class,"trancheStatsTable")]//tr[14]//input)[1]';
          browser.setValue(irr_input_xpath2,irr_value_list[4]);
        }

        //wait for cashflow loading
        var timeOut = arg1*60*1000;
        const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
        this.browser_session.waitForResource(browser,cashflow_xpath.dealCfsAssumptions);
        browser.getLocationInView(cashflow_xpath.runYieldCashflow);
        browser.click(cashflow_xpath.runYieldCashflow);
        try {
            browser.waitForExist(cashflow_xpath.dealCfsRunprogressBar,this.waitDefault);
            browser.waitForVisible(cashflow_xpath.dealCfsRunprogressBar,this.waitDefault);
            this.browser_session.waitForLoading(browser,cashflow_xpath.dealCfsRunprogressBar,1000,timeOut);
            browser.waitForVisible(cashflow_xpath.dealcfsCashflowRusult,this.waitDefault);
        }catch (e) {
            console.log(e);
            console.log("wait for second time as the running bar does not visible");
            browser.waitForExist(cashflow_xpath.dealCfsRunprogressBar,this.waitDefault);
            browser.waitForVisible(cashflow_xpath.dealCfsRunprogressBar,this.waitDefault);
            this.browser_session.waitForLoading(browser,cashflow_xpath.dealCfsRunprogressBar,1000,timeOut);
            browser.waitForVisible(cashflow_xpath.dealcfsCashflowRusult,timeOut);
        }
        expect(browser.isVisible(cashflow_xpath.dealCfsResultprogressBar)).toBe(false,'dealCfsResultprogressBar still show');

        //tranch select list
        //for(var tranch_index=0;tranch_index<tranche_count;tranche_index++){
          //save yield and irr function
          var AverageLife=browser.getText(irrTable+'//tr[2]//td[2]');
          var Duraion=browser.getText(irrTable+'//tr[3]//td[2]');
          var ModifiedDuration=browser.getText(irrTable+'//tr[4]//td[2]');
          var FirstPrincipalPayment=browser.getText(irrTable+'//tr[5]//td[2]');
          var LastPrincipalPayment=browser.getText(irrTable+'//tr[6]//td[2]');
          var TrancheLoss=browser.getText(irrTable+'//tr[7]//td[2]');
          var TrancheLossPer=browser.getText(irrTable+'//tr[8]//td[2]');
          var CollateralLoss=browser.getText(irrTable+'//tr[9]//td[2]');
          var CollateralLossPer=browser.getText(irrTable+'//tr[10]//td[2]');
          var FirstLossInPrincipal=browser.getText(irrTable+'//tr[11]//td[2]');
          var FirstLossInInterest=browser.getText(irrTable+'//tr[12]//td[2]');
          var PurchaseDate=browser.getText(irrTable+'//tr[13]//td[2]');
          var PurchasePrice=browser.getText(irrTable+'//tr[14]//td[2]');
          var IRR=browser.getText(irrTable+'//tr[15]//td[2]');
                   

          item["tranche statistics"]["Average Life"]=AverageLife;
          item["tranche statistics"]["Duraion"]=Duraion;
          item["tranche statistics"]["Modified Duration"]=ModifiedDuration;
          item["tranche statistics"]["First Principal Payment"]=FirstPrincipalPayment;
          item["tranche statistics"]["Last Principal Payment"]=LastPrincipalPayment;
          item["tranche statistics"]["Tranche Loss"]=TrancheLoss;
          item["tranche statistics"]["Tranche Loss %"]=TrancheLossPer;
          item["tranche statistics"]["Collateral Loss"]=CollateralLoss;
          item["tranche statistics"]["Collateral Loss %"]=CollateralLossPer;
          item["tranche statistics"]["First Loss in Principal"]=FirstLossInPrincipal;
          item["tranche statistics"]["First Loss in Interest"]=FirstLossInInterest;
          item["tranche statistics"]["Purchase Date (IRR)"]=PurchaseDate;
          item["tranche statistics"]["Purchase Price (IRR)"]=PurchasePrice;
          item["tranche statistics"]["IRR"]=IRR;

          
          
        //}

        
      }  

      yield_irr_res.push(item);
      var file_name='test_save_irr';
      var file_path='../../../../cashflow_res';
      export_res(file_name, file_path, yield_irr_res, 'json');          

      
      this.yield_value_list=yield_value_list;
      this.irr_value_list=irr_value_list;
      
  })
}
