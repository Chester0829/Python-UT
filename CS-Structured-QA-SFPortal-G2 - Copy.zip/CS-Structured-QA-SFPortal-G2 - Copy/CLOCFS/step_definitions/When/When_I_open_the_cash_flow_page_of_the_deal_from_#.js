// Recommended filename: Given_I_have_opened_the_#_#_#_page_directly.js
module.exports = function() {
  this.When(/^I open the cash flow page of the deal ([^"]*)$/,
    {timeout: process.env.StepTimeoutInMS*5},
    function (target) {
    const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
    const dealPage_xpath = this.xpath_lib.xpathRequire('dealPage_xpath');
  var path = require('path');
  var filename = 'dealList.xlsx';
  var filePath = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'CLOCFS', filename);
  var content = this.file_session.readXlsxAsCsvString(filePath,1).split('\n');
  // console.log("content:",content);

  // generate deal_key_list from deal_list file
  var deal_key_list = [];
  var deal_num = content.length - 1;
  for(var row = 1;row<=deal_num;row++){
      var deal_key = content[row].split(',')[0];
      if(deal_key_list.indexOf(deal_key) == -1){
          deal_key_list.push(deal_key)
      }
  }
  // console.log(deal_key_list);

  var s = '';
  for(var index in deal_key_list){
      s = '| 10401     | null     | null     | null     | null     | ' + deal_key_list[index] + ' |';
      // console.log(s)
  }
  // console.log(s);

  // generate url and open cashflow page
  var cashflowPageUrl = this.test_url + '/deal/cashflows/' + target;
  console.log("cashflowPage:",cashflowPageUrl);
  browser.url(cashflowPageUrl);
  this.browser_session.waitForLoading(browser);
  browser.waitForVisible(header_xpath.mainDashboard_button, this.waitDefault*2);
  this.browser_session.waitForResource(browser);




  });
}