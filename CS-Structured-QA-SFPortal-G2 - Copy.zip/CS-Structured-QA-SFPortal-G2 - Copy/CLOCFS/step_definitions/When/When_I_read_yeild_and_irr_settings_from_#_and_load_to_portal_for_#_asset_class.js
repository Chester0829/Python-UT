module.exports = function() {
  this.When(/^I read yield and irr settings from "([^"]*)" and load to portal for "([^"]*)" asset class$/,
    {timeout: process.env.StepTimeoutInMS*10},
    function (filename,assetclass,table){
      this.yield_used = {};
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
      var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', 'results');
      this.browser_session.waitForResource(browser,cashflow_xpath.dealCashflowsResult);
      browser.getLocationInView(cashflow_xpath.dealCashflowsResult);
      var self = this;
      var path = require('path');
      var filePath = path.join(process.env.HOME, 'Projects', 'SFPortal-G2', 'CLOCFS', filename);

      switch(assetclass){
        case "CLO":
          var yield_content = this.file_session.readXlsxAsCsvString(filePath,7).split('\n');
          var irr_content = this.file_session.readXlsxAsCsvString(filePath,8).split('\n');
          break;
      }
      //var stratifications = this.file_session.readXlsxAsCsvString(filePath,1).split('\n');
      //console.log("stratifications:",stratifications);
      var setting_list = table.hashes();
      var yield_dict = {};
      var irr_dict = {};
      var yieldcontent_length = yield_content.length;
      var irrcontent_length = irr_content.length;
      console.log(yieldcontent_length);
      console.log(irrcontent_length);
      var yield_setting;
      var irr_setting;

      if(assetclass=="CLO"){
        for(var i=4;i<yieldcontent_length;i++){
          yield_setting = yield_content[i].split(',');
          if(yield_setting[2] != ''){
              yield_dict[yield_setting[2]] = yield_setting;
          }
        }
        for(var i=4;i<irrcontent_length;i++){
          irr_setting = irr_content[i].split(',');
          if(irr_setting[2] != ''){
              irr_dict[irr_setting[2]] = irr_setting;
          }
        }
      }    

      var yield_value_list;
      var irr_value_list;
      
      if(setting_list[0]['setting_id']!='null'){
        yield_value_list=yield_dict[setting_list[0]['setting_id']];
        console.log(yield_value_list);
        browser.click(cashflow_xpath.yieldTableSelectIcon1);
        browser.waitForVisible(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__",yield_value_list[3]));
        browser.click(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__",yield_value_list[3]));
        if(yield_value_list[4]=='Y'){
          browser.click(cashflow_xpath.yieldTableSelectIcon2);
          browser.waitForVisible(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__","Custom"));
          browser.click(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__","Custom"));
          for(var i=1;i<=7;i++){
            var input_xpath='(//table[contains(@class,"yieldTable")]//input)['+i+']';
            browser.setValue(input_xpath,yield_value_list[i+5]);
          }
        }
        else{
          browser.click(cashflow_xpath.yieldTableSelectIcon2);
          browser.waitForVisible(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__","Custom"));
          browser.click(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__","Step Size (bps)"));
          for(var i=1;i<=2;i++){
            var input_xpath='(//table[contains(@class,"yieldTable")]//input)['+i+']';
            browser.setValue(input_xpath,yield_value_list[7-i]);
          }

        }
      }

      if(setting_list[1]['setting_id']!='null'){
        irr_value_list=irr_dict[setting_list[1]['setting_id']];
        console.log(irr_value_list);
        if (irr_value_list[3]!='default value') {
          var irr_input_xpath1='(//table[contains(@class,"trancheStatsTable")]//tr[13]//input)[1]';
          browser.setValue(irr_input_xpath1,irr_value_list[3]);
        }
        var irr_input_xpath2='(//table[contains(@class,"trancheStatsTable")]//tr[14]//input)[1]';
        browser.setValue(irr_input_xpath2,irr_value_list[4]);
      }
      
      this.yield_value_list=yield_value_list;
      this.irr_value_list=irr_value_list;
      
  })
}
