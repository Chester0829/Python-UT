//Then_I_should_see_the_#_value_display_under_the_#_panel-heading_should_be_#_in_file.js
module.exports = function() {
  this.When(/^I read scenarios from "([^"]*)" and load below scenario list to portal$/,
    {timeout: process.env.StepTimeoutInMS*100},
    function (filename,table){
      this.scenarios_used = {};
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
      this.browser_session.waitForResource(browser,cashflow_xpath.dealCfsAssumptions);
      browser.getLocationInView(cashflow_xpath.dealCfsAssumptions);
      var self = this;
      var path = require('path');
      var filePath = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'CLOCFS', filename);
      var content = this.file_session.readXlsxAsCsvString(filePath).split('\n');
      var stratifications = this.file_session.readXlsxAsCsvString(filePath,11).split('\n');
      console.log("stratifications:",stratifications);
      var scenario_list = table.hashes();
      var scenario_dict = {};
        var content_length = content.length;
        var scenario;
        for(var i=23;i<content_length;i++){
            scenario = content[i].split(',');
            if(scenario[0] != ''){
                scenario_dict[scenario[0]] = scenario
            }
      }

      var set_stratification = function (stratification_settings,self,stratification_type) {
          browser.click('//a[contains(text(),"Apply Stratification")]');
          browser.waitForVisible('//table[contains(@id,"watchlist")]',self.waitDefault);
          console.log('add new rule...')
          browser.click('//span[contains(text(),"Add New Rule")]');
          var header_list = ['watch.type1','watch.min1','watch.max1','watch.type2','watch.min2','watch.max2','watch.type3','watch.min3','watch.max3','watch.prepayrate','watch.prepaytype','watch.defaultrate','watch.defaulttype','watch.defaultDate','watch.lossrate','watch.lossType','watch.lagmonths','watch.cccDateIn','watch.cccDateOut','watch.lossRate'];
          for (var i = 0; i < stratification_settings.length; i++) {
              var column = header_list[i];
              var value = stratification_settings[i];
              console.log('column: ' + column + ', value: ' + value);
              switch(column){
                case 'watch.min2':
                case 'watch.max2':
                case 'watch.type1':
                case 'watch.type2':
                case 'watch.type3':
                case 'watch.prepaytype':
                case 'watch.defaulttype':
                case 'watch.lossType':
                case 'item.adjustable':
                case 'item.bankLoans':
                case 'item.juniorSenior':
                case 'item.country':
                case 'item.rating':
                case 'assumpCtrl.postReinv.autoReinvEnd':
                case 'assumpCtrl.postReinv.reinvestOverride':
                  var mdSelect = cashflow_xpath.mdSelect.replace('__NAME__',column);
                  var tmp = browser.isVisible(mdSelect);
                  // need to filter true in tmp list ?
                  var mdSelectLen = Array.isArray(tmp) ? tmp.length : 1;
                  browser.pause(200);
                   if(value == 'disabled'){
                    var isDisable = browser.getAttribute('(' + mdSelect +')[' + mdSelectLen + ']','disabled');
                    console.log(isDisable);
                    expect(isDisable).toEqual(value);
                  }else{
                    browser.click('(' + mdSelect +')[' + mdSelectLen + ']');
                    try {
                      var textXpath = cashflow_xpath.mdSelectMenu + '//*[text()="'+ value +'"]';
                      var t = browser.isVisible(textXpath);
                      var textXpathLen = Array.isArray(t) ? t.length : 1;
                      browser.click('(' + textXpath + ')[' + textXpathLen + ']');
                    } catch (error) {
                      var textXpath = cashflow_xpath.mdSelectMenu2 + '//*[text()="'+ value +'"]';
                      console.log('try more one time: ' + textXpath);
                      var t = browser.isVisible(textXpath);
                      var textXpathLen = Array.isArray(t) ? t.length : 1;
                      browser.click('(' + textXpath + ')[' + textXpathLen + ']');
                    }
                  }
                  break;
                case 'watch.min1':
                  // var uiSelectMatch = '//div[@ng-model="'+ column +'"]//div[@class="ui-select-match"]';
                  // var tmp = browser.isVisible(uiSelectMatch);
                  // var uiSelectMatchLen = Array.isArray(tmp) ? tmp.length : 1;
                  // console.log('(' + uiSelectMatch + ')[' + uiSelectMatchLen +']');
                  // try {
                  //   browser.click('(' + uiSelectMatch + ')[' + uiSelectMatchLen +']');
                  // } catch (error) {
                  //   console.log('try to click: ' + '(' + divSelectMatch + ')[' + uiSelectMatchLen + ']' );
                  //   browser.click('(' + divSelectMatch + ')[' + uiSelectMatchLen + ']');
                  // }
                  var divSelectMatch = '//*[@ng-model="'+ column +'"]';
                  var tmp = browser.isVisible(divSelectMatch);
                  console.log(tmp);
                  var divSelectMatchLen = Array.isArray(tmp) ? tmp.length : 1;
                  browser.click('(' + divSelectMatch + ')[' + divSelectMatchLen + ']');
                  browser.pause(200);
                  var input = '//div[@ng-model="watch.min1"]//input[contains(@placeholder,"Select or search")]';
                  var t = browser.isVisible(input);
                  console.log(t);
                  var inputLen =  Array.isArray(t) ? t.length : 1;
                  console.log(inputLen);
                  browser.click('(' + input + ')[' + inputLen + ']');
                  console.log('(' + input + ')[' + inputLen + ']');
                  browser.pause(1000);
                  browser.setValue('(' + input + ')[' + inputLen + ']',value);
                  browser.waitForVisible('//div[@ng-model="watch.min1"]//ul[not (contains(@class,"ng-hide"))]//*[text()="'+ value +'"]',self.waitDefault);
                  this.robot_session.keyTap();
                  if(this.portfolio && browser.isVisible('(' + input + ')[' + inputLen + ']')){
                    browser.pause(500);
                    browser.click('(' + input + ')[' + inputLen + ']');
                    browser.waitForVisible('//div[@ng-model="watch.min1"]//ul[not (contains(@class,"ng-hide"))]//*[text()="'+ value +'"]',self.waitDefault);
                    this.robot_session.keyTap();
                  }
                  break;
                case 'watch.max1':
                case 'watch.max3':
                case 'watch.min3':
                case 'watch.prepayrate':
                case 'watch.defaultrate':
                case 'watch.lossrate':
                case 'watch.lagmonths':
                case 'watch.defaultDate':
                case 'watch.cccDateIn':
                case 'watch.cccDateOut':
                case 'watch.lossRate':
                case 'item.companyName':
                case 'item.term':
                case 'item.coupon':
                case 'item.margin':
                case 'item.recoveryRate':
                case 'item.floor':
                case 'item.price':
                case 'item.mktprice':
                case 'row.months':
                case 'item.value':
                case 'item.value1':
                case 'item.value2':
                case 'item.value3':
                case 'item.value4':
                case 'item.value5':
                case 'item.value6':
                case 'item.value7':
                case 'item.value8':
                case 'item.value9':
                case 'item.value10':
                case 'item.value11':
                case 'item.value12':
                case 'item.value13':
                case 'item.value14':
                case 'item.value15':
                case 'item.value16':
                case 'item.value17':
                case 'item.value18':
                case 'item.value19':
                case 'item.value20':
                case 'item.value21':
                case 'item.value22':
                case 'item.value23':
                case 'item.value24':
                case 'assumpCtrl.postReinv.customDate':
                case 'assumpCtrl.postReinv.period':
                case 'assumpCtrl.postReinv.autoReinvEndval':
                case 'assumpCtrl.postReinv.intraPeriod':
                  var sfpTextInput = cashflow_xpath.sfpTextInput.replace('__NAME__',column) + '//input';
                  var tmp = browser.isVisible(sfpTextInput);
                  if(!tmp){
                    sfpTextInput = '//input[@ng-model="'+ column +'"]';
                    tmp = browser.isVisible(sfpTextInput);
                  }
                  var sfpTextInputLen = Array.isArray(tmp) ? tmp.length : 1;
                  // console.log('(' + sfpTextInput + ')[' + sfpTextInputLen + ']');
                  if(column=="item.value1" || column == "item.value2"||column=="item.value3" || column == "item.value4" || column == "item.value5" || column == "item.value6" || column == "item.value7" || column == "item.value8" || column == "item.value9" || column == "item.value10" || column == "item.value11" || column == "item.value12" || column == "item.value13" || column == "item.value14" || column == "item.value15" || column == "item.value16" || column == "item.value17" || column == "item.value18" || column == "item.value19" || column == "item.value20" || column == "item.value21" || column == "item.value22" || column == "item.value23" || column == "item.value24"){
                    sfpTextInput = '(//input[@ng-model="item.value"])['+column.substr(10)+']';
                    console.log(sfpTextInput);
                    tmp = browser.isVisible(sfpTextInput);
                    sfpTextInputLen = 1;
                  }
                  if(value == 'disabled'){
                    var isDisable = browser.getAttribute('(' + sfpTextInput + ')[' + sfpTextInputLen + ']','disabled');
                    console.log(isDisable);
                  }else{
                    browser.setValue('(' + sfpTextInput + ')[' + sfpTextInputLen + ']',value);
                  }
                  break;
                case 'assumpCtrl.postReinv.prepayment':
                case 'assumpCtrl.postReinv.scheduled':
                case 'assumpCtrl.postReinv.recoveries':
                case 'assumpCtrl.postReinv.prepayment2':
                case 'assumpCtrl.postReinv.scheduled2':
                case 'assumpCtrl.postReinv.scheduled2':
                case 'assumpCtrl.postReinv.recoveries2':
                  var mdCheckBox = cashflow_xpath.mdCheckbox.replace('__NAME__',column);
                  var checkStatus = browser.getAttribute(mdCheckBox,'aria-checked');
                  console.log(checkStatus);
                  if(value == 'checked' && checkStatus == "false"){
                    browser.click(mdCheckBox);
                    console.log('checked');
                  }else if(value == 'unchecked' && checkStatus == "true"){
                    browser.click(mdCheckbox);
                  }
                  break;
      }
          }
          // save Stratifications
          browser.click('//span[contains(text(),"Save Stratifications")]')
      };
             // call function set_stratification to set stratification
            // for (var i=0;i<stratifications.length;i++){
            //   var stratifications_settings = stratifications[2].split(',').slice(1)
            //   var stratification_type = stratifications_settings[0]
            //   console.log('stratifications_settings:',stratifications_settings);
            //   set_stratification(stratifications_settings,this,stratification_type);
            //       }

              // remove the item from scenario list which scenario_id is null
              var temp = [];
              for (var scenario_index=0;scenario_index < 5; scenario_index++){
                  if(scenario_list[scenario_index]["scenario_id"] != 'null'){
                      temp.push(scenario_list[scenario_index])
                  }
              }
              scenario_list = temp;

              //uncheck the scenario if don't need run
              var run_flag_unchecked_num = scenario_list.length + 1;
              for(var run_flag_uncheck_index = run_flag_unchecked_num;run_flag_uncheck_index<=5;run_flag_uncheck_index++){
                  var check_box = '(' + cashflow_xpath.dealcfsCheckBox.replace('__NAME__',"scen.run_flag") + ')[' + run_flag_uncheck_index + ']';
                  // var check_flag = '(' + cashflow_xpath.dealcfsCheckBox.replace('__NAME__',"scen.run_flag") + ')[' + run_flag_uncheck_index + ']';
                  this.browser_session.waitForResource(browser,check_box);
                  var target_attribute = browser.getAttribute(check_box, 'class');
                  if (target_attribute.indexOf('ng-not-empty')>-1) {
                      browser.click(check_box);
                      browser.pause(100);
                  }
              }

              var assumption_list;
              var output_type = process.env.output_type
              console.log('output type:',output_type);
              if (output_type == 'Payment'){
                  output_type = 'Payment Dates'
              }
              if (output_type == undefined){
                    output_type = 'Monthly'
                  }
              // console.log("scenario_dict:",scenario_dict);
              for (var scenario_row in scenario_list){
                  assumption_list = [];
                  var scenario_value_list = scenario_dict[scenario_list[scenario_row]['scenario_id']];
                  console.log('scenario_value_list:',scenario_value_list);

                  //transfer the scenario details to the follow step
                  this.scenarios_used[scenario_list[scenario_row]['scenario_id']] = scenario_value_list;
                  // console.log('this.scenario_used:',this.scenarios_used);
                  // console.log('scenario_value_list:',scenario_value_list);

                  assumption_list.push({'name':'scen.run_flag','value':'checked'},{'name':'scen.scenType','value':'User Defined'},{'name':'analyticsCtrl.outputType','value':output_type},{'name':'scen.cal_first_loss','value':scenario_value_list[3]},{'name':'scen.settle_date','value':scenario_value_list[4]},{'name':'scen.forward_curve','value':scenario_value_list[5]},{'name':'scen.apply_watch','value':scenario_value_list[6]},{'name':'scen.prepay_rate','value':scenario_value_list[7]},{'name':'scen.prepay_type','value':scenario_value_list[8]},{'name':'scen.default_rate','value':scenario_value_list[9]},{'name':'scen.default_type','value':scenario_value_list[10]},{'name':'scen.loss_rate','value':scenario_value_list[11]},{'name':'scen.loss_type','value':scenario_value_list[12]},{'name':'scen.prinLossSeverityPctNonPerf','value':scenario_value_list[13]},{'name':'scen.rec_lag','value':scenario_value_list[14]},{'name':'scen.reinvest_price_type','value':scenario_value_list[16]},{'name':'scen.reinvest_price','value':scenario_value_list[15]},{'name':'scen.reinvest_pool','value':scenario_value_list[19]},{'name':'scen.reinvest_spread','value':scenario_value_list[17]},{'name':'scen.reinvest_term','value':scenario_value_list[18]},{'name':'scen.reinvDefaultLockout','value':scenario_value_list[20]},{'name':'scen.reinvest_rules','value':scenario_value_list[21]},{'name':'scen.call_option','value':scenario_value_list[22]},{'name':'scen.call_date','value':scenario_value_list[23]},{'name':'scen.call_price_type','value':scenario_value_list[24]},{'name':'scen.call_price','value':scenario_value_list[25]});
                  console.log('assumption:',assumption_list);


                  var arg1 = parseInt(scenario_row) + 1;
                  assumption_list.forEach(function(list_row) {
                      console.log('setting:',list_row['name']);
                      switch(list_row['name']){
                          case "scen.run_flag":
                              var check_flag = '(//md-checkbox[contains(@ng-model,"run_flag")])' + '[' + arg1 + ']';
                              browser.waitForVisible(check_flag,self.waitDefault);
                              var target_attribute = browser.getAttribute(check_flag, 'class');
                              console.log('target_attribute:',target_attribute);
                              if (list_row['value']=='checked'&&target_attribute.indexOf('ng-empty') > -1 ){
                                  browser.click(check_flag);
                                  browser.pause(100);
                              }else if (list_row['value'] == 'unchecked'&&target_attribute.indexOf('ng-not-empty')>-1) {
                                  browser.click(check_flag);
                                  browser.pause(100);
                              }
                              break;
                          case "scen.cal_first_loss":
                          case "scen.seed_default":
                          case "scen.ignore_input_nonpayment_term":
                          case "scen.calc_curve_off_static_bal":
                          case "scen.useACHVector":
                          case "scen.apply_watch":
                          case "scen.apply_loan_level_assumps":
                          case 'scen.term_triggers_activate_LTV_trigger':
                          case 'scen.term_triggers_activate_DSCR_trigger':
                          case 'scen.maturity_trigger_activate_LTV_trigger':
                          case 'scen.maturity_trigger_activate_DY_trigger':
                              var check_box = '(' + cashflow_xpath.dealcfsCheckBox.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
                              browser.waitForVisible(check_box,self.waitDefault);
                              var target_attribute = browser.getAttribute(check_box, 'class');

                              if (list_row['value']=='checked'&&target_attribute.indexOf('ng-empty') > -1 ){
                                  browser.click(check_box);
                                  browser.pause(100);
                              }
                              if ((list_row['value']=='unchecked' || list_row['value']=='Off' || list_row['value'] == 'NA') && target_attribute.indexOf('ng-not-empty')>-1) {
                                  browser.click(check_box);
                                  browser.pause(100);
                              }if(list_row['value'] == 'Strat1'){
                                  if(target_attribute.indexOf('ng-empty') > -1){
                                      browser.click(check_box);
                                      browser.pause(100);
                                      }
                                      var item_value = list_row['value'];
                                      for(var item_index in stratifications){
                                          console.log('-----------------------------',stratifications[item_index]);
                                          if(stratifications[item_index].indexOf(item_value) != -1){
                                              var stratifications_settings = stratifications[item_index+2].split(',');
                                              console.log("stratifications_settings:",stratifications_settings);
                                              set_stratification(stratification_settings)
                                      }
                                  }
                              }
                              break;
                          case "scen.solve_for":
                          case "scen.forward_curve":
                          case "scen.loss_type":
                          case "scen.delinquency_type":
                          case "scen.repay_type":
                          case "scen.purchase_type":
                          case "scen.portfolio_yield_type":
                          case "scen.portfolio_loss_type":
                          case "scen.deferment_type":
                          case "scen.grace_type":
                          case "scen.forbear_type":
                          case "scen.interest_cap_freq":
                          case "scen.BB_type":
                          case "scen.reinvest_price_type":
                          case "scen.reinvest_pool":
                          case "scen.reinvest_rules":
                          case "scen.call_option":
                          case "scen.force_call":
                          case "scen.call_price_type":
                          case "scen.prepay_type":
                          case "scen.default_type":
                          case "scen.NOI_growth_rate_type":
                          case "scen.cap_rate_growth_rate_type":
                          case "scen.term_triggers_select_priority":
                          case "scen.maturity_trigger_select_priority":
                          case 'scen.servicer_basis':
                          case 'scen.servicer_type':
                              if (list_row['value'] == 'NA' || list_row['value'] == 'N/A'){
                                  break;
                                  }
                              var deal_CfSfpSelect = '(' + cashflow_xpath.dealCfSfpSelect.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
                              console.log(deal_CfSfpSelect);
                              browser.click(deal_CfSfpSelect);
                              browser.waitForVisible(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__',list_row['name']),self.waitDefault);
                              browser.click(cashflow_xpath.dealCfsDropDSelItem.replace('__NAME__',list_row['name']).replace('__ITEM__',list_row['value']));
                              console.log(browser.getValue(deal_CfSfpSelect));
                              // console.log(browser.getHTML(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__',list_row['name'])));
                              break;
                          case "analyticsCtrl.outputType":
                          case "analyticsCtrl.scenarioMethod":
                          case "analyticsCtrl.scenarioInput":
                              var deal_CfSfpSelect = cashflow_xpath.dealCfSfpSelect.replace('__NAME__',list_row['name']);
                              console.log(deal_CfSfpSelect);
                              browser.click(deal_CfSfpSelect);
                              browser.waitForVisible(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__',list_row['name']),self.waitDefault);
                              browser.click(cashflow_xpath.dealCfsDropDSelItem.replace('__NAME__',list_row['name']).replace('__ITEM__',list_row['value']));
                              break;
                          case "analyticsCtrl.scenarioMidPoint":
                          case "analyticsCtrl.scenarioStepSize":
                              var assumptions_input = cashflow_xpath.dealCfsInput.replace('__NAME__',list_row['name']);
                              browser.setValue(assumptions_input,list_row['value']);
                              console.log(browser.getValue(assumptions_input));
                              break;
                          case "scen.scenType":
                              var sentypeSelect = '(' + cashflow_xpath.mdSelect.replace('__NAME__',list_row['name'])  + ')[' + arg1 + ']';
                              browser.click(sentypeSelect);
                              var select_item = content_xpath.namedSelectItem.replace('__NAME__', list_row['value']);
                              console.log(select_item);
                              browser.waitForVisible(select_item,self.waitDefault);
                              browser.click(select_item);
                              break;
                          // // case "scen.NOI_growth_rate_type":
                          // // case "scen.cap_rate_growth_rate_type":
                          // // case "scen.term_triggers_select_priority":
                          // // case "scen.maturity_trigger_select_priority":
                          // // case "scen.servicer_basis":
                          // case "scen.servicer_type":
                          // // case "scen.apply_loan_level_assumps":
                          //   // Select field of select ng-model
                          //   var assumptions_select = '(' + cashflow_xpath.dealCfsSelect.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
                          //   console.log(assumptions_select);
                          //   browser.selectByVisibleText(assumptions_select, list_row['value']);
                          //   console.log(browser.getText(assumptions_select));
                          // break;
                          case "scen.settle_date":
                          case "scen.prepay_rate":
                          case "scen.default_rate":
                          case "scen.loss_rate":
                          case "scen.delinquency_rate":
                          case "scen.adv_loss_rate":
                          case "scen.adv_lag_mon":
                          case "scen.repay_rate":
                          case "scen.purchase_rate":
                          case "scen.portfolio_yield_rate":
                          case "scen.portfolio_loss_rate":
                          case "scen.deferment_rate":
                          case "scen.grace_rate":
                          case "scen.forbear_rate":
                          case "scen.BB_utilization_rate":
                          case "scen.subsidy_payment_delay":
                          case "scen.SAP_payment_delay":
                          case "scen.prinLossSeverityPctNonPerf":
                          case "scen.rec_lag":
                          case "scen.alloc_mon":
                          case "scen.reinvest_price":
                          case "scen.reinvDefaultLockout":
                          case "scen.NOI_growth_rate":
                          case "scen.cap_rate_growth_rate":
                          case "scen.term_triggers_LTV_liquidate":
                          case "scen.term_triggers_LTV_months":
                          case "scen.term_triggers_LTV_loss":
                          case "scen.term_triggers_DSCR_liquidate":
                          case "scen.term_triggers_DSCR_months":
                          case "scen.term_triggers_DSCR_loss":
                          case "scen.maturity_trigger_LTV_payoff":
                          case "scen.maturity_trigger_LTV_liquidate":
                          case "scen.maturity_trigger_LTV_loss":
                          case "scen.maturity_trigger_LTV_extension":
                          case "scen.maturity_trigger_LTV_end_of_extension_liq_or_payoff":
                          case "scen.maturity_trigger_LTV_end_of_extension_loss":
                          case "scen.maturity_trigger_DY_payoff":
                          case "scen.maturity_trigger_DY_liquidate":
                          case "scen.maturity_trigger_DY_loss":
                          case "scen.maturity_trigger_DY_extension":
                          case "scen.maturity_trigger_DY_end_of_extension_liq_or_payoff":
                          case "scen.maturity_trigger_DY_end_of_extension_loss":
                          case "scen.servicer_rate":
                          case "scen.call_date":
                          case "scen.reinvest_spread":
                          case "scen.reinvest_term":
                          case "scen.call_price":
                              //Input field with ng-model
                              if (list_row['value'] == 'NA' || list_row['value'] == 'N/A' || list_row['value'] == ''){
                                  break;
                              }else {
                                  var assumptions_input = '(' + cashflow_xpath.dealCfsInput.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
                                  browser.setValue(assumptions_input,list_row['value']);
                                  console.log("has set " + list_row['name'] + " to " + list_row['value']);
                                  console.log(browser.getValue(assumptions_input));
                                  break;
                              }
                      }
                  });
              }
                this.scenario_list = scenario_list;
          })
}

