 //Then_I_run_deal cashflows_and_should_see_cashflow_result_within_#_minutes.js
module.exports = function(){ 
      this.Then(/^I run deal cashflows and should see cashflow result within "([^"]*)" minutes for yield and irr setting$/, function (arg1) {
         // Write code here that turns the phrase above into concrete actions


         var timeOut = arg1*60*1000;
         const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
         this.browser_session.waitForResource(browser,cashflow_xpath.dealCfsAssumptions);
         browser.getLocationInView(cashflow_xpath.runYieldCashflow);
         browser.click(cashflow_xpath.runYieldCashflow);
         try {
             browser.waitForExist(cashflow_xpath.dealCfsRunprogressBar,this.waitDefault);
             browser.waitForVisible(cashflow_xpath.dealCfsRunprogressBar,this.waitDefault);
             this.browser_session.waitForLoading(browser,cashflow_xpath.dealCfsRunprogressBar,1000,timeOut);
             browser.waitForVisible(cashflow_xpath.dealcfsCashflowRusult,this.waitDefault);
         }catch (e) {
             console.log(e);
             console.log("wait for second time as the running bar does not visible");
             browser.waitForExist(cashflow_xpath.dealCfsRunprogressBar,this.waitDefault);
             browser.waitForVisible(cashflow_xpath.dealCfsRunprogressBar,this.waitDefault);
             this.browser_session.waitForLoading(browser,cashflow_xpath.dealCfsRunprogressBar,1000,timeOut);
             browser.waitForVisible(cashflow_xpath.dealcfsCashflowRusult,timeOut);
         }
         expect(browser.isVisible(cashflow_xpath.dealCfsResultprogressBar)).toBe(false,'dealCfsResultprogressBar still show');

             // it will check if the element is not visible every 500ms,until fulfill the condition or timeout
             // browser.waitUntil(function () {
             //     return browser.isVisible(cashflow_xpath.dealCfsResultprogressBar) === false
             // },timeOut,'dealCfsResultprogressBar still show after ' + arg1 + ' minutes');
       }); 
};