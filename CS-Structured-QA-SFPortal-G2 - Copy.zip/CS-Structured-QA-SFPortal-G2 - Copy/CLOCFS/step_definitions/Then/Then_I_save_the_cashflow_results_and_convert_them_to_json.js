//  Then_I_save_the_cashflow_results_and_convert_them_to_json.js
module.exports = function () {
    this.Then(/^I save the cashflow results and convert them to json$/,
        {timeout: process.env.StepTimeoutInMS * 10},
        function (table) {
            this.browser_session.waitForResource(browser);
            var fs = require("fs");
            const cashflow_xpath = this.xpath_lib.xpathRequire("cashflow_xpath");
            const content_xpath = this.xpath_lib.xpathRequire("content_xpath");
            var cashflow_res = {};
            var run_deal_request_flag = table.hashes()[0]["run_deal_request"];
            var myTable = "(" + cashflow_xpath.dealcfsCashflowRusult + ")";
            var mySelectCaret_xpath;
            var panelName = "Results";
            var myPanel = content_xpath.titledSectionLowercase.replace("__TITLE__", panelName.toLowerCase());
            var cashflow_type_list = ["Tranche Flows", "Collateral Flows", "Fees", "Tests", "Accounts"];
            // var cashflow_type_list = ["Tranche Flows","Collateral Flows"];
            var scenario_list_xpath = myPanel + content_xpath.named_mdSelectIcon2.replace("__NAME__", "analyticsCtrl.selectedScen");
            var scenario_list = this.scenario_list;
            var scenario_list_length = scenario_list.length;
            var scenarios_used = this.scenarios_used;
            console.log('this.scenario_used:', scenarios_used);

            //  defined the write function
            var export_res = function (file_name, file_path, file_content, file_type) {
                var myDate = new Date();
                var month = myDate.getMonth() + 1;
                var day = myDate.getDate();
                var today = '0' + month + day;
                file_name = file_name + '_' + today + '.' + file_type;
                if (file_type == 'json') {
                    var data_json = JSON.stringify(file_content);
                } else {
                    var data_json = file_content;
                }

                if (fs.existsSync(file_path)) {
                    console.log(file_path + ' exist!')
                } else {
                    fs.mkdir(file_path, function (err) {
                        if (err) {
                            throw err;
                        }
                        console.log('make dir success.');
                    });
                }
                // console.log("--------------------------cash flow---------------------------------",casgflow_json);
                fs.writeFile(file_path + '/' + file_name, data_json, {flag: "w"}, function (err) {
                    if (err) {
                        console.log(file_name + " saved failed!");
                        return console.log(err);
                    } else {
                        console.log(file_name + " saved successfully!");
                    }

                })
            };

            //  select all the scenario we run
            for (var scen_index = 1; scen_index <= scenario_list_length; scen_index++) {
                var sfwdealID;
                //  traverse the cash flow type list which we defined before
                for (var index in cashflow_type_list) {
                    //  console.log(cashflow_type_list[index]);
                    cashflow_res[cashflow_type_list[index]] = [];
                    mySelectCaret_xpath = myPanel + content_xpath.named_mdSelectIcon2.replace("__NAME__", "analyticsCtrl.cashflow_type");
                    console.log("click try: " + mySelectCaret_xpath);
                    browser.click(mySelectCaret_xpath);
                    var select_item = content_xpath.namedSelectItem.replace("__NAME__", cashflow_type_list[index]);
                    console.log("select_item:", select_item);
                    this.browser_session.waitForResource(browser, select_item);
                    browser.click(select_item);

                    var scenario_id = scenario_list[scen_index - 1]["scenario_id"];
                    var settles_date = scenarios_used[scenario_id][4];
                    if (scenario_list_length != 1) {
                        browser.click(scenario_list_xpath);
                        var select_item = "(" + content_xpath.namedSelectItem.replace("__NAME__", "") + ")[" + scen_index + "]";
                        console.log("select_scen:", select_item);
                        this.browser_session.waitForResource(browser, select_item);
                        browser.click(select_item);
                    }
                    //  make sure could catch all rows once,change show items number to 500 directly
                    var next_page_xpath = myTable + '// a[contains(@ng-click,"selectPage(page + 1,")]';
                    console.log("next_page:", next_page_xpath);
                    if (browser.isVisible(next_page_xpath)) {
                        var display_item_number_xpath = myTable + '// md-select[contains(@ng-model,"ctrl.model.numPerPage")]';
                        console.log("display_item_number_xpath:", display_item_number_xpath);
                        this.browser_session.waitForResource(browser, display_item_number_xpath);
                        browser.click(display_item_number_xpath);
                        var selectNumber = '// md-select-menu/parent::div[@aria-hidden="false"]// *[contains(@class,"md-text") and contains(normalize-space(),"500")]';
                        try {
                            browser.click(selectNumber);
                        } catch (err) {
                            console.log(err);
                            console.log("seconde click!");
                            browser.click(selectNumber);
                        }
                    }

                    var tranche_select_box = content_xpath.titledSectionLowercase.replace("__TITLE__", panelName.toLowerCase()) + "// select";
                    var tranche_select_xpath = tranche_select_box + "// option";
                    console.log("tranche_select_xpath:", tranche_select_xpath);
                    var item = {"perfsummary": {},};

                    if (cashflow_type_list[index] == "Tranche Flows") {
                        var cashflow_type = cashflow_type_list[index];
                        var tranche_count = browser.selectorExecute(tranche_select_xpath, function (selects) {
                            return selects.length;
                        });
                        myTable = "(" + cashflow_xpath.dealcfsCashflowRusult + ")";
                        console.log("tranche_count:", tranche_count);
                        for (var tranche_index = 0; tranche_index < tranche_count; tranche_index++) {
                            //  reset the item object for each tranche
                            item = {"perfsummary": {},};
                            //  in case can get all rows once
                            if (browser.isVisible(next_page_xpath)) {
                                var display_item_number_xpath = myTable + '// md-select[contains(@ng-model,"ctrl.model.numPerPage")]';
                                console.log("display_item_number_xpath:", display_item_number_xpath);
                                browser.waitForVisible(display_item_number_xpath, this.waitDefault);
                                browser.click(display_item_number_xpath);
                                var selectNumber = '// md-select-menu/parent::div[@aria-hidden="false"]// *[contains(@class,"md-text") and contains(normalize-space(),"500")]';
                                try {
                                    browser.click(selectNumber);
                                } catch (err) {
                                    console.log(err);
                                    console.log("seconde click!");
                                    browser.click(selectNumber);
                                }
                            }
                            // select tranche
                            browser.selectByIndex(tranche_select_box, tranche_index);
                            var tranche_name = browser.getValue(tranche_select_box);
                            sfwdealID = tranche_name.split('.')[0];
                            var class_name = tranche_name.split('.')[1];
                            console.log("current_tranche_name:", tranche_name);
                            this.browser_session.waitForResource(browser, myTable, 200);
                            var table_text = this.browser_session.getTableTextCFS(browser, myTable);
                            item["perfsummary"]["tranche_name"] = tranche_name;
                            item["perfsummary"]["scenario_id"] = scenario_id;
                            item["perfsummary"]["class"] = class_name;
                            item["perfsummary"]["settles_date"] = settles_date;
                            item["cashflows"] = table_text;
                            cashflow_res[cashflow_type].push(item);
                        }

                    } else if (cashflow_type_list[index] == "Tests" || cashflow_type_list[index] == "Accounts" || cashflow_type_list[index] == "Deal Flows") {
                        myTable = '// div[contains(@ng-if,"[cash.selectedIdentifier].length > 0")]// table';
                        var table_length = browser.elements(myTable).value.length;
                        //  console.log("TestsHeader_length:",table_length);
                        for (var i = 1; i <= table_length; i++) {
                            myTable = '// div[contains(@ng-if,"[cash.selectedIdentifier].length > 0")]// table' + '[' + i + ']';

                            var table_text = this.browser_session.getTableTextCFS(browser, myTable);
                            var TestsHeader = this.browser_session.getAnormalTableRowHeader(browser, myTable);
                            //  console.log('table_text:',table_text);
                            item["perfsummary"]["scenario_id"] = scenario_id;
                            item["perfsummary"]["settles_date"] = settles_date;
                            console.log("TestsHeader:", TestsHeader);
                            item[TestsHeader] = table_text;
                        }
                        cashflow_res[cashflow_type_list[index]].push(item);
                        //  console.log('cashflow_res[cashflow_type_list[index]]:',cashflow_res[cashflow_type_list[index]]);
                        //  add Month and Date to all the item of anormal table values
                        for (var keys in cashflow_res[cashflow_type_list[index]][scen_index - 1]) {
                            console.log('keys:', keys);
                            if (keys != ' :: ' && keys != 'perfsummary') {
                                if (keys == 'Interest Diversion Test') {
                                    try {
                                        for (var i in item[TestsHeader]) {
                                            //  console.log(cashflow_res[cashflow_type_list[index]][scen_index - 1][keys]);
                                            cashflow_res[cashflow_type_list[index]][scen_index - 1][keys][i]['Month'] = cashflow_res[cashflow_type_list[index]][scen_index - 1][' :: '][i]['Month'];
                                            cashflow_res[cashflow_type_list[index]][scen_index - 1][keys][i]['Date'] = cashflow_res[cashflow_type_list[index]][scen_index - 1][' :: '][i]['Date'];
                                        }
                                    } catch (e) {
                                        console.log(e)
                                    }
                                } else {
                                    for (var i in item[TestsHeader]) {
                                        //  console.log(cashflow_res[cashflow_type_list[index]][scen_index - 1][keys]);
                                        cashflow_res[cashflow_type_list[index]][scen_index - 1][keys][i]['Month'] = cashflow_res[cashflow_type_list[index]][scen_index - 1][' :: '][i]['Month'];
                                        cashflow_res[cashflow_type_list[index]][scen_index - 1][keys][i]['Date'] = cashflow_res[cashflow_type_list[index]][scen_index - 1][' :: '][i]['Date'];
                                    }
                                }
                            }
                        }
                        delete cashflow_res[cashflow_type_list[index]][0][' :: ']
                    } else {
                        console.log("myTable:", myTable);
                        var table_text = this.browser_session.getTableTextCFS(browser, myTable);
                        //  console.log(table_text);
                        item["perfsummary"]["scenario_id"] = scenario_id;
                        item["perfsummary"]["settles_date"] = settles_date;
                        item["cashflows"] = table_text;
                        cashflow_res[cashflow_type_list[index]] = item;
                    }
                }
                var file_name = scenario_id + '_' + sfwdealID + '_' + settles_date;
                var file_path = '../../../cashflow_res';
                // var file_path = 'C:\\Users\\HuBa\\Projects\\CS-Structured-QA-SFPortal-G2\\CLOCFS\\Deal\\cashflow_res' + '\\';
                export_res(file_name, file_path, cashflow_res, 'json');

                if (process.env.RunDealRequest == 'True' && scenario_list_length == 1) {
                    var run_deal_request_xpath = '//div[contains(@ng-repeat,"item in analyticsCtrl.debugOutput track by")][2]';
                    var toggle_output_button = '//span[contains(text(),"Toggle Debug Output")]';
                    try {
                        if (browser.isVisible(toggle_output_button)) {
                            browser.click(toggle_output_button);
                            browser.waitForVisible(run_deal_request_xpath, this.waitDefault);
                        } else {
                            console.log('click toggle output button failed')
                        }
                    } catch (e) {
                        console.log('wait for run deal request');
                        browser.waitForVisible(run_deal_request_xpath, this.waitDefault);
                    }
                    var request_xml = browser.getText(run_deal_request_xpath);
                    file_name = file_name + '_request';
                    // console.log('request_xml:',request_xml);
                    var run_deal_request = request_xml.substring(request_xml.indexOf("<runDealSettings"), request_xml.indexOf("</RundealRequest>"));
                    file_path = '../../../cashflow_res' + '/run_deal_request';
                    // file_path ='C:\\Users\\HuBa\\Projects\\CS-Structured-QA-SFPortal-G2\\CLOCFS\\Deal\\cashflow_res\\run_deal_request\\';
                    export_res(file_name, file_path, run_deal_request, 'xml');
                    // console.log('run_deal_request:',run_deal_request);
                }
            }

        });
};

