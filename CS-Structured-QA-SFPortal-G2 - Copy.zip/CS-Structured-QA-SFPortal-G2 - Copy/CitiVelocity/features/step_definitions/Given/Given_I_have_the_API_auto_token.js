// Recommended filename: Given_I_have_the_API_auth_token.js
module.exports = function() {
  this.Given(/^I have the API auth token$/, {timeout: process.env.StepTimeoutInMS}, function() {
    var username = this.test_user;

    if (!(this.license && this.license.username == this.username)) {
      var license = this.api_session.getLicense(username);
      this.license = license;
    }
    console.log("test_user: " + username);
    console.log("token_user: " + this.license.username);
    console.log("auth_token: " + this.license.token);
    // console.log(browser.log('browser'));
  });
};