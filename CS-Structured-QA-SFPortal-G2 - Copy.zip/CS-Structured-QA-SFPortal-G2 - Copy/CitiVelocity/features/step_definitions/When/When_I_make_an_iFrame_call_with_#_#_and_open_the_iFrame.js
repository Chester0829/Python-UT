// Recommended filename: When_I_make_an_iFrame_call_with_#_#_and_open_the_iFrame.js
module.exports = function() {
  this.When(/^I make an iFrame call with (citi-deal|citi-manager|citi-py) "([^"]*)" and open the iFrame$/, {timeout: process.env.StepTimeoutInMS}, function(type, identifier) {
    var iFrame_content = this.api_session.getIFrame(type, identifier, this.license);
    console.log(iFrame_content)
    var iFrame_filePath = this.file_session.writeFile(iFrame_content, null, null, 'html');
    var iFrame_fileUrl = 'file://' + iFrame_filePath;

    this.iFrame_type = type;
    this.iFrame_identifier = identifier;
    browser.url(iFrame_fileUrl);
    browser.pause(1000);
  });
}
