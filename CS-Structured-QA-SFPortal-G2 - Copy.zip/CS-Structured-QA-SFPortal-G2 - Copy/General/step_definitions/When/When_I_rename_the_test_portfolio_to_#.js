//// Recommended filename: When_I_rename_the_test_portfolio_to_#.js
module.exports = function() {
	this.When(/^I rename the test portfolio to "([^"]*)"$/, function (newPortfolioName) {
    const dashboardPage_xpath = this.xpath_lib.xpathRequire('dashboardPage_xpath');
    const createPortfolioPage_xpath = this.xpath_lib.xpathRequire('createPortfolioPage_xpath');

    var portfolioName_input = createPortfolioPage_xpath.portfolioName_input
    var saveChanges_button = createPortfolioPage_xpath.saveChanges_button;
    var create_success_message = createPortfolioPage_xpath.successfullyCreatedPortfolio_message;
    var new_name = newPortfolioName.replace('%%', (new Date()).toISOString());

    browser.clearElement(portfolioName_input);
    browser.pause(1000);
    browser.setValue(portfolioName_input, new_name)
    browser.click(saveChanges_button);
    browser.pause(1000);
    // wait for success message to show and disappear
    browser.waitForVisible(create_success_message, this.waitDefault*2);
    browser.waitForVisible(create_success_message, this.waitDefault, true);
    this.portfolio = new_name;
	});
}