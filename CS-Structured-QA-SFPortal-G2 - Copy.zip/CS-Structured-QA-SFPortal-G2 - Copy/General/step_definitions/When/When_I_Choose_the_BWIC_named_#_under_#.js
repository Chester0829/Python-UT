//When_I_choose_the_BWIC_named_#_under_#.js
module.exports = function() {
  this.When(/^I choose the BWIC named "([^"]*)" under "([^"]*)"$/,{timeout: process.env.StepTimeoutInMS*5}, function (itemName,labelName) {
    // Write the automation code here
    // pending();
    this.browser_session.waitForResource(browser);
    const bwic_xpath = this.xpath_lib.xpathRequire('bwic_xpath');

    this.bwicName = itemName;
    var item = bwic_xpath.bwicItem.replace('__LABEL__',labelName).replace('__ITEM__',itemName);

    try{
        browser.waitForVisible(item,this.waitDefault*2);
        browser.touchScroll(browser.element(item).value['ELEMENT'],0,200);
        // browser.getLocationInView(item)
      }
      catch(error){
        browser.refresh();
        var category = bwic_xpath.expendIcon.replace('__LABEL__',labelName);
        // console.log(category);
        browser.waitForVisible(category,this.waitDefault);
        browser.click(category);  
      }
      browser.waitForVisible(item,this.waitDefault*2);
      console.log(item);
      browser.touchScroll(browser.element(item).value['ELEMENT'],0,200);
      browser.click(item);   
  });
};
