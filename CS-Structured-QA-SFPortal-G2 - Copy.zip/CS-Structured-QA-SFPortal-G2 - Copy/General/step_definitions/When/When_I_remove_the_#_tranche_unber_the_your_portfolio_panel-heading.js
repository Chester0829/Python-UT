// Recommended filename: When_I_remove_the_#_tranche_unber_the_your_portfolio_panel-heading.js
module.exports = function() {
    this.When(/^I remove the (first|second|third|fourth|fifth|sixth|seventh|eighth|nineth|tenth) tranche under the Your Portfolio panel-heading$/, function (numOfCol) {
      // Write the automation code here
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      const createPortfolioPage_xpath = this.xpath_lib.xpathRequire('createPortfolioPage_xpath');
      var yourPortfolio_table = createPortfolioPage_xpath.yourPortfolio_table;
      
      var nth_index;
      switch (numOfCol) {
          case "first":
              nth_index = 1;
              break;
          case "second":
              nth_index = 2;
              break;
          case "third":
              nth_index = 3;
              break;
           case "fourth":
              nth_index = 4;
              break;
          case "fifth":
              nth_index = 5;
              break;
          case "sixth":
              nth_index = 6;
              break;
          case "seventh":
              nth_index = 7;
              break;
          case "eighth":
              nth_index = 8;
              break;
          case "nineth":
              nth_index = 9;
              break;
          case "tenth":
              nth_index = 10;
              break;
          default:
              nth_index = 1;
              break;
      };
    
      var column_xpath = yourPortfolio_table + '/tbody/tr[' + nth_index + ']//button';
      try{
        browser.waitForVisible(column_xpath,this.wait5);
      }catch(e){
        console.log('try again...');
        column_xpath = content_xpath.titledSectionLowercase.replace('__TITLE__', 'your portfolio') + '//table/tbody/tr[' + nth_index + ']//button';
      }
      console.log(column_xpath);
      browser.click(column_xpath);
      this.browser_session.waitForResource(browser);
      this.browser_session.waitForLoading(browser);
    });
  };
  