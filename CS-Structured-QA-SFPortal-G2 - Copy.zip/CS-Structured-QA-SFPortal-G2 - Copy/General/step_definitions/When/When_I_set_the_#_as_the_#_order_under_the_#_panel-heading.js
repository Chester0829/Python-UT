// When I set the "Book Price" as the first order under the "Pricing Assumptions" panel-heading
module.exports = function() {
	this.When(/^I set the "([^"]*)" as the (first) order under the "([^"]*)" panel\-heading$/, function (value,order,widgetName) {
	  this.browser_session.waitForResource(browser);
	  this.browser_session.waitForLoading(browser);

	  browser.waitForVisible('//*[contains(@id,"dragtarget")]',this.waitDefault);
	  var priceList = browser.getValue('//*[contains(@id,"dragtarget")]');
	  console.log(priceList);
	  // console.log(value);
	  
	  var allValues = ['Book Price','MA EMV','Par(100)'];
	  var index = priceList.indexOf(value);
	  // console.log(index);
	  var xpath = '//*[@id="dragtarget__INDEX__"]';
	  // Book Price :: MA EMV :: Par(100)
	  var str = 'document.getElementById("__ID__").removeAttribute("readonly")';

	  switch(index){
	  	case 0:
	  		break; 
	  	case 1:
	  		break;
	  	case 2:
	  		// remove readonly
	  		browser.execute(str.replace('__ID__','dragtarget3'));
	  		browser.execute(str.replace('__ID__','dragtarget1'));
	  		// set value
	  		browser.setValue(xpath.replace('__INDEX__',1),priceList[2]);
	  		browser.setValue(xpath.replace('__INDEX__',3),priceList[0]);
	  		break;
	  }

		expect(browser.getValue('//*[contains(@id,"dragtarget")]').sort().join('_')).toEqual(priceList.sort().join('_'));


 });
}