//When_I_call_#_Composition_Asset_Characteristics_PI_from_both_#_and_#_by_using_the_following_settings.js
module.exports = function() {
this.When(/^I call "([^"]*)" Composition Asset Characteristics API from both ([^"]*) and ([^"]*) by using the following settings$/, function (calloption, env1,env2, table) {
         // Write code here that turns the phrase above into concrete actions
         this.expected_row_list = table.hashes();
         var env1_fxRates = this.api_session.getFxRates(this.env1_license);
         var env2_fxRates = this.api_session.getFxRates(this.env2_license,this.env2_api_url);
          this.env1=env1;
          this.env2=env2;
         console.log(this.env1);
         console.log(this.env2);
         this.manager_name = calloption;
         var searchStr = calloption;
         var assetClasses = [];
         var in_reinvest = '';
         var is_terminated = '';
         var is_acquired = '';
         var include_affiliate = 0;
         var include_sub_advisor = 0;
         var vintageMin = '';
         var vintageMax = '';
         var self = this;
         var all_managers = [this.manager_name,this.manager_name];
         this.expected_row_list.forEach(function(expected_row, index) {
          // console.log(expected_row.item);
          switch(expected_row.item){
            case "BSL":
              if(expected_row.status == "checked"){
              assetClasses.push("CDO - Balance Sheet - Cash Flow");
              assetClasses.push("CDO - High Yield CLO-Arbitrage Cash Flow");
            }
            break;
            case "SME":
              if(expected_row.status == "checked"){
              assetClasses.push("CDO - Small and Middle Market CLO");
            }
            break;
            case "CBO":
            if(expected_row.status == "checked"){
              assetClasses.push("CDO - High Yield CBO-Arbitrage Cash Flow");
              assetClasses.push("CDO - Investment Grade CBO");
            }
              break;
            case "CDO":
            if(expected_row.status == "checked"){
              assetClasses.push("CDO - Cash ABS - High Grade");
              assetClasses.push("CDO - Cash ABS - Mezzanine");
              assetClasses.push("CDO - Emerging Markets");
              assetClasses.push("CDO - Hybrid - High Grade");
              assetClasses.push("CDO - Hybrid - Mezzanine");
              assetClasses.push("CDO - Market Value");
              assetClasses.push("CDO - Other");
              assetClasses.push("CDO - Project Finance");
              assetClasses.push("CDO - Repackaged Securities");
              assetClasses.push("CDO - Repackaged Securities - CLO");
              assetClasses.push("CDO - Resecuritization");
              assetClasses.push("CDO - Resecuritization - Cash Flow");
              assetClasses.push("CDO - Balance Sheet - Cash Flow");
            }
              break;
            case "Exclude Amortizing Deals":
              if(expected_row.status == "checked"){
                in_reinvest = "Yes";
              }else{
                in_reinvest = "No";
              }
              break;
            case "Exclude Acquired Deals":
              if(expected_row.status == "checked"){
                is_acquired = "No";
              }else{
                is_acquired = "Yes";
              }
              break;
            case "Exclude Terminated Deals":
              if(expected_row.status == "checked"){
                is_terminated = "No";
              }else{
                is_terminated = "Yes";
              }
              break;
            case "Include Affiliated Managers":
              if(expected_row.status == "checked"){
                include_affiliate = 1;
              }else{
                include_affiliate = 0;
              }
              break;
            case "Include Deals this Manager is Sub-Advisor to": 
              if(expected_row.status == "checked"){
                include_sub_advisor = 1;
              }else{
                include_sub_advisor = 0;
              }
              break;
            case "Vintage from":
              if(expected_row.status=="today"){
                vintageMin = self.time_lib.getTime("yyyy-mm-dd");
              }else{
                vintageMin = expected_row.status;
              }
              break;
            case "Vintage to":
              if(expected_row.status=="today"){
                vintageMax = self.time_lib.getTime("yyyy-mm-dd");
              }else{
                vintageMax = expected_row.status;
              }
              break;
          }
         });
         // console.log("searchStr:"+searchStr);
         // console.log("assetClasses:"+assetClasses);
         // console.log("in_reinvest:"+in_reinvest);
         // console.log("is_terminated:"+is_terminated);
         // console.log("include_affiliate:"+include_affiliate);
         // console.log("include_sub_advisor:"+include_sub_advisor);
         console.log("vintageMin:"+vintageMin);
         console.log("vintageMax:"+vintageMax);

         ///////////////////////////////////////////////////ENV 1 //////////////////////////////////////
         this.env1_manager_report = this.api_session.getManagersCompositionReport(this.env1_license,"GENERAL",searchStr,assetClasses,is_terminated,in_reinvest,is_acquired,vintageMin,vintageMax,include_sub_advisor,include_affiliate,all_managers,env1_fxRates);
         // console.log(this.env1_manager_report);


        // ///////////////////////////////////////////////////ENV 2 //////////////////////////////////////
        this.env2_manager_report = this.api_session.getManagersCompositionReport(this.env2_license,"GENERAL",searchStr,assetClasses,is_terminated,in_reinvest,is_acquired,vintageMin,vintageMax,include_sub_advisor,include_affiliate,all_managers,env2_fxRates,this.env2_api_url);
        // console.log(this.env2_manager_report);


    });
};