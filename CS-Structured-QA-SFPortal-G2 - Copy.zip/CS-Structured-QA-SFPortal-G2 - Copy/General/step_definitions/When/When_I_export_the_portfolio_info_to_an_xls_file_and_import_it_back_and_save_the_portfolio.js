//// Recommended filename: When_I_export_the_portfolio_info_to_an_xls_file_and_import_it_back_and_save_the_portfolio.js
module.exports = function() {
	this.When(/^I export the portfolio info to an xls file and import it back and save the portfolio$/, function () {
    const dashboardPage_xpath = this.xpath_lib.xpathRequire('dashboardPage_xpath');
    const createPortfolioPage_xpath = this.xpath_lib.xpathRequire('createPortfolioPage_xpath');

    var chooseUploadFile_button = createPortfolioPage_xpath.chooseUploadFile_button;
    var exportXLSX_button = createPortfolioPage_xpath.exportXLSX_button;
    var importXLSX_button = createPortfolioPage_xpath.importXLSX_button;
    var saveChanges_button = createPortfolioPage_xpath.saveChanges_button;
    var clearPortfolio_button = createPortfolioPage_xpath.clearPortfolio_button;
    var create_success_message = createPortfolioPage_xpath.successfullyCreatedPortfolio_message;
    var downloadFile_fullName = 'CreatePortfolio.xlsx';
    var downloadFile_name = downloadFile_fullName.split('.')[0];
    var downloadFile_ext = downloadFile_fullName.split('.').pop();


    // delete files of the same name
    this.file_session.deleteFiles(downloadFile_name);

    // export file
    browser.waitForVisible(exportXLSX_button, this.waitDefault);
    browser.click(exportXLSX_button);
    var downloaded_file = this.file_session.waitForDownload(browser, downloadFile_name, downloadFile_ext, 10*1000);
    console.log('downloaded: ' + downloaded_file);

    // if running locally download file full name include local download path
    if (process.env.RDPHOST == null || process.env.RDPHOST != '') {
      const myDownloadPathLocal = '/tmp/download_' + process.env.DISPLAY.substr(1);
      downloadFile_fullName = myDownloadPathLocal + '/' + downloadFile_fullName;
    }

    // import file from my download path
    browser.click(chooseUploadFile_button);
    switch(process.env.PLATFORM) {
      case 'Linux':
      case 'Win7':
          this.robot_session.typeString(downloadFile_fullName);
          browser.pause(3000);
          this.robot_session.keyTap();
          browser.pause(3000);
          this.robot_session.clickImage(null, 'FM_OpenButton.png');
          browser.pause(2000);
        // if (this.robot_session.findImage(null, 'FM_DownloadFolder_unselected.png')) {
        //   this.robot_session.clickImage(null, 'FM_DownloadFolder_unselected.png')
        // };
        // if (this.robot_session.findImage(null, 'FM_DownloadFolder_selected.png')) {
          
        // };
        break;
    }
    
    // import file and save portfolio
    browser.click(importXLSX_button);
    browser.pause(5000);
    browser.click(saveChanges_button);
    browser.pause(1000);
    // wait for success message to show and disappear
    browser.waitForVisible(create_success_message, this.waitDefault*2);
    browser.waitForVisible(create_success_message, this.waitDefault, true);
	});
}