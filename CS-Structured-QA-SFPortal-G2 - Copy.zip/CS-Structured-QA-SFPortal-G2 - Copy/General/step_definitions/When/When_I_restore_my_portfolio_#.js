// Recommended filename: When_I_restore_my_portfolio_#.js
module.exports = function() {
  this.When(/^I restore my portfolio "([^"]*)"$/, function (portfolioName) {
    const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    var portfoliosSection = content_xpath.titledSection.replace('__TITLE__', 'Portfolios');
    var dashboard_button = header_xpath.mainDashboard_button;
    var portfolioRestore_icon1 = '(' + content_xpath.portfolioRestore_icon + ')[1]';
    var successfullyRestoredPortfolio_message = content_xpath.successfullyRestoredPortfolio_message;
    var my_test_protfolio = portfolioName.includes('%%') ? this.portfolio : portfolioName;
    console.log('restore portfolio: ' + my_test_protfolio);
    var search_result;

    // exists in my portfolio restoration list
    var portfoliorestoration_url = this.test_url + this.url_lib.getTargetURL('settings', 'Portfolio Restoration');
    var portfolioRestoration_mdCard_xpath = content_xpath.titledPanel.replace('__TITLE__', 'Portfolio Restoration');
    var restorePortfolio_search_window = portfolioRestoration_mdCard_xpath + content_xpath.searchBox;
    browser.url(portfoliorestoration_url);
    console.log(portfolioRestoration_mdCard_xpath);
    browser.waitForVisible(portfolioRestoration_mdCard_xpath, this.waitDefault);
    browser.waitForVisible(restorePortfolio_search_window, this.waitDefault);
    console.log(restorePortfolio_search_window);
    browser.click(restorePortfolio_search_window);
    browser.pause(1000);
    console.log('clicked');
    browser.setValue(restorePortfolio_search_window, my_test_protfolio);
    browser.pause(1000);
    console.log('setValue');
    search_result = browser.getText(portfolioRestoration_mdCard_xpath);
    console.log(search_result);
    expect(search_result).toContain(my_test_protfolio);
    expect(search_result).not.toContain(this.noRecordFound_message);
    browser.click(portfolioRestore_icon1);
    browser.waitForVisible(successfullyRestoredPortfolio_message, this.waitDefault);
    browser.waitForVisible(successfullyRestoredPortfolio_message, this.waitDefault, true);
    // back to dashboard
    browser.click(dashboard_button);
    this.browser_session.waitForLoadingSection(browser, portfoliosSection);
  });
};
