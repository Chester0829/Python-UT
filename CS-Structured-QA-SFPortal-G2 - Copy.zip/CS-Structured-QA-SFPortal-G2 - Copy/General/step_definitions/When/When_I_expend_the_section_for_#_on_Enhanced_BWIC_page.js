//When_I_expend_the_section_for_#_on_Enhanced_BWIC_page.js
module.exports = function() {
  this.When(/^I expend the section for "([^"]*)" on Enhanced BWIC page$/, function (labelName) {
    // Write the automation code here
    // pending();
    this.browser_session.waitForResource(browser);
    const bwic_xpath = this.xpath_lib.xpathRequire('bwic_xpath');

    var category = bwic_xpath.expendIcon.replace('__LABEL__',labelName);
    // console.log(category);
    browser.waitForVisible(category,this.waitMax);
    browser.click(category);  
  });
};
