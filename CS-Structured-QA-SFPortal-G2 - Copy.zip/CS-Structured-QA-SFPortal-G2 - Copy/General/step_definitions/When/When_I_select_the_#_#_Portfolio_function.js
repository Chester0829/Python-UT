//// Recommended filename: When_I_select_the_#_#_Portfolio_function.js
module.exports = function() {
	this.When(/^I select the (create|edit) (Structured|Non\-Structured|Asset) Portfolio function$/, function (action, portfolioType) {
    const dashboardPage_xpath = this.xpath_lib.xpathRequire('dashboardPage_xpath');
    var myAssetTab_xpath;
    var portfolioEdit_icon;
    var create_portfolioType_link;
    var expected_url_path;
    switch (action) {
      case 'create':
        switch (portfolioType) {
          case 'Structured':
            create_portfolioType_link = dashboardPage_xpath.namedCreatePortfolio_link.replace('__NAME__', 'Structured Portfolio');
            expected_url_path = '/portfolio/create';
            break;
          case 'Asset':
            create_portfolioType_link = dashboardPage_xpath.namedCreatePortfolio_link.replace('__NAME__', 'Asset Portfolio');
            expected_url_path = '/portfolio/asset-create';
            break;
        }
        console.log(create_portfolioType_link);
        browser.waitForVisible(dashboardPage_xpath.createPortfolio_button, this.waitDefault);
        browser.click(dashboardPage_xpath.createPortfolio_button);
        browser.waitForVisible(create_portfolioType_link, this.waitDefault);
        browser.click(create_portfolioType_link);
        browser.pause(1000);
        this.browser_session.waitForLoading(browser, null, null, 5*1000);
        expect(browser.getUrl()).toContain(expected_url_path);
        break;
      case 'edit':
        switch (portfolioType) {
          case 'Structured':
            expected_url_path = '/portfolio/edit';
            break;
          case 'Asset':
            expected_url_path = '/portfolio/asset-edit';
            break;
        }
        myAssetTab_xpath = dashboardPage_xpath.namedPortfolioTypeTab1.replace('__NAME__', portfolioType);
        try{
            browser.waitForVisible(myAssetTab_xpath,this.wait5);
        }catch(e){
            console.log('try again...');
            myAssetTab_xpath = dashboardPage_xpath.namedPortfolioTypeTab.replace('__NAME__', portfolioType);
        }
        browser.click(myAssetTab_xpath);
        browser.pause(1000);
        portfolioEdit_icon = dashboardPage_xpath.portfolioEdit_icon;
        browser.click(portfolioEdit_icon);
        browser.pause(1000);
        expect(browser.getUrl()).toContain(expected_url_path);
        break;
    }
	});
}