// Recommended filename: Given_the_portfolio_name_#_does_not_exist_in_my_portfolios.js
module.exports = function() {
  this.Given(/^the portfolio "([^"]*)" does not exist in my portfolio list and portfolio restoration list$/, {timeout: process.env.StepTimeoutInMS*5},
    function (portfolioName) {
    const header_xpath = this.xpath_lib.xpathRequire('header_xpath');
    const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
    const dashboardPage_xpath = this.xpath_lib.xpathRequire('dashboardPage_xpath');
    var portfoliosSection = content_xpath.titledSection.replace('__TITLE__', 'Portfolios');
    var my_test_protfolio = portfolioName.replace('%%', (new Date()).toISOString());
    console.log(my_test_protfolio);
    this.portfolio = my_test_protfolio;
    var search_result;

    // does not exist in my portfolio list
    var dashboard_button = header_xpath.mainDashboard_button;
    var portfolio_search_window = dashboardPage_xpath.portfolioTableSearch_input;
    var portfolios_mdCard_xpath = dashboardPage_xpath.portfolios_mdCard
    browser.click(dashboard_button);
    browser.waitForVisible(portfolio_search_window, this.waitDefault);
    browser.click(portfolio_search_window);
    browser.pause(1000);
    browser.setValue(portfolio_search_window, my_test_protfolio);
    browser.pause(1000);
    search_result = browser.getText(portfolios_mdCard_xpath);
    expect(search_result).toContain(this.noRecordFound_message);

    // does not exist in my portfolio restoration list
    var portfoliorestoration_url = this.test_url + this.url_lib.getTargetURL('settings', 'Portfolio Restoration');
    var portfolioRestoration_mdCard_xpath = content_xpath.titledPanel.replace('__TITLE__', 'Portfolio Restoration');
    var restorePortfolio_search_window = portfolioRestoration_mdCard_xpath+ content_xpath.searchBox;
    browser.url(portfoliorestoration_url);
    console.log(portfolioRestoration_mdCard_xpath);
    browser.waitForVisible(portfolioRestoration_mdCard_xpath, this.waitDefault*5);
    browser.waitForVisible(restorePortfolio_search_window, this.waitDefault);
    console.log(restorePortfolio_search_window);
    browser.click(restorePortfolio_search_window);
    browser.pause(1000);
    console.log('clicked');
    browser.setValue(restorePortfolio_search_window, my_test_protfolio);
    browser.pause(1000);
    console.log('setValue');
    search_result = browser.getText(portfolioRestoration_mdCard_xpath);
    console.log(search_result);
    expect(search_result).toContain(this.noRecordFound_message);

    // back to dashboard
    browser.click(dashboard_button);
    this.browser_session.waitForLoadingSection(browser, portfoliosSection);
  });
};
