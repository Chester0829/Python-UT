// Recommended filename: Given_I_have_the_API_auth_token_both_#_and_#.js
const ProjectFullPath = process.env.ProjectFullPath || process.env.HOME + '/Projects/CS-Structured-QA-SFPortal-G2';
const World = require(ProjectFullPath + '/global/support/world').World();
module.exports = function() {
  this.Given(/^I have the API auth token both ([^"]*) and ([^"]*)$/, {timeout: process.env.StepTimeoutInMS}, function(env1,env2) {
    var username = this.test_user;

    var env1_license = this.api_session.getLicense(username);
    this.env1_license = env1_license;
    console.log("env1 test_user: " + username);
    console.log("env1 token_user: " + this.env1_license.username);
    console.log("env1 auth_token: " + this.env1_license.token);

    if(env2 == "PTC"){
      this.env2_config = require(ProjectFullPath + '/global/configs/staging-g2_default_config.js').test_config;
      this.env2_api_url = this.env2_config.api_url;
      var env2_license = this.api_session.getLicense(username,this.env2_api_url);
      this.env2_license = env2_license;
      console.log("env2 test_user: " + username);
      console.log("env2 token_user: " + this.env2_license.username);
      console.log("env2 auth_token: " + this.env2_license.token);
    }else{
      this.env2_license = this.env1_license;
      this.env2_api_url = World.api_url;
    }

  });
};