// Recommended filename:Then_I_should_see_#_under_section_#_on_Enhanced_BWIC_page.js
module.exports = function() {
  this.Then(/^I should see "([^"]*)" under section "([^"]*)" on Enhanced BWIC page$/, function (item, section) {

    const bwic_xpath = this.xpath_lib.xpathRequire('bwic_xpath');

    console.log(section);
    var searchItem = '(' + bwic_xpath.bwicItemForSearch.replace('__LABEL__',section) + ')[1]';
    console.log(searchItem);
    var searchName = browser.getText(searchItem);
    console.log(searchName);

    expect(searchName).toEqual(item);

  });
};
