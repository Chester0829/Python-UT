// Recommended filename: I_should_see_the_table_under_the_Your_Portfolio_panel-heading_to_#_the_following_table_row.js
module.exports = function() {
  this.Then(/^I should see the table under the Your Portfolio panel-heading to (contain|match) the following table row$/, function (action, table) {
    const my_regex_lib = this.regex_lib;
    var expected_row_list = table.hashes();
    var license = this.api_session.getLicense(this.test_user);
    var fxRates = this.api_session.getFxRates(license);
    var portfolio_id = this.api_session.getPortfolioInfo(this.portfolio, license).portfolioId;
    var portfolio_tranche_list = this.api_session.getTrancheListForPortfolio(portfolio_id, license, fxRates).investments;

    expected_row_list.forEach(function(expected_row, index) {
      var key = '';
      for(key in expected_row) {
        var expected_row_content = expected_row[key];
        var displayed_row_content = portfolio_tranche_list[index][key];
        console.log(key + ':' + expected_row_content + ' & ' + displayed_row_content);
        switch (action) {
          case 'contain':
            expect(displayed_row_content).toContain(expected_row_content);
            break;
          case 'match':
            expect(displayed_row_content).toMatch(my_regex_lib.replaceRegex(expected_row_content));
            break;
        };
      }
    });
  });
};
