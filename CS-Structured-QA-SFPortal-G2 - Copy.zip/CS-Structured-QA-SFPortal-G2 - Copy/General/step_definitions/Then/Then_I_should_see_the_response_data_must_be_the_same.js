// Recommended filename: Then_I_should_see_the_response_data_must_be_the_same.js
module.exports = function() {
  this.Then(/^I should see the response data must be the same$/, 
    function () {
      var reportSort = [
        'BSL',
        'Exclude Amortizing Deals',
        'Exclude Terminated Deals',
        'Include Affiliated Managers',
        'Include Deals this Manager is Sub-Advisor to',
        'SME',
        'CDO',
        'CBO',
        'Exclude Acquired Deals',
        '2001-01-01_today',
        '2010-01-01_2016-12-31'
      ];
      // console.log(this.manager_name);
      // console.log(this.expected_row_list);
      var setting = ['','','','','','','','',''];
      var vintage = [];
      for(var i=0;i<this.expected_row_list.length;i++){
        var item = this.expected_row_list[i]['item'];
        var status = this.expected_row_list[i]['status'];
        // setting.push(status);
        if(item.indexOf('Vintage') != -1){
          vintage.push(status);
        }else{
          setting[reportSort.indexOf(item) ] = status;
        }
      }
      setting.push(vintage.join('_'));
      // console.log(setting);
      var compareResult = this.file_session.managerTableCompare(this.env1_manager_report,this.env2_manager_report,this.env1,this.env2);
      console.log(compareResult);
      var filename = this.manager_name + '_' + setting.join(',') + '.csv';
      var isSame = this.file_session.createCSV(compareResult,filename);
      setting.splice(0,0,this.manager_name);
      setting.push(isSame == true ? 'Pass' : 'Fail');
      console.log(setting);
      var diffStr = [];
      if(!isSame){
        for(var key in compareResult){
          var entry = compareResult[key];
          if(entry.join().indexOf('Diff') != -1){
            diffStr.push(entry[0]+'\n');
            for(var i=0;i<entry.length;i++){
              if(entry[i].indexOf('Diff') != -1){
                diffStr.push(entry[i]);
              }
            }
            diffStr.push('------');
          }
        }
      }
      // this.file_session.setExcelColumn(setting);
      expect(isSame).toBe(true,diffStr);
    })
    
};