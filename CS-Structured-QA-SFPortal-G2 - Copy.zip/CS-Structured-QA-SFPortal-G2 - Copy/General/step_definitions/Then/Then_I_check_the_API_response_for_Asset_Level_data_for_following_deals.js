//Then_I_check_the_API_response_for_Asset_Level_data_for_deal_#s.js
module.exports = function() {
this.Then(/^I check the API response for Asset Level data for deal "([^"]*)"$/, function (dealkey) {
  //var dealkey = this.arrayforCLONewDeals[index]["deal_key"];
  //console.log(dealkey);
  
  var token = this.api_session.getLicense(this.test_user);
  this.token = token;
  var results = this.api_session.getDealAssetLevelInfo(this.token, dealkey);
  console.log(results['Response']);
  var results_len = results['Response']['Asset'].length;
  console.log(results_len);
  expect(results_len).toBeGreaterThan(0);
 });
}