//Then_I_should_see_the_#_value_display_under_the_#_panel-heading_should_be_#_in_file.js
module.exports = function() {
  this.When(/^I read scenarios from "([^"]*)" and load below scenario list to portfolio for "([^"]*)" asset class$/,
    {timeout: process.env.StepTimeoutInMS*100},
    function (filename,assetclass,table){
      this.scenarios_used = {};
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath'); 
      // this.browser_session.waitForResource(browser,cashflow_xpath.dealCfsAssumptions);
      // browser.getLocationInView(cashflow_xpath.dealCfsAssumptions);
      var assumption_div = content_xpath.assumptionsPanel;
      var set_size = this.set_size;
      var batchSize = this.batchSize;
      var self = this;
      var path = require('path');
      var filePath = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'ALLCFS', filename);
      this.assettype = assetclass;
      
      switch(assetclass){
        case "CLO":
          var content = this.file_session.readXlsxAsCsvString(filePath,0).split('\n');
          break;
        case "ABS": 
          var content = this.file_session.readXlsxAsCsvString(filePath,1).split('\n');
          break;
        case "AUTO": 
          var content = this.file_session.readXlsxAsCsvString(filePath,2).split('\n');
          break;
        case "CARDS": 
          var content = this.file_session.readXlsxAsCsvString(filePath,3).split('\n');
          break;
        case "SLABS": 
          var content = this.file_session.readXlsxAsCsvString(filePath,4).split('\n');
          break;
        case "RMBS": 
          var content = this.file_session.readXlsxAsCsvString(filePath,5).split('\n');
          break;
        case "CMBS": 
          var content = this.file_session.readXlsxAsCsvString(filePath,6).split('\n');
          break;
      }
      var stratifications = this.file_session.readXlsxAsCsvStrBysheetName(filePath,"Stratification").split('\n');
      console.log("stratifications:",stratifications);
      //console.log("stratifications:",stratifications);
      var scenario_list = table.hashes();
      var scenario_dict = {};
      var content_length = content.length;
      console.log(content_length);
      var scenario;

      if(assetclass=="CLO"){
        for(var i=23;i<content_length;i++){
          scenario = content[i].split(',');
          if(scenario[0] != ''){
              scenario_dict[scenario[0]] = scenario
          }
        }
      }
      else{
        for(var i=7;i<content_length;i++){
          scenario = content[i].split(',');
          if(scenario[2] != ''){
              scenario_dict[scenario[2]] = scenario
          }
        }
      }
     var set_stratification = function (stratification_settings) {
          // browser.click('//a[contains(text(),"Apply Stratification")]');
          browser.waitForVisible('//table[contains(@id,"watchlist")]',self.waitDefault);
          // add new rule
          browser.click("//*[contains(text(),'Add New Rule')]");
          var header_list = ['watch.type1','watch.min1','watch.max1','watch.type2','watch.min2','watch.max2','watch.type3','watch.min3','watch.max3','watch.prepayrate','watch.prepaytype','watch.defaultrate','watch.defaulttype','watch.defaultDate','watch.lossrate','watch.lossType','watch.lagmonths','watch.cccDateIn','watch.cccDateOut','watch.lossRate'];
          for (var i = 2; i < stratification_settings.length; i++) {
              var value = stratification_settings[i];
              var column = header_list[(i-2)];
              console.log('column: ' + column + ', value: ' + value);
              switch (column) {
                  // case 'watch.min2':
                  // case 'watch.max2':
                  case 'watch.type1':
                  case 'watch.type2':
                  case 'watch.type3':
                  case 'watch.prepaytype':
                  case 'watch.defaulttype':
                  case 'watch.lossType':
                  case 'item.adjustable':
                  case 'item.bankLoans':
                  case 'item.juniorSenior':
                  case 'item.country':
                  case 'item.rating':
                      if(value==''){
                        break; 
                      }
                      var mdSelect = cashflow_xpath.mdSelect.replace('__NAME__', column);
                      var tmp = browser.isVisible(mdSelect);
                      // need to filter true in tmp list ?
                      var mdSelectLen = Array.isArray(tmp) ? tmp.length : 1;
                      browser.pause(200);
                      if (value == 'disabled') {
                          var isDisable = browser.getAttribute('(' + mdSelect + ')[' + mdSelectLen + ']', 'disabled');
                          console.log('isDisable',isDisable);
                          expect(isDisable).toEqual(value);
                      } else {
                        console.log('click' + '(' + mdSelect + ')[' + mdSelectLen + ']');
                          browser.click('(' + mdSelect + ')[' + mdSelectLen + ']');
                          try {
                              var textXpath = cashflow_xpath.mdSelectMenu + '//*[text()="' + value + '"]';
                              var t = browser.isVisible(textXpath);
                              var textXpathLen = Array.isArray(t) ? t.length : 1;
                              browser.click('(' + textXpath + ')[' + textXpathLen + ']');
                          } catch (error) {
                              var textXpath = cashflow_xpath.mdSelectMenu2 + '//*[text()="' + value + '"]';
                              console.log('try more one time: ' + textXpath);
                              var t = browser.isVisible(textXpath);
                              var textXpathLen = Array.isArray(t) ? t.length : 1;
                              browser.click('(' + textXpath + ')[' + textXpathLen + ']');
                          }
                      }
                      break;
                  case 'watch.min1':
                  case 'watch.max1':
                  case 'watch.min2':
                  case 'watch.max2':
                  case 'watch.min3':
                  case 'watch.max3':
                  if(value==''){
                    break;
                  }
                  var divSelectMatch = '//*[@ng-model="' + column + '"]';
                  var tmp = browser.isVisible(divSelectMatch);
                  console.log(tmp);
                  var divSelectMatchLen = Array.isArray(tmp) ? tmp.length : 1;
                  browser.click('(' + divSelectMatch + ')[' + divSelectMatchLen + ']');
                  browser.pause(200);
                  var attribute = browser.getAttribute('(' + divSelectMatch + ')[' + divSelectMatchLen + ']'+'/ancestor::td','ng-if')
                  console.log('attribute',attribute) 
                  if(attribute.indexOf('price')>-1 || attribute.indexOf('loanx')>-1 || attribute.indexOf("!== 'moodysRating'")>-1){
                    var t = browser.isVisible(divSelectMatch);
                    console.log('2',t);
                    var inputLen = Array.isArray(t) ? t.length : 1;
                    console.log(inputLen);
                    console.log('(' + divSelectMatch + ')[' + inputLen + ']');
                        // browser.click('(' + divSelectMatch + ')[' + inputLen + ']');
                        browser.pause(1000);
                        browser.setValue('(' + divSelectMatch + ')[' + inputLen + ']', value);
                   }else if(attribute.indexOf('moodysRating')>-1 || attribute.indexOf('spRating')>-1 || attribute.indexOf('bankLoan')>-1 || attribute.indexOf('seniority')>-1){
                        // var selectDropDown = '//div[@aria-hidden="false"]//md-select-menu[@class="_md md-overflow"]//md-option[@aria-selected="false"]'
                        var selectDropDown = '//div[@aria-hidden="false"]/md-select-menu//md-option[@aria-selected="false"]';
                        var tmp = browser.isVisible('('+selectDropDown+')[1]');
                        console.log('tmp 2',tmp)
                        // if(tmp == false){
                        //   selectDropDown = '//md-option[@aria-selected="false"]//div[text()="Sr Sec"]/..'
                        // }
                        browser.pause(200);
                        console.log('element:'+selectDropDown+'//div[text()="'+ value + '"]');
                        browser.click(selectDropDown+'//div[text()="'+ value + '"]');
                    }else{
                        // var input = '//div[@ng-model="watch.min1"]//input[contains(@placeholder,"Select or search")]';
                        var t = browser.isVisible(divSelectMatch);
                        console.log(t);
                        var inputLen = Array.isArray(t) ? t.length : 1;
                        console.log(inputLen);
                        console.log('(' + divSelectMatch + ')[' + inputLen + ']');
                        browser.click('(' + divSelectMatch + ')[' + inputLen + ']');
                        browser.pause(1000);
                        browser.setValue('(' + divSelectMatch + ')[' + inputLen + ']//input[contains(@placeholder,"Select or search")]', value);
                        browser.waitForVisible('//*[@ng-model="' + column + '"]//ul[not (contains(@class,"ng-hide"))]//*[contains(text(),"' + value + '")]', self.waitDefault);
                        browser.click('//*[@ng-model="' + column + '"]//ul[not (contains(@class,"ng-hide"))]//*[contains(text(),"' + value + '")]');
                        // self.robot_session.keyTap();
                        // if (self.portfolio && browser.isVisible('(' + input + ')[' + inputLen + ']')) {
                        //   if (browser.isVisible('(' + input + ')[' + inputLen + ']')) {
                        //   browser.pause(500);
                        //   browser.click('(' + input + ')[' + inputLen + ']');
                        //   browser.waitForVisible('//div[@ng-model="watch.min1"]//ul[not (contains(@class,"ng-hide"))]//*[contains(text(),"' + value + '")]', self.waitDefault);
                        //   browser.click('//div[@ng-model="watch.min1"]//ul[not (contains(@class,"ng-hide"))]//*[contains(text(),"' + value + '")]');
                        //   // self.robot_session.keyTap();
                        // }

                    }
                      break;
                  // case 'watch.max1':
                  // case 'watch.max3':
                  // case 'watch.min3':
                  case 'watch.prepayrate':
                  case 'watch.defaultrate':
                  case 'watch.lossrate':
                  case 'watch.lagmonths':
                  case 'watch.defaultDate':
                  case 'watch.cccDateIn':
                  case 'watch.cccDateOut':
                  case 'watch.lossRate':
                      if(value==''){
                        break;
                      }
                      var sfpTextInput = cashflow_xpath.sfpTextInput.replace('__NAME__',column) + '//input';
                      var tmp = browser.isVisible(sfpTextInput);
                      if(!tmp){
                        sfpTextInput = '//input[@ng-model="'+ column +'"]';
                        tmp = browser.isVisible(sfpTextInput);
                        if(!tmp){

                        }
                      }
                      var sfpTextInputLen = Array.isArray(tmp) ? tmp.length : 1;
                      if(value == 'disabled'){
                            var isDisable = browser.getAttribute('(' + sfpTextInput + ')[' + sfpTextInputLen + ']','disabled');
                            console.log(isDisable);
                      }else{
                            browser.setValue('(' + sfpTextInput + ')[' + sfpTextInputLen + ']',value);
                          }
                      break;

              }
          }
          // save Stratifications
          browser.click('//span[contains(text(),"Save Stratifications")]');
      };
      // var set_stratification = function (stratification_settings) {
      //     browser.click('//a[contains(text(),"Apply Stratification")]');
      //     browser.waitForVisible('//table[contains(@id,"watchlist")]',this.waitDefault);
      //     var header_list = ['watch.type1','watch.min1','watch.max1','watch.type2','watch.min2','watch.max2','watch.type3','watch.min3','watch.max3','watch.prepayrate','watch.prepaytype','watch.defaultrate','watch.defaulttype','watch.defaultDate','watch.lossrate','watch.lossType','watch.lagmonths','watch.cccDateIn','watch.cccDateOut','watch.lossRate'];
      //     for (var i = 1; i < stratification_settings.length; i++) {
      //         var column = stratification_settings[i];
      //         var value = header_list[i];
      //         console.log('column: ' + column + ', value: ' + value);
      //         switch (column) {
      //             case 'watch.min2':
      //             case 'watch.max2':
      //             case 'watch.type1':
      //             case 'watch.type2':
      //             case 'watch.type3':
      //             case 'watch.prepaytype':
      //             case 'watch.defaulttype':
      //             case 'watch.lossType':
      //             case 'item.adjustable':
      //             case 'item.bankLoans':
      //             case 'item.juniorSenior':
      //             case 'item.country':
      //             case 'item.rating':
      //                 var mdSelect = cashflow_xpath.mdSelect.replace('__NAME__', column);
      //                 var tmp = browser.isVisible(mdSelect);
      //                 // need to filter true in tmp list ?
      //                 var mdSelectLen = Array.isArray(tmp) ? tmp.length : 1;
      //                 browser.pause(200);
      //                 if (value == 'disabled') {
      //                     var isDisable = browser.getAttribute('(' + mdSelect + ')[' + mdSelectLen + ']', 'disabled');
      //                     console.log(isDisable);
      //                     expect(isDisable).toEqual(value);
      //                 } else {
      //                     browser.click('(' + mdSelect + ')[' + mdSelectLen + ']');
      //                     try {
      //                         var textXpath = cashflow_xpath.mdSelectMenu + '//*[text()="' + value + '"]';
      //                         var t = browser.isVisible(textXpath);
      //                         var textXpathLen = Array.isArray(t) ? t.length : 1;
      //                         browser.click('(' + textXpath + ')[' + textXpathLen + ']');
      //                     } catch (error) {
      //                         var textXpath = cashflow_xpath.mdSelectMenu2 + '//*[text()="' + value + '"]';
      //                         console.log('try more one time: ' + textXpath);
      //                         var t = browser.isVisible(textXpath);
      //                         var textXpathLen = Array.isArray(t) ? t.length : 1;
      //                         browser.click('(' + textXpath + ')[' + textXpathLen + ']');
      //                     }
      //                 }
      //                 break;
      //             case 'watch.min1':
      //                 // var uiSelectMatch = '//div[@ng-model="'+ column +'"]//div[@class="ui-select-match"]';
      //                 // var tmp = browser.isVisible(uiSelectMatch);
      //                 // var uiSelectMatchLen = Array.isArray(tmp) ? tmp.length : 1;
      //                 // console.log('(' + uiSelectMatch + ')[' + uiSelectMatchLen +']');
      //                 // try {
      //                 //   browser.click('(' + uiSelectMatch + ')[' + uiSelectMatchLen +']');
      //                 // } catch (error) {
      //                 //   console.log('try to click: ' + '(' + divSelectMatch + ')[' + uiSelectMatchLen + ']' );
      //                 //   browser.click('(' + divSelectMatch + ')[' + uiSelectMatchLen + ']');
      //                 // }
      //                 var divSelectMatch = '//div[@ng-model="' + column + '"]';
      //                 var tmp = browser.isVisible(divSelectMatch);
      //                 console.log(tmp);
      //                 var divSelectMatchLen = Array.isArray(tmp) ? tmp.length : 1;
      //                 browser.click('(' + divSelectMatch + ')[' + divSelectMatchLen + ']');
      //                 browser.pause(200);
      //                 var input = '//div[@ng-model="watch.min1"]//input[contains(@placeholder,"Select or search")]';
      //                 var t = browser.isVisible(input);
      //                 console.log(t);
      //                 var inputLen = Array.isArray(t) ? t.length : 1;
      //                 console.log(inputLen);
      //                 browser.click('(' + input + ')[' + inputLen + ']');
      //                 console.log('(' + input + ')[' + inputLen + ']');
      //                 browser.pause(1000);
      //                 browser.setValue('(' + input + ')[' + inputLen + ']', value);
      //                 browser.waitForVisible('//div[@ng-model="watch.min1"]//ul[not (contains(@class,"ng-hide"))]//*[text()="' + value + '"]', this.waitDefault);
      //                 this.robot_session.keyTap();
      //                 if (this.portfolio && browser.isVisible('(' + input + ')[' + inputLen + ']')) {
      //                     browser.pause(500);
      //                     browser.click('(' + input + ')[' + inputLen + ']');
      //                     browser.waitForVisible('//div[@ng-model="watch.min1"]//ul[not (contains(@class,"ng-hide"))]//*[text()="' + value + '"]', this.waitDefault);
      //                     this.robot_session.keyTap();
      //                 }
      //                 break;
      //             case 'watch.max1':
      //             case 'watch.max3':
      //             case 'watch.min3':
      //             case 'watch.prepayrate':
      //             case 'watch.defaultrate':
      //             case 'watch.lossrate':
      //             case 'watch.lagmonths':
      //             case 'watch.defaultDate':
      //             case 'watch.cccDateIn':
      //             case 'watch.cccDateOut':
      //             case 'watch.lossRate':
      //                 var sfpTextInput = cashflow_xpath.sfpTextInput.replace('__NAME__',column) + '//input';
      //                 var tmp = browser.isVisible(sfpTextInput);
      //                 if(!tmp){
      //                   sfpTextInput = '//input[@ng-model="'+ column +'"]';
      //                   tmp = browser.isVisible(sfpTextInput);
      //                 }
      //                 var sfpTextInputLen = Array.isArray(tmp) ? tmp.length : 1;
      //                 if(value == 'disabled'){
      //                       var isDisable = browser.getAttribute('(' + sfpTextInput + ')[' + sfpTextInputLen + ']','disabled');
      //                       console.log(isDisable);
      //                 }else{
      //                       browser.setValue('(' + sfpTextInput + ')[' + sfpTextInputLen + ']',value);
      //                     }
      //                 break;

      //         }
      //     }
      //     // save Stratifications
      // };

      // remove the item from scenario list which scenario_id is null
      var temp = [];
      for (var scenario_index=0;scenario_index < 5; scenario_index++){
          if(scenario_list[scenario_index]["scenario_id"] != 'null'){
              temp.push(scenario_list[scenario_index])
          }
      }
      scenario_list = temp;

      //uncheck the scenario if don't need run
      // var run_flag_unchecked_num = scenario_list.length + 1;
      // for(var run_flag_uncheck_index = run_flag_unchecked_num;run_flag_uncheck_index<=5;run_flag_uncheck_index++){
      //     var check_box = '(' + cashflow_xpath.dealcfsCheckBox.replace('__NAME__',"tranche.run_flag") + ')[' + run_flag_uncheck_index + ']';
      //     // var check_flag = '(' + cashflow_xpath.dealcfsCheckBox.replace('__NAME__',"tranche.run_flag") + ')[' + run_flag_uncheck_index + ']';
      //     this.browser_session.waitForResource(browser,check_box);
      //     var target_attribute = browser.getAttribute(check_box, 'class');
      //     if (target_attribute.indexOf('ng-not-empty')>-1) {
      //         browser.click(check_box);
      //         browser.pause(100);
      //     }
      // }

      var assumption_list;
      var output_type = process.env.output_type
     if (output_type==undefined) {
        output_type="Monthly";
      }
      if (output_type == 'Payment'){
          output_type = 'Payment Dates'
      }
      console.log('output type:',output_type);
      //console.log("scenario_dict:",scenario_dict);
      //console.log("scenario_list");
      for (var scenario_row in scenario_list){
          assumption_list = [];
          var scenario_value_list = scenario_dict[scenario_list[scenario_row]['scenario_id']];
          //transfer the scenario details to the follow step
          this.scenarios_used[scenario_list[scenario_row]['scenario_id']] = scenario_value_list;
          console.log('this.scenario_used:',this.scenarios_used);
          console.log('scenario_value_list:',scenario_value_list);
          if (assetclass == 'ABS'){
            assumption_list.push({'name':'cash.settles_date','value':scenario_value_list[18]},{'name':'tranche.prepay_rate','value':scenario_value_list[7]},{'name':'tranche.prepay_type','value':scenario_value_list[8]},{'name':'tranche.default_rate','value':scenario_value_list[9]},{'name':'tranche.default_type','value':scenario_value_list[10]},{'name':'tranche.loss_rate','value':scenario_value_list[11]},{'name':'tranche.loss_type','value':scenario_value_list[12]},{'name':'tranche.rec_lag','value':scenario_value_list[13]},{'name':'tranche.alloc_mon','value':scenario_value_list[14]},{'name':'tranche.call_option','value':scenario_value_list[16]},{'name':'tranche.force_call','value':scenario_value_list[15]},{'name':'tranche.call_date','value':scenario_value_list[17]});
          }
          else if (assetclass == 'AUTO'){
            assumption_list.push({'name':'cash.settles_date','value':scenario_value_list[23]},{'name':'tranche.prepay_rate','value':scenario_value_list[7]},{'name':'tranche.prepay_type','value':scenario_value_list[8]},{'name':'tranche.default_rate','value':scenario_value_list[9]},{'name':'tranche.default_type','value':scenario_value_list[10]},{'name':'tranche.loss_rate','value':scenario_value_list[11]},{'name':'tranche.loss_type','value':scenario_value_list[12]},{'name':'tranche.rec_lag','value':scenario_value_list[13]},{'name':'tranche.alloc_mon','value':scenario_value_list[14]},{'name':'tranche.delinquency_type','value':scenario_value_list[16]},{'name':'tranche.delinquency_rate','value':scenario_value_list[15]},{'name':'tranche.seed_default','value':scenario_value_list[17]},{'name':'tranche.adv_loss_rate','value':scenario_value_list[18]},{'name':'tranche.adv_lag_mon','value':scenario_value_list[19]},{'name':'tranche.call_option','value':scenario_value_list[21]},{'name':'tranche.force_call','value':scenario_value_list[20]},{'name':'tranche.call_date','value':scenario_value_list[22]});
          }
          else if (assetclass == 'CARDS'){
            assumption_list.push({'name':'cash.settles_date','value':scenario_value_list[18]},{'name':'tranche.repay_rate','value':scenario_value_list[7]},{'name':'tranche.repay_type','value':scenario_value_list[8]},{'name':'tranche.purchase_rate','value':scenario_value_list[9]},{'name':'tranche.purchase_type','value':scenario_value_list[10]},{'name':'tranche.portfolio_yield_rate','value':scenario_value_list[11]},{'name':'tranche.portfolio_yield_type','value':scenario_value_list[12]},{'name':'tranche.portfolio_loss_rate','value':scenario_value_list[13]},{'name':'tranche.portfolio_loss_type','value':scenario_value_list[14]},{'name':'tranche.call_option','value':scenario_value_list[16]},{'name':'tranche.force_call','value':scenario_value_list[15]},{'name':'tranche.call_date','value':scenario_value_list[17]});
          }
          else if (assetclass == 'SLABS'){
            assumption_list.push({'name':'cash.settles_date','value':scenario_value_list[33]},{'name':'tranche.prepay_rate','value':scenario_value_list[7]},{'name':'tranche.prepay_type','value':scenario_value_list[8]},{'name':'tranche.default_rate','value':scenario_value_list[9]},{'name':'tranche.default_type','value':scenario_value_list[10]},{'name':'tranche.loss_rate','value':scenario_value_list[11]},{'name':'tranche.loss_type','value':scenario_value_list[12]},{'name':'tranche.rec_lag','value':scenario_value_list[13]},{'name':'tranche.alloc_mon','value':scenario_value_list[14]},{'name':'tranche.deferment_rate','value':scenario_value_list[15]},{'name':'tranche.deferment_type','value':scenario_value_list[16]},{'name':'tranche.grace_rate','value':scenario_value_list[17]},{'name':'tranche.grace_type','value':scenario_value_list[18]},{'name':'tranche.forbear_rate','value':scenario_value_list[19]},{'name':'tranche.forbear_type','value':scenario_value_list[20]},{'name':'tranche.ignore_input_nonpayment_term','value':scenario_value_list[21]},{'name':'tranche.calc_curve_off_static_bal','value':scenario_value_list[22]},{'name':'tranche.useACHVector','value':scenario_value_list[23]},{'name':'tranche.BB_utilization_rate','value':scenario_value_list[25]},{'name':'tranche.call_option','value':scenario_value_list[28]},{'name':'tranche.force_call','value':scenario_value_list[27]},{'name':'tranche.call_date','value':scenario_value_list[29]},{'name':'tranche.interest_cap_freq','value':scenario_value_list[30]},{'name':'tranche.subsidy_payment_delay','value':scenario_value_list[31]},{'name':'tranche.SAP_payment_delay','value':scenario_value_list[32]});        
          } 
          else if (assetclass == 'RMBS'){
            assumption_list.push({'name':'cash.settles_date','value':scenario_value_list[26]},{'name':'tranche.prepay_rate','value':scenario_value_list[7]},{'name':'tranche.prepay_type','value':scenario_value_list[8]},{'name':'tranche.default_rate','value':scenario_value_list[9]},{'name':'tranche.default_type','value':scenario_value_list[10]},{'name':'tranche.loss_rate','value':scenario_value_list[11]},{'name':'tranche.loss_type','value':scenario_value_list[12]},{'name':'tranche.rec_lag','value':scenario_value_list[13]},{'name':'tranche.alloc_mon','value':scenario_value_list[14]},{'name':'tranche.delinquency_type','value':scenario_value_list[16]},{'name':'tranche.delinquency_rate','value':scenario_value_list[15]},{'name':'tranche.servicer_basis','value':scenario_value_list[17]},{'name':'tranche.servicer_rate','value':scenario_value_list[18]},{'name':'tranche.servicer_type','value':scenario_value_list[19]},{'name':'tranche.seed_default','value':scenario_value_list[20]},{'name':'tranche.adv_loss_rate','value':scenario_value_list[21]},{'name':'tranche.adv_lag_mon','value':scenario_value_list[22]},{'name':'tranche.call_option','value':scenario_value_list[24]},{'name':'tranche.force_call','value':scenario_value_list[23]},{'name':'tranche.call_date','value':scenario_value_list[25]});
          }
          else if (assetclass == 'CMBS'){
            assumption_list.push({'name':'cash.settles_date','value':scenario_value_list[50]},{'name':'tranche.prepay_rate','value':scenario_value_list[7]},{'name':'tranche.prepay_type','value':scenario_value_list[8]},{'name':'tranche.default_rate','value':scenario_value_list[9]},{'name':'tranche.default_type','value':scenario_value_list[10]},{'name':'tranche.loss_rate','value':scenario_value_list[11]},{'name':'tranche.loss_type','value':scenario_value_list[12]},{'name':'tranche.rec_lag','value':scenario_value_list[13]},{'name':'tranche.alloc_mon','value':scenario_value_list[14]},{'name':'tranche.NOI_growth_rate','value':scenario_value_list[15]},{'name':'tranche.NOI_growth_rate_type','value':scenario_value_list[16]},{'name':'tranche.cap_rate_growth_rate','value':scenario_value_list[17]},{'name':'tranche.cap_rate_growth_rate_type','value':scenario_value_list[18]},{'name':'tranche.term_triggers_activate_LTV_trigger','value':scenario_value_list[23]},{'name':'tranche.term_triggers_LTV_liquidate','value':scenario_value_list[24]},{'name':'tranche.term_triggers_LTV_months','value':scenario_value_list[25]},{'name':'tranche.term_triggers_LTV_loss','value':scenario_value_list[26]},{'name':'tranche.term_triggers_activate_DSCR_trigger','value':scenario_value_list[27]},{'name':'tranche.term_triggers_DSCR_liquidate','value':scenario_value_list[28]},{'name':'tranche.term_triggers_DSCR_months','value':scenario_value_list[29]},{'name':'tranche.term_triggers_DSCR_loss','value':scenario_value_list[30]},{'name':'tranche.term_triggers_select_priority','value':scenario_value_list[31]},{'name':'tranche.maturity_trigger_activate_LTV_trigger','value':scenario_value_list[32]},{'name':'tranche.maturity_trigger_LTV_payoff','value':scenario_value_list[33]},{'name':'tranche.maturity_trigger_LTV_liquidate','value':scenario_value_list[34]},{'name':'tranche.maturity_trigger_LTV_loss','value':scenario_value_list[35]},{'name':'tranche.maturity_trigger_LTV_extension','value':scenario_value_list[36]},{'name':'tranche.maturity_trigger_LTV_end_of_extension_liq_or_payoff','value':scenario_value_list[37]},{'name':'tranche.maturity_trigger_LTV_end_of_extension_loss','value':scenario_value_list[38]},{'name':'tranche.maturity_trigger_activate_DY_trigger','value':scenario_value_list[39]},{'name':'tranche.maturity_trigger_DY_payoff','value':scenario_value_list[40]},{'name':'tranche.maturity_trigger_DY_liquidate','value':scenario_value_list[41]},{'name':'tranche.maturity_trigger_DY_loss','value':scenario_value_list[42]},{'name':'tranche.maturity_trigger_DY_extension','value':scenario_value_list[43]},{'name':'tranche.maturity_trigger_DY_end_of_extension_liq_or_payoff','value':scenario_value_list[44]},{'name':'tranche.maturity_trigger_DY_end_of_extension_loss','value':scenario_value_list[45]},{'name':'tranche.maturity_trigger_select_priority','value':scenario_value_list[46]},{'name':'tranche.servicer_basis','value':scenario_value_list[19]},{'name':'tranche.servicer_rate','value':scenario_value_list[20]},{'name':'tranche.servicer_type','value':scenario_value_list[21]},{'name':'tranche.apply_loan_level_assumps','value':scenario_value_list[22]},{'name':'tranche.call_option','value':scenario_value_list[48]},{'name':'tranche.force_call','value':scenario_value_list[47]},{'name':'tranche.call_date','value':scenario_value_list[49]});
          }
          else if (assetclass == 'CLO'){
            assumption_list.push({'name':'tranche.cal_first_loss','value':scenario_value_list[3]},{'name':'cash.settles_date','value':scenario_value_list[28]},{'name':'cash.isCustomRates','value':scenario_value_list[5]},{'name':'cash.apply_watch','value':scenario_value_list[6]},{'name':'tranche.prepay_rate','value':scenario_value_list[7]},{'name':'tranche.prepay_type','value':scenario_value_list[8]},{'name':'tranche.default_rate','value':scenario_value_list[9]},{'name':'tranche.default_type','value':scenario_value_list[10]},{'name':'tranche.loss_rate','value':scenario_value_list[11]},{'name':'tranche.loss_type','value':scenario_value_list[12]},{'name':'tranche.prinLossSeverityPctNonPerf','value':scenario_value_list[13]},{'name':'tranche.rec_lag','value':scenario_value_list[14]},{'name':'tranche.reinvest_price_type','value':scenario_value_list[16]},{'name':'tranche.reinvest_price','value':scenario_value_list[15]},{'name':'tranche.reinvest_pool','value':scenario_value_list[19]},{'name':'tranche.reinvest_spread','value':scenario_value_list[17]},{'name':'tranche.reinvest_term','value':scenario_value_list[18]},{'name':'tranche.reinvDefaultLockout','value':scenario_value_list[20]},{'name':'tranche.reinvest_rules','value':scenario_value_list[21]},{'name':'tranche.call_option','value':scenario_value_list[23]},{'name':'tranche.force_call','value':scenario_value_list[22]},{'name':'tranche.call_date','value':scenario_value_list[24]},{'name':'tranche.plus_minus_months','value':scenario_value_list[25]},{'name':'tranche.call_price_type','value':scenario_value_list[26]},{'name':'tranche.call_price','value':scenario_value_list[27]});
            this.settles_date = scenario_value_list[28];
          }
          console.log('assumption:',assumption_list);

          var arg1 = parseInt(scenario_row) + 1;
          assumption_list.forEach(function(list_row) {
              console.log('setting:',list_row['name']);
              console.log('setting:',list_row['value']);
              switch(list_row['name']){
                  // case "tranche.run_flag":
                  //     var check_flag = '(//md-checkbox[contains(@ng-model,"run_flag")])' + '[' + arg1 + ']';
                  //     browser.waitForVisible(check_flag,self.waitDefault);
                  //     var target_attribute = browser.getAttribute(check_flag, 'class');
                  //     console.log('target_attribute:',target_attribute);
                  //     if (list_row['value']=='checked'&&target_attribute.indexOf('ng-empty') > -1 ){
                  //         browser.click(check_flag);
                  //         browser.pause(100);
                  //     }else if (list_row['value'] == 'uncheccolWatchListked'&&target_attribute.indexOf('ng-not-empty')>-1) {
                  //         browser.click(check_flag);
                  //         browser.pause(100);
                  //     }
                  //     break;
                  case "tranche.seed_default":
                  case "tranche.ignore_input_nonpayment_term":
                  case "tranche.calc_curve_off_static_bal":
                  // case "tranche.useACHVector":
                  // case "tranche.apply_watch":
                  // case "tranche.apply_loan_level_assumps":
                  // case 'tranche.term_triggers_activate_LTV_trigger':
                  // case 'tranche.term_triggers_activate_DSCR_trigger':
                  // case 'tranche.maturity_trigger_activate_LTV_trigger':
                  // case 'tranche.maturity_trigger_activate_DY_trigger':
                      var target_set = assumption_div + content_xpath.inputoption.replace('__NAME__',list_row['name']);
                      console.log(target_set);
                      for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
                        var target_item = '(' + target_set + ')[' + i + ']';
                        console.log(target_item);
                        var target_attribute = browser.getAttribute(target_item, 'class');
                        console.log(target_attribute);
                        if ((list_row['value']=='checked' && target_attribute.indexOf('ng-empty') > -1) || (list_row['value']=='unchecked' && target_attribute.indexOf('ng-not-empty') > -1)){
                          console.log(target_item);
                          browser.click(target_item);
                          browser.pause(100);
                          expect(browser.getAttribute(target_item,'class').indexOf('ng-not-empty')>-1).toBe(true,target_item)
                         }  
                      }
                      break;
                  case "cash.apply_watch":
                   var target_set = '//md-checkbox[contains(@ng-model,"cash.apply_watch")]'
                      console.log(target_set);
                      if(list_row['value'].indexOf('Strat') > -1){
                          //Open Stratification
                          browser.click('//*[@ng-repeat="item in cash.tabs" and text()="Stratification"]');
                          browser.waitForVisible('//table[contains(@id,"watchlist")]',self.waitDefault);
                          var stra_length = browser.elements('//*[contains(@ng-click,"assumpCtrl.deleteRule")]').value.length;
                          console.log('stra_length:',stra_length)
                          for(var strItem = 1; strItem <= stra_length; strItem++){
                            console.log('strItem:',strItem)
                            browser.click('(//*[contains(@ng-click,"assumpCtrl.deleteRule")])[1]');
                          }
                          var item_value = list_row['value'];
                          var count = 1;
                          for(var item_index in stratifications){
                            console.log('-----------------------------',stratifications[item_index]);
                            console.log('item_value',item_value)
                            var stratifications_settings = stratifications[item_index].split(',');
                            console.log('stratifications_settings[0]',stratifications_settings[0])
                            if(stratifications_settings[0]==item_value){
                              console.log('-----setting----')
                              // var stratifications_settings = stratifications[item_index].split(',');
                              console.log("stratifications_settings:",stratifications_settings);
                              set_stratification(stratifications_settings)
                              count++;
                            }
                          }
                          // close Stratifications
                          browser.click('//*[@ng-repeat="item in cash.tabs" and text()="Settings"]');
                          self.stratifications_flag=true
                        }
                      // for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
                        var target_item = target_set ;
                        // var target_icon = target_set+'//div[@class="md-icon"]';
                        console.log(target_item);
                        var target_attribute = browser.getAttribute(target_item, 'class');
                        console.log(target_attribute);
                        // if(list_row['value'].indexOf('Strat') > -1){
                        if ((list_row['value'].indexOf('Strat') > -1 && target_attribute.indexOf('ng-empty') > -1) || (list_row['value'].indexOf('Strat') == -1 && target_attribute.indexOf('ng-not-empty') > -1)){
                          console.log(target_item);
                          browser.click(target_item);
                          browser.pause(100);
                          expect(browser.getAttribute(target_item,'class').indexOf('ng-not-empty')>-1).toBe(true,target_item)
                         } 
                       // } 
                      // }
                    break
                  case "cash.isCustomRates":
                    var target_set = '//md-checkbox[contains(@ng-model,"cash.isCustomRates")]'
                     console.log(target_set);
                     // for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
                       var target_item = target_set
                       console.log(target_item);
                       var target_attribute = browser.getAttribute(target_item, 'class');
                       console.log(target_attribute);
                       // if(list_row['value'].indexOf('custom_rate')>-1){
                       if ((list_row['value'].indexOf('custom_rate')>-1 && target_attribute.indexOf('ng-empty') > -1) || (list_row['value'].indexOf('custom_rate')==-1 && target_attribute.indexOf('ng-not-empty') > -1)){
                         console.log(target_item);
                         browser.click(target_item);
                         browser.pause(100);
                         expect(browser.getAttribute(target_item,'class').indexOf('ng-not-empty')>-1).toBe(true,target_item)
                       } 
                      // } 
                     // }

                    break
                  case "tranche.solve_for":
                  case "tranche.forward_curve":
                  case "tranche.loss_type":
                  case "tranche.delinquency_type":
                  case "tranche.repay_type":
                  case "tranche.purchase_type":
                  case "tranche.portfolio_yield_type":
                  case "tranche.portfolio_loss_type":
                  case "tranche.deferment_type":
                  case "tranche.grace_type":
                  case "tranche.forbear_type":
                  case "tranche.interest_cap_freq":
                  case "tranche.BB_type":
                  case "tranche.reinvest_price_type":
                  case "tranche.reinvest_pool":
                  case "tranche.reinvest_rules":
                  case "tranche.call_option":
                  case "tranche.force_call":
                  case "tranche.call_price_type":
                  case "tranche.prepay_type":
                  case "tranche.default_type":
                  case "tranche.NOI_growth_rate_type":
                  case "tranche.cap_rate_growth_rate_type":
                  case "tranche.term_triggers_select_priority":
                  case "tranche.maturity_trigger_select_priority":
                  case 'tranche.servicer_basis':
                  case 'tranche.servicer_type':
                      if (list_row['value'] == "NA"){
                        break;
                      }
                      else{
                        var target_set = assumption_div + cashflow_xpath.selectButton.replace('__NAME__',list_row['name']);
                        for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
                          var target_item = '(' + target_set + ')[' + i + ']';
                          console.log(target_item);
                          console.log(list_row['value']);
                          browser.waitForVisible(target_item,self.waitDefault);
                          browser.selectByVisibleText(target_item,list_row['value']);
                          console.log(browser.getText(target_item));
                        }
                        break;
                      }
                  // case "cash.cashflowOutputType":
                  //   try{
                  //     var selectPicker_select = content_xpath.selectPicker.replace('__SELECTNAME__','Cashflow Output');
                  //     //self.browser_session.waitForResource(browser, selectPicker_select);
                  //     browser.click(selectPicker_select);
                  //     //browser.waitForVisible(content_xpath.selectBox2,self.waitDefault);
                  //     // this.browser_session.waitForResource(browser,content_xpath.selectBox2);
                  //     if (browser.isVisible(content_xpath.selectBox2)) {
                  //       browser.click(content_xpath.selectOption.replace('__OPTION__',list_row['value']));
                  //     }
                  //     browser.pause(500);
                  //     break;
                  //   }catch(err){   
                  //     break;                   
                  //   }                    
                      // var deal_CfSfpSelect = '(' + cashflow_xpath.dealCfSfpSelect.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
                      // console.log(deal_CfSfpSelect);
                      // browser.click(deal_CfSfpSelect);
                      // browser.waitForVisible(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__',list_row['name']),self.waitDefault);
                      // browser.click(cashflow_xpath.dealCfsDropDSelItem.replace('__NAME__',list_row['name']).replace('__ITEM__',list_row['value']));
                      // console.log(browser.getValue(deal_CfSfpSelect));
                      // // console.log(browser.getHTML(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__',list_row['name'])));
                  // case "analyticsCtrl.outputType":
                  // case "analyticsCtrl.scenarioMethod":
                  // case "analyticsCtrl.scenarioInput":
                  //     var deal_CfSfpSelect = cashflow_xpath.dealCfSfpSelect.replace('__NAME__',list_row['name']);
                  //     console.log(deal_CfSfpSelect);
                  //     browser.click(deal_CfSfpSelect);
                  //     browser.waitForVisible(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__',list_row['name']),self.waitDefault);
                  //     browser.click(cashflow_xpath.dealCfsDropDSelItem.replace('__NAME__',list_row['name']).replace('__ITEM__',list_row['value']));
                  //     break;
                  // case "analyticsCtrl.scenarioMidPoint":
                  // case "analyticsCtrl.scenarioStepSize":
                  //     var assumptions_input = cashflow_xpath.dealCfsInput.replace('__NAME__',list_row['name']);
                  //     browser.setValue(assumptions_input,list_row['value']);
                  //     console.log(browser.getValue(assumptions_input));
                  //     break;
                  case "tranche.scenType":
                      var sentypeSelect = '(' + cashflow_xpath.mdSelect.replace('__NAME__',list_row['name'])  + ')[' + arg1 + ']';
                      browser.click(sentypeSelect);
                      var select_item = content_xpath.namedSelectItem.replace('__NAME__', list_row['value']);
                      console.log(select_item);
                      browser.waitForVisible(select_item,self.waitDefault);
                      browser.click(select_item);
                      break;                  
                  // // case "tranche.NOI_growth_rate_type":
                  // // case "tranche.cap_rate_growth_rate_type":
                  // // case "tranche.term_triggers_select_priority":
                  // // case "tranche.maturity_trigger_select_priority":
                  // // case "tranche.servicer_basis":
                  // case "tranche.servicer_type":
                  // // case "tranche.apply_loan_level_assumps":
                  //   // Select field of select ng-model
                  //   var assumptions_select = '(' + cashflow_xpath.dealCfsSelect.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
                  //   console.log(assumptions_select);
                  //   browser.selectByVisibleText(assumptions_select, list_row['value']);
                  //   console.log(browser.getText(assumptions_select));
                  // break;
                  case "cash.settles_date":
                      var settleDateInput = cashflow_xpath.cashflowPortfolioInput.replace('__NAME__',list_row['name']);
                      if(list_row['value'] == 'current date'){
                          browser.click(settleDateInput);
                          var today = cashflow_xpath.settleDateToday;
                          browser.click(today);
                          console.log("has set " + list_row['name'] + " to " + list_row['value']);
                          console.log(browser.getValue(settleDateInput));
                      }
                      else{
                          console.log(settleDateInput);
                          //browser.click(selectPicker_select);
                          browser.setValue(settleDateInput, list_row['value']);
                      }
                       break;
                  case "tranche.default_rate":
                      //Input field with ng-model
                      if (list_row['value'] == 'NA' || list_row['value'] == 'N/A'){
                          break;
                      }
                      else{
                          var target_set = assumption_div + content_xpath.inputoption.replace('__NAME__',list_row['name']);
                          console.log(target_set);
                          try{
                            for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
                              var target_item = '(' + target_set + ')[' + i + ']';
                              console.log(target_item);
                              browser.setValue(target_item, list_row['value']);
                            }
                          }catch(err){
                            console.log("Fail to set Default rate!!!");
                          }                          
                          break;
                      }
                  case "tranche.prepay_rate":                  
                  case "tranche.loss_rate":
                  case "tranche.delinquency_rate":
                  case "tranche.adv_loss_rate":
                  case "tranche.adv_lag_mon":
                  case "tranche.repay_rate":
                  case "tranche.purchase_rate":
                  case "tranche.portfolio_yield_rate":
                  case "tranche.portfolio_loss_rate":
                  case "tranche.deferment_rate":
                  case "tranche.grace_rate":
                  case "tranche.forbear_rate":
                  case "tranche.BB_utilization_rate":
                  case "tranche.subsidy_payment_delay":
                  case "tranche.SAP_payment_delay":
                  case "tranche.prinLossSeverityPctNonPerf":
                  case "tranche.rec_lag":
                  case "tranche.alloc_mon":
                  case "tranche.reinvest_price":
                  case "tranche.reinvDefaultLockout":
                  case "tranche.NOI_growth_rate":
                  case "tranche.cap_rate_growth_rate":
                  case "tranche.term_triggers_LTV_liquidate":
                  case "tranche.term_triggers_LTV_months":
                  case "tranche.term_triggers_LTV_loss":
                  case "tranche.term_triggers_DSCR_liquidate":
                  case "tranche.term_triggers_DSCR_months":
                  case "tranche.term_triggers_DSCR_loss":
                  case "tranche.maturity_trigger_LTV_payoff":
                  case "tranche.maturity_trigger_LTV_liquidate":
                  case "tranche.maturity_trigger_LTV_loss":
                  case "tranche.maturity_trigger_LTV_extension":
                  case "tranche.maturity_trigger_LTV_end_of_extension_liq_or_payoff":
                  case "tranche.maturity_trigger_LTV_end_of_extension_loss":
                  case "tranche.maturity_trigger_DY_payoff":
                  case "tranche.maturity_trigger_DY_liquidate":
                  case "tranche.maturity_trigger_DY_loss":
                  case "tranche.maturity_trigger_DY_extension":
                  case "tranche.maturity_trigger_DY_end_of_extension_liq_or_payoff":
                  case "tranche.maturity_trigger_DY_end_of_extension_loss":
                  case "tranche.servicer_rate":
                  case "tranche.call_date":
                  case "tranche.reinvest_spread":
                  case "tranche.reinvest_term":
                  case "tranche.call_price":
                  case "tranche.plus_minus_months":
                      //Input field with ng-model
                      if (list_row['value'] == 'NA' || list_row['value'] == 'N/A'){
                          break;
                      }
                      else{
                          var target_set = assumption_div + content_xpath.inputoption.replace('__NAME__',list_row['name']);
                          console.log(target_set);
                          for (var i = 1; i <= Math.min(set_size, batchSize); i++) {
                            var target_item = '(' + target_set + ')[' + i + ']';
                            console.log(target_item);
                            browser.setValue(target_item, list_row['value']);
                          }
                          break;
                      }
              }
          });
      }
        this.scenario_list = scenario_list;
  })
}

