// Recommended filename: Given_I_have_opened_the_#_#_#_page_directly.js
module.exports = function () {
  this.When(/^I test soft assert step 1$/,
    { timeout: process.env.StepTimeoutInMS * 5 },
    function () {
      //var a = require('soft-assert');
      //var chai = require('soft-assert');
      this.errorList.push('Test');
      console.log(this.softAssert);
      var arr1 = '123';
      var arr2 = '12344';
      //this.softAssert.softAssert(arr1, arr2, 'not match');
      //console.log('can still execute this row')
      //this.softAssert.softAssertAll();
      try {
        expect(arr1).toEqual(arr2);
      } catch (ex) {
        this.errorList.push('step 1------->' + ex);
        console.log(this.errorList);
        global.Test.push('step 2------->' + ex);
        console.log(global.Test);
      }

      //resolve the question that 
      //expect(arr1).to.equal(arr2);

    });

  this.When(/^I test soft assert step 2$/,
    { timeout: process.env.StepTimeoutInMS * 5 },
    function () {
      //var a = require('soft-assert');
      var chai = require('soft-assert');
      var arr1 = '123';
      var arr2 = '123';
      this.softAssert.softAssert(arr1, arr2, 'not match');
      console.log('can still run');
      this.softAssert.softContains('12', arr2, 'not match');
      this.softAssert.softTrue(false, 'not match');
      console.log();
      this.softAssert.softAssertAll();
      /* try {
         expect(arr1).toEqual(arr2);
       } catch (ex) {
         console.log(ex);
       }
       */
      //resolve the question that 
      //expect(arr1).to.equal(arr2);

    });

    /**
     * below is test for try and catch for assert and collect all the error msg
     */
    this.When(/^I test catch up error msg 1$/,
      { timeout: process.env.StepTimeoutInMS * 5 },
      function () {
        //var a = require('soft-assert');
        //var chai = require('soft-assert');
        this.errorList.push('Test');
        console.log(this.softAssert);
        var arr1 = '123';
        var arr2 = '12344';
        //this.softAssert.softAssert(arr1, arr2, 'not match');
        //console.log('can still execute this row')
        //this.softAssert.softAssertAll();
        try {
          expect(arr1).toEqual(arr2);
        } catch (ex) {
          this.errorList.push('step 1------->' + ex);
          console.log(this.errorList);
          global.Test.push('step 2------->' + ex);
          console.log(global.Test);
        }
  
        //resolve the question that 
        //expect(arr1).to.equal(arr2);
  
      });
  
    this.When(/^I test catch up error msg 2$/,
      { timeout: process.env.StepTimeoutInMS * 5 },
      function () {
        //var a = require('soft-assert');
        var chai = require('soft-assert');
        var arr1 = '123';
        var arr2 = '123';
        this.softAssert.softAssert(arr1, arr2, 'not match');
        console.log('can still run');
        this.softAssert.softContains('12', arr2, 'not match');
        this.softAssert.softTrue(false, 'not match');
        console.log();
        this.softAssert.softAssertAll();
        /* try {
           expect(arr1).toEqual(arr2);
         } catch (ex) {
           console.log(ex);
         }
         */
        //resolve the question that 
        //expect(arr1).to.equal(arr2);
  
      });
}