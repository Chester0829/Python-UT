module.exports = function() {
  this.When(/^I read yield and irr settings from "([^"]*)" and load to portal for "([^"]*)" asset class$/,
    {timeout: process.env.StepTimeoutInMS*10},
    function (filename,assetclass,table){
      this.yield_used = {};
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
      var myPanel = content_xpath.titledSectionLowercase.replace('__TITLE__', 'results');
      this.browser_session.waitForResource(browser,cashflow_xpath.dealCashflowsResult);
      browser.getLocationInView(cashflow_xpath.dealCashflowsResult);
      var self = this;
      var path = require('path');
      var filePath = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'ALLCFS', filename);

      // switch(assetclass){
      //   case "CLO":
          var yield_content = this.file_session.readXlsxAsCsvString(filePath,7).split('\n');
          var irr_content = this.file_session.readXlsxAsCsvString(filePath,8).split('\n');
          // break;
      // }
      //var stratifications = this.file_session.readXlsxAsCsvString(filePath,1).split('\n');
      //console.log("stratifications:",stratifications);
      var setting_list = table.hashes();
      console.log('setting_list:',setting_list)
      console.log('setting_list[0]',setting_list[0])
      var yield_dict = {};
      var irr_dict = {};
      var yieldcontent_length = yield_content.length;
      var irrcontent_length = irr_content.length;
      console.log(yieldcontent_length);
      console.log(irrcontent_length);
      var yield_setting;
      var irr_setting;

      // if(assetclass=="CLO"){
        for(var i=4;i<yieldcontent_length;i++){
          yield_setting = yield_content[i].split(',');
          if(yield_setting[2] != ''){
              yield_dict[yield_setting[2]] = yield_setting;
          }
        }
        for(var i=4;i<irrcontent_length;i++){
          irr_setting = irr_content[i].split(',');
          if(irr_setting[2] != ''){
              irr_dict[irr_setting[2]] = irr_setting;
          }
        }
      // }     

      var yield_value_list;
      var irr_value_list;
      
      console.log(setting_list[0]['yield_setting'])
      if(setting_list[0]['yield_setting']!='null'){
        this.yield_settingId = setting_list[0]['yield_setting'];
        yield_value_list=yield_dict[setting_list[0]['yield_setting']];
        console.log(yield_value_list);
        browser.click(cashflow_xpath.yieldTableSelectIcon1);
        browser.waitForVisible(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__",yield_value_list[3]),this.waitDefault);
        browser.click(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__",yield_value_list[3]));
        if(yield_value_list[4]=='Y'){
          browser.click(cashflow_xpath.yieldTableSelectIcon2);
          browser.waitForVisible(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__","Custom"),this.waitDefault);
          browser.click(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__","Custom"));
          for(var i=1;i<=7;i++){
            var input_xpath='(//table[contains(@class,"yieldTable")]//input)['+i+']';
            browser.setValue(input_xpath,yield_value_list[i+5]);
            expect(browser.getValue(input_xpath)).toEqual(yield_value_list[i+5])
          }
        }
        else{
          browser.click(cashflow_xpath.yieldTableSelectIcon2);
          browser.waitForVisible(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__","Step Size (bps)"),this.waitDefault);
          browser.click(cashflow_xpath.yieldTableSelectItem.replace("__TEXT__","Step Size (bps)"));
          for(var i=1;i<=2;i++){
            var input_xpath='(//table[contains(@class,"yieldTable")]//input)['+i+']';
            browser.setValue(input_xpath,yield_value_list[7-i]);
            expect(browser.getValue(input_xpath)).toEqual(yield_value_list[7-i])

          }

        }
      }
       console.log(setting_list[0]['irr_setting'])
       console.log('-------need setting irr when we change a tranche-------------')
      if(setting_list[0]['irr_setting']!='null'){
        this.irr_settingId = setting_list[0]['irr_setting'];
        this.irr_value_list=irr_dict[setting_list[0]['irr_setting']];
        console.log(this.irr_value_list);
      }else{
        this.irr_value_list=null
      }
      
      this.yield_value_list=yield_value_list;
      browser.click("//*[text()='Run Price/Yield Table']")
      var runningBar = '//*[contains(@ng-if,"analyticsCtrl.priceYieldRunning")]';
      var timeOut = 60*1000;
      try {
        browser.waitForExist(runningBar,1000);
        browser.waitForVisible(runningBar,1000);
        this.browser_session.waitForLoading(browser,cashflow_xpath.runningBar,1000,timeOut);
      }catch (e) {
        console.log(e);
      }
      // this.irr_value_list=irr_value_list;
      
  })
}
