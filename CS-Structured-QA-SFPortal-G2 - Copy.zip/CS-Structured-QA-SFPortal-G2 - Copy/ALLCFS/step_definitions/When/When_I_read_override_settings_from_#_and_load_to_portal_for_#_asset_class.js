//Then_I_read_override_settings_from_#_and_load_to_portal_for_#_asset_class.js
module.exports = function() {
  this.When(/^I read override settings from "([^"]*)" and load to portal for "([^"]*)" asset class$/,
    {timeout: process.env.StepTimeoutInMS*10},
    function (filename,assetclass,table){
      this.ovverride_used = {};
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath'); 
      const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
      var override_id =  table.hashes()[0]["override_setting"];
      this.override_rule = override_id
      var override_tranche_id =''
      var override_collateral_id = ''
      this.browser_session.waitForResource(browser,cashflow_xpath.dealCfsAssumptions);
      browser.getLocationInView(cashflow_xpath.dealCfsAssumptions);
      var self = this;
      var path = require('path');
      var filePath = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'ALLCFS', filename);


      var overrides = this.file_session.readXlsxAsCsvStrBysheetName(filePath,"Override").split('\n');
      console.log(overrides) 
      console.log(overrides.length)
      var tranche_override_arr=[];
      var collateral_override_arr=[];
      for (var i=1;i< overrides.length;i++){
        var overr_setting = overrides[i].split(',');
        if (overr_setting[0]==override_id){
          override_tranche_id = overr_setting[1]
          override_collateral_id = overr_setting[2]
          console.log(override_tranche_id)
          console.log(override_collateral_id)
          for (var j =0;j<overrides.length;j++){
            var rule_setting = overrides[j].split(',');
            if(rule_setting[0]==override_tranche_id && override_tranche_id!=''){
              tranche_override_arr.push(rule_setting);
            }
            if(rule_setting[0]==override_collateral_id && override_collateral_id!=''){
              collateral_override_arr.push(rule_setting)
            }
          }
        }
      }

      console.log(tranche_override_arr)
      console.log(collateral_override_arr)
      var editDealTable = '//*[contains(@ng-if,"analyticsCtrl.editDealActiveTab")]//table'
      var override_setting_list = {'Tranches':tranche_override_arr,'Collateral':collateral_override_arr}
      for(var key in override_setting_list){
        console.log(key)
        if(override_setting_list[key]!=[]){
          var editTab = cashflow_xpath.editDealFrame + cashflow_xpath.editDealTab.replace('__TAB__',key);
          browser.getLocationInView(editTab);
          browser.click(editTab);
          this.browser_session.waitForResource(browser,cashflow_xpath.editDealFrame);
        // var collateral_Index = expect_row.Index;
        // var balance_override = "("+cashflow_xpath.editCollateralDealRow+cashflow_xpath.editDealBalance+")["+collateral_Index+"]";
        // var table_html;
        // table_html = browser.getHTML(editDealTable);
        // var editDeal_table_json = this.tabletojson.convert(table_html)[0];
        // expect(editDeal_table_json).not.toBe(null);
        // console.log(editDeal_table_json);
        // console.log(tranche_summary_table_json.length);
        for(var i = 0;i<override_setting_list[key].length;i++){
          // for(var j = 0;j<tranche_summary_table_json.length;j++){
            if(override_setting_list[key][i][1]!='All'){
              var bond_index = override_setting_list[key][i][1].match(/\d+/g)[0]
            // if(override_setting_list[key][i][3]==tranche_summary_table_json[j][4]){
              var tranche_tr="("+cashflow_xpath.editTrancheColDealRow.replace('__NAME__',override_setting_list[key][i][3])+")["+bond_index+"]"
              console.log(tranche_tr)
              if(browser.isExisting(tranche_tr)){
                var balance_td = tranche_tr + cashflow_xpath.editDealBalance
                var coupon_td = tranche_tr + cashflow_xpath.editDealCouponSpread
                if(override_setting_list[key][i][2]!=''&&override_setting_list[key][i][2]!='NA'){
                  browser.setValue(balance_td,override_setting_list[key][i][2])
                }
                if(override_setting_list[key][i][5]!=''&&override_setting_list[key][i][5]!='NA'){
                  browser.setValue(coupon_td,override_setting_list[key][i][5])
                }

              }
            }else{
              var tranche_tr=cashflow_xpath.editTrancheColDealRow.replace('__NAME__',override_setting_list[key][i][3])
              var balance_td = tranche_tr + cashflow_xpath.editDealBalance
              var coupon_td = tranche_tr + cashflow_xpath.editDealCouponSpread
              console.log(balance_td)
              // console.log(override_setting_list[key][i][2])
              // console.log(override_setting_list[key][i][5])
              if(browser.isExisting(balance_td)&&override_setting_list[key][i][2]!=''&&override_setting_list[key][i][2]!='NA'){
                // console.log('set balance 1')
                var balance_length=browser.elements(balance_td).value.length
                console.log(balance_length)
                for(var j=1;j<=balance_length;j++){
                  var td_setting="("+balance_td+")["+j+"]"
                  // console.log('setting:',td_setting)
                  browser.setValue(td_setting,override_setting_list[key][i][2])
                }
              }
              if(browser.isExisting(coupon_td)&&override_setting_list[key][i][5]!=''&&override_setting_list[key][i][5]!='NA'){
                var coupon_length=browser.elements(coupon_td).value.length
                for(var j=1;j<=coupon_length;j++){
                  var td_setting="("+coupon_td+")["+j+"]"
                  browser.setValue(td_setting,override_setting_list[key][i][5])
                }
              }
            }
          // }
          // if(override_setting_list[key][i][3]==tranche_summary_table_json[])
        }
      }

    }
      // cashflow_xpath.editTrancheAllRow
      // var editTab = cashflow_xpath.editDealFrame + cashflow_xpath.editDealTab.replace('__TAB__',arg1);
      // browser.getLocationInView(editTab);
      // browser.click(editTab);
      // this.browser_session.waitForResource(browser,cashflow_xpath.editDealFrame);
      // var table_html = browser.getHTML(cashflow_xpath.editDealTable);
      
  })
}
