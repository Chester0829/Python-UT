//Then_I_should_see_the_#_value_display_under_the_#_panel-heading_should_be_#_in_file.js
module.exports = function() {
  this.When(/^I read scenarios from "([^"]*)" and load below scenario list to portal for "([^"]*)" asset class$/,
    {timeout: process.env.StepTimeoutInMS*100},
    function (filename,assetclass,table){
      this.scenarios_used = {};
      const content_xpath = this.xpath_lib.xpathRequire('content_xpath');
      const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
      this.browser_session.waitForResource(browser,cashflow_xpath.dealCfsAssumptions);
      browser.getLocationInView(cashflow_xpath.dealCfsAssumptions);
      var self = this;
      var path = require('path');
      var filePath = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'ALLCFS', filename);
      this.assettype = assetclass;
      const dateFormat = require('dateformat');
      switch(assetclass){
        case "CLO":
          var content = this.file_session.readXlsxAsCsvString(filePath,0).split('\n');
          break;
        case "ABS": 
          var content = this.file_session.readXlsxAsCsvString(filePath,1).split('\n');
          break;
        case "AUTO": 
          var content = this.file_session.readXlsxAsCsvString(filePath,2).split('\n');
          break;
        case "CARDS": 
          var content = this.file_session.readXlsxAsCsvString(filePath,3).split('\n');
          break;
        case "SLABS": 
          var content = this.file_session.readXlsxAsCsvString(filePath,4).split('\n');
          break;
        case "RMBS": 
          var content = this.file_session.readXlsxAsCsvString(filePath,5).split('\n');
          break;
        case "CMBS": 
          var content = this.file_session.readXlsxAsCsvString(filePath,6).split('\n');
          break;
      }
      var stratifications = this.file_session.readXlsxAsCsvStrBysheetName(filePath,"Stratification").split('\n');
      console.log("stratifications:",stratifications);
      var scenario_list = table.hashes();
      var scenario_dict = {};
      var content_length = content.length;
      console.log(content_length);
      var scenario;

      if(assetclass=="CLO"){
        for(var i=23;i<content_length;i++){
          scenario = content[i].split(',');
          if(scenario[0] != ''){
              scenario_dict[scenario[0]] = scenario
          }
        }
      }
      else{
        for(var i=7;i<content_length;i++){
          scenario = content[i].split(',');
          if(scenario[2] != ''){
              scenario_dict[scenario[2]] = scenario
          }
        }
      }

      var set_stratification = function (stratification_settings) {
          // browser.click('//a[contains(text(),"Apply Stratification")]');
          browser.waitForVisible('//table[contains(@id,"watchlist")]',self.waitDefault);
          // add new rule
          browser.click("//*[contains(text(),'Add New Rule')]");
          var header_list = ['watch.type1','watch.min1','watch.max1','watch.type2','watch.min2','watch.max2','watch.type3','watch.min3','watch.max3','watch.prepayrate','watch.prepaytype','watch.defaultrate','watch.defaulttype','watch.defaultDate','watch.lossrate','watch.lossType','watch.lagmonths','watch.cccDateIn','watch.cccDateOut','watch.lossRate'];
          for (var i = 2; i < stratification_settings.length; i++) {
              var value = stratification_settings[i];
              var column = header_list[(i-2)];
              console.log('column: ' + column + ', value: ' + value);
              switch (column) {
                  // case 'watch.min2':
                  // case 'watch.max2':
                  case 'watch.type1':
                  case 'watch.type2':
                  case 'watch.type3':
                  case 'watch.prepaytype':
                  case 'watch.defaulttype':
                  case 'watch.lossType':
                  case 'item.adjustable':
                  case 'item.bankLoans':
                  case 'item.juniorSenior':
                  case 'item.country':
                  case 'item.rating':
                      if(value==''){
                        break; 
                      }
                      var mdSelect = cashflow_xpath.mdSelect.replace('__NAME__', column);
                      var tmp = browser.isVisible(mdSelect);
                      // need to filter true in tmp list ?
                      var mdSelectLen = Array.isArray(tmp) ? tmp.length : 1;
                      browser.pause(200);
                      if (value == 'disabled') {
                          var isDisable = browser.getAttribute('(' + mdSelect + ')[' + mdSelectLen + ']', 'disabled');
                          console.log('isDisable',isDisable);
                          expect(isDisable).toEqual(value);
                      } else {
                        console.log('click' + '(' + mdSelect + ')[' + mdSelectLen + ']');
                          browser.click('(' + mdSelect + ')[' + mdSelectLen + ']');
                          try {
                              var textXpath = cashflow_xpath.mdSelectMenu + '//*[text()="' + value + '"]';
                              var t = browser.isVisible(textXpath);
                              var textXpathLen = Array.isArray(t) ? t.length : 1;
                              browser.click('(' + textXpath + ')[' + textXpathLen + ']');
                          } catch (error) {
                              var textXpath = cashflow_xpath.mdSelectMenu2 + '//*[text()="' + value + '"]';
                              console.log('try more one time: ' + textXpath);
                              var t = browser.isVisible(textXpath);
                              var textXpathLen = Array.isArray(t) ? t.length : 1;
                              browser.click('(' + textXpath + ')[' + textXpathLen + ']');
                          }
                      }
                      break;
                  case 'watch.min1':
                  case 'watch.max1':
                  case 'watch.min2':
                  case 'watch.max2':
                  case 'watch.min3':
                  case 'watch.max3':
                  if(value==''){
                    break;
                  }
                  var divSelectMatch = '//*[@ng-model="' + column + '"]';
                  var tmp = browser.isVisible(divSelectMatch);
                  console.log(tmp);
                  var divSelectMatchLen = Array.isArray(tmp) ? tmp.length : 1;
                  browser.click('(' + divSelectMatch + ')[' + divSelectMatchLen + ']');
                  browser.pause(200);
                  var attribute = browser.getAttribute('(' + divSelectMatch + ')[' + divSelectMatchLen + ']'+'/ancestor::td','ng-if')
                  console.log('attribute',attribute) 
                  if(attribute.indexOf('price')>-1 || attribute.indexOf('loanx')>-1 || attribute.indexOf("!== 'moodysRating'")>-1){
                    var t = browser.isVisible(divSelectMatch);
                    console.log('2',t);
                    var inputLen = Array.isArray(t) ? t.length : 1;
                    console.log(inputLen);
                    console.log('(' + divSelectMatch + ')[' + inputLen + ']');
                        // browser.click('(' + divSelectMatch + ')[' + inputLen + ']');
                        browser.pause(1000);
                        browser.setValue('(' + divSelectMatch + ')[' + inputLen + ']', value);
                   }else if(attribute.indexOf('moodysRating')>-1 || attribute.indexOf('spRating')>-1 || attribute.indexOf('bankLoan')>-1 || attribute.indexOf('seniority')>-1){
                        // var selectDropDown = '//div[@aria-hidden="false"]//md-select-menu[@class="_md md-overflow"]//md-option[@aria-selected="false"]'
                        var selectDropDown = '//div[@aria-hidden="false"]/md-select-menu//md-option[@aria-selected="false"]';
                        var tmp = browser.isVisible('('+selectDropDown+')[1]');
                        console.log('tmp 2',tmp)
                        // if(tmp == false){
                        //   selectDropDown = '//md-option[@aria-selected="false"]//div[text()="Sr Sec"]/..'
                        // }
                        browser.pause(200);
                        console.log('element:'+selectDropDown+'//div[text()="'+ value + '"]');
                        browser.click(selectDropDown+'//div[text()="'+ value + '"]');
                    }else{
                        // var input = '//div[@ng-model="watch.min1"]//input[contains(@placeholder,"Select or search")]';
                        var t = browser.isVisible(divSelectMatch);
                        console.log(t);
                        var inputLen = Array.isArray(t) ? t.length : 1;
                        console.log(inputLen);
                        console.log('(' + divSelectMatch + ')[' + inputLen + ']');
                        browser.click('(' + divSelectMatch + ')[' + inputLen + ']');
                        browser.pause(1000);
                        browser.setValue('(' + divSelectMatch + ')[' + inputLen + ']//input[contains(@placeholder,"Select or search")]', value);
                        browser.waitForVisible('//*[@ng-model="' + column + '"]//ul[not (contains(@class,"ng-hide"))]//*[contains(text(),"' + value + '")]', self.waitDefault);
                        browser.click('//*[@ng-model="' + column + '"]//ul[not (contains(@class,"ng-hide"))]//*[contains(text(),"' + value + '")]');
                        // // self.robot_session.keyTap();
                        // if (browser.isVisible('(' + input + ')[' + inputLen + ']')) {
                        // // if (self.portfolio && browser.isVisible('(' + input + ')[' + inputLen + ']')) {
                        //   browser.pause(500);
                        //   browser.click('(' + input + ')[' + inputLen + ']');
                        //   browser.waitForVisible('//div[@ng-model="watch.min1"]//ul[not (contains(@class,"ng-hide"))]//*[contains(text(),"' + value + '")]', self.waitDefault);
                        //   browser.click('//div[@ng-model="watch.min1"]//ul[not (contains(@class,"ng-hide"))]//*[contains(text(),"' + value + '")]');
                        //   // self.robot_session.keyTap();
                        // }

                    }




                      // var input = '//input[@ng-model="' + column + '"]';
                      // // var filter = '//div[@ng-model="' + column + '"]';
                      // var t = browser.isVisible(input);
                      // var f = browser.isVisible(filter);
                      // console.log(t);
                      // if(t){
                      //   var inputLen = Array.isArray(t) ? t.length : 1;
                      //   console.log(inputLen);
                      //   console.log('(' + input + ')[' + inputLen + ']');
                      //   browser.click('(' + input + ')[' + inputLen + ']');
                      //   browser.pause(1000);
                      //   browser.setValue('(' + input + ')[' + inputLen + ']', value);
                      //   browser.pause(2000);
                      //   var tmp = browser.isVisible('//*[@ng-model="' + column + '"]//ul[not (contains(@class,"ng-hide"))]//*[text()="' + value + '"]');
                      //   // browser.waitForVisible('//*[@ng-model="' + column + '"]//ul[not (contains(@class,"ng-hide"))]//*[text()="' + value + '"]', self.waitDefault);
                      //   if(tmp){
                      //     self.robot_session.keyTap();
                      //     if (self.portfolio && browser.isVisible('(' + input + ')[' + inputLen + ']')) {
                      //       browser.pause(500);
                      //       browser.click('(' + input + ')[' + inputLen + ']');
                      //       browser.waitForVisible('//div[@ng-model="watch.min1"]//ul[not (contains(@class,"ng-hide"))]//*[text()="' + value + '"]', self.waitDefault);
                      //       self.robot_session.keyTap();
                      //     }
                      //   }
                      // }else if(f){

                      // }else{
                      //   var selectDropDown = '//div[@aria-hidden="false"]//md-select-menu[@class="_md md-overflow"]//md-option[@aria-selected="false"]'
                      //   var tmp = browser.isVisible('('+selectDropDown+')[1]');
                      //   console.log('tmp 2',tmp)
                      //   if(tmp == 'false'){
                      //     selectDropDown = '//md-option[@aria-selected="false"]//div[text()="Sr Sec"]/..'
                      //   }
                      //   browser.pause(200);
                      //   console.log('element:'+selectDropDown+'//div[text()="'+ value + '"]');
                      //   browser.click(selectDropDown+'//div[text()="'+ value + '"]');
                      //   // else{
                      //   //   browser.pause(200);
                      //   //   browser.click(selectDropDown+'//md-text[text()="'+ value + '"]')
                      //   // }

                      // }
                      break;
                  // case 'watch.max1':
                  // case 'watch.max3':
                  // case 'watch.min3':
                  case 'watch.prepayrate':
                  case 'watch.defaultrate':
                  case 'watch.lossrate':
                  case 'watch.lagmonths':
                  case 'watch.defaultDate':
                  case 'watch.cccDateIn':
                  case 'watch.cccDateOut':
                  case 'watch.lossRate':
                      if(value==''){
                        break;
                      }
                      var sfpTextInput = cashflow_xpath.sfpTextInput.replace('__NAME__',column) + '//input';
                      var tmp = browser.isVisible(sfpTextInput);
                      if(!tmp){
                        sfpTextInput = '//input[@ng-model="'+ column +'"]';
                        tmp = browser.isVisible(sfpTextInput);
                        if(!tmp){

                        }
                      }
                      var sfpTextInputLen = Array.isArray(tmp) ? tmp.length : 1;
                      if(value == 'disabled'){
                            var isDisable = browser.getAttribute('(' + sfpTextInput + ')[' + sfpTextInputLen + ']','disabled');
                            console.log(isDisable);
                      }else{
                            browser.setValue('(' + sfpTextInput + ')[' + sfpTextInputLen + ']',value);
                          }
                      break;

              }
          }
          // save Stratifications
          browser.click('//span[contains(text(),"Save Stratifications")]');
      };

      // remove the item from scenario list which scenario_id is null
      var temp = [];
      for (var scenario_index=0;scenario_index < 5; scenario_index++){
          if(scenario_list[scenario_index]["scenario_id"] != 'null'){
              temp.push(scenario_list[scenario_index])
          }
      }
      scenario_list = temp;

      //uncheck the scenario if don't need run
      var run_flag_unchecked_num = scenario_list.length + 1;
      for(var run_flag_uncheck_index = run_flag_unchecked_num;run_flag_uncheck_index<=5;run_flag_uncheck_index++){
          var check_box = '(' + cashflow_xpath.dealcfsCheckBox.replace('__NAME__',"scen.run_flag") + ')[' + run_flag_uncheck_index + ']';
          // var check_flag = '(' + cashflow_xpath.dealcfsCheckBox.replace('__NAME__',"scen.run_flag") + ')[' + run_flag_uncheck_index + ']';
          this.browser_session.waitForResource(browser,check_box);
          var target_attribute = browser.getAttribute(check_box, 'class');
          if (target_attribute.indexOf('ng-not-empty')>-1) {
              browser.click(check_box);
              browser.pause(100);
          }
      }

      var assumption_list;
      var output_type = process.env.output_type
      if (output_type==undefined) {
        output_type="Monthly";
      }
      if (output_type == 'Payment'){
          output_type = 'Payment Dates'
      }
      console.log('output type:',output_type);
      //console.log("scenario_dict:",scenario_dict);
      //console.log("scenario_list");
      for (var scenario_row in scenario_list){
          assumption_list = [];
          var scenario_value_list = scenario_dict[scenario_list[scenario_row]['scenario_id']];
          //transfer the scenario details to the follow step
          this.scenarios_used[scenario_list[scenario_row]['scenario_id']] = scenario_value_list;
          console.log('this.scenario_used:',this.scenarios_used);
          console.log('scenario_value_list:',scenario_value_list);
          if (assetclass == 'ABS'){
            assumption_list.push({'name':'scen.run_flag','value':'checked'},{'name':'scen.scenType','value':'User Defined'},{'name':'scen.cal_first_loss','value':scenario_value_list[4]},{'name':'scen.settle_date','value':scenario_value_list[5]},{'name':'scen.forward_curve','value':scenario_value_list[6]},{'name':'scen.prepay_rate','value':scenario_value_list[7]},{'name':'scen.prepay_type','value':scenario_value_list[8]},{'name':'scen.default_rate','value':scenario_value_list[9]},{'name':'scen.default_type','value':scenario_value_list[10]},{'name':'scen.loss_rate','value':scenario_value_list[11]},{'name':'scen.loss_type','value':scenario_value_list[12]},{'name':'scen.rec_lag','value':scenario_value_list[13]},{'name':'scen.alloc_mon','value':scenario_value_list[14]},{'name':'scen.call_option','value':scenario_value_list[16]},{'name':'scen.force_call','value':scenario_value_list[15]},{'name':'scen.call_date','value':scenario_value_list[17]});
          }
          else if (assetclass == 'AUTO'){
            assumption_list.push({'name':'scen.run_flag','value':'checked'},{'name':'scen.scenType','value':'User Defined'},{'name':'scen.cal_first_loss','value':scenario_value_list[4]},{'name':'scen.settle_date','value':scenario_value_list[5]},{'name':'scen.forward_curve','value':scenario_value_list[6]},{'name':'scen.prepay_rate','value':scenario_value_list[7]},{'name':'scen.prepay_type','value':scenario_value_list[8]},{'name':'scen.default_rate','value':scenario_value_list[9]},{'name':'scen.default_type','value':scenario_value_list[10]},{'name':'scen.loss_rate','value':scenario_value_list[11]},{'name':'scen.loss_type','value':scenario_value_list[12]},{'name':'scen.rec_lag','value':scenario_value_list[13]},{'name':'scen.alloc_mon','value':scenario_value_list[14]},{'name':'scen.delinquency_type','value':scenario_value_list[16]},{'name':'scen.delinquency_rate','value':scenario_value_list[15]},{'name':'scen.seed_default','value':scenario_value_list[17]},{'name':'scen.adv_loss_rate','value':scenario_value_list[18]},{'name':'scen.adv_lag_mon','value':scenario_value_list[19]},{'name':'scen.call_option','value':scenario_value_list[21]},{'name':'scen.force_call','value':scenario_value_list[20]},{'name':'scen.call_date','value':scenario_value_list[22]});
          }
          else if (assetclass == 'CARDS'){
            assumption_list.push({'name':'scen.run_flag','value':'checked'},{'name':'scen.scenType','value':'User Defined'},{'name':'scen.cal_first_loss','value':scenario_value_list[4]},{'name':'scen.settle_date','value':scenario_value_list[5]},{'name':'scen.forward_curve','value':scenario_value_list[6]},{'name':'scen.repay_rate','value':scenario_value_list[7]},{'name':'scen.repay_type','value':scenario_value_list[8]},{'name':'scen.purchase_rate','value':scenario_value_list[9]},{'name':'scen.purchase_type','value':scenario_value_list[10]},{'name':'scen.portfolio_yield_rate','value':scenario_value_list[11]},{'name':'scen.portfolio_yield_type','value':scenario_value_list[12]},{'name':'scen.portfolio_loss_rate','value':scenario_value_list[13]},{'name':'scen.portfolio_loss_type','value':scenario_value_list[14]},{'name':'scen.call_option','value':scenario_value_list[16]},{'name':'scen.force_call','value':scenario_value_list[15]},{'name':'scen.call_date','value':scenario_value_list[17]});
          }
          else if (assetclass == 'SLABS'){
            assumption_list.push({'name':'scen.run_flag','value':'checked'},{'name':'scen.scenType','value':'User Defined'},{'name':'scen.cal_first_loss','value':scenario_value_list[4]},{'name':'scen.settle_date','value':scenario_value_list[5]},{'name':'scen.forward_curve','value':scenario_value_list[6]},{'name':'scen.prepay_rate','value':scenario_value_list[7]},{'name':'scen.prepay_type','value':scenario_value_list[8]},{'name':'scen.default_rate','value':scenario_value_list[9]},{'name':'scen.default_type','value':scenario_value_list[10]},{'name':'scen.loss_rate','value':scenario_value_list[11]},{'name':'scen.loss_type','value':scenario_value_list[12]},{'name':'scen.rec_lag','value':scenario_value_list[13]},{'name':'scen.alloc_mon','value':scenario_value_list[14]},{'name':'scen.deferment_rate','value':scenario_value_list[15]},{'name':'scen.deferment_type','value':scenario_value_list[16]},{'name':'scen.grace_rate','value':scenario_value_list[17]},{'name':'scen.grace_type','value':scenario_value_list[18]},{'name':'scen.forbear_rate','value':scenario_value_list[19]},{'name':'scen.forbear_type','value':scenario_value_list[20]},{'name':'scen.ignore_input_nonpayment_term','value':scenario_value_list[21]},{'name':'scen.calc_curve_off_static_bal','value':scenario_value_list[22]},{'name':'scen.useACHVector','value':scenario_value_list[23]},{'name':'scen.BB_utilization_rate','value':scenario_value_list[25]},{'name':'scen.BB_type','value':scenario_value_list[24]},{'name':'scen.call_option','value':scenario_value_list[28]},{'name':'scen.force_call','value':scenario_value_list[27]},{'name':'scen.call_date','value':scenario_value_list[29]},{'name':'scen.interest_cap_freq','value':scenario_value_list[30]},{'name':'scen.subsidy_payment_delay','value':scenario_value_list[31]},{'name':'scen.SAP_payment_delay','value':scenario_value_list[32]});
          }
          else if (assetclass == 'RMBS'){
            assumption_list.push({'name':'scen.run_flag','value':'checked'},{'name':'scen.scenType','value':'User Defined'},{'name':'scen.cal_first_loss','value':scenario_value_list[4]},{'name':'scen.settle_date','value':scenario_value_list[5]},{'name':'scen.forward_curve','value':scenario_value_list[6]},{'name':'scen.prepay_rate','value':scenario_value_list[7]},{'name':'scen.prepay_type','value':scenario_value_list[8]},{'name':'scen.default_rate','value':scenario_value_list[9]},{'name':'scen.default_type','value':scenario_value_list[10]},{'name':'scen.loss_rate','value':scenario_value_list[11]},{'name':'scen.loss_type','value':scenario_value_list[12]},{'name':'scen.rec_lag','value':scenario_value_list[13]},{'name':'scen.alloc_mon','value':scenario_value_list[14]},{'name':'scen.delinquency_type','value':scenario_value_list[16]},{'name':'scen.delinquency_rate','value':scenario_value_list[15]},{'name':'scen.servicer_basis','value':scenario_value_list[17]},{'name':'scen.servicer_rate','value':scenario_value_list[18]},{'name':'scen.servicer_type','value':scenario_value_list[19]},{'name':'scen.seed_default','value':scenario_value_list[20]},{'name':'scen.adv_loss_rate','value':scenario_value_list[21]},{'name':'scen.adv_lag_mon','value':scenario_value_list[22]},{'name':'scen.call_option','value':scenario_value_list[24]},{'name':'scen.force_call','value':scenario_value_list[23]},{'name':'scen.call_date','value':scenario_value_list[25]});
          }
          else if (assetclass == 'CMBS'){
            assumption_list.push({'name':'scen.run_flag','value':'checked'},{'name':'scen.scenType','value':'User Defined'},{'name':'scen.cal_first_loss','value':scenario_value_list[4]},{'name':'scen.settle_date','value':scenario_value_list[5]},{'name':'scen.forward_curve','value':scenario_value_list[6]},{'name':'scen.prepay_rate','value':scenario_value_list[7]},{'name':'scen.prepay_type','value':scenario_value_list[8]},{'name':'scen.default_rate','value':scenario_value_list[9]},{'name':'scen.default_type','value':scenario_value_list[10]},{'name':'scen.loss_rate','value':scenario_value_list[11]},{'name':'scen.loss_type','value':scenario_value_list[12]},{'name':'scen.rec_lag','value':scenario_value_list[13]},{'name':'scen.alloc_mon','value':scenario_value_list[14]},{'name':'scen.NOI_growth_rate','value':scenario_value_list[15]},{'name':'scen.NOI_growth_rate_type','value':scenario_value_list[16]},{'name':'scen.cap_rate_growth_rate','value':scenario_value_list[17]},{'name':'scen.cap_rate_growth_rate_type','value':scenario_value_list[18]},{'name':'scen.term_triggers_activate_LTV_trigger','value':scenario_value_list[23]},{'name':'scen.term_triggers_LTV_liquidate','value':scenario_value_list[24]},{'name':'scen.term_triggers_LTV_months','value':scenario_value_list[25]},{'name':'scen.term_triggers_LTV_loss','value':scenario_value_list[26]},{'name':'scen.term_triggers_activate_DSCR_trigger','value':scenario_value_list[27]},{'name':'scen.term_triggers_DSCR_liquidate','value':scenario_value_list[28]},{'name':'scen.term_triggers_DSCR_months','value':scenario_value_list[29]},{'name':'scen.term_triggers_DSCR_loss','value':scenario_value_list[30]},{'name':'scen.term_triggers_select_priority','value':scenario_value_list[31]},{'name':'scen.maturity_trigger_activate_LTV_trigger','value':scenario_value_list[32]},{'name':'scen.maturity_trigger_LTV_payoff','value':scenario_value_list[33]},{'name':'scen.maturity_trigger_LTV_liquidate','value':scenario_value_list[34]},{'name':'scen.maturity_trigger_LTV_loss','value':scenario_value_list[35]},{'name':'scen.maturity_trigger_LTV_extension','value':scenario_value_list[36]},{'name':'scen.maturity_trigger_LTV_end_of_extension_liq_or_payoff','value':scenario_value_list[37]},{'name':'scen.maturity_trigger_LTV_end_of_extension_loss','value':scenario_value_list[38]},{'name':'scen.maturity_trigger_activate_DY_trigger','value':scenario_value_list[39]},{'name':'scen.maturity_trigger_DY_payoff','value':scenario_value_list[40]},{'name':'scen.maturity_trigger_DY_liquidate','value':scenario_value_list[41]},{'name':'scen.maturity_trigger_DY_loss','value':scenario_value_list[42]},{'name':'scen.maturity_trigger_DY_extension','value':scenario_value_list[43]},{'name':'scen.maturity_trigger_DY_end_of_extension_liq_or_payoff','value':scenario_value_list[44]},{'name':'scen.maturity_trigger_DY_end_of_extension_loss','value':scenario_value_list[45]},{'name':'scen.maturity_trigger_select_priority','value':scenario_value_list[46]},{'name':'scen.servicer_basis','value':scenario_value_list[19]},{'name':'scen.servicer_rate','value':scenario_value_list[20]},{'name':'scen.servicer_type','value':scenario_value_list[21]},{'name':'scen.apply_loan_level_assumps','value':scenario_value_list[22]},{'name':'scen.call_option','value':scenario_value_list[48]},{'name':'scen.force_call','value':scenario_value_list[47]},{'name':'scen.call_date','value':scenario_value_list[49]});
          }
          else if (assetclass == 'CLO'){
            assumption_list.push({'name':'scen.run_flag','value':'checked'},{'name':'scen.scenType','value':'User Defined'},{'name':'analyticsCtrl.outputType','value':output_type},{'name':'scen.cal_first_loss','value':scenario_value_list[3]},{'name':'scen.settle_date','value':scenario_value_list[4]},{'name':'scen.forward_curve','value':scenario_value_list[5]},{'name':'scen.apply_watch','value':scenario_value_list[6]},{'name':'scen.prepay_rate','value':scenario_value_list[7]},{'name':'scen.prepay_type','value':scenario_value_list[8]},{'name':'scen.default_rate','value':scenario_value_list[9]},{'name':'scen.default_type','value':scenario_value_list[10]},{'name':'scen.loss_rate','value':scenario_value_list[11]},{'name':'scen.loss_type','value':scenario_value_list[12]},{'name':'scen.prinLossSeverityPctNonPerf','value':scenario_value_list[13]},{'name':'scen.rec_lag','value':scenario_value_list[14]},{'name':'scen.reinvest_price_type','value':scenario_value_list[16]},{'name':'scen.reinvest_price','value':scenario_value_list[15]},{'name':'scen.reinvest_pool','value':scenario_value_list[19]},{'name':'scen.reinvest_spread','value':scenario_value_list[17]},{'name':'scen.reinvest_term','value':scenario_value_list[18]},{'name':'scen.reinvDefaultLockout','value':scenario_value_list[20]},{'name':'scen.reinvest_rules','value':scenario_value_list[21]},{'name':'scen.call_option','value':scenario_value_list[23]},{'name':'scen.force_call','value':scenario_value_list[22]},{'name':'scen.call_date','value':scenario_value_list[24]},{'name':'scen.plus_minus_months','value':scenario_value_list[25]},{'name':'scen.call_price_type','value':scenario_value_list[26]},{'name':'scen.call_price','value':scenario_value_list[27]});
          }
          console.log('assumption:',assumption_list);

          var arg1 = parseInt(scenario_row) + 1;
          assumption_list.forEach(function(list_row) {
              console.log('setting:',list_row['name']);
              switch(list_row['name']){
                  case "scen.run_flag":
                      var check_flag = '(//md-checkbox[contains(@ng-model,"run_flag")])' + '[' + arg1 + ']';
                      browser.waitForVisible(check_flag,self.waitDefault);
                      var target_attribute = browser.getAttribute(check_flag, 'class');
                      console.log('target_attribute:',target_attribute);
                      if (list_row['value']=='checked'&&target_attribute.indexOf('ng-empty') > -1 ){
                          browser.click(check_flag);
                          browser.pause(100);
                      }else if (list_row['value'] == 'unchecked'&&target_attribute.indexOf('ng-not-empty')>-1) {
                          browser.click(check_flag);
                          browser.pause(100);
                      }
                      break;
                  case "scen.cal_first_loss":
                  case "scen.seed_default":
                  case "scen.ignore_input_nonpayment_term":
                  case "scen.calc_curve_off_static_bal":
                  case "scen.useACHVector":
                  case "scen.apply_watch": 
                  case "scen.apply_loan_level_assumps":
                  case 'scen.term_triggers_activate_LTV_trigger':
                  case 'scen.term_triggers_activate_DSCR_trigger':
                  case 'scen.maturity_trigger_activate_LTV_trigger':
                  case 'scen.maturity_trigger_activate_DY_trigger':
                      var check_box = '(' + cashflow_xpath.dealcfsCheckBox.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
                      console.log(check_box);
                      browser.waitForVisible(check_box,self.waitDefault);
                      var target_attribute = browser.getAttribute(check_box, 'class');
                      console.log(target_attribute);
                      if ((list_row['value']=='checked' || list_row['value']=='Either' || list_row['value']=='Both') && target_attribute.indexOf('ng-empty') > -1){
                          browser.click(check_box);
                          browser.pause(100);
                          expect(browser.getAttribute(check_box,'class').indexOf('ng-not-empty')>-1).toBe(true,check_box)
                      }
                      if ((list_row['value']=='unchecked' || list_row['value']=='Off' || list_row['value'] == 'NA') && target_attribute.indexOf('ng-not-empty')>-1) {
                          browser.click(check_box);
                          browser.pause(100);
                          expect(browser.getAttribute(check_box,'class').indexOf('ng-empty')>-1).toBe(true,check_box)
                        }if(list_row['value'].indexOf('Strat') > -1){
                          if(target_attribute.indexOf('ng-empty') > -1){
                            browser.click(check_box);
                            browser.pause(100);
                            expect(browser.getAttribute(check_box,'class').indexOf('ng-not-empty')>-1).toBe(true,check_box)
                          }
                          //Open Stratification
                          browser.click('//a[contains(text(),"Apply Stratification")]');
                          browser.waitForVisible('//table[contains(@id,"watchlist")]',self.waitDefault);
                          var stra_length = browser.elements('//*[contains(@ng-click,"assumpCtrl.deleteRule")]').value.length;
                          console.log('stra_length:',stra_length)
                          for(var strItem = 1; strItem <= stra_length; strItem++){
                            console.log('strItem:',strItem)
                            browser.click('(//*[contains(@ng-click,"assumpCtrl.deleteRule")])[1]');
                          }
                          var item_value = list_row['value'];
                          var count = 1;
                          for(var item_index in stratifications){
                            console.log('-----------------------------',stratifications[item_index]);
                            console.log('item_value',item_value)
                            var stratifications_settings = stratifications[item_index].split(',');
                            console.log('stratifications_settings[0]',stratifications_settings[0])
                            if(stratifications_settings[0]==item_value){
                              console.log('-----setting----')
                              // var stratifications_settings = stratifications[item_index].split(',');
                              console.log("stratifications_settings:",stratifications_settings);
                              set_stratification(stratifications_settings)
                              count++;
                            }
                          }
                          // close Stratifications
                          browser.click('//*[contains(@ng-click,"assumpCtrl.colWatchList = false")]');
                          self.stratifications_flag=true
                        }
                      break;
                  case "scen.solve_for":
                  case "scen.forward_curve":
                  case "scen.loss_type":
                  case "scen.delinquency_type":
                  case "scen.repay_type":
                  case "scen.purchase_type":
                  case "scen.portfolio_yield_type":
                  case "scen.portfolio_loss_type":
                  case "scen.deferment_type":
                  case "scen.grace_type":
                  case "scen.forbear_type":
                  case "scen.interest_cap_freq":
                  case "scen.BB_type":
                  case "scen.reinvest_price_type":
                  case "scen.reinvest_pool":
                  case "scen.reinvest_rules":
                  case "scen.call_option":
                  case "scen.force_call":
                  case "scen.call_price_type":
                  case "scen.prepay_type":
                  case "scen.default_type":
                  case "scen.NOI_growth_rate_type":
                  case "scen.cap_rate_growth_rate_type":
                  case "scen.term_triggers_select_priority":
                  case "scen.maturity_trigger_select_priority":
                  case 'scen.servicer_basis':
                  case 'scen.servicer_type':
                      if (list_row['value'] == "NA"){ 
                        break;
                      }
                      if (list_row['value'].indexOf('custom_rate')>-1){
                          list_row['value']='Custom'
                      }
                      var deal_CfSfpSelect = '(' + cashflow_xpath.dealCfSfpSelect.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
                      console.log(deal_CfSfpSelect);
                      browser.click(deal_CfSfpSelect);
                      browser.waitForVisible(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__',list_row['name']),self.waitDefault);
                      console.log('test')
                      console.log(cashflow_xpath.dealCfsDropDSelItem.replace('__NAME__',list_row['name']).replace('__ITEM__',list_row['value']))
                      browser.click(cashflow_xpath.dealCfsDropDSelItem.replace('__NAME__',list_row['name']).replace('__ITEM__',list_row['value']));
                      var selectValue = browser.getValue(deal_CfSfpSelect+'//input');
                      console.log('selectValue',selectValue);
                      expect(selectValue==list_row['value']).toBe(true,selectValue,list_row['value'])
                      // console.log(browser.getHTML(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__',list_row['name'])));
                      break;
                  case "analyticsCtrl.outputType":
                  case "analyticsCtrl.scenarioMethod":
                  case "analyticsCtrl.scenarioInput":
                      var deal_CfSfpSelect = cashflow_xpath.dealCfSfpSelect.replace('__NAME__',list_row['name']);
                      console.log(deal_CfSfpSelect);
                      browser.click(deal_CfSfpSelect);
                      browser.waitForVisible(cashflow_xpath.dealCfsSelDropDown.replace('__NAME__',list_row['name']),self.waitDefault);
                      browser.click(cashflow_xpath.dealCfsDropDSelItem.replace('__NAME__',list_row['name']).replace('__ITEM__',list_row['value']));
                      var selectValue = browser.getValue(deal_CfSfpSelect+'//input');
                      console.log('selectValue',selectValue);
                      expect(selectValue==list_row['value']).toBe(true,selectValue,list_row['value'])
                      break;
                  case "analyticsCtrl.scenarioMidPoint":
                  case "analyticsCtrl.scenarioStepSize":
                      var assumptions_input = cashflow_xpath.dealCfsInput.replace('__NAME__',list_row['name']);
                      browser.setValue(assumptions_input,list_row['value']);
                      console.log(browser.getValue(assumptions_input));
                      expect(assumptions_input==list_row['value']).toBe(true,assumptions_input,list_row['value'])
                      break;
                  case "scen.scenType":
                      var sentypeSelect = '(' + cashflow_xpath.mdSelect.replace('__NAME__',list_row['name'])  + ')[' + arg1 + ']';
                      browser.click(sentypeSelect);
                      var select_item = content_xpath.namedSelectItem.replace('__NAME__', list_row['value']);
                      console.log(select_item);
                      browser.waitForVisible(select_item,self.waitDefault);
                      browser.click(select_item);
                      break;
                  // // case "scen.NOI_growth_rate_type":
                  // // case "scen.cap_rate_growth_rate_type":
                  // // case "scen.term_triggers_select_priority":
                  // // case "scen.maturity_trigger_select_priority":
                  // // case "scen.servicer_basis":
                  // case "scen.servicer_type":
                  // // case "scen.apply_loan_level_assumps":
                  //   // Select field of select ng-model
                  //   var assumptions_select = '(' + cashflow_xpath.dealCfsSelect.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
                  //   console.log(assumptions_select);
                  //   browser.selectByVisibleText(assumptions_select, list_row['value']);
                  //   console.log(browser.getText(assumptions_select));
                  // break;
                  case "scen.settle_date":
                  case "scen.prepay_rate":
                  case "scen.default_rate":
                  case "scen.loss_rate":
                  case "scen.delinquency_rate":
                  case "scen.adv_loss_rate":
                  case "scen.adv_lag_mon":
                  case "scen.repay_rate":
                  case "scen.purchase_rate":
                  case "scen.portfolio_yield_rate":
                  case "scen.portfolio_loss_rate":
                  case "scen.deferment_rate":
                  case "scen.grace_rate":
                  case "scen.forbear_rate":
                  case "scen.BB_utilization_rate":
                  case "scen.subsidy_payment_delay":
                  case "scen.SAP_payment_delay":
                  case "scen.prinLossSeverityPctNonPerf":
                  case "scen.rec_lag":
                  case "scen.alloc_mon":
                  case "scen.reinvest_price":
                  case "scen.reinvDefaultLockout":
                  case "scen.NOI_growth_rate":
                  case "scen.cap_rate_growth_rate":
                  case "scen.term_triggers_LTV_liquidate":
                  case "scen.term_triggers_LTV_months":
                  case "scen.term_triggers_LTV_loss":
                  case "scen.term_triggers_DSCR_liquidate":
                  case "scen.term_triggers_DSCR_months":
                  case "scen.term_triggers_DSCR_loss":
                  case "scen.maturity_trigger_LTV_payoff":
                  case "scen.maturity_trigger_LTV_liquidate":
                  case "scen.maturity_trigger_LTV_loss":
                  case "scen.maturity_trigger_LTV_extension":
                  case "scen.maturity_trigger_LTV_end_of_extension_liq_or_payoff":
                  case "scen.maturity_trigger_LTV_end_of_extension_loss":
                  case "scen.maturity_trigger_DY_payoff":
                  case "scen.maturity_trigger_DY_liquidate":
                  case "scen.maturity_trigger_DY_loss":
                  case "scen.maturity_trigger_DY_extension":
                  case "scen.maturity_trigger_DY_end_of_extension_liq_or_payoff":
                  case "scen.maturity_trigger_DY_end_of_extension_loss":
                  case "scen.servicer_rate":
                  case "scen.call_date":
                  case "scen.reinvest_spread":
                  case "scen.reinvest_term":
                  case "scen.call_price":
                  case "scen.plus_minus_months":
                      //Input field with ng-model
                      if (list_row['value'] == 'NA' || list_row['value'] == 'N/A'){
                          break;
                      }
                      else if(list_row['value'] == 'current date' || list_row['value']=='Current Date'){
                          var assumptions_input = '(' + cashflow_xpath.dealCfsInput.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
                          browser.click(assumptions_input);
                          var today = cashflow_xpath.settleDateToday;
                          browser.click(today);
                          // console.log("has set " + list_row['name'] + " to " + list_row['value']);
                          console.log(browser.getValue(assumptions_input));
                          var date = browser.getValue(assumptions_input);
                          date = date.replace(/-/g,'/');
                          var date = new Date(date);
                          date.setDate(date.getDate() - 2);
                          var new_date = dateFormat(date,"yyyy-mm-dd");
                          console.log(new_date);
                          browser.setValue(assumptions_input,new_date);
                          console.log("has set " + list_row['name'] + " to " + new_date);
                          break;
                      }
                      else{
                          var assumptions_input = '(' + cashflow_xpath.dealCfsInput.replace('__NAME__',list_row['name']) + ')[' + arg1 + ']';
                          browser.setValue(assumptions_input,list_row['value']);
                          console.log("has set " + list_row['name'] + " to " + list_row['value']);
                          var input_value = browser.getValue(assumptions_input)
                          console.log(input_value);
                          expect(input_value==list_row['value']).toBe(true,input_value,list_row['value'])
                          break;
                      }
              }
          });
      }
        this.scenario_list = scenario_list;
  })
}

