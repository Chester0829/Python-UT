//Recommended filename : Then_I_use_API_to_get_IndexRate_for_the_date_above_to_calculate_spread.js
module.exports = function() {
    this.Then(/^I use API to get IndexRate for the date above to calculate spread$/, function () {
        // Write code here that turns the phrase above into concrete actions

        console.log(this.settles_date); 
        var temp = this.settles_date.split("/"); 
        temp = temp[2]+temp[0]+temp[1];
        console.log(temp); 

        var token = this.api_session.getLicense(this.test_user);
        this.token = token;
        var fxRates = this.api_session.getFxRates(token);
        this.fxRates = fxRates;

        var results = this.api_session.getIndexRates(this.settles_date, this.token, this.fxRates);
        var getIndexRates_index = results['indexRates'][0]['treasury'];
        // console.log(getIndexRates_index);
        this.getIndexRates_index = getIndexRates_index;
        var getIndexRates_swap = results['indexRates'][0]['swap'];
        // console.log(getIndexRates_swap);
        this.getIndexRates_swap = getIndexRates_swap;    
    });
}; 