 //Then_I_save_the_#_ Yield and IRR results and convert them to json.js
 module.exports = function(){ 
   this.Then(/^I save the (one tranche basic|basic|multiple) Yield and IRR (results|clickwrap results|visitor-clickwrap results) and convert them to json$/, 
      { timeout: process.env.StepTimeoutInMS * 10 },
      function (saveType,pageType,table) { 
     this.browser_session.waitForResource(browser);
     var fs = require("fs");
     var path = require('path');
     var run_particular_tranche = table.hashes()[0]["run_particular_tranche"];
     var irr_purchase_date = table.hashes()[0]["irr_purchase_date"];
     const cashflow_xpath = this.xpath_lib.xpathRequire("cashflow_xpath");
     const content_xpath = this.xpath_lib.xpathRequire("content_xpath");
     var resultTable = {};
     var panelName = "Results";
     var self = this;
     var myPanel = content_xpath.titledSectionLowercase.replace("__TITLE__", panelName.toLowerCase());
     var cf_scenario_list = this.scenario_list;
     var cf_scenario_list_length = cf_scenario_list.length;
     var cf_scenarios_used = this.scenarios_used;
     var yield_id = 'price_001';
     var irr_id = 'IRR_001';
     var timeOut = 60*1000;
     var deal_name_xpath = '//div[@class="module-name-banner-name"]/div[@class="inline-block"]';
     browser.waitForVisible(deal_name_xpath, this.waitDefault);
     console.log(browser.isVisible(deal_name_xpath));
     var deal_name = browser.getText(deal_name_xpath);
     console.log(deal_name);

     if(saveType == 'multiple'){
       yield_id = this.yield_settingId;
       irr_id =  this.irr_settingId;

     }

     if(yield_id.indexOf('price')>-1){
       var yield_input_key = 'price'
       var yield_result_key = 'dm/yield'
       var yield_reuslt_dm_key = 'dm'
       var yield_result_yield_key = 'yield'
     }else{
       var yield_input_key = 'dm (bps)'
       var yield_result_key = 'price'
     }
     console.log('yield_result_key:'+yield_result_key)
     if(yield_id.indexOf('price')>-1){
     console.log('yield_reuslt_dm_key:'+yield_reuslt_dm_key)
    }
     console.log('this.scenario_used:', cf_scenarios_used);
     console.log('cf_scenario_list_length',cf_scenario_list_length);
     var tranche_select_box = content_xpath.titledSectionLowercase.replace("__TITLE__", panelName.toLowerCase()) + "// select";
     var tranche_select_xpath = tranche_select_box + "// option";
     console.log("tranche_select_xpath:", tranche_select_xpath);
     var tranche_name = browser.getValue(tranche_select_box);
     console.log('default tranche_name' + tranche_name);
     var sfwdealID = tranche_name.split('.')[0];

     var myTable = myPanel + content_xpath.descendantDataTable;
     console.log('myTable: '+myTable);
     var myYieldTableElement = '(' + myTable + ')[1]';
     var myTrancheStatisticsElement = '(' + myTable + ')[2]';
      var tranche_count = browser.selectorExecute(tranche_select_xpath, function (selects) {
           return selects.length;
       });
       console.log("tranche_count:", tranche_count);
       // select all tranche
       var full_scenarios_list = {};
       // var tranche_lists = [];
       var file_scen_name = '';
       console.log('cf_scenario_list.length',cf_scenario_list.length);
       /////////////////create json template /////////////////////////////
       console.log('--------------------------Create json template ----------------------------------')
       for (var scenIndex = 1; scenIndex <= cf_scenario_list.length; scenIndex++) {
          var scenario_id = cf_scenario_list[scenIndex - 1]["scenario_id"];
          var settles_date = cf_scenarios_used[scenario_id][4];
          full_scenarios_list[scenario_id]={};
          full_scenarios_list[scenario_id]["Yield Table"]=[];
          full_scenarios_list[scenario_id]["Tranche Statistics"]=[];
          file_scen_name = file_scen_name + '_' + scenario_id;
        }
        console.log('full_scenarios_list default',full_scenarios_list)

       /////////////////save all tranche all scenarios json ////////////////
       // var tranche_count = 1;
       if(run_particular_tranche!='All'){
         tranche_count = 1
       }
       for (var tranche_index = 0; tranche_index < tranche_count; tranche_index++) {
          // select tranche
          if(run_particular_tranche!='All'){
           browser.selectByVisibleText(tranche_select_box,run_particular_tranche)
           var tranche_name = run_particular_tranche;
           sfwdealID = tranche_name.split('.')[0];
           var class_name = tranche_name.split('.')[1];
          }else{
           browser.selectByIndex(tranche_select_box, tranche_index);
           var tranche_name = browser.getValue(tranche_select_box);
           sfwdealID = tranche_name.split('.')[0];
           var class_name = tranche_name.split('.')[1];
          } 
          console.log("current_tranche_name:", tranche_name);
          var runningBar = '//*[contains(@ng-if,"analyticsCtrl.priceYieldRunning")]';
                   //wait first loss caculate end
          try {
             browser.waitForExist(runningBar,2000);
             browser.waitForVisible(runningBar,2000);
             this.browser_session.waitForLoading(browser,runningBar,1000,timeOut);
         }catch (e) {
           console.log(e);
         }
         // self.browser_session.waitForResource(browser, myTable, 200);
         if(yield_id=='price_001'){
           var price_input = '//table[contains(@class,"yieldTable")]//input'
           console.log('*****step******:',browser.getValue('('+price_input+')[1]'))
           console.log('*****step******:',browser.getValue('('+price_input+')[2]'))
           if(browser.getValue('('+price_input+')[1]')!='100'||browser.getValue('('+price_input+')[2]')!='100'){
             browser.setValue('('+price_input+')[1]','100')
             browser.setValue('('+price_input+')[2]','100')
             expect(browser.getValue('('+price_input+')[1]')).toEqual('100')
             expect(browser.getValue('('+price_input+')[2]')).toEqual('100')
             browser.click("//*[text()='Run Price/Yield Table']")
             var runningBar = '//*[contains(@ng-if,"analyticsCtrl.priceYieldRunning")]';
             var timeOut = 60*1000;
             try {
               browser.waitForExist(runningBar,1000);
               browser.waitForVisible(runningBar,1000);
               this.browser_session.waitForLoading(browser,cashflow_xpath.runningBar,1000,timeOut);
             }catch (e) {
               console.log(e);
             }
           }
         }

         ///////////Set IRR value////////////////
         console.log('self.irr_value_list:',self.irr_value_list)
         if(self.irr_value_list == null || self.irr_value_list == undefined){
           irr_id = 'IRR_001'
           // var irr_input_xpath2='//table[contains(@class,"trancheStatsTable")]//tr[14]//input';
           // try{ 
           //   browser.waitForVisible(irr_input_xpath2,self.wait10)
           //   browser.waitForEnabled(irr_input_xpath2,self.wait10)
           //   self.browser_session.waitForResource(browser,irr_input_xpath2,2000);
           //   }catch(e){
           //   console.log(e)
           // }
           // if(self.browser_session.elementAllVisible(browser,irr_input_xpath2)!=true){
           //  var element_len=browser.elements(irr_input_xpath2).value.length
           //  for(var i=1;i<=element_len;i++){
           //    var wait_element= '(' + irr_input_xpath2+')['+i+']'
           //    browser.waitForVisible(wait_element,self.wait10)
           //  }
           //  self.browser_session.waitForResource(browser,irr_input_xpath2,2000);
           // }
         }else{
           if (self.irr_value_list[3]!='default value') {
             var irr_input_xpath1='(//table[contains(@class,"trancheStatsTable")]//tr[13]//input)[1]';
             console.log('watiVisible')
             browser.waitForVisible(irr_input_xpath1,self.waitDefault);
             console.log('waitVisible end')
             browser.waitForEnabled(irr_input_xpath1,self.waitDefault);
             browser.setValue(irr_input_xpath1,self.irr_value_list[3]);
             self.browser_session.waitForResource(browser,irr_input_xpath1,2000)
             var irr_input1_value = browser.getValue(irr_input_xpath1)
             if(irr_input1_value!=self.irr_value_list[3]){
               console.log('irr_input1_value set fail, set again')
               browser.setValue(irr_input_xpath1,self.irr_value_list[3]);
               expect(browser.getValue(irr_input_xpath1)).toEqual(irr_value_list[3])
             }
           }
           var irr_input_xpath2='(//table[contains(@class,"trancheStatsTable")]//tr[14]//input)[1]';
           try{
             browser.waitForVisible(irr_input_xpath2,self.wait10)
             browser.waitForEnabled(irr_input_xpath2,self.wait10)
             self.browser_session.waitForResource(browser,irr_input_xpath2,2000);
             // console.log(self.irr_value_list[4]);
             browser.setValue(irr_input_xpath2,self.irr_value_list[4]);
             self.browser_session.waitForResource(browser,irr_input_xpath1,2000)
             var irr_input2_value=browser.getValue(irr_input_xpath2)
             if(irr_input2_value!=self.irr_value_list[4]){
               console.log('irr_input2_value set fail, set again')
               browser.waitForVisible(irr_input_xpath2,self.wait10)
               browser.waitForEnabled(irr_input_xpath2,self.wait10)
               self.browser_session.waitForResource(browser,irr_input_xpath2,2000);
               browser.setValue(irr_input_xpath2,self.irr_value_list[4]);
               expect(browser.getValue(irr_input_xpath2)).toEqual(irr_value_list[4])
             }
           }catch(e){
             console.log(e);
           }
           console.log('click aaa');
           var irr_value_elem = '(//table[contains(@class,"trancheStatsTable")])[1]';
           browser.click(irr_value_elem);
           self.browser_session.waitForResource(browser,myTable,5000);
         }
         var fistLossRunning='//span[contains(@ng-if,"analyticsCtrl.firstLossPrinRunning")]'
         var firstLossIntRunning = '//span[contains(@ng-if,"analyticsCtrl.firstLossIntRunning")]'
         try{
          if(browser.isVisible(fistLossRunning)||browser.isVisible(firstLossIntRunning)){
            console.log('wait first loss loading');
            this.browser_session.waitForLoading(browser,fistLossRunning,1000,2*timeOut);
            this.browser_session.waitForLoading(browser,firstLossIntRunning,1000,2*timeOut);
          }
          }catch (e){
            console.log(e);
          }
          self.browser_session.waitForResource(browser,myYieldTableElement+"//tbody",2000);
          self.browser_session.waitForResource(browser,'//table[contains(@class,"trancheStatsTable")]//tr[15]//td',2000);
          ///////////////// get all YieldTable data////////////////////////
         console.log('--------get all YieldTable data and get all Tranche Statistics table start----------')
         var waitYieldelement = myYieldTableElement+"//tbody//tr[3]//td[3]"
         try{
          browser.waitForText(waitYieldelement,self.wait15)
         }catch(e){
          console.log(e)
         } 

        if (saveType.indexOf('basic')>-1){
          console.log('Change IRR Purchase Date to 2019-03-29');
          console.log(irr_purchase_date);
          var irr_purchase_date_path = cashflow_xpath.purchaseDateInput;
          //Change the IRR Purchase Date
          try{
             browser.waitForVisible(irr_purchase_date_path,self.wait10);
             browser.waitForEnabled(irr_purchase_date_path,self.wait10);
             self.browser_session.waitForResource(browser,irr_purchase_date_path,2000);
             // console.log(self.irr_value_list[4]);
             browser.setValue(irr_purchase_date_path,irr_purchase_date);
             self.browser_session.waitForResource(browser,irr_input_xpath1,2000)
             var irr_date_value=browser.getValue(irr_purchase_date_path);
             if(irr_date_value!=irr_purchase_date){
               console.log('irr_date_value set fail, set again');
               browser.waitForVisible(irr_purchase_date_path,self.wait10);
               browser.waitForEnabled(irr_purchase_date_path,self.wait10);
               self.browser_session.waitForResource(browser,irr_purchase_date_path,2000);
               browser.setValue(irr_purchase_date_path,irr_purchase_date);
               expect(browser.getValue(irr_purchase_date_path)).toEqual(irr_purchase_date);
             }
             browser.click(cashflow_xpath.purchaseDateLabel);
             browser.pause(5000);
           }catch(e){
             console.log(e);
           }
        }
         
         var myYiledTable=self.browser_session.waitForTextChange(browser,myYieldTableElement+"//tbody//tr",self.tranche_YieldTable)
         // var myYiledTable = browser.getText(myYieldTableElement+"//tbody//tr");
         self.tranche_YieldTable = myYiledTable;
         console.log(myYiledTable);
         console.log(myYiledTable.length)
         var myYiledTableArray = [];
         for (var yield_index = 2; yield_index< myYiledTable.length; yield_index++){
           var str = myYiledTable[yield_index].replace(/ \/ /g,"/");
           // console.log('str:',str)
           var yield_value = str.split(' ');
           myYiledTableArray.push(yield_value);
           var yield_element = myYieldTableElement + '//tbody'+'//tr['+(yield_index+1)+']//td[1]//input'
           if(saveType == 'multiple' && self.yield_value_list[4]=='Y'){             
             myYiledTableArray[(yield_index-2)].unshift(browser.getValue(yield_element))
           }else if(yield_index == 5){
              myYiledTableArray[(yield_index-2)].unshift(browser.getValue(yield_element))
           }
         }

         // var price_element = myYieldTableElement+'//tbody'+'//tr[6]'+'//td[1]'+'//input';
         // myYiledTableArray[3].unshift(browser.getValue(price_element));
         console.log('myYiledTableArray:',myYiledTableArray);

         ////////////get all Tranche Statistics table/////////////////////
         var myTrancheStatisticsIRR=self.browser_session.waitForTextChange(browser,myTrancheStatisticsElement+"//tbody//tr[15]",self.trancheStatisticsIRR)
         self.trancheStatisticsIRR = myTrancheStatisticsIRR;
         var myTrancheStatistics = browser.getText(myTrancheStatisticsElement+"//tbody//tr");
         console.log(myTrancheStatistics);
         console.log(myTrancheStatistics.length)
         var myTrancheStaticArray = [];
         for (var static_index = 1; static_index< myTrancheStatistics.length; static_index++){
           if(myTrancheStatistics[static_index].indexOf('N/A')!= -1){
             var static_title_tmp = myTrancheStatistics[static_index].replace(/N\/A/g,'').replace(/\d{1,2}\/\d{4}/g,'').replace(/(\s*$)/g,'');
             console.log(myTrancheStatistics[static_index]);
             console.log('static_title_tmp:',static_title_tmp);
             var static_title = [];
             static_title.push(static_title_tmp);
           }else{
             var static_title = /^\D+(?=( (\-?)\d))/.exec(myTrancheStatistics[static_index]);
           }
           var static_value=[];
           if (static_title == null){static_value.push(myTrancheStatistics[static_index])
           }else{
                 var static_value_str = myTrancheStatistics[static_index].replace(static_title[0],'').trim();
                 var static_value = static_value_str.split(' ');
                static_value.unshift(static_title[0]);
           }
           console.log(static_value);
           myTrancheStaticArray.push(static_value);
         }
         var irrDate_element = myTrancheStatisticsElement+'//tbody'+'//tr[13]'+'//input';
         try{
           var irrDate = browser.getValue(irrDate_element);
         }catch (e){
           var irrDate = '';
         }
         // var irrDate = browser.getValue(irrDate_element);
         var irrDateArray = [];
         if(typeof(irrDate)=='string'){
           irrDateArray.push(irrDate);
         }else{
           irrDateArray=irrDate;
         }
         irrDateArray.unshift('Purchase Date (IRR)');
         console.log('irrDateArray:',irrDateArray);
         console.log('irrDateArray length:',irrDateArray.length);
         myTrancheStaticArray[11]=irrDateArray;
         var irrPrice_element = myTrancheStatisticsElement + '//tbody' + '//tr[14]'+'//input';
         try{
           var irrPrice = browser.getValue(irrPrice_element);
         }catch (e){
           var irrPrice = '';
         }
         // var irrPrice = browser.getValue(irrPrice_element);
         var irrPriceArray = [];
         if(typeof(irrPrice)=='string'){
           irrPriceArray.push(irrPrice);
         }else{
           irrPriceArray=irrPrice;
         }
         irrPriceArray.unshift('Purchase Price (IRR)');
         console.log(irrPriceArray);
         myTrancheStaticArray[12]=irrPriceArray;
         console.log('myTrancheStaticArray:',myTrancheStaticArray);

         for (var scen_index = 1; scen_index <= cf_scenario_list_length; scen_index++) {
           var scenario_id = cf_scenario_list[scen_index - 1]["scenario_id"];
             console.log('scenario_id two:',scenario_id);
             console.log('self.assettype:',self.assettype)
             if (self.assettype == 'CLO'){
               var settles_date = cf_scenarios_used[scenario_id][4];
             }else{
               var settles_date = cf_scenarios_used[scenario_id][5];
             }
             self.browser_session.waitForResource(browser, myTable, 200);
             console.log('--------------------------1. generate json file for Yield Table start ----------------------------------')
             if(run_particular_tranche=='All'){
              var scen_lists = [];
              for(var yield_index = 0; yield_index< myYiledTableArray.length; yield_index++){
               var yieldItem={};
               var price_value = myYiledTableArray[yield_index][0];
               yieldItem[yield_input_key]= price_value;
               console.log('yield_result_key*************'+yield_result_key)
               if (myYiledTableArray[yield_index].length<2||myYiledTableArray[yield_index][scen_index]==undefined){
                if(yield_result_key=='dm/yield'){
                  console.log('yield_reuslt_dm_key***'+yield_reuslt_dm_key)
                   yieldItem[yield_reuslt_dm_key]='';
                   yieldItem[yield_result_yield_key]='';
                }else{
                   yieldItem[yield_result_key] = '';
                }
                 
               }else{
                if(yield_result_key=='dm/yield'){
                  yieldItem[yield_reuslt_dm_key] = myYiledTableArray[yield_index][scen_index].split('/')[0]
                  yieldItem[yield_result_yield_key] = myYiledTableArray[yield_index][scen_index].split('/')[1]
                }else{
                  yieldItem[yield_result_key]= myYiledTableArray[yield_index][scen_index];
                }
               }
               scen_lists.push(yieldItem);
                // console.log('scen_lists',scen_lists);
               }
               var item = {"perfsummary": {},"result": {}};
               item["perfsummary"]["tranche_name"] = tranche_name;
               item["perfsummary"]["scenario_id"] = scenario_id;
               item["perfsummary"]["class"] = class_name;
               item["perfsummary"]["settles_date"] = settles_date;
               item["perfsummary"]["yield_id"] = yield_id;
               item["result"] = scen_lists;
             // console.log('item',item);
             full_scenarios_list[scenario_id]["Yield Table"].push(item);
            }else{
             var scen_lists = [];
             var price_value = myYiledTableArray[3][0]
             var yieldItem={}
             yieldItem[yield_input_key]= price_value;
             if (myYiledTableArray[3].length<2||myYiledTableArray[3][scen_index]==undefined){
                if(yield_result_key=='dm/yield'){
                 yieldItem[yield_reuslt_dm_key]='';
                 yieldItem[yield_result_yield_key]='';
               }else{
               yieldItem[yield_result_key] = '';
              }
            }else{
              if(yield_result_key=='dm/yield'){
                  yieldItem[yield_reuslt_dm_key] = myYiledTableArray[3][scen_index].split('/')[0]
                  yieldItem[yield_result_yield_key] = myYiledTableArray[3][scen_index].split('/')[1]
             }else{
                yieldItem[yield_result_key]= myYiledTableArray[3][scen_index];
              }
            }
               scen_lists.push(yieldItem);
               var item = {"perfsummary": {},"result": {}};
               var deal_name1 = deal_name.split(',')[0];
               item["perfsummary"]["tranche_name"] = deal_name1.toUpperCase() + '-' + class_name;
               item["perfsummary"]["scenario_id"] = scenario_id;
               item["perfsummary"]["settles_date"] = settles_date;
               item["perfsummary"]["yield_id"] = yield_id;
               item["result"] = scen_lists;
             // console.log('item',item);
             full_scenarios_list[scenario_id]["Yield Table"].push(item);
            }
             console.log('--------------------------1. generate json file for Yield Table end ----------------------------------')

             console.log('--------------------------1. generate json file for Tranche Statistics start ----------------------------------')
             var scen_lists = [];
             if(run_particular_tranche=='All'){
              for(var static_index = 0; static_index< myTrancheStaticArray.length; static_index++){
                var statiItem={};
                var static_key = myTrancheStaticArray[static_index][0];
                if (myTrancheStaticArray[static_index].length<2||myTrancheStaticArray[static_index][scen_index]==undefined){
                  statiItem[static_key] = '';
                }else{
                  statiItem[static_key]= myTrancheStaticArray[static_index][scen_index];
                  var myStaticValue = myTrancheStaticArray[static_index][scen_index];
                  if(static_key.indexOf('Principal Payment')>-1 && myStaticValue.indexOf('/')>-1 && myStaticValue.indexOf('N/A')<=-1){
                    var myStaticValue_tmp = myStaticValue.split("/");
                    if (myStaticValue_tmp[0].length == 1){
                      myStaticValue = myStaticValue_tmp[1] + "-0" + myStaticValue_tmp[0]; 
                    }
                    else{
                      myStaticValue = myStaticValue_tmp[1] + "-" + myStaticValue_tmp[0];
                    }
                    statiItem[static_key]= myStaticValue;
                    console.log('myStaticValue ddd:',myStaticValue);
                  }
                  if(static_key == "Purchase Date (IRR)" && myStaticValue == ""){
                    statiItem["Purchase Price (IRR)"] = "";
                    statiItem["IRR"] = "";
                  }
                }
                scen_lists.push(statiItem);
                console.log('scen_lists',scen_lists);
              }
              var item = {"perfsummary": {},"result": {}};
              item["perfsummary"]["tranche_name"] = tranche_name;
              item["perfsummary"]["scenario_id"] = scenario_id;
              item["perfsummary"]["class"] = class_name;
              item["perfsummary"]["settles_date"] = settles_date;
              item["perfsummary"]["irr_id"] = irr_id;
              item["result"] = scen_lists;
             // console.log('item',item);
             full_scenarios_list[scenario_id]["Tranche Statistics"].push(item);
            }else{
             var statiItem={};
             for(var static_index = 0; static_index< myTrancheStaticArray.length; static_index++){
              var static_key = myTrancheStaticArray[static_index][0];
              if(static_key.indexOf('First Loss')<=-1){
                if (myTrancheStaticArray[static_index].length<2||myTrancheStaticArray[static_index][scen_index]==undefined){
                  statiItem[static_key] = '';
                }else{
                var myStaticValue = myTrancheStaticArray[static_index][scen_index];
                if(static_key.indexOf('Principal Payment')<=-1&&static_key.indexOf('Date')<=-1){
                  myStaticValue=parseFloat(myStaticValue.replace(/,/g,'')).toFixed(2);
                  console.log('myStaticValue ttt:',myStaticValue);
                }
                if(static_key.indexOf('Principal Payment')>-1 && myStaticValue.indexOf('/')>-1 && myStaticValue.indexOf('N/A')<=-1){
                  var myStaticValue_tmp = myStaticValue.split("/");
                  if (myStaticValue_tmp[0].length == 1){
                    myStaticValue = myStaticValue_tmp[1] + "-0" + myStaticValue_tmp[0]; 
                  }
                  else{
                    myStaticValue = myStaticValue_tmp[1] + "-" + myStaticValue_tmp[0];
                  }
                  console.log('myStaticValue ddd:',myStaticValue);
                  statiItem[static_key]= myStaticValue;
                }
                if(static_key == "Purchase Date (IRR)" && myStaticValue == ""){
                  statiItem["Purchase Price (IRR)"] = "";
                  statiItem["IRR"] = "";
                }
               }
              }
             }
             scen_lists.push(statiItem);
             console.log('scen_lists',scen_lists);
             var item = {"perfsummary": {},"result": {}};
             var deal_name1 = deal_name.split(',')[0];
             item["perfsummary"]["tranche_name"] = deal_name1.toUpperCase() + '-' + class_name;
             item["perfsummary"]["scenario_id"] = scenario_id;
             item["perfsummary"]["settles_date"] = settles_date;
             item["perfsummary"]["irr_id"] = irr_id;
             item["result"] = scen_lists;
             // console.log('item',item);
             full_scenarios_list[scenario_id]["Tranche Statistics"].push(item);
            }
         console.log('--------------------------1. generate json file for Tranche Statistics end ----------------------------------')
         }
          console.log("full_scenarios_list",full_scenarios_list);            
    }
    if(run_particular_tranche!='All'){
      for(var key in full_scenarios_list){
        var one_scen_list = {}
        one_scen_list[key]=full_scenarios_list[key]
        console.log(one_scen_list)
        var file_name = deal_name1.toUpperCase() + '-' + class_name + '_' + key+'_' + yield_id + '_' + irr_id + '_' + settles_date;
        var file_path = path.join(process.env.HOME,'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res','portfolio_cashflow_in_deal_res');
        self.file_session.exportCfsResult(file_name, file_path, one_scen_list, 'json');
      }

    }else{
      var file_name = sfwdealID + '_' + file_scen_name+'_' + yield_id + '_' + irr_id + '_' + settles_date;
          if(pageType == 'clickwrap results'){
            var file_path = path.join(process.env.HOME,'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res','clickwrap_cashflow_res');
          }
          else if(pageType == 'visitor-clickwrap results'){
            var file_path = path.join(process.env.HOME,'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res','visitor_clickwrap_cashflow_res');
          }
          else{
            var file_path = path.join(process.env.HOME,'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res','deal_cashflow_res');
          }
          self.file_session.exportCfsResult(file_name, file_path, full_scenarios_list, 'json');
    }
    console.log(process.env.RunDealRequest)
    console.log(process.env.NODE_ENV)
    if (process.env.RunDealRequest == 'True' && process.env.NODE_ENV != 'Prod') {
    // if (process.env.RunDealRequest == 'True'&& process.env.NODE_ENV == 'Dev') {
      var pricing_debug_xpath = '//div[contains(@ng-show,"analyticsCtrl.showPricingDebug")]';
      var toggle_pricing_button = '//span[contains(text(),"Toggle Pricing Debug")]';
      if(!browser.isVisible(pricing_debug_xpath)){
        try {
          if (browser.isVisible(toggle_pricing_button)) {
            browser.click(toggle_pricing_button);
            browser.waitForVisible(pricing_debug_xpath, this.waitDefault);
          } else {
            console.log('click toggle output button failed');
          }
        } catch (e) {
          console.log('wait for run deal pricing debug information');
          browser.waitForVisible(pricing_debug_xpath, this.waitDefault);
        }
      }
      var pricing_json = browser.getText(pricing_debug_xpath);
      var price_file_name = file_name + '_pricing_debug';
      // console.log('pricing_json:',pricing_json);
      file_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res', 'pricing_debug');
      self.file_session.exportCfsResult(price_file_name, file_path, pricing_json, 'json');
      // console.log('run_deal_request:',run_deal_request);
      // 
      //Close pricing button
      browser.click(toggle_pricing_button);
      var irr_debug_xpath = '//div[contains(@ng-show,"analyticsCtrl.showIRRDebug")]';
      var toggle_irr_button = '//span[contains(text(),"Toggle IRR Debug")]';
      if(!browser.isVisible(irr_debug_xpath)){
        try {
          if (browser.isVisible(toggle_irr_button)) {
            browser.click(toggle_irr_button);
            browser.waitForVisible(irr_debug_xpath, this.waitDefault);
          } else {
            console.log('click toggle output button failed');
          }
        } catch (e) {
          console.log('wait for run deal irr debug information');
          browser.waitForVisible(irr_debug_xpath, this.waitDefault);
        }
      }
      var irr_json = browser.getText(irr_debug_xpath);
      var irr_file_name = file_name + '_irr_debug';
      // console.log('pricing_json:',pricing_json);
      // var run_deal_request = pricing_json.substring(pricing_json.indexOf("<runDealSettings"), pricing_json.indexOf("</RundealRequest>"));
      // file_path = '../../../cashflow_res' + '/run_deal_request';
      file_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res', "irr_debug");
      // file_path ='C:\\Users\\HuBa\\Projects\\CS-Structured-QA-SFPortal-G2\\CLOCFS\\Deal\\cashflow_res\\run_deal_request\\';
      self.file_session.exportCfsResult(irr_file_name, file_path, irr_json, 'json');

    }

   });
}