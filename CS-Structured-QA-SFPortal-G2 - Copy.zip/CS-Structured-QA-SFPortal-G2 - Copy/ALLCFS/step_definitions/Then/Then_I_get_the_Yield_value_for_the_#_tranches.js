//Recommended filename : Then_I_get_the_Yield_value_for_the_#_tranches.js
module.exports = function() {
    this.Then(/^I get the Yield value for the "([^"]*)" tranches$/, function (numberofTranche) {
        // Write code here that turns the phrase above into concrete actions
        const cashflow_xpath = this.xpath_lib.xpathRequire('cashflow_xpath');
        var tranche_summary_table = "("+cashflow_xpath.trancheSummaryTable+")[1]";

        this.browser_session.waitForResource(browser,tranche_summary_table);
         browser.getLocationInView(tranche_summary_table);
         expect(browser.isExisting(tranche_summary_table));

         var yield_values_in_portfolio = {};
         var row = tranche_summary_table + "/tbody/tr";
         var deal_name;
         var yield_value;
         for (var i = 1; i <= numberofTranche; i++){
             deal_name = browser.getText(row + '['+i+']/td[1]');
             console.log(deal_name);
             yield_value = browser.getText(row + '['+i+']/td[9]');
             console.log(yield_value);
             yield_values_in_portfolio[deal_name] = yield_value;
         }
         console.log(yield_values_in_portfolio);
         this.yield_values_in_portfolio = yield_values_in_portfolio;

    });
}; 