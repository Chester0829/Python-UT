 //Then_I_save_the_#_ Yield_and_IRR_results_in_portfolio_and_convert_them_to_json.js
 module.exports = function(){ 
   this.Then(/^I save the (basic|multiple) Yield and IRR results in portfolio and convert them to json$/, 
      { timeout: process.env.StepTimeoutInMS * 10 },
      function (saveType, table) { 
     this.browser_session.waitForResource(browser);
     const dateFormat = require('dateformat');
     var fs = require("fs");
     var path = require('path');
     const cashflow_xpath = this.xpath_lib.xpathRequire("cashflow_xpath");
     const content_xpath = this.xpath_lib.xpathRequire("content_xpath");
     var irr_purchase_date = table.hashes()[0]["irr_purchase_date"];
     var totalWaitTime = 5 * 30 * 1000;
     var resultTable = {};
     var panelName = "Results"; 
     var self = this;
     var myPanel = content_xpath.titledSectionLowercase.replace("__TITLE__", panelName.toLowerCase());
     var cf_scenario_list = this.scenario_list;
     var cf_scenario_list_length = cf_scenario_list.length;
     var cf_scenarios_used = this.scenarios_used;
     var yield_id = 'price_001';
     var irr_id = 'IRR_001';
     var timeOut = 60*1000;
     console.log('this.scenario_used:', cf_scenarios_used);
     console.log('cf_scenario_list_length',cf_scenario_list_length);
     var tranche_summary_table = "("+cashflow_xpath.trancheSummaryTable+")[1]";
     var cashflow_process_bar = content_xpath.tableWaitline;
     var cf_progress_status = cashflow_xpath.cashflowProcess;
     var run_button = '//button[text()="Run Cashflows"]';
     var output_element = '//*[@ng-model="cash.output_type"]';

     if(browser.getText('//*[@ng-model="cash.output_type"]//div')!='DM / Yield'){
            ////// change to dm/yield mode and rerun/////////
        browser.click(output_element);
        var dmYield_element = '//*[@value="DISCOUNTMARGIN"]';
        browser.waitForVisible(dmYield_element,this.waitDefault);
        browser.click(dmYield_element);
        if(!browser.isVisible(cashflow_xpath.portfolioCashflowAssumption)){
          console.log('isVisible not');
          browser.click('//*[@class="sfp-card-title" and contains(@ng-click,"Assumptions")]');
        }
        console.log('show assumptions');
        browser.waitForVisible(cashflow_xpath.portfolioCashflowAssumption,this.waitDefault)

        ////Enter price value to all tranche
        browser.click('//*[text()="Select All"]');
        var assumptions_tr = cashflow_xpath.portfolioCashflowAssumption+'//table//tbody//tr';
        var price_all_element = assumptions_tr+'//*[@ng-model="tranche.price"]';
        var assumptions_tr_length = browser.elements(price_all_element).value.length;
        for (var i = 1; i<=assumptions_tr_length;i++) {
          var price_element = '('+assumptions_tr+'//*[@ng-model="tranche.price"])['+i+']'
          browser.setValue(price_element,'100');
          except(browser.getValue(price_element)).toEqual('100')
        }

        browser.click(run_button);
        this.browser_session.waitVisible(browser,cashflow_process_bar);
        this.browser_session.waitForLoading(browser,cashflow_process_bar,1000,totalWaitTime);
        this.browser_session.waitVisible(browser,cf_progress_status,this.waitDefault);
        this.browser_session.waitForLoading(browser, cf_progress_status, 1000,totalWaitTime);
      }
      this.browser_session.waitForResource(browser,tranche_summary_table);
      browser.getLocationInView(tranche_summary_table);
      expect(browser.isExisting(tranche_summary_table));

    var table_html;
    table_html = browser.getHTML(tranche_summary_table);
    var tranche_summary_table_json = this.tabletojson.convert(table_html)[0];
    expect(tranche_summary_table_json).not.toBe(null);
    console.log(tranche_summary_table_json);
    console.log(tranche_summary_table_json.length);
    var all_tranche_list = [];
    // var file_scen_name = '';
     for (var summaryIndex = 0; summaryIndex < tranche_summary_table_json.length; summaryIndex++) {
        var full_scenarios_list = {};
        var scenario_id = cf_scenario_list[0]["scenario_id"];
        // var settles_date = cf_scenarios_used[scenario_id][4];
        console.log('self.assettype:',self.assettype)
        if (self.assettype == 'CLO'){
          var settles_date = cf_scenarios_used[scenario_id][4];
        }else{
          var settles_date = cf_scenarios_used[scenario_id][5];
        }
        full_scenarios_list[scenario_id]={};
        full_scenarios_list[scenario_id]["Yield Table"]=[];
        full_scenarios_list[scenario_id]["Tranche Statistics"]=[];
        console.log('--------------------------1. generate json file for Yield Table start ----------------------------------');
        var item = {"perfsummary": {},"result": {}};
        item["perfsummary"]["tranche_name"] = tranche_summary_table_json[summaryIndex]["ISIN"];
        item["perfsummary"]["scenario_id"] = scenario_id;
        // item["perfsummary"]["class"] = class_name;
        item["perfsummary"]["settles_date"] = settles_date;
        item["perfsummary"]["yield_id"] = yield_id;
        console.log('item',item);
        // full_scenarios_list[scenario_id]["Tranche Statistics"].push(item);
        var scen_lists = [];
        var yieldItem={};
        yieldItem['price']=tranche_summary_table_json[summaryIndex]["Price"];
        yieldItem['dm']=tranche_summary_table_json[summaryIndex]["DM (%)"]
        yieldItem['yield']=tranche_summary_table_json[summaryIndex]["Yield (%)"]
        // yieldItem['dm/yield']=tranche_summary_table_json[summaryIndex]["DM (%)"]+'/'+tranche_summary_table_json[summaryIndex]["Yield (%)"];
        scen_lists.push(yieldItem);
        item["result"] = scen_lists;
        full_scenarios_list[scenario_id]["Yield Table"].push(item);

        console.log('--------------------------1. generate json file for Tranche Statistics except IRR start ----------------------------------');
        var item = {"perfsummary": {},"result": {}};
        item["perfsummary"]["tranche_name"] = tranche_summary_table_json[summaryIndex]["ISIN"]
        item["perfsummary"]["scenario_id"] = scenario_id;
        item["perfsummary"]["settles_date"] = settles_date;
        item["perfsummary"]["irr_id"] = irr_id;
        var scen_lists = [];
        // var statiItem={};

        for(var static_key in tranche_summary_table_json[summaryIndex]){
          if(static_key == 'Average Life'){
            break;
          }
          delete tranche_summary_table_json[summaryIndex][static_key];
        }
        console.log("--------------------------");
        console.log(tranche_summary_table_json[summaryIndex]);
        for(var static_key in tranche_summary_table_json[summaryIndex]){
          console.log("static_key:"+static_key);
          if(static_key.indexOf('Principal Payment')>-1 && tranche_summary_table_json[summaryIndex][static_key].indexOf('/')>-1 && tranche_summary_table_json[summaryIndex][static_key].indexOf('N/A')<=-1){
            console.log("change the date format for Principal Payment");
            var tmp = tranche_summary_table_json[summaryIndex][static_key].split("/");
            if (tmp[0].length == 1){
              tranche_summary_table_json[summaryIndex][static_key] = tmp[1] + "-0" + tmp[0]; 
            }
            else{
              tranche_summary_table_json[summaryIndex][static_key] = tmp[1] + "-" + tmp[0];
            }
            console.log('tranche_summary_table_json[summaryIndex][static_key] ddd:',tranche_summary_table_json[summaryIndex][static_key]);
          }
        }
        scen_lists.push(tranche_summary_table_json[summaryIndex]);
        console.log('scen_lists:',scen_lists);
        item["result"]=scen_lists;
        console.log('item',item);
        full_scenarios_list[scenario_id]["Tranche Statistics"].push(item);

        console.log('full_scenarios_list:',full_scenarios_list[scenario_id]["Tranche Statistics"][0]["perfsummary"]);

        all_tranche_list.push(full_scenarios_list);
      }
      console.log('all_tranche_list default',all_tranche_list);
      console.log(all_tranche_list[0][scenario_id]["Tranche Statistics"][0]["perfsummary"]);
      console.log(all_tranche_list[1][scenario_id]["Tranche Statistics"][0]["perfsummary"]);


     // Get IRR Value:
                 ////// change to dm/yield mode and rerun/////////
      console.log('--------------------------1. change to IRR mode and rerun ----------------------------------');
      browser.click(output_element);
      var IRR_element = '//*[@value="IRR"]';
      browser.waitForVisible(IRR_element,this.waitDefault);
      browser.click(IRR_element);
      if(!browser.isVisible(cashflow_xpath.portfolioCashflowAssumption)){
        console.log('isVisible not');
        browser.click('//*[@class="sfp-card-title" and contains(@ng-click,"Assumptions")]');
      }
      console.log('show assumptions');
      browser.waitForVisible(cashflow_xpath.portfolioCashflowAssumption,this.waitDefault);

      ////Enter price value to all tranche
      browser.click('//*[text()="Select All"]')
      var assumptions_tr = cashflow_xpath.portfolioCashflowAssumption+'//table//tbody//tr';
      var all_buy_date_element = assumptions_tr + '//*[@ng-model="tranche.buy_date"]';
      var assumptions_tr_length = browser.elements(all_buy_date_element).value.length;
      console.log(assumptions_tr_length);
      //Set IRR Date
      for (var i = 1; i<=assumptions_tr_length;i++) {
        var buyDate_element = '('+assumptions_tr+'//*[@ng-model="tranche.buy_date"])['+i+']';
        // var date = browser.getValue(buyDate_element);
        // date = date.replace(/-/g,'/');
        // var date = new Date(date);
        // date.setDate(date.getDate() + 1);
        // var new_date = dateFormat(date,"yyyy-mm-dd");
        // console.log(new_date);
        // console.log(typeof(new_date));
        console.log(buyDate_element);
        browser.setValue(buyDate_element,irr_purchase_date);
        expect(browser.getValue(buyDate_element)).toEqual(irr_purchase_date);
        var buyPrice = browser.getValue('(//input[@ng-model="tranche.buy_price"])['+i+']');

        // portfolio_length = browser.elements(tranche_table_elem).value.length
        // var isin_name = browser.getText('('+tranche_table_elem+')['+i+']//td[3]').split('/')[1].trim()
        // cashflow_tranche_list.push(isin_name)
        var isin_name = '';
        var tranche_summary_div = cashflow_xpath.portfolioCfsAllresultwidget;
        var tranche_table_elem = "("+tranche_summary_div+'//table)[1]//tbody';
        var isin_name_xpath = tranche_table_elem + '/tr['+i+']/td[4]';
        isin_name = browser.getText(isin_name_xpath);
         
        for(var listIndex = 0; listIndex < all_tranche_list.length; listIndex ++){
          console.log(listIndex);
          console.log(scenario_id);
          console.log(isin_name);
          console.log(all_tranche_list[listIndex][scenario_id]["Tranche Statistics"][0]["perfsummary"]);
          if(all_tranche_list[listIndex][scenario_id]["Tranche Statistics"][0]["perfsummary"]["tranche_name"] == isin_name){
            all_tranche_list[listIndex][scenario_id]["Tranche Statistics"][0]["result"][0]["Purchase Date (IRR)"]= irr_purchase_date;
            all_tranche_list[listIndex][scenario_id]["Tranche Statistics"][0]["result"][0]["Purchase Price (IRR)"]= buyPrice;
          }
        }
      }

      browser.click(run_button);
      this.browser_session.waitVisible(browser,cashflow_process_bar);
      this.browser_session.waitForLoading(browser,cashflow_process_bar,1000,totalWaitTime);
      this.browser_session.waitVisible(browser,cf_progress_status,this.waitDefault);
      this.browser_session.waitForLoading(browser, cf_progress_status, 1000,totalWaitTime);
      this.browser_session.waitForResource(browser,tranche_summary_table);
      browser.pause(6000);

      var table_html;
      table_html = browser.getHTML(tranche_summary_table);
      var tranche_summary_table_json = this.tabletojson.convert(table_html)[0];
      expect(tranche_summary_table_json).not.toBe(null);
      console.log(tranche_summary_table_json);
      console.log(tranche_summary_table_json.length);

      console.log(all_tranche_list);
      // console.log(all_tranche_list[0])
      // console.log(all_tranche_list[0][scenario_id])
      // console.log(all_tranche_list[0][scenario_id]["Tranche Statistics"])
      console.log(all_tranche_list[0][scenario_id]["Tranche Statistics"][0]["result"]);

      for (var summaryIndex = 0; summaryIndex < tranche_summary_table_json.length; summaryIndex++) {
        var tranche_name = tranche_summary_table_json[summaryIndex]["ISIN"]
        console.log(tranche_name);
        for(var listIndex = 0; listIndex < all_tranche_list.length; listIndex ++){
          console.log(listIndex);
          console.log(scenario_id);
          console.log(all_tranche_list[listIndex][scenario_id]["Tranche Statistics"][0]["perfsummary"]);
          if(all_tranche_list[listIndex][scenario_id]["Tranche Statistics"][0]["perfsummary"]["tranche_name"] == tranche_name){
            console.log(all_tranche_list[listIndex][scenario_id]["Tranche Statistics"][0]["result"]);
            console.log(all_tranche_list[listIndex][scenario_id]["Tranche Statistics"][0]);
            console.log('AAAAA',tranche_summary_table_json[summaryIndex]["IRR"]);
            all_tranche_list[listIndex][scenario_id]["Tranche Statistics"][0]["result"][0]["IRR"] = parseFloat(tranche_summary_table_json[summaryIndex]["IRR"]).toFixed(2);
            var file_name = self.portfolio+'.'+tranche_name + '_' + scenario_id+'_' + yield_id + '_' + irr_id + '_' + settles_date;
            var file_path = path.join(process.env.HOME,'Projects', 'CS-Structured-QA-SFPortal-G2','cashflow_res','portfolio_cashflow_res'); 
            self.file_session.exportCfsResult(file_name, file_path, all_tranche_list[listIndex], 'json');
          }
        }
      }

      // if (process.env.RunDealRequest == 'True' && process.env.NODE_ENV != 'Prod') {
      if (process.env.RunDealRequest == 'True'&& process.env.NODE_ENV == 'Dev') {
         var pricing_request_xpath = '//*[contains(@ng-show,"cash.showPriceRequestDebugOutput")]';
         var toggle_price_req_button = '//span[contains(text(),"Toggle Price Request Debug Output")]';
         if(!browser.isVisible(pricing_request_xpath)){
           try {
             if (browser.isVisible(toggle_price_req_button)) {
               browser.click(toggle_price_req_button);
               browser.waitForVisible(pricing_request_xpath, this.waitDefault);
             } else {
               console.log('click toggle price req output button failed');
             }
           } catch (e) {
             console.log('wait for run deal pricing request information');
             browser.waitForVisible(pricing_request_xpath, this.waitDefault);
           }
         }
         var pricing_json = browser.getText(pricing_request_xpath);
         var request_file_name ='portfolio_' + file_name + '_pricing_request';
      // console.log('pricing_json:',pricing_json);
      file_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res', 'pricing_debug');
      self.file_session.exportCfsResult(request_file_name, file_path, pricing_json, 'json');
      // console.log('run_deal_request:',run_deal_request);
      // 
      //Close pricing button
      browser.click(toggle_price_req_button);
      var price_response_xpath = '//div[contains(@ng-show,"cash.showPriceResponseDebugOutput")]';
      var toggle_price_resp_button = '//span[contains(text(),"Toggle Price Response Debug Output")]';
      console.log('try click')
      try {
        if (browser.isVisible(toggle_price_resp_button)) {
          browser.click(toggle_price_resp_button);
          browser.waitForVisible(price_response_xpath, this.waitDefault);
        } else {
          console.log('click toggle output button failed');
        }
      } catch (e) {
        console.log('wait for run deal price response information');
        browser.waitForVisible(price_response_xpath, this.waitDefault);
      }
      console.log('try get text')
      var irr_json = browser.getText(price_response_xpath);
      var response_file_name = 'portfolio_' + file_name + '_pricing_response';
      // console.log('pricing_json:',pricing_json);
      // var run_deal_request = pricing_json.substring(pricing_json.indexOf("<runDealSettings"), pricing_json.indexOf("</RundealRequest>"));
      // file_path = '../../../cashflow_res' + '/run_deal_request';
      file_path = path.join(process.env.HOME, 'Projects', 'CS-Structured-QA-SFPortal-G2', 'cashflow_res', "pricing_debug");
      // file_path ='C:\\Users\\HuBa\\Projects\\CS-Structured-QA-SFPortal-G2\\CLOCFS\\Deal\\cashflow_res\\run_deal_request\\';
      self.file_session.exportCfsResult(response_file_name, file_path, irr_json, 'json');
      // close button
      browser.click(toggle_price_resp_button);
    }
  });
} 