 //Then_I_save_the_Tranche_Summary_results_in_portfolio_and_convert_them_to_json.js
 module.exports = function(){ 
   this.Then(/^I save the Tranche Summary results in portfolio and convert them to json$/, 
      { timeout: process.env.StepTimeoutInMS * 10 },function (){
         this.browser_session.waitForResource(browser);
         const dateFormat = require('dateformat');
         var fs = require("fs");
         var path = require('path');
         const cashflow_xpath = this.xpath_lib.xpathRequire("cashflow_xpath");
         const content_xpath = this.xpath_lib.xpathRequire("content_xpath");
         var portfolio_output = this.portfolio_output;
         var totalWaitTime = 5 * 30 * 1000;
         var panelName = "Results";
         var self = this;
         var myPanel = content_xpath.titledSectionLowercase.replace("__TITLE__", panelName.toLowerCase());
         var cf_scenario_list = this.scenario_list;
         var cf_scenarios_used = this.scenarios_used;
         var timeOut = 60*1000;
         console.log('this.scenario_used:', cf_scenarios_used);
         var tranche_summary_table = "("+cashflow_xpath.trancheSummaryTable+")[1]";
         var cashflow_process_bar = content_xpath.tableWaitline;
         var cf_progress_status = cashflow_xpath.cashflowProcess;
         var run_button = '//button[text()="Run Cashflows"]';
         var output_element = '//*[@ng-model="cash.output_type"]';

         
            //  defined the write function
            var export_res = function (file_name, file_path, file_content, file_type) {
                var myDate = new Date();
                var month = myDate.getMonth() + 1;
                var day = myDate.getDate();
                var today = '0' + month + day;
                file_name = file_name + '_' + today + '.' + file_type;
                if (file_type == 'json') {
                    var data_json = JSON.stringify(file_content);
                } else {
                    var data_json = file_content;
                }
                //if (fs.existsSync(file_path)) {
                //    console.log(file_path + ' exist!') 
                //} else {
                //    fs.mkdir(file_path, function (err) {
                //        if (err) {
                //            console.log(err);
                //            throw err;
                //        }
                //        console.log('make dir success.');
                //    });
                //}
                self.utility_lib.mkdirsSync(file_path);
                // console.log("--------------------------cash flow---------------------------------",casgflow_json);
                fs.writeFile(file_path + '/' + file_name, data_json, { flag: "w" }, function (err) {
                    if (err) {
                        console.log(file_name + " saved failed!");
                        return console.log(err);
                    } else {
                        console.log(file_name + " saved successfully!");
                    }

                })
            }; 

         
         this.browser_session.waitForResource(browser,tranche_summary_table);
         browser.getLocationInView(tranche_summary_table);
         expect(browser.isExisting(tranche_summary_table));

         browser.pause(5000);

        var table_html;
        table_html = browser.getHTML(tranche_summary_table);
        var tranche_summary_table_json = this.tabletojson.convert(table_html)[0];
        expect(tranche_summary_table_json).not.toBe(null);
        console.log(tranche_summary_table_json);
        console.log(tranche_summary_table_json.length); 
        var all_tranche_result = [];       
        for (var summaryIndex = 0; summaryIndex < tranche_summary_table_json.length; summaryIndex++) {            
            var scenario_id = cf_scenario_list[0]["scenario_id"];
            // var settles_date = cf_scenarios_used[scenario_id][4];
            console.log('self.assettype:',self.assettype)
            if (self.assettype == 'CLO'){
              var settles_date = cf_scenarios_used[scenario_id][4];
            }else{
              var settles_date = cf_scenarios_used[scenario_id][5];
            }            
            var item = {"perfsummary": {},"trancheSummary": {}};
            var tranche_name = tranche_summary_table_json[summaryIndex]["ISIN"]
            item["perfsummary"]["scenario_id"] = scenario_id;
            // item["perfsummary"]["class"] = tranche_summary_table_json[summaryIndex]["Class"];
            item["perfsummary"]["settles_date"] = settles_date;
            item["perfsummary"]["output_type"] = portfolio_output;
            item["trancheSummary"]=tranche_summary_table_json[summaryIndex];  
            for(var static_key in tranche_summary_table_json[summaryIndex]){
              console.log("static_key:"+static_key);
              if(static_key=='First Loss' && this.assettype == 'CLO'){
                var tmp = tranche_summary_table_json[summaryIndex]['First Loss'].replace(' (CDR)','');
                tranche_summary_table_json[summaryIndex]['First Loss'] = tmp;
              }
              if(static_key.indexOf('Principal Payment')>-1 && tranche_summary_table_json[summaryIndex][static_key].indexOf('/')>-1 && tranche_summary_table_json[summaryIndex][static_key].indexOf('N/A')<=-1){
                console.log("change the date format for Principal Payment");
                var tmp = tranche_summary_table_json[summaryIndex][static_key].split("/");
                if (tmp[0].length == 1){
                  tranche_summary_table_json[summaryIndex][static_key] = tmp[1] + "-0" + tmp[0]; 
                }
                else{
                  tranche_summary_table_json[summaryIndex][static_key] = tmp[1] + "-" + tmp[0];
                }
                console.log('tranche_summary_table_json[summaryIndex][static_key] ddd:',tranche_summary_table_json[summaryIndex][static_key]);
              }
              if(static_key == 'Pricing Spread' && process.env.NODE_ENV == 'Dev' && this.assettype == 'CLO'){
                console.log("-------------------calculate spread----------------------");
                var row = tranche_summary_table + "/tbody/tr";
                var curr = browser.getText(row + '['+(summaryIndex+1)+']/td[5]');
                var deal_name = browser.getText(row + '['+(summaryIndex+1)+']/td[1]');
                var avg_life = browser.getText(row + '['+(summaryIndex+1)+']/td[9]');
                console.log(curr);
                console.log(deal_name);
                console.log(this.benchmark);
                var yield_v = this.yield_values_in_portfolio[deal_name];
                console.log(yield_v);
                if (yield_v == 'N/A'){
                    tranche_summary_table_json[summaryIndex]['Pricing Spread'] = '';
                }else{
                  if(this.benchmark.indexOf('Tsy')>-1){
                    console.log("--------------------"+this.benchmark);
                    var len = this.getIndexRates_index[0]['index_rate'].length;
                    console.log(len);
                    console.log(Number(yield_v));
                    for (var j = 0; j<len; j++){
                      if (this.getIndexRates_index[0]['index_rate'][j]["$"]["index"] == this.benchmark){
                        console.log(this.getIndexRates_index[0]['index_rate'][j]["_"]);
                        tranche_summary_table_json[summaryIndex]['Pricing Spread'] = (Number(yield_v)-Number(this.getIndexRates_index[0]['index_rate'][j]["_"])).toString();
                        break;
                      }
                    }
                  }
                  else{
                    var len1 = this.getIndexRates_swap.length;
                    var avg_life_int = parseInt(avg_life);
                    if(avg_life_int<2){
                      var swap_1 = "Swap 2Y";
                      var swap_2 = "Swap 3Y";
                      var swap_1_n = 2;
                      var swap_2_n = 3;
                    }else if(avg_life_int>30){
                      var swap_1 = "Swap 20Y";
                      var swap_2 = "Swap 30Y";
                      var swap_1_n = 20;
                      var swap_2_n = 30;
                    }else if(10>=avg_life_int>=15){
                      var swap_1 = "Swap 10Y";
                      var swap_2 = "Swap 15Y";
                      var swap_1_n = 10;
                      var swap_2_n = 15;
                    }else if(15>avg_life_int>=20){
                      var swap_1 = "Swap 15Y";
                      var swap_2 = "Swap 20Y";
                      var swap_1_n = 15;
                      var swap_2_n = 20;
                    }else if(20>avg_life_int>=30){
                      var swap_1 = "Swap 20Y";
                      var swap_2 = "Swap 30Y";
                      var swap_1_n = 20;
                      var swap_2_n = 30;
                    }else{
                      var swap_1 = "Swap "+avg_life_int+"Y";
                      var swap_2 = "Swap "+(avg_life_int+1)+"Y";
                      var swap_1_n = avg_life_int;
                      var swap_2_n = avg_life_int+1;
                    }
                    console.log("swap_1"+swap_1);
                    console.log("swap_2"+swap_2);
                    for (var k =0; k<len1; k++){
                      if (this.getIndexRates_swap[k]["$"]["fx"] == curr){
                        var len2 = this.getIndexRates_swap[k]["index_rate"].length;
                        for (var m =0; m<len2; m++){
                          if(this.getIndexRates_swap[k]["index_rate"][m]["$"]["index"]==swap_1){
                            var swap_1_value = this.getIndexRates_swap[k]["index_rate"][m]["_"];
                          }
                          if(this.getIndexRates_swap[k]["index_rate"][m]["$"]["index"]==swap_2){
                            var swap_2_value = this.getIndexRates_swap[k]["index_rate"][m]["_"];
                            break;
                          }
                        }
                        break;
                      }
                    }
                    if(swap_1_value.indexOf('.')==0){
                      swap_1_value = '0'+swap_1_value;
                    }
                    if(swap_1_value.indexOf('-.')==0){
                      swap_1_value = '-0.'+swap_1_value.split('.')[1];
                    }
                    if(swap_2_value.indexOf('.')==0){
                      swap_2_value = '0'+swap_2_value;
                    }
                    if(swap_2_value.indexOf('-.')==0){
                      swap_2_value = '-0.'+swap_2_value.split('.')[1];
                    }
                    console.log("swap_1_value"+Number(swap_1_value));
                    console.log("swap_2_value"+Number(swap_2_value));
                    var kk = (Number(swap_1_value)-Number(swap_2_value))/(swap_1_n-swap_2_n);
                    var bb = (swap_2_n*Number(swap_1_value)-swap_1_n*Number(swap_2_value))/(swap_2_n-swap_1_n);
                    var swap_3_value = Number(avg_life)*kk+bb;
                    tranche_summary_table_json[summaryIndex]['Pricing Spread'] = (Number(yield_v) - swap_3_value).toFixed(4).toString();
                    console.log("spread: "+tranche_summary_table_json[summaryIndex]['Pricing Spread']);
                  }
                }
              }
            }          
            all_tranche_result.push(item);             
          }
          console.log("before sort",all_tranche_result);
          function sortName(a,b){
            return a.trancheSummary.Deal.charCodeAt(0) - b.trancheSummary.Deal.charCodeAt(0);
          }
          all_tranche_result.sort(sortName);
          console.log("after sort",all_tranche_result);
           console.log("length",all_tranche_result.length);

          for(var i=0;i<all_tranche_result.length;i++){ 
            var one_tranche_list = {} 
            one_tranche_list = all_tranche_result[i]
            console.log(one_tranche_list);
            if(self.isCurrentdate){
              settles_date='Current Date';
            }
            var file_name = scenario_id + self.economyNum + this.selectedAssetClass +'portfolio' 
            + portfolio_output.replace(' / ','')+ self.portfolio_fistloss_type+self.isCustom + 'TrancheSummary'+ '_'+self.portfolio+'.'+one_tranche_list["trancheSummary"]['ISIN']+'_'+settles_date
           var file_path = path.join(process.env.HOME,'Projects', 'CS-Structured-QA-SFPortal-G2','cashflow_res','deal_cashflow_res'); 
           export_res(file_name, file_path, one_tranche_list, 'json');
          }


          // var file_name = this.portfolio.replace(/\ /g,'_') + '_' + scenario_id+ '_' + this.selectedAssetClass +'_portfolio_' + portfolio_output.replace(' / ','_') + '_mode_trancheSummary_table_' + settles_date;
          // var file_path = path.join(process.env.HOME,'Projects', 'CS-Structured-QA-SFPortal-G2','cashflow_res','deal_cashflow_res'); 
          // self.file_session.exportCfsResult(file_name, file_path, all_tranche_result, 'json');
   });
} 